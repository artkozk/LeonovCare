--
-- PostgreSQL database cluster dump
--

\restrict lqCiyky6KN0jD4XWw00gLWZsDbafzqJpOBtoJVYQasJdaxOzxhCUxSViaw8xNbn

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE habitbot;
ALTER ROLE habitbot WITH NOSUPERUSER INHERIT NOCREATEROLE NOCREATEDB LOGIN NOREPLICATION NOBYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:l3JliebXXM5pkUM9HEbj4Q==$gvorPhEybCIOH3PTmRYT7BVrfX/PPM07OPoNl70+l/k=:+0DlH8qVd7WFX2bXcnt2VHSlbhmothv3hjB/r5df1kI=';
CREATE ROLE postgres;
ALTER ROLE postgres WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS;

--
-- User Configurations
--








\unrestrict lqCiyky6KN0jD4XWw00gLWZsDbafzqJpOBtoJVYQasJdaxOzxhCUxSViaw8xNbn

--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

\restrict tLiERj4JwD0846KqNXAwVPGTR8QSp5PEozsCUEM46IxgWv5RfCCVLx4h4uXz5Ju

-- Dumped from database version 16.13 (Ubuntu 16.13-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.13 (Ubuntu 16.13-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict tLiERj4JwD0846KqNXAwVPGTR8QSp5PEozsCUEM46IxgWv5RfCCVLx4h4uXz5Ju

--
-- Database "develop_a_habit" dump
--

--
-- PostgreSQL database dump
--

\restrict 02IDh8d0BGaenhPBgKToV4qldu8OhVyJAdRcfXiKo0TIbt6Cof34yQjco0A2uWy

-- Dumped from database version 16.13 (Ubuntu 16.13-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.13 (Ubuntu 16.13-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: develop_a_habit; Type: DATABASE; Schema: -; Owner: habitbot
--

CREATE DATABASE develop_a_habit WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C.UTF-8';


ALTER DATABASE develop_a_habit OWNER TO habitbot;

\unrestrict 02IDh8d0BGaenhPBgKToV4qldu8OhVyJAdRcfXiKo0TIbt6Cof34yQjco0A2uWy
\connect develop_a_habit
\restrict 02IDh8d0BGaenhPBgKToV4qldu8OhVyJAdRcfXiKo0TIbt6Cof34yQjco0A2uWy

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: checkin_status; Type: TYPE; Schema: public; Owner: habitbot
--

CREATE TYPE public.checkin_status AS ENUM (
    'done',
    'missed',
    'violated',
    'optional_done'
);


ALTER TYPE public.checkin_status OWNER TO habitbot;

--
-- Name: diary_entry_type; Type: TYPE; Schema: public; Owner: habitbot
--

CREATE TYPE public.diary_entry_type AS ENUM (
    'text',
    'voice',
    'mixed'
);


ALTER TYPE public.diary_entry_type OWNER TO habitbot;

--
-- Name: habit_type; Type: TYPE; Schema: public; Owner: habitbot
--

CREATE TYPE public.habit_type AS ENUM (
    'positive',
    'negative'
);


ALTER TYPE public.habit_type OWNER TO habitbot;

--
-- Name: schedule_type; Type: TYPE; Schema: public; Owner: habitbot
--

CREATE TYPE public.schedule_type AS ENUM (
    'daily',
    'every_other_day',
    'specific_weekdays'
);


ALTER TYPE public.schedule_type OWNER TO habitbot;

--
-- Name: time_slot; Type: TYPE; Schema: public; Owner: habitbot
--

CREATE TYPE public.time_slot AS ENUM (
    'morning',
    'day',
    'evening',
    'all_day'
);


ALTER TYPE public.time_slot OWNER TO habitbot;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: habitbot
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO habitbot;

--
-- Name: day_off_rules; Type: TABLE; Schema: public; Owner: habitbot
--

CREATE TABLE public.day_off_rules (
    id integer NOT NULL,
    user_id integer NOT NULL,
    weekday integer,
    exact_date date
);


ALTER TABLE public.day_off_rules OWNER TO habitbot;

--
-- Name: day_off_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: habitbot
--

CREATE SEQUENCE public.day_off_rules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.day_off_rules_id_seq OWNER TO habitbot;

--
-- Name: day_off_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: habitbot
--

ALTER SEQUENCE public.day_off_rules_id_seq OWNED BY public.day_off_rules.id;


--
-- Name: diary_entries; Type: TABLE; Schema: public; Owner: habitbot
--

CREATE TABLE public.diary_entries (
    id integer NOT NULL,
    user_id integer NOT NULL,
    entry_date date NOT NULL,
    entry_type public.diary_entry_type NOT NULL,
    text_body text,
    tags character varying(256),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.diary_entries OWNER TO habitbot;

--
-- Name: diary_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: habitbot
--

CREATE SEQUENCE public.diary_entries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.diary_entries_id_seq OWNER TO habitbot;

--
-- Name: diary_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: habitbot
--

ALTER SEQUENCE public.diary_entries_id_seq OWNED BY public.diary_entries.id;


--
-- Name: diary_transcripts; Type: TABLE; Schema: public; Owner: habitbot
--

CREATE TABLE public.diary_transcripts (
    id integer NOT NULL,
    entry_id integer NOT NULL,
    transcript_text text,
    language character varying(32),
    confidence integer,
    stt_status character varying(16) DEFAULT 'pending'::character varying NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    last_error text,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.diary_transcripts OWNER TO habitbot;

--
-- Name: diary_transcripts_id_seq; Type: SEQUENCE; Schema: public; Owner: habitbot
--

CREATE SEQUENCE public.diary_transcripts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.diary_transcripts_id_seq OWNER TO habitbot;

--
-- Name: diary_transcripts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: habitbot
--

ALTER SEQUENCE public.diary_transcripts_id_seq OWNED BY public.diary_transcripts.id;


--
-- Name: diary_voice; Type: TABLE; Schema: public; Owner: habitbot
--

CREATE TABLE public.diary_voice (
    id integer NOT NULL,
    entry_id integer NOT NULL,
    telegram_file_id character varying(256) NOT NULL,
    telegram_file_unique_id character varying(256) NOT NULL,
    duration_sec integer,
    mime character varying(128),
    message_id integer
);


ALTER TABLE public.diary_voice OWNER TO habitbot;

--
-- Name: diary_voice_id_seq; Type: SEQUENCE; Schema: public; Owner: habitbot
--

CREATE SEQUENCE public.diary_voice_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.diary_voice_id_seq OWNER TO habitbot;

--
-- Name: diary_voice_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: habitbot
--

ALTER SEQUENCE public.diary_voice_id_seq OWNED BY public.diary_voice.id;


--
-- Name: habit_checkins; Type: TABLE; Schema: public; Owner: habitbot
--

CREATE TABLE public.habit_checkins (
    id integer NOT NULL,
    habit_id integer NOT NULL,
    check_date date NOT NULL,
    time_slot public.time_slot NOT NULL,
    status public.checkin_status NOT NULL,
    note text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    actual_sets integer,
    actual_reps_csv character varying(256),
    target_sets integer,
    target_reps integer,
    sport_plan_adhered boolean
);


ALTER TABLE public.habit_checkins OWNER TO habitbot;

--
-- Name: habit_checkins_id_seq; Type: SEQUENCE; Schema: public; Owner: habitbot
--

CREATE SEQUENCE public.habit_checkins_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.habit_checkins_id_seq OWNER TO habitbot;

--
-- Name: habit_checkins_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: habitbot
--

ALTER SEQUENCE public.habit_checkins_id_seq OWNED BY public.habit_checkins.id;


--
-- Name: habit_schedule_rules; Type: TABLE; Schema: public; Owner: habitbot
--

CREATE TABLE public.habit_schedule_rules (
    id integer NOT NULL,
    habit_id integer NOT NULL,
    schedule_type public.schedule_type NOT NULL,
    time_slot public.time_slot NOT NULL,
    weekday integer,
    interval_days integer DEFAULT 1 NOT NULL,
    start_from date
);


ALTER TABLE public.habit_schedule_rules OWNER TO habitbot;

--
-- Name: habit_schedule_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: habitbot
--

CREATE SEQUENCE public.habit_schedule_rules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.habit_schedule_rules_id_seq OWNER TO habitbot;

--
-- Name: habit_schedule_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: habitbot
--

ALTER SEQUENCE public.habit_schedule_rules_id_seq OWNED BY public.habit_schedule_rules.id;


--
-- Name: habits; Type: TABLE; Schema: public; Owner: habitbot
--

CREATE TABLE public.habits (
    id integer NOT NULL,
    user_id integer NOT NULL,
    name character varying(256) NOT NULL,
    habit_type public.habit_type NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    icon_emoji character varying(16),
    is_sport boolean DEFAULT false NOT NULL,
    sport_base_sets integer,
    sport_base_reps integer,
    sport_linear_step_reps integer,
    sport_start_date date,
    sport_progression_enabled boolean DEFAULT true NOT NULL,
    goal_days integer DEFAULT 30,
    goal_start_date date,
    goal_completed_cycles integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.habits OWNER TO habitbot;

--
-- Name: habits_id_seq; Type: SEQUENCE; Schema: public; Owner: habitbot
--

CREATE SEQUENCE public.habits_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.habits_id_seq OWNER TO habitbot;

--
-- Name: habits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: habitbot
--

ALTER SEQUENCE public.habits_id_seq OWNED BY public.habits.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: habitbot
--

CREATE TABLE public.users (
    id integer NOT NULL,
    telegram_user_id bigint NOT NULL,
    timezone character varying(128) DEFAULT 'Europe/Moscow'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.users OWNER TO habitbot;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: habitbot
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO habitbot;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: habitbot
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: weekly_prompts; Type: TABLE; Schema: public; Owner: habitbot
--

CREATE TABLE public.weekly_prompts (
    id integer NOT NULL,
    user_id integer NOT NULL,
    week_start date NOT NULL,
    sent_at timestamp with time zone DEFAULT now() NOT NULL,
    comment_saved boolean DEFAULT false NOT NULL
);


ALTER TABLE public.weekly_prompts OWNER TO habitbot;

--
-- Name: weekly_prompts_id_seq; Type: SEQUENCE; Schema: public; Owner: habitbot
--

CREATE SEQUENCE public.weekly_prompts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.weekly_prompts_id_seq OWNER TO habitbot;

--
-- Name: weekly_prompts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: habitbot
--

ALTER SEQUENCE public.weekly_prompts_id_seq OWNED BY public.weekly_prompts.id;


--
-- Name: day_off_rules id; Type: DEFAULT; Schema: public; Owner: habitbot
--

ALTER TABLE ONLY public.day_off_rules ALTER COLUMN id SET DEFAULT nextval('public.day_off_rules_id_seq'::regclass);


--
-- Name: diary_entries id; Type: DEFAULT; Schema: public; Owner: habitbot
--

ALTER TABLE ONLY public.diary_entries ALTER COLUMN id SET DEFAULT nextval('public.diary_entries_id_seq'::regclass);


--
-- Name: diary_transcripts id; Type: DEFAULT; Schema: public; Owner: habitbot
--

ALTER TABLE ONLY public.diary_transcripts ALTER COLUMN id SET DEFAULT nextval('public.diary_transcripts_id_seq'::regclass);


--
-- Name: diary_voice id; Type: DEFAULT; Schema: public; Owner: habitbot
--

ALTER TABLE ONLY public.diary_voice ALTER COLUMN id SET DEFAULT nextval('public.diary_voice_id_seq'::regclass);


--
-- Name: habit_checkins id; Type: DEFAULT; Schema: public; Owner: habitbot
--

ALTER TABLE ONLY public.habit_checkins ALTER COLUMN id SET DEFAULT nextval('public.habit_checkins_id_seq'::regclass);


--
-- Name: habit_schedule_rules id; Type: DEFAULT; Schema: public; Owner: habitbot
--

ALTER TABLE ONLY public.habit_schedule_rules ALTER COLUMN id SET DEFAULT nextval('public.habit_schedule_rules_id_seq'::regclass);


--
-- Name: habits id; Type: DEFAULT; Schema: public; Owner: habitbot
--

ALTER TABLE ONLY public.habits ALTER COLUMN id SET DEFAULT nextval('public.habits_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: habitbot
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: weekly_prompts id; Type: DEFAULT; Schema: public; Owner: habitbot
--

ALTER TABLE ONLY public.weekly_prompts ALTER COLUMN id SET DEFAULT nextval('public.weekly_prompts_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: habitbot
--

COPY public.alembic_version (version_num) FROM stdin;
0011_habit_goal_default_30
\.


--
-- Data for Name: day_off_rules; Type: TABLE DATA; Schema: public; Owner: habitbot
--

COPY public.day_off_rules (id, user_id, weekday, exact_date) FROM stdin;
\.


--
-- Data for Name: diary_entries; Type: TABLE DATA; Schema: public; Owner: habitbot
--

COPY public.diary_entries (id, user_id, entry_date, entry_type, text_body, tags, created_at) FROM stdin;
1	1	2026-04-11	text	Я сегодня проснулся в 6:30 утра, сделал зарядку и сел за работу. Сегодня я схожу на допы по математике, а ещё в баню. Сегодня первый день, когда я прочитал Эвелине глву из книги Гэри Чепмена "пять языков любви"	\N	2026-04-11 06:59:47.32348+00
2	1	2026-04-11	voice	\N	\N	2026-04-11 07:00:10.714391+00
\.


--
-- Data for Name: diary_transcripts; Type: TABLE DATA; Schema: public; Owner: habitbot
--

COPY public.diary_transcripts (id, entry_id, transcript_text, language, confidence, stt_status, attempts, last_error, updated_at) FROM stdin;
1	2	[mock transcription for tmpmtdmfiqb.ogg]	ru	\N	done	1	\N	2026-04-11 07:00:12.408257+00
\.


--
-- Data for Name: diary_voice; Type: TABLE DATA; Schema: public; Owner: habitbot
--

COPY public.diary_voice (id, entry_id, telegram_file_id, telegram_file_unique_id, duration_sec, mime, message_id) FROM stdin;
1	2	AwACAgIAAxkBAAMcadnxem91qqsnfJhlN1Mx5r0HPNoAAkCPAAIylNBK5wkr7O7tM_s7BA	AgADQI8AAjKU0Eo	646	audio/ogg	28
\.


--
-- Data for Name: habit_checkins; Type: TABLE DATA; Schema: public; Owner: habitbot
--

COPY public.habit_checkins (id, habit_id, check_date, time_slot, status, note, created_at, actual_sets, actual_reps_csv, target_sets, target_reps, sport_plan_adhered) FROM stdin;
25	9	2026-04-11	morning	done	\N	2026-04-11 18:24:39.639931+00	\N	\N	\N	\N	\N
27	11	2026-04-11	all_day	done	\N	2026-04-11 18:38:54.448438+00	\N	\N	2	12	t
28	10	2026-04-11	morning	done	\N	2026-04-11 18:39:02.508562+00	\N	\N	\N	\N	\N
29	14	2026-04-11	morning	done	\N	2026-04-11 18:39:07.738497+00	\N	\N	\N	\N	\N
30	16	2026-04-11	morning	done	\N	2026-04-11 19:03:19.548563+00	\N	\N	\N	\N	\N
34	12	2026-04-11	evening	done	\N	2026-04-11 19:57:00.365141+00	\N	\N	\N	\N	\N
35	9	2026-04-12	morning	done	\N	2026-04-12 03:38:39.361494+00	\N	\N	\N	\N	\N
36	10	2026-04-12	morning	done	\N	2026-04-12 03:38:39.979083+00	\N	\N	\N	\N	\N
37	11	2026-04-12	all_day	done	\N	2026-04-12 03:38:47.925649+00	\N	\N	2	12	t
38	16	2026-04-12	morning	done	\N	2026-04-12 03:42:33.067875+00	\N	\N	\N	\N	\N
39	10	2026-04-11	evening	done	\N	2026-04-12 15:49:58.224484+00	\N	\N	\N	\N	\N
40	14	2026-04-11	evening	done	\N	2026-04-12 15:49:58.228593+00	\N	\N	\N	\N	\N
41	14	2026-04-12	morning	done	\N	2026-04-12 15:49:58.229724+00	\N	\N	\N	\N	\N
42	16	2026-04-11	evening	done	\N	2026-04-12 15:49:58.232034+00	\N	\N	\N	\N	\N
43	10	2026-04-12	evening	done	\N	2026-04-12 19:52:04.300889+00	\N	\N	\N	\N	\N
44	14	2026-04-12	evening	done	\N	2026-04-12 19:52:05.40616+00	\N	\N	\N	\N	\N
45	16	2026-04-12	evening	done	\N	2026-04-12 19:52:06.111718+00	\N	\N	\N	\N	\N
46	12	2026-04-12	evening	done	\N	2026-04-12 19:52:06.868608+00	\N	\N	\N	\N	\N
47	9	2026-04-13	morning	done	\N	2026-04-13 04:14:04.236754+00	\N	\N	\N	\N	\N
48	10	2026-04-13	morning	done	\N	2026-04-13 04:14:05.050305+00	\N	\N	\N	\N	\N
49	14	2026-04-13	morning	done	\N	2026-04-13 04:14:07.135507+00	\N	\N	\N	\N	\N
50	16	2026-04-13	morning	done	\N	2026-04-13 04:14:07.926706+00	\N	\N	\N	\N	\N
51	11	2026-04-13	all_day	done	\N	2026-04-13 04:14:13.678802+00	\N	\N	2	12	t
52	10	2026-04-13	evening	done	\N	2026-04-13 19:45:25.265702+00	\N	\N	\N	\N	\N
53	14	2026-04-13	evening	done	\N	2026-04-13 19:45:26.167998+00	\N	\N	\N	\N	\N
54	12	2026-04-13	evening	done	\N	2026-04-13 19:45:26.730679+00	\N	\N	\N	\N	\N
55	8	2026-04-13	all_day	violated	\N	2026-04-13 19:45:28.602261+00	\N	\N	\N	\N	\N
56	16	2026-04-13	evening	done	\N	2026-04-13 19:55:11.480119+00	\N	\N	\N	\N	\N
57	9	2026-04-14	morning	done	\N	2026-04-14 03:13:50.665397+00	\N	\N	\N	\N	\N
58	10	2026-04-14	morning	done	\N	2026-04-14 03:13:51.100971+00	\N	\N	\N	\N	\N
59	14	2026-04-14	evening	done	\N	2026-04-14 19:57:06.39712+00	\N	\N	\N	\N	\N
60	16	2026-04-14	evening	done	\N	2026-04-14 19:57:07.454125+00	\N	\N	\N	\N	\N
61	12	2026-04-14	evening	done	\N	2026-04-14 19:57:08.395638+00	\N	\N	\N	\N	\N
62	10	2026-04-14	evening	done	\N	2026-04-14 19:57:09.112399+00	\N	\N	\N	\N	\N
63	8	2026-04-14	all_day	violated	\N	2026-04-14 19:57:09.675867+00	\N	\N	\N	\N	\N
68	8	2026-04-16	all_day	violated	\N	2026-04-16 08:57:29.886848+00	\N	\N	\N	\N	\N
69	16	2026-04-16	morning	done	\N	2026-04-16 08:57:36.885247+00	\N	\N	\N	\N	\N
70	14	2026-04-16	morning	done	\N	2026-04-16 08:57:38.501175+00	\N	\N	\N	\N	\N
\.


--
-- Data for Name: habit_schedule_rules; Type: TABLE DATA; Schema: public; Owner: habitbot
--

COPY public.habit_schedule_rules (id, habit_id, schedule_type, time_slot, weekday, interval_days, start_from) FROM stdin;
3	3	daily	all_day	\N	1	\N
4	4	daily	morning	\N	1	\N
5	5	daily	day	\N	1	\N
6	6	specific_weekdays	all_day	5	1	\N
8	8	daily	all_day	\N	1	\N
9	9	daily	morning	\N	1	\N
10	10	daily	morning	\N	1	\N
11	11	daily	all_day	\N	1	\N
12	12	daily	evening	\N	1	\N
14	14	daily	morning	\N	1	\N
16	16	daily	morning	\N	1	\N
18	10	daily	evening	\N	1	\N
19	14	daily	evening	\N	1	\N
20	16	daily	evening	\N	1	\N
\.


--
-- Data for Name: habits; Type: TABLE DATA; Schema: public; Owner: habitbot
--

COPY public.habits (id, user_id, name, habit_type, is_active, created_at, icon_emoji, is_sport, sport_base_sets, sport_base_reps, sport_linear_step_reps, sport_start_date, sport_progression_enabled, goal_days, goal_start_date, goal_completed_cycles) FROM stdin;
9	1	Подъём 6:00	positive	t	2026-04-11 18:22:04.415086+00	📊	f	\N	\N	\N	\N	f	30	2026-04-11	0
3	2	Побрюканить	negative	t	2026-04-11 12:20:14.149341+00	\N	f	\N	\N	\N	\N	f	30	2026-04-11	0
4	2	Подъём 6:30 утра	positive	t	2026-04-11 12:20:58.61892+00	\N	f	\N	\N	\N	\N	f	30	2026-04-11	0
5	2	4	positive	t	2026-04-11 12:53:03.764977+00	\N	f	\N	\N	\N	\N	f	30	2026-04-11	0
6	2	-	positive	t	2026-04-11 12:55:14.860018+00	\N	f	\N	\N	\N	\N	f	30	2026-04-11	0
10	1	Зарядка	positive	t	2026-04-11 18:23:25.749492+00	🕺	f	\N	\N	\N	\N	f	30	2026-04-11	0
11	1	Отжимания\\подтягивания	positive	t	2026-04-11 18:25:35.415687+00	🔋	t	2	12	1	2026-04-11	t	30	2026-04-11	0
12	1	Отбой в 23:00	positive	t	2026-04-11 18:26:04.975464+00	💤	f	\N	\N	\N	\N	f	30	2026-04-11	0
14	1	Чистить зубы	positive	t	2026-04-11 18:38:31.940323+00	\N	f	\N	\N	\N	\N	f	30	2026-04-11	0
16	1	Библия	positive	t	2026-04-11 19:02:54.514811+00	\N	f	\N	\N	\N	\N	f	30	2026-04-11	0
8	1	Побрюканить	negative	t	2026-04-11 18:20:49.313878+00	🙈	f	\N	\N	\N	\N	f	30	2026-04-11	0
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: habitbot
--

COPY public.users (id, telegram_user_id, timezone, created_at) FROM stdin;
1	6553771455	Europe/Moscow	2026-04-11 06:31:57.694181+00
2	8228250460	Europe/Moscow	2026-04-11 07:02:59.160747+00
\.


--
-- Data for Name: weekly_prompts; Type: TABLE DATA; Schema: public; Owner: habitbot
--

COPY public.weekly_prompts (id, user_id, week_start, sent_at, comment_saved) FROM stdin;
1	1	2026-04-06	2026-04-12 14:30:17.424219+00	f
2	1	2026-04-13	2026-04-19 14:30:08.293937+00	f
\.


--
-- Name: day_off_rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: habitbot
--

SELECT pg_catalog.setval('public.day_off_rules_id_seq', 1, false);


--
-- Name: diary_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: habitbot
--

SELECT pg_catalog.setval('public.diary_entries_id_seq', 2, true);


--
-- Name: diary_transcripts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: habitbot
--

SELECT pg_catalog.setval('public.diary_transcripts_id_seq', 1, true);


--
-- Name: diary_voice_id_seq; Type: SEQUENCE SET; Schema: public; Owner: habitbot
--

SELECT pg_catalog.setval('public.diary_voice_id_seq', 1, true);


--
-- Name: habit_checkins_id_seq; Type: SEQUENCE SET; Schema: public; Owner: habitbot
--

SELECT pg_catalog.setval('public.habit_checkins_id_seq', 70, true);


--
-- Name: habit_schedule_rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: habitbot
--

SELECT pg_catalog.setval('public.habit_schedule_rules_id_seq', 20, true);


--
-- Name: habits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: habitbot
--

SELECT pg_catalog.setval('public.habits_id_seq', 17, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: habitbot
--

SELECT pg_catalog.setval('public.users_id_seq', 2, true);


--
-- Name: weekly_prompts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: habitbot
--

SELECT pg_catalog.setval('public.weekly_prompts_id_seq', 2, true);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: habitbot
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: day_off_rules day_off_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: habitbot
--

ALTER TABLE ONLY public.day_off_rules
    ADD CONSTRAINT day_off_rules_pkey PRIMARY KEY (id);


--
-- Name: diary_entries diary_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: habitbot
--

ALTER TABLE ONLY public.diary_entries
    ADD CONSTRAINT diary_entries_pkey PRIMARY KEY (id);


--
-- Name: diary_transcripts diary_transcripts_pkey; Type: CONSTRAINT; Schema: public; Owner: habitbot
--

ALTER TABLE ONLY public.diary_transcripts
    ADD CONSTRAINT diary_transcripts_pkey PRIMARY KEY (id);


--
-- Name: diary_voice diary_voice_pkey; Type: CONSTRAINT; Schema: public; Owner: habitbot
--

ALTER TABLE ONLY public.diary_voice
    ADD CONSTRAINT diary_voice_pkey PRIMARY KEY (id);


--
-- Name: habit_checkins habit_checkins_pkey; Type: CONSTRAINT; Schema: public; Owner: habitbot
--

ALTER TABLE ONLY public.habit_checkins
    ADD CONSTRAINT habit_checkins_pkey PRIMARY KEY (id);


--
-- Name: habit_schedule_rules habit_schedule_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: habitbot
--

ALTER TABLE ONLY public.habit_schedule_rules
    ADD CONSTRAINT habit_schedule_rules_pkey PRIMARY KEY (id);


--
-- Name: habits habits_pkey; Type: CONSTRAINT; Schema: public; Owner: habitbot
--

ALTER TABLE ONLY public.habits
    ADD CONSTRAINT habits_pkey PRIMARY KEY (id);


--
-- Name: diary_transcripts uq_diary_transcripts_entry_id; Type: CONSTRAINT; Schema: public; Owner: habitbot
--

ALTER TABLE ONLY public.diary_transcripts
    ADD CONSTRAINT uq_diary_transcripts_entry_id UNIQUE (entry_id);


--
-- Name: diary_voice uq_diary_voice_entry_id; Type: CONSTRAINT; Schema: public; Owner: habitbot
--

ALTER TABLE ONLY public.diary_voice
    ADD CONSTRAINT uq_diary_voice_entry_id UNIQUE (entry_id);


--
-- Name: habit_checkins uq_habit_checkin_slot; Type: CONSTRAINT; Schema: public; Owner: habitbot
--

ALTER TABLE ONLY public.habit_checkins
    ADD CONSTRAINT uq_habit_checkin_slot UNIQUE (habit_id, check_date, time_slot);


--
-- Name: weekly_prompts uq_weekly_prompt_user_week; Type: CONSTRAINT; Schema: public; Owner: habitbot
--

ALTER TABLE ONLY public.weekly_prompts
    ADD CONSTRAINT uq_weekly_prompt_user_week UNIQUE (user_id, week_start);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: habitbot
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: weekly_prompts weekly_prompts_pkey; Type: CONSTRAINT; Schema: public; Owner: habitbot
--

ALTER TABLE ONLY public.weekly_prompts
    ADD CONSTRAINT weekly_prompts_pkey PRIMARY KEY (id);


--
-- Name: ix_day_off_rules_user_id; Type: INDEX; Schema: public; Owner: habitbot
--

CREATE INDEX ix_day_off_rules_user_id ON public.day_off_rules USING btree (user_id);


--
-- Name: ix_diary_entries_entry_date; Type: INDEX; Schema: public; Owner: habitbot
--

CREATE INDEX ix_diary_entries_entry_date ON public.diary_entries USING btree (entry_date);


--
-- Name: ix_diary_entries_text_fts; Type: INDEX; Schema: public; Owner: habitbot
--

CREATE INDEX ix_diary_entries_text_fts ON public.diary_entries USING gin (to_tsvector('russian'::regconfig, COALESCE(text_body, ''::text)));


--
-- Name: ix_diary_entries_text_trgm; Type: INDEX; Schema: public; Owner: habitbot
--

CREATE INDEX ix_diary_entries_text_trgm ON public.diary_entries USING gin (text_body public.gin_trgm_ops);


--
-- Name: ix_diary_entries_user_id; Type: INDEX; Schema: public; Owner: habitbot
--

CREATE INDEX ix_diary_entries_user_id ON public.diary_entries USING btree (user_id);


--
-- Name: ix_diary_transcripts_entry_id; Type: INDEX; Schema: public; Owner: habitbot
--

CREATE UNIQUE INDEX ix_diary_transcripts_entry_id ON public.diary_transcripts USING btree (entry_id);


--
-- Name: ix_diary_transcripts_stt_status; Type: INDEX; Schema: public; Owner: habitbot
--

CREATE INDEX ix_diary_transcripts_stt_status ON public.diary_transcripts USING btree (stt_status);


--
-- Name: ix_diary_transcripts_text_fts; Type: INDEX; Schema: public; Owner: habitbot
--

CREATE INDEX ix_diary_transcripts_text_fts ON public.diary_transcripts USING gin (to_tsvector('russian'::regconfig, COALESCE(transcript_text, ''::text)));


--
-- Name: ix_diary_transcripts_text_trgm; Type: INDEX; Schema: public; Owner: habitbot
--

CREATE INDEX ix_diary_transcripts_text_trgm ON public.diary_transcripts USING gin (transcript_text public.gin_trgm_ops);


--
-- Name: ix_diary_voice_entry_id; Type: INDEX; Schema: public; Owner: habitbot
--

CREATE UNIQUE INDEX ix_diary_voice_entry_id ON public.diary_voice USING btree (entry_id);


--
-- Name: ix_diary_voice_telegram_file_id; Type: INDEX; Schema: public; Owner: habitbot
--

CREATE INDEX ix_diary_voice_telegram_file_id ON public.diary_voice USING btree (telegram_file_id);


--
-- Name: ix_diary_voice_telegram_file_unique_id; Type: INDEX; Schema: public; Owner: habitbot
--

CREATE INDEX ix_diary_voice_telegram_file_unique_id ON public.diary_voice USING btree (telegram_file_unique_id);


--
-- Name: ix_habit_checkins_check_date; Type: INDEX; Schema: public; Owner: habitbot
--

CREATE INDEX ix_habit_checkins_check_date ON public.habit_checkins USING btree (check_date);


--
-- Name: ix_habit_checkins_habit_id; Type: INDEX; Schema: public; Owner: habitbot
--

CREATE INDEX ix_habit_checkins_habit_id ON public.habit_checkins USING btree (habit_id);


--
-- Name: ix_habit_checkins_time_slot; Type: INDEX; Schema: public; Owner: habitbot
--

CREATE INDEX ix_habit_checkins_time_slot ON public.habit_checkins USING btree (time_slot);


--
-- Name: ix_habit_schedule_rules_habit_id; Type: INDEX; Schema: public; Owner: habitbot
--

CREATE INDEX ix_habit_schedule_rules_habit_id ON public.habit_schedule_rules USING btree (habit_id);


--
-- Name: ix_habit_schedule_rules_time_slot; Type: INDEX; Schema: public; Owner: habitbot
--

CREATE INDEX ix_habit_schedule_rules_time_slot ON public.habit_schedule_rules USING btree (time_slot);


--
-- Name: ix_habits_user_id; Type: INDEX; Schema: public; Owner: habitbot
--

CREATE INDEX ix_habits_user_id ON public.habits USING btree (user_id);


--
-- Name: ix_users_telegram_user_id; Type: INDEX; Schema: public; Owner: habitbot
--

CREATE UNIQUE INDEX ix_users_telegram_user_id ON public.users USING btree (telegram_user_id);


--
-- Name: ix_weekly_prompts_user_id; Type: INDEX; Schema: public; Owner: habitbot
--

CREATE INDEX ix_weekly_prompts_user_id ON public.weekly_prompts USING btree (user_id);


--
-- Name: ix_weekly_prompts_week_start; Type: INDEX; Schema: public; Owner: habitbot
--

CREATE INDEX ix_weekly_prompts_week_start ON public.weekly_prompts USING btree (week_start);


--
-- Name: day_off_rules day_off_rules_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: habitbot
--

ALTER TABLE ONLY public.day_off_rules
    ADD CONSTRAINT day_off_rules_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: diary_entries diary_entries_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: habitbot
--

ALTER TABLE ONLY public.diary_entries
    ADD CONSTRAINT diary_entries_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: diary_transcripts diary_transcripts_entry_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: habitbot
--

ALTER TABLE ONLY public.diary_transcripts
    ADD CONSTRAINT diary_transcripts_entry_id_fkey FOREIGN KEY (entry_id) REFERENCES public.diary_entries(id) ON DELETE CASCADE;


--
-- Name: diary_voice diary_voice_entry_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: habitbot
--

ALTER TABLE ONLY public.diary_voice
    ADD CONSTRAINT diary_voice_entry_id_fkey FOREIGN KEY (entry_id) REFERENCES public.diary_entries(id) ON DELETE CASCADE;


--
-- Name: habit_checkins habit_checkins_habit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: habitbot
--

ALTER TABLE ONLY public.habit_checkins
    ADD CONSTRAINT habit_checkins_habit_id_fkey FOREIGN KEY (habit_id) REFERENCES public.habits(id) ON DELETE CASCADE;


--
-- Name: habit_schedule_rules habit_schedule_rules_habit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: habitbot
--

ALTER TABLE ONLY public.habit_schedule_rules
    ADD CONSTRAINT habit_schedule_rules_habit_id_fkey FOREIGN KEY (habit_id) REFERENCES public.habits(id) ON DELETE CASCADE;


--
-- Name: habits habits_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: habitbot
--

ALTER TABLE ONLY public.habits
    ADD CONSTRAINT habits_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: weekly_prompts weekly_prompts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: habitbot
--

ALTER TABLE ONLY public.weekly_prompts
    ADD CONSTRAINT weekly_prompts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict 02IDh8d0BGaenhPBgKToV4qldu8OhVyJAdRcfXiKo0TIbt6Cof34yQjco0A2uWy

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

\restrict PtjUcfUbseJFhSa1pXedDg8g9ZjgToHY8l1rAXShoNeRXr8OynWoG89tkf21cWr

-- Dumped from database version 16.13 (Ubuntu 16.13-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.13 (Ubuntu 16.13-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict PtjUcfUbseJFhSa1pXedDg8g9ZjgToHY8l1rAXShoNeRXr8OynWoG89tkf21cWr

--
-- PostgreSQL database cluster dump complete
--

