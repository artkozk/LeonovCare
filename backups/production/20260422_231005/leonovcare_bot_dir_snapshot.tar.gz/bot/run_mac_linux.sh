#!/usr/bin/env bash
set -e

if [ ! -d ".venv" ]; then
  echo "[1/3] Создаю виртуальное окружение .venv"
  python3 -m venv .venv
fi

echo "[2/3] Устанавливаю зависимости"
. .venv/bin/activate
python -m pip install --upgrade pip >/dev/null
python -m pip install -r requirements.txt

echo "[3/3] Запускаю бота"
python main.py
