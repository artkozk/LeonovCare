param(
    [Parameter(Mandatory = $true)]
    [string]$RepoName,
    [switch]$Public
)

$ErrorActionPreference = "Stop"

if (-not (Get-Command gh -ErrorAction SilentlyContinue)) {
    throw "GitHub CLI (gh) is not installed."
}

if (-not $env:GH_TOKEN -and -not $env:GITHUB_TOKEN) {
    throw "Set GH_TOKEN (or GITHUB_TOKEN) before running this script."
}

$visibility = if ($Public) { "--public" } else { "--private" }

Write-Host "Creating GitHub repo '$RepoName' and pushing current project..."
gh repo create $RepoName --source . $visibility --remote origin --push

Write-Host "Done."
