from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from app.bot import build_app
from app.config import Config
from app.db import connect
from app.handlers.registry import DEFAULT_HANDLER_MODULES


def main() -> int:
    cfg = Config(
        BOT_TOKEN="123456:TEST_TOKEN",
        ADMIN_IDS=[1],
        DB_PATH=":memory:",
        TZ="Europe/Moscow",
        ALERT_REPEAT_MIN=10,
        SCHEDULER_TICK_SEC=20,
        BOT_WORKER_THREADS=8,
        DB_BUSY_TIMEOUT_SEC=15,
    )
    conn = connect(cfg)
    bot, _ctx = build_app(cfg, conn)
    try:
        msg_handlers = len(getattr(bot, "_message_handlers", []))
        cb_handlers = len(getattr(bot, "_callback_handlers", []))
        if msg_handlers < 10:
            raise RuntimeError(f"Too few message handlers registered: {msg_handlers}")
        if cb_handlers < 50:
            raise RuntimeError(f"Too few callback handlers registered: {cb_handlers}")
        if len(DEFAULT_HANDLER_MODULES) < 10:
            raise RuntimeError("Handler module registry looks incomplete")
        print(
            f"OK modules={len(DEFAULT_HANDLER_MODULES)} "
            f"message_handlers={msg_handlers} callback_handlers={cb_handlers}"
        )
        return 0
    finally:
        try:
            bot.close()
        except Exception:
            pass
        try:
            conn.close()
        except Exception:
            pass


if __name__ == "__main__":
    raise SystemExit(main())
