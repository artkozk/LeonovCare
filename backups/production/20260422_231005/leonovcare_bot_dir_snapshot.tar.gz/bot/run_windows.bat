@echo off
setlocal EnableExtensions

REM Use the Windows Python launcher if available
where py >nul 2>nul
if %errorlevel%==0 (
  set "PY=py -3"
) else (
  set "PY=python"
)

%PY% --version >nul 2>nul
if not %errorlevel%==0 (
  echo Python 3 was not found.
  echo Install Python 3.10+ from python.org, then run this file again.
  pause
  exit /b 1
)

if not exist ".venv" (
  echo Creating virtual environment .venv ...
  %PY% -m venv .venv
)

echo Installing dependencies ...
call ".venv\Scripts\python.exe" -m pip install --upgrade pip >nul
call ".venv\Scripts\python.exe" -m pip install -r requirements.txt

echo Starting bot ...
call ".venv\Scripts\python.exe" main.py

pause
