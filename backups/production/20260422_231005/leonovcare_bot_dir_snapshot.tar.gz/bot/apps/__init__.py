"""Compatibility shim.

Some older versions of the project imported DB connector as:
    from apps import connect

The current code uses `from app.db import connect`.
This module keeps the old import working.
"""

from __future__ import annotations

from app.db import connect  # re-export

__all__ = ["connect"]
