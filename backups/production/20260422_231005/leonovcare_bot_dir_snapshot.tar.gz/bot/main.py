from __future__ import annotations

import logging
import time
import random
import socket
import warnings

import requests

from telebot.apihelper import ApiTelegramException

from app.config import load_config
from app.db import connect
from app.bot import build_app
from app.services.scheduler import start_scheduler


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s (%(filename)s:%(lineno)d %(threadName)s) %(levelname)s - %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)

# aiogram/pydantic can emit non-fatal protected_namespaces warnings in some envs.
# They do not affect runtime logic of this bot.
warnings.filterwarnings(
    "ignore",
    category=UserWarning,
    message=r".*protected_namespaces.*",
)

try:
    # uvloop gives better polling throughput on Linux/macOS.
    import uvloop  # type: ignore

    uvloop.install()
except Exception:
    logger.debug("uvloop is unavailable; continuing with default event loop", exc_info=True)


def run_polling(bot) -> None:
    # If a webhook was set earlier, polling may conflict.
    try:
        bot.delete_webhook(drop_pending_updates=True)
    except Exception:
        logger.warning("Failed to delete webhook before polling; continuing")

    # Reduce noisy internal logs on transient network issues.
    logging.getLogger("telebot").setLevel(logging.WARNING)
    logging.getLogger("urllib3").setLevel(logging.WARNING)

    # Resilient loop: network hiccups and temporary conflicts shouldn't kill the process.
    backoff = 2
    while True:
        try:
            bot.infinity_polling(timeout=60, long_polling_timeout=20, skip_pending=True)
            backoff = 2
        except ApiTelegramException as e:
            error_text = str(e).lower()
            if (
                "clientconnectorerror" in error_text
                or "cannot connect to host" in error_text
                or "networkerror" in error_text
                or "timed out" in error_text
                or "timeout" in error_text
                or "отказано в доступе" in error_text
                or "winerror 5" in error_text
            ):
                delay = min(10, backoff)
                logger.warning(
                    "Нет соединения с Telegram API (api.telegram.org:443). Проверь сеть/VPN/фаервол. Повтор через %ss.",
                    delay,
                )
                time.sleep(delay)
                backoff = min(60, backoff * 2)
                continue
            # Conflict usually means another instance is polling with the same token.
            # We'll retry, but you still must ensure only one instance is running.
            if getattr(e, "error_code", None) == 409 and "getUpdates" in str(e):
                delay = min(10, backoff)
                logger.warning(
                    "Telegram polling conflict (409 getUpdates). Another instance may be running; retrying in %ss.",
                    delay,
                )
                time.sleep(delay)
                backoff = min(60, backoff * 2)
                continue
            delay = min(10, backoff)
            logger.warning(
                "Telegram API error during polling (code=%s); retrying in %ss.",
                getattr(e, "error_code", None),
                delay,
            )
            time.sleep(delay)
            backoff = min(60, backoff * 2)
        except (requests.exceptions.RequestException, socket.gaierror, TimeoutError, OSError) as e:
            # DNS / handshake / timeouts.
            delay = min(60, backoff) + random.random()
            logger.warning("Network error during polling (%s); retrying in %.1fs.", type(e).__name__, delay)
            time.sleep(delay)
            backoff = min(60, backoff * 2)
        except Exception:
            delay = min(60, backoff) + random.random()
            logger.exception("Unexpected polling error; retrying in %.1fs.", delay)
            time.sleep(delay)
            backoff = min(60, backoff * 2)


if __name__ == "__main__":
    cfg = load_config()
    conn = connect(cfg)
    bot, ctx = build_app(cfg, conn)
    scheduler = start_scheduler(bot, ctx)
    try:
        run_polling(bot)
    finally:
        try:
            scheduler.stop()
        except Exception:
            logger.warning("Failed to stop scheduler cleanly", exc_info=True)
        try:
            bot.close()
        except Exception:
            logger.warning("Failed to close bot cleanly", exc_info=True)
        try:
            conn.close()
        except Exception:
            logger.warning("Failed to close DB connection cleanly", exc_info=True)
