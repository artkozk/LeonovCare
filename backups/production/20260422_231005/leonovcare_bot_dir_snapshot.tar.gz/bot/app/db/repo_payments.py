from __future__ import annotations
import sqlite3
from app.services.timeutils import now, iso

def add_payment(
    conn: sqlite3.Connection,
    student_id: int,
    pay_type: str,
    amount: int,
    pay_date: str,
    tz: str,
    source: str | None = None,
    proof_file_id: str | None = None,
    note: str | None = None,
) -> int:
    ts = iso(now(tz))
    cur = conn.execute(
        "INSERT INTO payments(student_id, pay_type, amount, pay_date, source, proof_file_id, note, created_at) "
        "VALUES(?,?,?,?,?,?,?,?)",
        (student_id, pay_type, int(amount), pay_date, source, proof_file_id, note, ts)
    )
    conn.commit()
    return int(cur.lastrowid)

def list_payments(conn: sqlite3.Connection, student_id: int, limit: int=30) -> list[sqlite3.Row]:
    return conn.execute(
        "SELECT * FROM payments WHERE student_id=? ORDER BY id DESC LIMIT ?",
        (student_id, limit)
    ).fetchall()

def sum_payments(conn: sqlite3.Connection, student_id: int, pay_type: str) -> int:
    row = conn.execute("SELECT COALESCE(SUM(amount),0) AS s FROM payments WHERE student_id=? AND pay_type=?",
                       (student_id, pay_type)).fetchone()
    return int(row["s"]) if row else 0

def sum_all(conn: sqlite3.Connection) -> int:
    row = conn.execute("SELECT COALESCE(SUM(amount),0) AS s FROM payments").fetchone()
    return int(row["s"]) if row else 0
