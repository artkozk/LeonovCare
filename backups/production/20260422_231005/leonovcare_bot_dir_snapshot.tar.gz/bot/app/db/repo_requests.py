from __future__ import annotations

import json
import sqlite3

from app.services.timeutils import now, iso


def create(conn: sqlite3.Connection, tz: str, owner_tg_id: int, req_type: str, payload: dict, student_id: int | None = None) -> int:
    ts = iso(now(tz))
    cur = conn.execute(
        "INSERT INTO student_requests(owner_tg_id, req_type, student_id, payload_json, status, created_at, updated_at) "
        "VALUES(?,?,?,?,?,?,?)",
        (int(owner_tg_id), req_type, student_id, json.dumps(payload, ensure_ascii=False), "PENDING", ts, ts),
    )
    conn.commit()
    return int(cur.lastrowid)


def get(conn: sqlite3.Connection, req_id: int) -> sqlite3.Row | None:
    return conn.execute("SELECT * FROM student_requests WHERE id=?", (int(req_id),)).fetchone()


def list_pending(conn: sqlite3.Connection, limit: int = 20) -> list[sqlite3.Row]:
    return conn.execute(
        "SELECT * FROM student_requests WHERE status='PENDING' ORDER BY created_at LIMIT ?",
        (int(limit),),
    ).fetchall()


def set_status(conn: sqlite3.Connection, tz: str, req_id: int, status: str) -> None:
    ts = iso(now(tz))
    conn.execute(
        "UPDATE student_requests SET status=?, updated_at=? WHERE id=?",
        (status, ts, int(req_id)),
    )
    conn.commit()


def payload(row: sqlite3.Row) -> dict:
    try:
        return json.loads(row["payload_json"] or "{}")
    except Exception:
        return {}
