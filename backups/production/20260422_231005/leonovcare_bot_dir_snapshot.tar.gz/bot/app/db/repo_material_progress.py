from __future__ import annotations

import sqlite3

from app.db import repo_materials
from app.services.timeutils import iso, now


def set_done(conn: sqlite3.Connection, tz: str, user_id: int, step_id: int, done: bool) -> None:
    ts = iso(now(tz))
    conn.execute(
        "INSERT INTO user_material_progress(user_id, step_id, is_done, updated_at) VALUES(?,?,?,?) "
        "ON CONFLICT(user_id, step_id) DO UPDATE SET is_done=excluded.is_done, updated_at=excluded.updated_at",
        (int(user_id), int(step_id), 1 if done else 0, ts),
    )
    conn.commit()


def is_done(conn: sqlite3.Connection, user_id: int, step_id: int) -> bool:
    row = conn.execute(
        "SELECT is_done FROM user_material_progress WHERE user_id=? AND step_id=? LIMIT 1",
        (int(user_id), int(step_id)),
    ).fetchone()
    return bool(row and int(row["is_done"] or 0) == 1)


def done_map(conn: sqlite3.Connection, user_id: int, direction: str | None = None) -> dict[int, bool]:
    if direction:
        d = repo_materials.normalize_direction(direction)
        if not d:
            return {}
        rows = conn.execute(
            "SELECT p.step_id, p.is_done "
            "FROM user_material_progress p "
            "JOIN material_steps s ON s.id=p.step_id "
            "WHERE p.user_id=? AND s.direction=? AND s.is_active=1",
            (int(user_id), d),
        ).fetchall()
    else:
        rows = conn.execute(
            "SELECT p.step_id, p.is_done "
            "FROM user_material_progress p "
            "JOIN material_steps s ON s.id=p.step_id "
            "WHERE p.user_id=? AND s.is_active=1",
            (int(user_id),),
        ).fetchall()
    out: dict[int, bool] = {}
    for r in rows:
        out[int(r["step_id"])] = int(r["is_done"] or 0) == 1
    return out


def direction_stats(conn: sqlite3.Connection, user_id: int, direction: str) -> dict:
    d = repo_materials.normalize_direction(direction)
    if not d:
        return {"total": 0, "done": 0, "percent": 0}

    row = conn.execute(
        "SELECT "
        "COUNT(1) AS total, "
        "SUM(CASE WHEN COALESCE(p.is_done, 0)=1 THEN 1 ELSE 0 END) AS done "
        "FROM material_steps s "
        "LEFT JOIN user_material_progress p ON p.step_id=s.id AND p.user_id=? "
        "WHERE s.direction=? AND s.is_active=1",
        (int(user_id), d),
    ).fetchone()
    total = int(row["total"] or 0) if row else 0
    done = int(row["done"] or 0) if row else 0
    percent = int((done * 100) / total) if total > 0 else 0
    return {"total": total, "done": done, "percent": percent}


def overall_stats(conn: sqlite3.Connection, user_id: int) -> dict:
    row = conn.execute(
        "SELECT "
        "COUNT(1) AS total, "
        "SUM(CASE WHEN COALESCE(p.is_done, 0)=1 THEN 1 ELSE 0 END) AS done "
        "FROM material_steps s "
        "LEFT JOIN user_material_progress p ON p.step_id=s.id AND p.user_id=? "
        "WHERE s.is_active=1",
        (int(user_id),),
    ).fetchone()
    total = int(row["total"] or 0) if row else 0
    done = int(row["done"] or 0) if row else 0
    percent = int((done * 100) / total) if total > 0 else 0
    return {"total": total, "done": done, "percent": percent}
