from __future__ import annotations
import sqlite3
import datetime as dt
from typing import Optional
from app.services.timeutils import now, iso

def create(conn: sqlite3.Connection, tz: str, student_id: int | None, event_type: str,
           company: str | None, role: str | None, direction: str | None,
           link: str | None, start_at_iso: str, duration_min: int,
           remind_before_min: int, next_alert_at_iso: str) -> int:
    ts = iso(now(tz))
    cur = conn.execute(
        "INSERT INTO events(student_id, event_type, company, role, direction, link, start_at, duration_min, remind_before_min, next_alert_at, alerted, active, created_at, updated_at) "
        "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (student_id, event_type, company, role, direction, link, start_at_iso, int(duration_min), int(remind_before_min), next_alert_at_iso, 0, 1, ts, ts)
    )
    conn.commit()
    return int(cur.lastrowid)

def update(conn: sqlite3.Connection, event_id: int, tz: str, **fields) -> None:
    if not fields:
        return
    fields["updated_at"]=iso(now(tz))
    parts=[]
    vals=[]
    for k,v in fields.items():
        parts.append(f"{k}=?")
        vals.append(v)
    vals.append(event_id)
    conn.execute(f"UPDATE events SET {', '.join(parts)} WHERE id=?", vals)
    conn.commit()

def get(conn: sqlite3.Connection, event_id: int) -> Optional[sqlite3.Row]:
    q = '''
    SELECT e.*, s.fio, s.username
    FROM events e
    LEFT JOIN students s ON s.id=e.student_id
    WHERE e.id=?
    '''
    return conn.execute(q, (event_id,)).fetchone()

def list_upcoming(conn: sqlite3.Connection, from_iso: str, to_iso: str) -> list[sqlite3.Row]:
    q = '''
    SELECT e.*, s.fio, s.username
    FROM events e
    LEFT JOIN students s ON s.id=e.student_id
    WHERE e.active=1 AND e.start_at >= ? AND e.start_at <= ?
    ORDER BY e.start_at
    '''
    return conn.execute(q, (from_iso, to_iso)).fetchall()

def list_all_upcoming(conn: sqlite3.Connection, limit: int=50) -> list[sqlite3.Row]:
    q = '''
    SELECT e.*, s.fio, s.username
    FROM events e
    LEFT JOIN students s ON s.id=e.student_id
    WHERE e.active=1
    ORDER BY e.start_at
    LIMIT ?
    '''
    return conn.execute(q, (limit,)).fetchall()


def list_candidates_for_range(conn: sqlite3.Connection, from_iso: str, to_iso: str) -> list[sqlite3.Row]:
    """Events that may intersect with the range; exact intersection is checked in python."""
    q = '''
    SELECT e.*, s.fio, s.username
    FROM events e
    LEFT JOIN students s ON s.id=e.student_id
    WHERE e.active=1 AND e.start_at >= ? AND e.start_at <= ?
    ORDER BY e.start_at
    '''
    return conn.execute(q, (from_iso, to_iso)).fetchall()


def find_overlaps(
    conn: sqlite3.Connection,
    start_at: dt.datetime,
    end_at: dt.datetime,
    tz: str,
    exclude_event_id: int | None = None,
) -> list[sqlite3.Row]:
    """Find active events that overlap with [start_at, end_at)."""
    candidates = list_candidates_for_range(
        conn,
        iso(start_at - dt.timedelta(days=1)),
        iso(end_at + dt.timedelta(days=1)),
    )

    overlaps: list[sqlite3.Row] = []
    for r in candidates:
        try:
            if exclude_event_id is not None and int(r["id"]) == int(exclude_event_id):
                continue
            s = dt.datetime.fromisoformat(r["start_at"])  # preserves tzinfo
            e = s + dt.timedelta(minutes=int(r["duration_min"] or 0))
            if s < end_at and e > start_at:
                overlaps.append(r)
        except Exception:
            continue
    return overlaps


def list_for_day(conn: sqlite3.Connection, day: dt.date, tz: str) -> list[sqlite3.Row]:
    """List active events that intersect the given day (00:00..24:00 in tz)."""
    tzinfo = now(tz).tzinfo
    day_start = dt.datetime.combine(day, dt.time.min).replace(tzinfo=tzinfo)
    day_end = day_start + dt.timedelta(days=1)
    candidates = list_candidates_for_range(conn, iso(day_start - dt.timedelta(days=1)), iso(day_end))
    res: list[sqlite3.Row] = []
    for r in candidates:
        try:
            s = dt.datetime.fromisoformat(r["start_at"])  # preserves tzinfo
            e = s + dt.timedelta(minutes=int(r["duration_min"] or 0))
            if s < day_end and e > day_start:
                res.append(r)
        except Exception:
            continue
    return res

def mark_alerted(conn: sqlite3.Connection, event_id: int, tz: str) -> None:
    update(conn, event_id, tz, alerted=1)


def delete(conn: sqlite3.Connection, event_id: int) -> None:
    conn.execute("DELETE FROM events WHERE id=?", (event_id,))
    conn.commit()
