from __future__ import annotations
import sqlite3
from typing import Optional

def get(conn: sqlite3.Connection, student_id: int) -> Optional[sqlite3.Row]:
    return conn.execute("SELECT * FROM student_postpay WHERE student_id=?", (student_id,)).fetchone()

def upsert(conn: sqlite3.Connection, student_id: int, **fields) -> None:
    existing = get(conn, student_id)
    if existing:
        parts=[]
        vals=[]
        for k,v in fields.items():
            parts.append(f"{k}=?")
            vals.append(v)
        vals.append(student_id)
        conn.execute(f"UPDATE student_postpay SET {', '.join(parts)} WHERE student_id=?", vals)
    else:
        cols=["student_id"] + list(fields.keys())
        vals=[student_id] + list(fields.values())
        qmarks=",".join(["?"]*len(cols))
        conn.execute(f"INSERT INTO student_postpay({','.join(cols)}) VALUES({qmarks})", vals)
    conn.commit()

def disable(conn: sqlite3.Connection, student_id: int) -> None:
    upsert(conn, student_id, enabled=0)

def enable(conn: sqlite3.Connection, student_id: int) -> None:
    upsert(conn, student_id, enabled=1)

def list_due(conn: sqlite3.Connection, from_date: str, to_date: str) -> list[sqlite3.Row]:
    # join with student
    q = '''
    SELECT s.id AS student_id, s.fio, s.username, d.name AS direction_name, st.name AS stage_name,
           s.offer_amount, pp.total_percent, pp.schedule_type, pp.per_period_value, pp.next_due_date
    FROM student_postpay pp
    JOIN students s ON s.id=pp.student_id
    LEFT JOIN directions d ON d.id=s.direction_id
    LEFT JOIN stages st ON st.id=s.stage_id
    WHERE s.archived=0 AND pp.enabled=1 AND pp.next_due_date IS NOT NULL
      AND pp.next_due_date >= ? AND pp.next_due_date <= ?
    ORDER BY pp.next_due_date, d.sort, st.sort, s.fio
    '''
    return conn.execute(q, (from_date, to_date)).fetchall()
