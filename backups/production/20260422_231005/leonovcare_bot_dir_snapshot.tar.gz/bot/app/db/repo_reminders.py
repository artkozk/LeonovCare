from __future__ import annotations
import sqlite3
from typing import Optional
import datetime as dt

from app.services.timeutils import now, iso, parse_time_hhmm, tzinfo

WEEKDAY_LABELS = {
    1: "Пн", 2: "Вт", 3: "Ср", 4: "Чт", 5: "Пт", 6: "Сб", 7: "Вс"
}


def create(
    conn: sqlite3.Connection,
    tz: str,
    student_id: int | None,
    title: str,
    note: str | None,
    freq_type: str,
    freq_value: int,
    time_of_day: str,
    next_run_at_iso: str,
    days_of_week: str | None = None,
    enabled: int = 1,
) -> int:
    ts = iso(now(tz))
    cur = conn.execute(
        "INSERT INTO reminders(student_id, title, note, freq_type, freq_value, days_of_week, time_of_day, next_run_at, enabled, created_at, updated_at) "
        "VALUES(?,?,?,?,?,?,?,?,?,?,?)",
        (student_id, title, note, freq_type, int(freq_value or 1), days_of_week, time_of_day, next_run_at_iso, int(enabled), ts, ts)
    )
    conn.commit()
    return int(cur.lastrowid)


def update(conn: sqlite3.Connection, reminder_id: int, tz: str, **fields) -> None:
    if not fields:
        return
    fields["updated_at"] = iso(now(tz))
    parts, vals = [], []
    for k, v in fields.items():
        parts.append(f"{k}=?")
        vals.append(v)
    vals.append(reminder_id)
    conn.execute(f"UPDATE reminders SET {', '.join(parts)} WHERE id=?", vals)
    conn.commit()


def delete(conn: sqlite3.Connection, reminder_id: int) -> None:
    conn.execute("DELETE FROM reminders WHERE id=?", (reminder_id,))
    conn.commit()


def get(conn: sqlite3.Connection, reminder_id: int) -> Optional[sqlite3.Row]:
    return conn.execute("SELECT * FROM reminders WHERE id=?", (reminder_id,)).fetchone()


def list_due_today(conn: sqlite3.Connection, day_start_iso: str, day_end_iso: str) -> list[sqlite3.Row]:
    q = '''
    SELECT r.*, s.fio, s.username, d.name AS direction_name, st.name AS stage_name
    FROM reminders r
    LEFT JOIN students s ON s.id=r.student_id
    LEFT JOIN directions d ON d.id=s.direction_id
    LEFT JOIN stages st ON st.id=s.stage_id
    WHERE r.enabled=1 AND r.next_run_at >= ? AND r.next_run_at <= ?
    ORDER BY r.next_run_at, s.fio
    '''
    return conn.execute(q, (day_start_iso, day_end_iso)).fetchall()


def list_by_student(conn: sqlite3.Connection, student_id: int) -> list[sqlite3.Row]:
    q = '''
    SELECT r.* FROM reminders r
    WHERE r.student_id=?
    ORDER BY r.enabled DESC, r.next_run_at
    '''
    return conn.execute(q, (student_id,)).fetchall()


def list_all(conn: sqlite3.Connection, limit: int = 50, offset: int = 0) -> list[sqlite3.Row]:
    q = '''
    SELECT r.*, s.fio, s.username
    FROM reminders r
    LEFT JOIN students s ON s.id=r.student_id
    ORDER BY r.enabled DESC, r.next_run_at
    LIMIT ? OFFSET ?
    '''
    return conn.execute(q, (limit, offset)).fetchall()


def count_all(conn: sqlite3.Connection) -> int:
    row = conn.execute("SELECT COUNT(*) AS c FROM reminders").fetchone()
    return int(row["c"] or 0)


def _parse_days(days_of_week: str | None) -> list[int]:
    if not days_of_week:
        return []
    out = []
    for p in str(days_of_week).split(","):
        p = p.strip()
        if not p:
            continue
        try:
            d = int(p)
            if 1 <= d <= 7:
                out.append(d)
        except Exception:
            pass
    return sorted(set(out))


def _next_weekly(base: dt.datetime, tz: str, days: list[int], time_of_day: str) -> dt.datetime:
    t = parse_time_hhmm(time_of_day) or dt.time(12, 0)
    if not days:
        days = [base.isoweekday()]
    for i in range(1, 15):
        cand = (base + dt.timedelta(days=i)).astimezone(tzinfo(tz))
        if cand.isoweekday() in days:
            return cand.replace(hour=t.hour, minute=t.minute, second=0, microsecond=0)
    cand = (base + dt.timedelta(days=7)).astimezone(tzinfo(tz))
    return cand.replace(hour=t.hour, minute=t.minute, second=0, microsecond=0)


def compute_next_run(
    current_next_iso: str,
    tz: str,
    freq_type: str,
    freq_value: int,
    time_of_day: str,
    days_of_week: str | None = None,
) -> str:
    base = dt.datetime.fromisoformat(current_next_iso)
    if base.tzinfo is None:
        base = base.replace(tzinfo=tzinfo(tz))

    ft = (freq_type or "daily").lower()
    if ft == "once":
        return iso(base)

    if ft == "weekly":
        nxt = _next_weekly(base, tz, _parse_days(days_of_week), time_of_day)
        return iso(nxt)

    days = 1
    if ft == "every_n_days":
        days = max(1, int(freq_value or 1))

    t = parse_time_hhmm(time_of_day) or dt.time(12, 0)
    nxt = (base + dt.timedelta(days=days)).astimezone(tzinfo(tz))
    nxt = nxt.replace(hour=t.hour, minute=t.minute, second=0, microsecond=0)
    return iso(nxt)


def first_run_from_now(tz: str, time_of_day: str) -> str:
    n = now(tz)
    t = parse_time_hhmm(time_of_day) or dt.time(12, 0)
    run = n.replace(hour=t.hour, minute=t.minute, second=0, microsecond=0)
    if run <= n:
        run = run + dt.timedelta(days=1)
    return iso(run)
