from __future__ import annotations

import sqlite3

from app.services.timeutils import now, iso


def get_by_owner(conn: sqlite3.Connection, owner_tg_id: int) -> sqlite3.Row | None:
    return conn.execute(
        "SELECT * FROM enrollment_contracts WHERE owner_tg_id=? LIMIT 1",
        (int(owner_tg_id),),
    ).fetchone()


def create_once(
    conn: sqlite3.Connection,
    tz: str,
    owner_tg_id: int,
    owner_chat_id: int | None,
    level_key: str,
    track_key: str,
    track_title: str,
    tariff_key: str,
    tariff_title: str,
    tariff_price: str,
    contract_file_path: str | None,
    sign_url: str | None,
    status: str = "sent",
    note: str | None = None,
) -> int | None:
    ts = iso(now(tz))
    cur = conn.execute(
        "INSERT OR IGNORE INTO enrollment_contracts("
        "owner_tg_id, owner_chat_id, level_key, track_key, track_title, tariff_key, tariff_title, tariff_price, "
        "contract_file_path, sign_url, status, note, created_at, updated_at"
        ") VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (
            int(owner_tg_id),
            int(owner_chat_id) if owner_chat_id is not None else None,
            (level_key or "").strip(),
            (track_key or "").strip(),
            (track_title or "").strip(),
            (tariff_key or "").strip(),
            (tariff_title or "").strip(),
            (tariff_price or "").strip(),
            (contract_file_path or "").strip() or None,
            (sign_url or "").strip() or None,
            (status or "sent").strip(),
            (note or "").strip() or None,
            ts,
            ts,
        ),
    )
    conn.commit()
    if int(cur.rowcount or 0) <= 0:
        return None
    return int(cur.lastrowid)


def set_status(conn: sqlite3.Connection, tz: str, owner_tg_id: int, status: str, note: str | None = None) -> None:
    ts = iso(now(tz))
    conn.execute(
        "UPDATE enrollment_contracts SET status=?, note=COALESCE(?, note), updated_at=? WHERE owner_tg_id=?",
        ((status or "").strip(), (note or "").strip() or None, ts, int(owner_tg_id)),
    )
    conn.commit()
