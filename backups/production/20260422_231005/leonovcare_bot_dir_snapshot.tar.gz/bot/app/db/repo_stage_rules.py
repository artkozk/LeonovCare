from __future__ import annotations
import sqlite3
from typing import Optional

from app.services.timeutils import now, iso
from app.db import repo_reminders

DEFAULT_TITLE = "Пинг"
DEFAULT_NOTE = "Списаться, спросить прогресс и трудности."


def list_stages(conn: sqlite3.Connection) -> list[sqlite3.Row]:
    return conn.execute("SELECT id, name, sort FROM stages ORDER BY sort, name").fetchall()


def get_rule(conn: sqlite3.Connection, stage_id: int) -> Optional[sqlite3.Row]:
    return conn.execute("SELECT * FROM stage_reminder_rules WHERE stage_id=?", (stage_id,)).fetchone()


def ensure_rule(conn: sqlite3.Connection, tz: str, stage_id: int) -> sqlite3.Row:
    r = get_rule(conn, stage_id)
    if r:
        return r
    ts = iso(now(tz))
    conn.execute(
        "INSERT INTO stage_reminder_rules(stage_id, enabled, title, note, freq_type, freq_value, days_of_week, time_of_day, updated_at) "
        "VALUES(?,?,?,?,?,?,?,?,?)",
        (stage_id, 1, DEFAULT_TITLE, DEFAULT_NOTE, "daily", 1, None, "12:00", ts)
    )
    conn.commit()
    return get_rule(conn, stage_id)


def upsert_rule(
    conn: sqlite3.Connection,
    tz: str,
    stage_id: int,
    enabled: int,
    title: str,
    note: str,
    freq_type: str,
    freq_value: int,
    days_of_week: str | None,
    time_of_day: str,
) -> None:
    ts = iso(now(tz))
    exists = get_rule(conn, stage_id)
    if exists:
        conn.execute(
            "UPDATE stage_reminder_rules SET enabled=?, title=?, note=?, freq_type=?, freq_value=?, days_of_week=?, time_of_day=?, updated_at=? WHERE stage_id=?",
            (int(enabled), title, note, freq_type, int(freq_value or 1), days_of_week, time_of_day, ts, stage_id)
        )
    else:
        conn.execute(
            "INSERT INTO stage_reminder_rules(stage_id, enabled, title, note, freq_type, freq_value, days_of_week, time_of_day, updated_at) "
            "VALUES(?,?,?,?,?,?,?,?,?)",
            (stage_id, int(enabled), title, note, freq_type, int(freq_value or 1), days_of_week, time_of_day, ts)
        )
    conn.commit()


def get_student_stage_reminder(conn: sqlite3.Connection, student_id: int) -> Optional[sqlite3.Row]:
    return conn.execute("SELECT * FROM student_stage_reminders WHERE student_id=?", (student_id,)).fetchone()


def sync_student_auto_reminder(conn: sqlite3.Connection, tz: str, student_id: int, stage_id: int | None) -> None:
    if stage_id is None:
        return

    rule = ensure_rule(conn, tz, stage_id)
    mapping = get_student_stage_reminder(conn, student_id)

    enabled = int(rule["enabled"] or 0)
    title = str(rule["title"] or DEFAULT_TITLE)
    note = str(rule["note"] or DEFAULT_NOTE)
    freq_type = str(rule["freq_type"] or "daily")
    freq_value = int(rule["freq_value"] or 1)
    days_of_week = rule["days_of_week"]
    time_of_day = str(rule["time_of_day"] or "12:00")

    if mapping:
        rid = int(mapping["reminder_id"])
        repo_reminders.update(
            conn,
            rid,
            tz,
            student_id=student_id,
            title=title,
            note=note,
            freq_type=freq_type,
            freq_value=freq_value,
            days_of_week=days_of_week,
            time_of_day=time_of_day,
            enabled=enabled,
        )
        conn.execute("UPDATE student_stage_reminders SET stage_id=? WHERE student_id=?", (stage_id, student_id))
        conn.commit()
        return

    next_run = repo_reminders.first_run_from_now(tz, time_of_day)
    rid = repo_reminders.create(
        conn,
        tz,
        student_id,
        title,
        note,
        freq_type,
        freq_value,
        time_of_day,
        next_run,
        days_of_week=days_of_week,
        enabled=enabled,
    )
    conn.execute(
        "INSERT OR REPLACE INTO student_stage_reminders(student_id, stage_id, reminder_id) VALUES(?,?,?)",
        (student_id, stage_id, rid)
    )
    conn.commit()


def apply_rule_to_stage(conn: sqlite3.Connection, tz: str, stage_id: int) -> int:
    """Apply current rule to all active students in stage and reset next_run_at to ближайшее время."""
    rule = ensure_rule(conn, tz, stage_id)
    rows = conn.execute("SELECT id FROM students WHERE archived=0 AND stage_id=?", (stage_id,)).fetchall()
    for r in rows:
        sid = int(r["id"])
        sync_student_auto_reminder(conn, tz, sid, stage_id)
        # reset next run to near future (по времени правила)
        mapping = get_student_stage_reminder(conn, sid)
        if mapping:
            rid = int(mapping["reminder_id"])
            nxt = repo_reminders.first_run_from_now(tz, str(rule["time_of_day"] or '12:00'))
            repo_reminders.update(conn, rid, tz, next_run_at=nxt)
    return len(rows)
