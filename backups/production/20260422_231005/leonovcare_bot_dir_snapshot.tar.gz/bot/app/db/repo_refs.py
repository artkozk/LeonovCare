from __future__ import annotations

from dataclasses import dataclass

from app.db.core import get_conn


@dataclass(frozen=True)
class RefItem:
    name: str
    sort_order: int


def list_directions(db_path: str, active_only: bool = True) -> list[RefItem]:
    sql = "SELECT name, sort_order FROM directions"
    if active_only:
        sql += " WHERE active=1"
    sql += " ORDER BY sort_order, name"
    with get_conn(db_path) as conn:
        rows = conn.execute(sql).fetchall()
    return [RefItem(name=r[0], sort_order=r[1]) for r in rows]


def list_stages(db_path: str, active_only: bool = True) -> list[RefItem]:
    sql = "SELECT name, sort_order FROM stages"
    if active_only:
        sql += " WHERE active=1"
    sql += " ORDER BY sort_order, name"
    with get_conn(db_path) as conn:
        rows = conn.execute(sql).fetchall()
    return [RefItem(name=r[0], sort_order=r[1]) for r in rows]


def get_setting(db_path: str, key: str, default: str | None = None) -> str | None:
    with get_conn(db_path) as conn:
        row = conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        return row[0] if row else default


def set_setting(db_path: str, key: str, value: str) -> None:
    with get_conn(db_path) as conn:
        conn.execute(
            "INSERT INTO settings(key, value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, value),
        )
