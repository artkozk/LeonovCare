from __future__ import annotations
import sqlite3
from typing import Any, Optional
from app.services.timeutils import now, iso

TARIFF_LABELS = {
    "pre": "Только предоплата",
    "post": "Только постоплата",
    "pre_post": "Предоплата + постоплата",
}

def tariff_label(code: str) -> str:
    return TARIFF_LABELS.get(code, code)

def list_directions(conn: sqlite3.Connection) -> list[sqlite3.Row]:
    return conn.execute("SELECT * FROM directions ORDER BY sort, name").fetchall()

def list_stages(conn: sqlite3.Connection) -> list[sqlite3.Row]:
    return conn.execute("SELECT * FROM stages ORDER BY sort, name").fetchall()

def create_student(conn: sqlite3.Connection, tz: str, **fields) -> int:
    ts = iso(now(tz))
    keys = ["fio","username","direction_id","stage_id","tariff","comment","join_date",
            "interviews_active","offer_amount","contract_url","hh_phone","hh_email","hh_password",
            "hh_birth_date","hh_location","hh_salary_min","hh_salary_comfort",
            "archived","archive_failed","created_at","updated_at"]
    data = {k: fields.get(k) for k in keys}
    data["created_at"]=ts
    data["updated_at"]=ts
    cols=",".join(keys)
    qmarks=",".join(["?"]*len(keys))
    cur = conn.execute(f"INSERT INTO students({cols}) VALUES({qmarks})", [data[k] for k in keys])
    conn.commit()
    return int(cur.lastrowid)

def update_student(conn: sqlite3.Connection, student_id: int, tz: str, **fields) -> None:
    if not fields:
        return
    ts = iso(now(tz))
    fields["updated_at"]=ts
    parts=[]
    vals=[]
    for k,v in fields.items():
        parts.append(f"{k}=?")
        vals.append(v)
    vals.append(student_id)
    conn.execute(f"UPDATE students SET {', '.join(parts)} WHERE id=?", vals)
    conn.commit()

def get_student(conn: sqlite3.Connection, student_id: int) -> Optional[sqlite3.Row]:
    q = '''
    SELECT s.*, d.name AS direction_name, st.name AS stage_name
    FROM students s
    LEFT JOIN directions d ON d.id=s.direction_id
    LEFT JOIN stages st ON st.id=s.stage_id
    WHERE s.id=?
    '''
    return conn.execute(q, (student_id,)).fetchone()


def get_by_owner(conn: sqlite3.Connection, owner_tg_id: int) -> Optional[sqlite3.Row]:
    q = '''
    SELECT s.*, d.name AS direction_name, st.name AS stage_name
    FROM students s
    LEFT JOIN directions d ON d.id=s.direction_id
    LEFT JOIN stages st ON st.id=s.stage_id
    WHERE s.owner_tg_id=? AND s.archived=0
    ORDER BY s.id DESC
    LIMIT 1
    '''
    return conn.execute(q, (int(owner_tg_id),)).fetchone()


def get_latest_by_owner(conn: sqlite3.Connection, owner_tg_id: int) -> Optional[sqlite3.Row]:
    q = '''
    SELECT s.*, d.name AS direction_name, st.name AS stage_name
    FROM students s
    LEFT JOIN directions d ON d.id=s.direction_id
    LEFT JOIN stages st ON st.id=s.stage_id
    WHERE s.owner_tg_id=?
    ORDER BY s.id DESC
    LIMIT 1
    '''
    return conn.execute(q, (int(owner_tg_id),)).fetchone()


def set_owner(conn: sqlite3.Connection, tz: str, student_id: int, owner_tg_id: int, owner_chat_id: int, owner_username: str | None) -> None:
    ts = iso(now(tz))
    conn.execute(
        "UPDATE students SET owner_tg_id=?, owner_chat_id=?, owner_username=?, updated_at=? WHERE id=?",
        (int(owner_tg_id), int(owner_chat_id), owner_username, ts, int(student_id)),
    )
    conn.commit()

def search_students(conn: sqlite3.Connection, text: str, archived: bool=False, limit: int=20) -> list[sqlite3.Row]:
    t = (text or "").strip()
    if not t:
        return []
    like = f"%{t}%"
    q = '''
    SELECT s.id, s.fio, s.username, d.name AS direction_name, st.name AS stage_name
    FROM students s
    LEFT JOIN directions d ON d.id=s.direction_id
    LEFT JOIN stages st ON st.id=s.stage_id
    WHERE s.archived=?
      AND (s.fio LIKE ? OR s.username LIKE ? OR s.hh_phone LIKE ? OR s.comment LIKE ?)
    ORDER BY s.fio
    LIMIT ?
    '''
    return conn.execute(q, (1 if archived else 0, like, like, like, like, limit)).fetchall()

def list_students(conn: sqlite3.Connection, filters: dict, page: int, page_size: int=5) -> tuple[list[sqlite3.Row], bool, bool]:
    archived = 1 if filters.get("archived") else 0
    where = ["s.archived=?"]
    args=[archived]
    if filters.get("direction_id"):
        where.append("s.direction_id=?")
        args.append(filters["direction_id"])
    if filters.get("stage_id"):
        where.append("s.stage_id=?")
        args.append(filters["stage_id"])
    if filters.get("tariff"):
        where.append("s.tariff=?")
        args.append(filters["tariff"])
    if filters.get("offer") == "yes":
        where.append("s.offer_amount IS NOT NULL")
    if filters.get("offer") == "no":
        where.append("s.offer_amount IS NULL")
    where_sql = " AND ".join(where)
    offset = max(page,0) * page_size
    q = f'''
    SELECT s.id, s.fio, s.username, d.name AS direction_name, st.name AS stage_name
    FROM students s
    LEFT JOIN directions d ON d.id=s.direction_id
    LEFT JOIN stages st ON st.id=s.stage_id
    WHERE {where_sql}
    ORDER BY d.sort, st.sort, s.fio
    LIMIT ? OFFSET ?
    '''
    rows = conn.execute(q, (*args, page_size+1, offset)).fetchall()
    has_next = len(rows) > page_size
    rows = rows[:page_size]
    has_prev = page > 0
    return rows, has_prev, has_next


def list_student_ids(conn: sqlite3.Connection, filters: dict) -> list[int]:
    """Return ordered student ids for current filters (used by cards carousel)."""
    archived = 1 if filters.get("archived") else 0
    where = ["s.archived=?"]
    args=[archived]
    if filters.get("direction_id"):
        where.append("s.direction_id=?")
        args.append(filters["direction_id"])
    if filters.get("stage_id"):
        where.append("s.stage_id=?")
        args.append(filters["stage_id"])
    if filters.get("tariff"):
        where.append("s.tariff=?")
        args.append(filters["tariff"])
    if filters.get("offer") == "yes":
        where.append("s.offer_amount IS NOT NULL")
    if filters.get("offer") == "no":
        where.append("s.offer_amount IS NULL")
    where_sql = " AND ".join(where)
    q = f'''
    SELECT s.id
    FROM students s
    LEFT JOIN directions d ON d.id=s.direction_id
    LEFT JOIN stages st ON st.id=s.stage_id
    WHERE {where_sql}
    ORDER BY d.sort, st.sort, s.fio
    '''
    rows = conn.execute(q, tuple(args)).fetchall()
    return [int(r[0]) for r in rows]

def archive_student(conn: sqlite3.Connection, student_id: int, failed: bool, tz: str) -> None:
    update_student(conn, student_id, tz, archived=1, archive_failed=1 if failed else 0)

def restore_student(conn: sqlite3.Connection, student_id: int, tz: str) -> None:
    update_student(conn, student_id, tz, archived=0, archive_failed=0)
