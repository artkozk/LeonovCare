from __future__ import annotations

import datetime as dt
import secrets
import sqlite3
import string

from app.services.timeutils import iso, now

STATUS_ACTIVE = "active"
STATUS_USED = "used"
STATUS_REVOKED = "revoked"
STATUS_EXPIRED = "expired"

_ALPHABET = string.ascii_uppercase + string.digits


def _ts(tz: str) -> str:
    return iso(now(tz))


def _normalize_code(code: str) -> str:
    return (code or "").strip().upper()


def _generate_raw_code(length: int = 8) -> str:
    return "".join(secrets.choice(_ALPHABET) for _ in range(max(4, int(length))))


def generate_code(prefix: str = "STU", length: int = 8) -> str:
    return f"{(prefix or 'STU').strip().upper()}-{_generate_raw_code(length)}"


def mark_expired(conn: sqlite3.Connection, tz: str) -> int:
    ts = _ts(tz)
    cur = conn.execute(
        "UPDATE student_access_codes "
        "SET status=? "
        "WHERE status=? AND expires_at IS NOT NULL AND expires_at<=?",
        (STATUS_EXPIRED, STATUS_ACTIVE, ts),
    )
    conn.commit()
    return int(cur.rowcount or 0)


def create(
    conn: sqlite3.Connection,
    tz: str,
    created_by_admin_id: int,
    ttl_hours: int | None = 24,
    code: str | None = None,
) -> sqlite3.Row:
    ts = _ts(tz)
    expires_at = None
    if ttl_hours is not None and int(ttl_hours) > 0:
        expires_at = iso(now(tz) + dt.timedelta(hours=int(ttl_hours)))

    attempts = 0
    while True:
        attempts += 1
        candidate = _normalize_code(code or generate_code())
        try:
            cur = conn.execute(
                "INSERT INTO student_access_codes(code, status, created_by_admin_id, created_at, expires_at) "
                "VALUES(?,?,?,?,?)",
                (candidate, STATUS_ACTIVE, int(created_by_admin_id), ts, expires_at),
            )
            conn.commit()
            row_id = int(cur.lastrowid)
            row = get_by_id(conn, row_id)
            if not row:
                raise RuntimeError("created code row not found")
            return row
        except sqlite3.IntegrityError:
            if code:
                raise
            if attempts >= 20:
                raise RuntimeError("failed to generate unique code")


def get_by_code(conn: sqlite3.Connection, code: str) -> sqlite3.Row | None:
    return conn.execute(
        "SELECT * FROM student_access_codes WHERE code=? LIMIT 1",
        (_normalize_code(code),),
    ).fetchone()


def get_by_id(conn: sqlite3.Connection, code_id: int) -> sqlite3.Row | None:
    return conn.execute(
        "SELECT * FROM student_access_codes WHERE id=? LIMIT 1",
        (int(code_id),),
    ).fetchone()


def validate_for_use(conn: sqlite3.Connection, tz: str, code: str) -> tuple[sqlite3.Row | None, str | None]:
    mark_expired(conn, tz)
    row = get_by_code(conn, code)
    if not row:
        return None, "not_found"
    status = (row["status"] or "").strip().lower()
    if status != STATUS_ACTIVE:
        return None, status or "invalid"
    return row, None


def mark_used(conn: sqlite3.Connection, tz: str, code_id: int, user_id: int) -> bool:
    ts = _ts(tz)
    cur = conn.execute(
        "UPDATE student_access_codes "
        "SET status=?, used_by_user_id=?, used_at=? "
        "WHERE id=? AND status=?",
        (STATUS_USED, int(user_id), ts, int(code_id), STATUS_ACTIVE),
    )
    conn.commit()
    return int(cur.rowcount or 0) > 0


def revoke(conn: sqlite3.Connection, tz: str, code_id: int) -> bool:
    ts = _ts(tz)
    cur = conn.execute(
        "UPDATE student_access_codes "
        "SET status=?, revoked_at=? "
        "WHERE id=? AND status IN (?, ?)",
        (STATUS_REVOKED, ts, int(code_id), STATUS_ACTIVE, STATUS_EXPIRED),
    )
    conn.commit()
    return int(cur.rowcount or 0) > 0


def has_used_code(conn: sqlite3.Connection, user_id: int) -> bool:
    row = conn.execute(
        "SELECT 1 FROM student_access_codes WHERE used_by_user_id=? AND status=? LIMIT 1",
        (int(user_id), STATUS_USED),
    ).fetchone()
    return bool(row)


def list_codes(
    conn: sqlite3.Connection,
    tz: str,
    status: str,
    limit: int = 30,
) -> list[sqlite3.Row]:
    mark_expired(conn, tz)
    status = (status or "").strip().lower()
    if status not in {STATUS_ACTIVE, STATUS_USED, STATUS_EXPIRED, STATUS_REVOKED}:
        status = STATUS_ACTIVE
    order = {
        STATUS_ACTIVE: "created_at DESC",
        STATUS_USED: "used_at DESC, created_at DESC",
        STATUS_EXPIRED: "expires_at DESC, created_at DESC",
        STATUS_REVOKED: "revoked_at DESC, created_at DESC",
    }[status]
    return conn.execute(
        f"SELECT * FROM student_access_codes WHERE status=? ORDER BY {order} LIMIT ?",
        (status, int(limit)),
    ).fetchall()


def counts(conn: sqlite3.Connection, tz: str) -> dict[str, int]:
    mark_expired(conn, tz)
    out = {
        STATUS_ACTIVE: 0,
        STATUS_USED: 0,
        STATUS_EXPIRED: 0,
        STATUS_REVOKED: 0,
    }
    rows = conn.execute(
        "SELECT status, COUNT(1) AS c FROM student_access_codes GROUP BY status"
    ).fetchall()
    for r in rows:
        st = (r["status"] or "").strip().lower()
        if st in out:
            out[st] = int(r["c"] or 0)
    return out
