from __future__ import annotations
import sqlite3

SCHEMA_SQL = r'''
CREATE TABLE IF NOT EXISTS settings(
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS directions(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE,
  sort INTEGER NOT NULL DEFAULT 100
);

CREATE TABLE IF NOT EXISTS stages(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE,
  sort INTEGER NOT NULL DEFAULT 100
);

CREATE TABLE IF NOT EXISTS students(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  fio TEXT NOT NULL,
  username TEXT,
  direction_id INTEGER,
  stage_id INTEGER,
  tariff TEXT NOT NULL DEFAULT 'post', -- pre, post, pre_post
  comment TEXT,
  join_date TEXT, -- dd.mm.yyyy
  interviews_active INTEGER NOT NULL DEFAULT 0,
  offer_amount INTEGER, -- rub
  contract_url TEXT,
  hh_phone TEXT,
  hh_email TEXT,
  hh_password TEXT,
  hh_birth_date TEXT, -- dd.mm.yyyy
  hh_location TEXT,
  hh_salary_min INTEGER, -- rub
  hh_salary_comfort INTEGER, -- rub
  owner_tg_id INTEGER,
  owner_chat_id INTEGER,
  owner_username TEXT,
  archived INTEGER NOT NULL DEFAULT 0,
  archive_failed INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY(direction_id) REFERENCES directions(id),
  FOREIGN KEY(stage_id) REFERENCES stages(id)
);

CREATE INDEX IF NOT EXISTS idx_students_archived ON students(archived);
CREATE INDEX IF NOT EXISTS idx_students_direction ON students(direction_id);
CREATE INDEX IF NOT EXISTS idx_students_stage ON students(stage_id);

CREATE TABLE IF NOT EXISTS student_postpay(
  student_id INTEGER PRIMARY KEY,
  total_percent REAL, -- e.g. 350, 600
  schedule_type TEXT NOT NULL DEFAULT 'percent_per_month', -- percent_per_month, fixed_per_month, custom
  per_period_value REAL, -- e.g. 50 (% per month) or 30000 (rub)
  period_unit TEXT NOT NULL DEFAULT 'month',
  start_date TEXT, -- dd.mm.yyyy
  next_due_date TEXT, -- dd.mm.yyyy
  student_notify_enabled INTEGER NOT NULL DEFAULT 1,
  student_notify_repeat_min INTEGER,
  student_next_notify_date TEXT, -- dd.mm.yyyy (сдвиг уведомлений ученику, не меняя срок платежа)
  enabled INTEGER NOT NULL DEFAULT 0,
  FOREIGN KEY(student_id) REFERENCES students(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS payments(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  student_id INTEGER NOT NULL,
  pay_type TEXT NOT NULL, -- prepay, postpay
  amount INTEGER NOT NULL,
  pay_date TEXT NOT NULL, -- dd.mm.yyyy
  source TEXT, -- mentor, student
  proof_file_id TEXT,
  note TEXT,
  created_at TEXT NOT NULL,
  FOREIGN KEY(student_id) REFERENCES students(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_payments_student ON payments(student_id);

CREATE TABLE IF NOT EXISTS reminders(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  student_id INTEGER,
  title TEXT NOT NULL,
  note TEXT,
  freq_type TEXT NOT NULL DEFAULT 'daily', -- daily, every_n_days, weekly
  freq_value INTEGER NOT NULL DEFAULT 1,
  days_of_week TEXT, -- e.g. "1,3,5"
  time_of_day TEXT NOT NULL DEFAULT '12:00', -- HH:MM
  next_run_at TEXT NOT NULL, -- ISO local datetime
  enabled INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY(student_id) REFERENCES students(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_reminders_next ON reminders(next_run_at);
CREATE INDEX IF NOT EXISTS idx_reminders_enabled ON reminders(enabled);

CREATE TABLE IF NOT EXISTS events(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  student_id INTEGER,
  event_type TEXT NOT NULL, -- HR, TECH, CALL, OTHER
  company TEXT,
  role TEXT,
  direction TEXT,
  link TEXT,
  start_at TEXT NOT NULL, -- ISO local datetime
  duration_min INTEGER NOT NULL DEFAULT 60,
  remind_before_min INTEGER NOT NULL DEFAULT 60,
  next_alert_at TEXT NOT NULL, -- ISO local datetime
  alerted INTEGER NOT NULL DEFAULT 0,
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY(student_id) REFERENCES students(id) ON DELETE SET NULL
);

CREATE INDEX IF NOT EXISTS idx_events_next_alert ON events(next_alert_at);
CREATE INDEX IF NOT EXISTS idx_events_active ON events(active);

CREATE TABLE IF NOT EXISTS alerts(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  alert_type TEXT NOT NULL, -- REMINDER, EVENT, PAYMENT
  related_table TEXT NOT NULL, -- reminders, events, students
  related_id INTEGER NOT NULL,
  student_id INTEGER,
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  due_at TEXT NOT NULL, -- ISO local datetime
  status TEXT NOT NULL DEFAULT 'PENDING', -- PENDING, SEEN
  message_id INTEGER,
  chat_id INTEGER NOT NULL,
  retry_after_min INTEGER NOT NULL DEFAULT 10,
  next_retry_at TEXT, -- ISO local datetime
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY(student_id) REFERENCES students(id) ON DELETE SET NULL
);

CREATE INDEX IF NOT EXISTS idx_alerts_status ON alerts(status);
CREATE INDEX IF NOT EXISTS idx_alerts_due ON alerts(due_at);
CREATE INDEX IF NOT EXISTS idx_alerts_retry ON alerts(next_retry_at);

CREATE TABLE IF NOT EXISTS user_states(
  user_id INTEGER PRIMARY KEY,
  state TEXT,
  data_json TEXT,
  updated_at TEXT NOT NULL
);


-- Requests from students (profile/accounts/payment proofs)
CREATE TABLE IF NOT EXISTS student_requests(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  owner_tg_id INTEGER NOT NULL,
  req_type TEXT NOT NULL, -- PROFILE, ACCOUNTS, PAYMENT
  student_id INTEGER,
  payload_json TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'PENDING', -- PENDING, APPROVED, REJECTED
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY(student_id) REFERENCES students(id) ON DELETE SET NULL
);

CREATE INDEX IF NOT EXISTS idx_requests_status ON student_requests(status);
CREATE INDEX IF NOT EXISTS idx_requests_owner ON student_requests(owner_tg_id);

CREATE TABLE IF NOT EXISTS enrollment_contracts(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  owner_tg_id INTEGER NOT NULL UNIQUE,
  owner_chat_id INTEGER,
  level_key TEXT NOT NULL, -- zero, not_zero
  track_key TEXT NOT NULL, -- zero-offer, interview-prep, grade-salary
  track_title TEXT NOT NULL,
  tariff_key TEXT NOT NULL,
  tariff_title TEXT NOT NULL,
  tariff_price TEXT NOT NULL,
  contract_file_path TEXT,
  sign_url TEXT,
  status TEXT NOT NULL DEFAULT 'sent', -- sent, signed, canceled
  note TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_enrollment_status ON enrollment_contracts(status, created_at);

CREATE TABLE IF NOT EXISTS autoapply_runs(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  owner_tg_id INTEGER NOT NULL,
  owner_chat_id INTEGER,
  login TEXT NOT NULL,
  direction TEXT NOT NULL,
  target_applies INTEGER NOT NULL DEFAULT 200,
  query_text TEXT,
  status TEXT NOT NULL DEFAULT 'created', -- created, launched, failed
  error_text TEXT,
  create_response_json TEXT,
  run_response_json TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_autoapply_runs_owner ON autoapply_runs(owner_tg_id, created_at);
CREATE INDEX IF NOT EXISTS idx_autoapply_runs_status ON autoapply_runs(status, created_at);


-- Stage reminder rules (этап = группа)
CREATE TABLE IF NOT EXISTS stage_reminder_rules(
  stage_id INTEGER PRIMARY KEY,
  enabled INTEGER NOT NULL DEFAULT 1,
  title TEXT NOT NULL DEFAULT 'Пинг',
  note TEXT NOT NULL DEFAULT 'Списаться, спросить прогресс и трудности.',
  freq_type TEXT NOT NULL DEFAULT 'daily', -- daily, every_n_days, weekly, once
  freq_value INTEGER NOT NULL DEFAULT 1,
  days_of_week TEXT, -- e.g. "1,3,5" (Mon=1..Sun=7)
  time_of_day TEXT NOT NULL DEFAULT '12:00',
  updated_at TEXT NOT NULL,
  FOREIGN KEY(stage_id) REFERENCES stages(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS student_stage_reminders(
  student_id INTEGER PRIMARY KEY,
  stage_id INTEGER NOT NULL,
  reminder_id INTEGER NOT NULL,
  FOREIGN KEY(student_id) REFERENCES students(id) ON DELETE CASCADE,
  FOREIGN KEY(stage_id) REFERENCES stages(id) ON DELETE CASCADE,
  FOREIGN KEY(reminder_id) REFERENCES reminders(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_stage_rules_enabled ON stage_reminder_rules(enabled);

CREATE TABLE IF NOT EXISTS student_access_codes(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  code TEXT NOT NULL UNIQUE,
  status TEXT NOT NULL DEFAULT 'active', -- active, used, revoked, expired
  created_by_admin_id INTEGER NOT NULL,
  created_at TEXT NOT NULL,
  expires_at TEXT, -- ISO local datetime
  used_by_user_id INTEGER,
  used_at TEXT, -- ISO local datetime
  revoked_at TEXT -- ISO local datetime
);

CREATE INDEX IF NOT EXISTS idx_student_codes_status ON student_access_codes(status);
CREATE INDEX IF NOT EXISTS idx_student_codes_expires ON student_access_codes(expires_at);
CREATE INDEX IF NOT EXISTS idx_student_codes_used_by ON student_access_codes(used_by_user_id);

CREATE TABLE IF NOT EXISTS material_steps(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  direction TEXT NOT NULL, -- java, golang, frontend, python
  position INTEGER NOT NULL,
  title TEXT NOT NULL,
  message_url TEXT NOT NULL,
  is_active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_material_steps_direction ON material_steps(direction, is_active, position);

CREATE TABLE IF NOT EXISTS user_material_progress(
  user_id INTEGER NOT NULL,
  step_id INTEGER NOT NULL,
  is_done INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL,
  PRIMARY KEY(user_id, step_id),
  FOREIGN KEY(step_id) REFERENCES material_steps(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_material_progress_user ON user_material_progress(user_id, is_done);

CREATE TABLE IF NOT EXISTS user_profiles(
  user_id INTEGER PRIMARY KEY,
  role_type TEXT NOT NULL DEFAULT 'regular', -- admin, student, regular
  username TEXT,
  first_seen_at TEXT NOT NULL, -- ISO local datetime
  last_seen_at TEXT NOT NULL, -- ISO local datetime
  last_start_at TEXT -- ISO local datetime
);

CREATE INDEX IF NOT EXISTS idx_user_profiles_role ON user_profiles(role_type);
CREATE INDEX IF NOT EXISTS idx_user_profiles_last_seen ON user_profiles(last_seen_at);

CREATE TABLE IF NOT EXISTS event_log(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  event_name TEXT NOT NULL,
  user_id INTEGER NOT NULL,
  payload_json TEXT,
  created_at TEXT NOT NULL -- ISO local datetime
);

CREATE INDEX IF NOT EXISTS idx_event_log_event ON event_log(event_name, created_at);
CREATE INDEX IF NOT EXISTS idx_event_log_user ON event_log(user_id, created_at);

CREATE TABLE IF NOT EXISTS broadcast_campaigns(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  created_by_admin_id INTEGER NOT NULL,
  scope TEXT NOT NULL, -- all, student, regular, admin
  template_kind TEXT NOT NULL DEFAULT 'manual', -- manual, auto
  source_chat_id INTEGER NOT NULL,
  source_message_id INTEGER NOT NULL,
  auto_rule_id INTEGER,
  total_targets INTEGER NOT NULL DEFAULT 0,
  sent_count INTEGER NOT NULL DEFAULT 0,
  failed_count INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'created', -- created, sent, deleted
  created_at TEXT NOT NULL,
  sent_at TEXT,
  deleted_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_campaigns_kind ON broadcast_campaigns(template_kind, created_at);
CREATE INDEX IF NOT EXISTS idx_campaigns_rule ON broadcast_campaigns(auto_rule_id, created_at);

CREATE TABLE IF NOT EXISTS broadcast_deliveries(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  campaign_id INTEGER NOT NULL,
  user_id INTEGER NOT NULL,
  chat_id INTEGER NOT NULL,
  message_id INTEGER,
  status TEXT NOT NULL, -- sent, failed, deleted
  error_text TEXT,
  sent_at TEXT,
  deleted_at TEXT,
  FOREIGN KEY(campaign_id) REFERENCES broadcast_campaigns(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_deliveries_campaign ON broadcast_deliveries(campaign_id, status);
CREATE INDEX IF NOT EXISTS idx_deliveries_user ON broadcast_deliveries(user_id, sent_at);

CREATE TABLE IF NOT EXISTS auto_broadcast_rules(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  created_by_admin_id INTEGER NOT NULL,
  scope TEXT NOT NULL, -- all, student, regular, admin
  inactivity_days INTEGER NOT NULL DEFAULT 7,
  source_chat_id INTEGER NOT NULL,
  source_message_id INTEGER NOT NULL,
  template_payload_json TEXT,
  enabled INTEGER NOT NULL DEFAULT 1,
  last_run_at TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_auto_rules_enabled ON auto_broadcast_rules(enabled, scope);

'''

def ensure_schema(conn: sqlite3.Connection) -> None:
    conn.executescript(SCHEMA_SQL)
    # lightweight migrations for existing db files
    def _has_col(table: str, col: str) -> bool:
        cols = conn.execute(f"PRAGMA table_info({table})").fetchall()
        return any(r[1] == col for r in cols)

    # students: owner fields
    for col, ddl in [
        ("owner_tg_id", "ALTER TABLE students ADD COLUMN owner_tg_id INTEGER"),
        ("owner_chat_id", "ALTER TABLE students ADD COLUMN owner_chat_id INTEGER"),
        ("owner_username", "ALTER TABLE students ADD COLUMN owner_username TEXT"),
        ("hh_birth_date", "ALTER TABLE students ADD COLUMN hh_birth_date TEXT"),
        ("hh_location", "ALTER TABLE students ADD COLUMN hh_location TEXT"),
        ("hh_salary_min", "ALTER TABLE students ADD COLUMN hh_salary_min INTEGER"),
        ("hh_salary_comfort", "ALTER TABLE students ADD COLUMN hh_salary_comfort INTEGER"),
    ]:
        try:
            if not _has_col("students", col):
                conn.execute(ddl)
        except Exception:
            pass

    # payments: proof fields
    for col, ddl in [
        ("source", "ALTER TABLE payments ADD COLUMN source TEXT"),
        ("proof_file_id", "ALTER TABLE payments ADD COLUMN proof_file_id TEXT"),
        ("note", "ALTER TABLE payments ADD COLUMN note TEXT"),
    ]:
        try:
            if not _has_col("payments", col):
                conn.execute(ddl)
        except Exception:
            pass

    conn.commit()

    # events: enrich interview/meeting metadata
    for col, ddl in [
        ("company", "ALTER TABLE events ADD COLUMN company TEXT"),
        ("role", "ALTER TABLE events ADD COLUMN role TEXT"),
        ("direction", "ALTER TABLE events ADD COLUMN direction TEXT"),
    ]:
        try:
            if not _has_col("events", col):
                conn.execute(ddl)
        except Exception:
            pass

    conn.commit()

    # student_postpay: student notification controls
    for col, ddl in [
        ("student_notify_enabled", "ALTER TABLE student_postpay ADD COLUMN student_notify_enabled INTEGER NOT NULL DEFAULT 1"),
        ("student_notify_repeat_min", "ALTER TABLE student_postpay ADD COLUMN student_notify_repeat_min INTEGER"),
        ("student_next_notify_date", "ALTER TABLE student_postpay ADD COLUMN student_next_notify_date TEXT"),
    ]:
        try:
            if not _has_col("student_postpay", col):
                conn.execute(ddl)
        except Exception:
            pass

    # auto broadcast rules: serialized template payload (sender-agnostic delivery)
    for col, ddl in [
        ("template_payload_json", "ALTER TABLE auto_broadcast_rules ADD COLUMN template_payload_json TEXT"),
    ]:
        try:
            if not _has_col("auto_broadcast_rules", col):
                conn.execute(ddl)
        except Exception:
            pass

    # user_profiles: keep last known Telegram username for admin-friendly stats listing
    for col, ddl in [
        ("username", "ALTER TABLE user_profiles ADD COLUMN username TEXT"),
    ]:
        try:
            if not _has_col("user_profiles", col):
                conn.execute(ddl)
        except Exception:
            pass

    conn.commit()
