from __future__ import annotations
import sqlite3
import threading
from typing import Any

def get_conn(db_path: str, busy_timeout_sec: int = 15) -> sqlite3.Connection:
    conn = sqlite3.connect(db_path, timeout=max(1, int(busy_timeout_sec)))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON;")
    conn.execute("PRAGMA journal_mode=WAL;")
    conn.execute("PRAGMA synchronous=NORMAL;")
    conn.execute(f"PRAGMA busy_timeout={int(max(1, busy_timeout_sec) * 1000)};")
    conn.execute("PRAGMA temp_store=MEMORY;")
    conn.execute("PRAGMA cache_size=-20000;")
    try:
        conn.execute("PRAGMA mmap_size=268435456;")
    except Exception:
        pass
    return conn


class ThreadLocalConnection:
    """A lightweight per-thread SQLite connection proxy.

    Keeps external API compatible with sqlite3.Connection methods used in codebase
    (`execute`, `cursor`, `commit`, `rollback`, `close`, etc.), while avoiding
    cross-thread contention on a single connection object.
    """

    def __init__(
        self,
        db_path: str,
        busy_timeout_sec: int = 15,
        bootstrap_conn: sqlite3.Connection | None = None,
    ) -> None:
        self._db_path = db_path
        self._busy_timeout_sec = int(max(1, busy_timeout_sec))
        self._local = threading.local()
        self._lock = threading.Lock()
        self._conns: dict[int, sqlite3.Connection] = {}
        if bootstrap_conn is not None:
            tid = threading.get_ident()
            self._local.conn = bootstrap_conn
            with self._lock:
                self._conns[tid] = bootstrap_conn

    def _get_conn(self) -> sqlite3.Connection:
        conn = getattr(self._local, "conn", None)
        if conn is not None:
            return conn
        conn = get_conn(self._db_path, busy_timeout_sec=self._busy_timeout_sec)
        self._local.conn = conn
        with self._lock:
            self._conns[threading.get_ident()] = conn
        return conn

    def execute(self, *args: Any, **kwargs: Any) -> sqlite3.Cursor:
        return self._get_conn().execute(*args, **kwargs)

    def executemany(self, *args: Any, **kwargs: Any) -> sqlite3.Cursor:
        return self._get_conn().executemany(*args, **kwargs)

    def executescript(self, *args: Any, **kwargs: Any) -> sqlite3.Cursor:
        return self._get_conn().executescript(*args, **kwargs)

    def cursor(self, *args: Any, **kwargs: Any) -> sqlite3.Cursor:
        return self._get_conn().cursor(*args, **kwargs)

    def commit(self) -> None:
        self._get_conn().commit()

    def rollback(self) -> None:
        self._get_conn().rollback()

    def close(self) -> None:
        with self._lock:
            conns = list(self._conns.values())
            self._conns.clear()
        for conn in conns:
            try:
                conn.close()
            except Exception:
                pass

    def __getattr__(self, name: str) -> Any:
        return getattr(self._get_conn(), name)
