from __future__ import annotations

import json
import sqlite3
from typing import Any

from app.services.timeutils import now, iso


def create(
    conn: sqlite3.Connection,
    tz: str,
    owner_tg_id: int,
    owner_chat_id: int | None,
    login: str,
    direction: str,
    target_applies: int,
    query_text: str,
    status: str,
    create_response: dict[str, Any] | None = None,
    run_response: dict[str, Any] | None = None,
    error_text: str | None = None,
) -> int:
    ts = iso(now(tz))
    cur = conn.execute(
        "INSERT INTO autoapply_runs("
        "owner_tg_id, owner_chat_id, login, direction, target_applies, query_text, status, "
        "error_text, create_response_json, run_response_json, created_at, updated_at"
        ") VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
        (
            int(owner_tg_id),
            int(owner_chat_id) if owner_chat_id is not None else None,
            (login or "").strip(),
            (direction or "").strip(),
            max(int(target_applies or 0), 0),
            (query_text or "").strip(),
            (status or "created").strip(),
            (error_text or "").strip() or None,
            json.dumps(create_response or {}, ensure_ascii=False),
            json.dumps(run_response or {}, ensure_ascii=False),
            ts,
            ts,
        ),
    )
    conn.commit()
    return int(cur.lastrowid)


def last_by_owner(conn: sqlite3.Connection, owner_tg_id: int) -> sqlite3.Row | None:
    return conn.execute(
        "SELECT * FROM autoapply_runs WHERE owner_tg_id=? ORDER BY id DESC LIMIT 1",
        (int(owner_tg_id),),
    ).fetchone()
