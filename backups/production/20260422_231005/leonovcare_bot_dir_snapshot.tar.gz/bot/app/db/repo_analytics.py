from __future__ import annotations

import datetime as dt
import json
import sqlite3

from app.db import repo_materials
from app.services.timeutils import iso, now

ROLE_ADMIN = "admin"
ROLE_STUDENT = "student"
ROLE_REGULAR = "regular"


def _normalize_role(role_type: str | None) -> str:
    r = (role_type or "").strip().lower()
    if r in {ROLE_ADMIN, ROLE_STUDENT, ROLE_REGULAR}:
        return r
    return ROLE_REGULAR


def touch_user(
    conn: sqlite3.Connection,
    tz: str,
    user_id: int,
    role_type: str | None = None,
    username: str | None = None,
    is_start: bool = False,
) -> None:
    uid = int(user_id)
    # System/technical events may use non-positive user ids; do not pollute user profiles.
    if uid <= 0:
        return
    ts = iso(now(tz))
    uname = (username or "").strip()
    if uname.startswith("@"):
        uname = uname[1:]
    if not uname:
        uname = None

    row = conn.execute("SELECT role_type, username FROM user_profiles WHERE user_id=?", (uid,)).fetchone()
    if not row:
        role = _normalize_role(role_type)
        conn.execute(
            "INSERT INTO user_profiles(user_id, role_type, username, first_seen_at, last_seen_at, last_start_at) "
            "VALUES(?,?,?,?,?,?)",
            (uid, role, uname, ts, ts, ts if is_start else None),
        )
        conn.commit()
        return

    current_role = _normalize_role(row["role_type"])
    current_username = (row["username"] or "").strip() if "username" in row.keys() else ""
    next_username = uname or (current_username or None)
    new_role = _normalize_role(role_type) if role_type else current_role
    if current_role == ROLE_ADMIN:
        new_role = ROLE_ADMIN
    elif current_role == ROLE_STUDENT and new_role == ROLE_REGULAR:
        new_role = ROLE_STUDENT

    if is_start:
        conn.execute(
            "UPDATE user_profiles SET role_type=?, username=?, last_seen_at=?, last_start_at=? WHERE user_id=?",
            (new_role, next_username, ts, ts, uid),
        )
    else:
        conn.execute(
            "UPDATE user_profiles SET role_type=?, username=?, last_seen_at=? WHERE user_id=?",
            (new_role, next_username, ts, uid),
        )
    conn.commit()


def set_role(conn: sqlite3.Connection, tz: str, user_id: int, role_type: str) -> None:
    touch_user(conn, tz, int(user_id), role_type=role_type, username=None, is_start=False)


def log_event(
    conn: sqlite3.Connection,
    tz: str,
    user_id: int,
    event_name: str,
    payload: dict | None = None,
    username: str | None = None,
) -> None:
    uid = int(user_id)
    if uid > 0:
        touch_user(conn, tz, uid, username=username)
    conn.execute(
        "INSERT INTO event_log(event_name, user_id, payload_json, created_at) VALUES(?,?,?,?)",
        (
            (event_name or "").strip(),
            uid,
            json.dumps(payload or {}, ensure_ascii=False),
            iso(now(tz)),
        ),
    )
    conn.commit()


def user_totals(conn: sqlite3.Connection) -> dict:
    totals = {ROLE_ADMIN: 0, ROLE_STUDENT: 0, ROLE_REGULAR: 0, "all": 0}
    rows = conn.execute(
        "SELECT role_type, COUNT(1) AS c FROM user_profiles GROUP BY role_type"
    ).fetchall()
    for r in rows:
        role = _normalize_role(r["role_type"])
        totals[role] = int(r["c"] or 0)
    totals["all"] = totals[ROLE_ADMIN] + totals[ROLE_STUDENT] + totals[ROLE_REGULAR]
    return totals


def new_users(conn: sqlite3.Connection, tz: str, days: int) -> int:
    cutoff = iso(now(tz) - dt.timedelta(days=max(1, int(days))))
    row = conn.execute(
        "SELECT COUNT(1) AS c FROM user_profiles WHERE first_seen_at>=?",
        (cutoff,),
    ).fetchone()
    return int(row["c"] or 0) if row else 0


def active_users(conn: sqlite3.Connection, tz: str, days: int) -> int:
    cutoff = iso(now(tz) - dt.timedelta(days=max(1, int(days))))
    row = conn.execute(
        "SELECT COUNT(1) AS c FROM user_profiles WHERE last_seen_at>=?",
        (cutoff,),
    ).fetchone()
    return int(row["c"] or 0) if row else 0


def dau_wau_mau(conn: sqlite3.Connection, tz: str) -> dict:
    dau = active_users(conn, tz, 1)
    wau = active_users(conn, tz, 7)
    mau = active_users(conn, tz, 30)
    stickiness = round((dau / mau) * 100, 2) if mau > 0 else 0.0
    return {"dau": dau, "wau": wau, "mau": mau, "stickiness": stickiness}


def retention(conn: sqlite3.Connection) -> dict:
    row = conn.execute("SELECT COUNT(1) AS c FROM user_profiles").fetchone()
    cohort = int(row["c"] or 0) if row else 0
    out = {"cohort": cohort, "d1": 0.0, "d7": 0.0, "d30": 0.0}
    if cohort <= 0:
        return out
    for days, key in ((1, "d1"), (7, "d7"), (30, "d30")):
        r = conn.execute(
            "SELECT COUNT(1) AS c "
            "FROM user_profiles "
            "WHERE (julianday(last_seen_at) - julianday(first_seen_at)) >= ?",
            (float(days),),
        ).fetchone()
        retained = int(r["c"] or 0) if r else 0
        out[key] = round((retained / cohort) * 100, 2)
    return out


def funnel_distinct_users(conn: sqlite3.Connection, event_names: list[str]) -> dict[str, int]:
    out: dict[str, int] = {}
    for event in event_names:
        r = conn.execute(
            "SELECT COUNT(DISTINCT user_id) AS c FROM event_log WHERE event_name=?",
            ((event or "").strip(),),
        ).fetchone()
        out[event] = int(r["c"] or 0) if r else 0
    return out


def _parse_payload(raw: str | None) -> dict:
    if not raw:
        return {}
    try:
        val = json.loads(raw)
        return val if isinstance(val, dict) else {}
    except Exception:
        return {}


def direction_progress(conn: sqlite3.Connection) -> list[dict]:
    rows: list[dict] = []
    for direction in repo_materials.DIRECTIONS:
        total_steps_row = conn.execute(
            "SELECT COUNT(1) AS c FROM material_steps WHERE direction=? AND is_active=1",
            (direction,),
        ).fetchone()
        total_steps = int(total_steps_row["c"] or 0) if total_steps_row else 0

        started_users: set[int] = set()
        ev_rows = conn.execute(
            "SELECT user_id, payload_json FROM event_log WHERE event_name='funnel.materials.direction_selected'"
        ).fetchall()
        for ev in ev_rows:
            payload = _parse_payload(ev["payload_json"])
            if (payload.get("direction") or "").strip().lower() == direction:
                started_users.add(int(ev["user_id"]))

        done_rows = conn.execute(
            "SELECT p.user_id, SUM(CASE WHEN p.is_done=1 THEN 1 ELSE 0 END) AS done_cnt "
            "FROM user_material_progress p "
            "JOIN material_steps s ON s.id=p.step_id "
            "WHERE s.direction=? AND s.is_active=1 "
            "GROUP BY p.user_id",
            (direction,),
        ).fetchall()
        done_map: dict[int, int] = {int(r["user_id"]): int(r["done_cnt"] or 0) for r in done_rows}
        completed = 0
        sum_percent = 0.0
        for uid in started_users:
            done_cnt = done_map.get(uid, 0)
            if total_steps > 0 and done_cnt >= total_steps:
                completed += 1
            user_percent = (done_cnt * 100.0 / total_steps) if total_steps > 0 else 0.0
            sum_percent += user_percent
        started = len(started_users)
        in_progress = max(0, started - completed)
        avg_percent = round((sum_percent / started), 2) if started > 0 else 0.0
        rows.append(
            {
                "direction": direction,
                "started": started,
                "in_progress": in_progress,
                "completed": completed,
                "avg_percent": avg_percent,
                "steps_total": total_steps,
            }
        )
    return rows


def material_step_dropoff(conn: sqlite3.Connection) -> list[dict]:
    open_rows = conn.execute(
        "SELECT user_id, payload_json FROM event_log WHERE event_name='funnel.materials.step_open'"
    ).fetchall()
    opened_by_step: dict[int, set[int]] = {}
    for r in open_rows:
        payload = _parse_payload(r["payload_json"])
        step_id = payload.get("step_id")
        try:
            sid = int(step_id)
        except Exception:
            continue
        opened_by_step.setdefault(sid, set()).add(int(r["user_id"]))

    results: list[dict] = []
    for d in repo_materials.DIRECTIONS:
        steps = conn.execute(
            "SELECT id, position, title FROM material_steps WHERE direction=? AND is_active=1 ORDER BY position",
            (d,),
        ).fetchall()
        prev_opens: int | None = None
        for s in steps:
            sid = int(s["id"])
            opens = len(opened_by_step.get(sid, set()))
            drop_abs = 0
            drop_pct = 0.0
            if prev_opens is not None and prev_opens > 0:
                drop_abs = max(0, prev_opens - opens)
                drop_pct = round((drop_abs / prev_opens) * 100, 2)
            results.append(
                {
                    "direction": d,
                    "step_id": sid,
                    "position": int(s["position"]),
                    "title": s["title"],
                    "opens": opens,
                    "drop_abs": drop_abs,
                    "drop_pct": drop_pct,
                }
            )
            prev_opens = opens
    results.sort(key=lambda x: (-x["drop_abs"], -x["drop_pct"], x["direction"], x["position"]))
    return results


def operational_metrics(conn: sqlite3.Connection) -> dict:
    out = {
        "alerts_total": 0,
        "alerts_pending": 0,
        "alerts_seen": 0,
        "alerts_delivered": 0,
        "avg_alert_delay_min": 0.0,
        "scheduler_errors": 0,
        "alert_send_errors": 0,
    }

    row = conn.execute("SELECT COUNT(1) AS c FROM alerts").fetchone()
    out["alerts_total"] = int(row["c"] or 0) if row else 0
    row = conn.execute("SELECT COUNT(1) AS c FROM alerts WHERE status='PENDING'").fetchone()
    out["alerts_pending"] = int(row["c"] or 0) if row else 0
    row = conn.execute("SELECT COUNT(1) AS c FROM alerts WHERE status='SEEN'").fetchone()
    out["alerts_seen"] = int(row["c"] or 0) if row else 0
    row = conn.execute("SELECT COUNT(1) AS c FROM alerts WHERE message_id IS NOT NULL").fetchone()
    out["alerts_delivered"] = int(row["c"] or 0) if row else 0

    row = conn.execute(
        "SELECT AVG((julianday(updated_at) - julianday(due_at))*24*60) AS avg_m "
        "FROM alerts WHERE message_id IS NOT NULL"
    ).fetchone()
    out["avg_alert_delay_min"] = round(float(row["avg_m"] or 0.0), 2) if row else 0.0

    row = conn.execute(
        "SELECT COUNT(1) AS c FROM event_log WHERE event_name='ops.scheduler_error'"
    ).fetchone()
    out["scheduler_errors"] = int(row["c"] or 0) if row else 0
    row = conn.execute(
        "SELECT COUNT(1) AS c FROM event_log WHERE event_name='ops.alert_send_error'"
    ).fetchone()
    out["alert_send_errors"] = int(row["c"] or 0) if row else 0

    return out
