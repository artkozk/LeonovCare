"""DB package.

This project historically used `connect(cfg)` from `app.db`.
During refactors the low-level connector was moved to `app.db.core.get_conn`,
but `connect` is still referenced from `main.py`.

Expose a stable `connect` helper that:
 - opens sqlite connection with correct row_factory/pragmas
 - ensures schema exists
 - seeds reference tables (directions/stages/rules) on empty DB
"""

from __future__ import annotations

import sqlite3
from typing import Union, TYPE_CHECKING, Any

from .core import ThreadLocalConnection, get_conn
from .schema import ensure_schema
from .seed import ensure_seed

if TYPE_CHECKING:  # pragma: no cover
    from app.config import Config


def connect(cfg_or_path: Union["Config", str]) -> Any:
    """Create DB connection and prepare schema/seed.

    Accepts either Config (preferred) or direct db_path.
    """
    db_path = getattr(cfg_or_path, "DB_PATH", None) or str(cfg_or_path)
    busy_timeout_sec = int(getattr(cfg_or_path, "DB_BUSY_TIMEOUT_SEC", 15))
    bootstrap = get_conn(db_path, busy_timeout_sec=busy_timeout_sec)
    ensure_schema(bootstrap)
    ensure_seed(bootstrap)
    return ThreadLocalConnection(db_path, busy_timeout_sec=busy_timeout_sec, bootstrap_conn=bootstrap)


__all__ = ["connect", "get_conn", "ensure_schema", "ensure_seed"]
