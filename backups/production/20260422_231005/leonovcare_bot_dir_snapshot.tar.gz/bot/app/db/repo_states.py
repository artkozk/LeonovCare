from __future__ import annotations

import json
import sqlite3

from app.services.timeutils import iso, now


def _default_tz() -> str:
    # Local import to avoid circular imports.
    from app.config import TZ

    return TZ


def get_state(conn: sqlite3.Connection, user_id: int) -> tuple[str | None, dict]:
    cur = conn.execute("SELECT state, data_json FROM user_states WHERE user_id=?", (user_id,))
    row = cur.fetchone()
    if not row:
        return None, {}
    state = row["state"]
    try:
        data = json.loads(row["data_json"] or "{}")
    except Exception:
        data = {}
    if not isinstance(data, dict):
        data = {}
    return state, data


def set_state(
    conn: sqlite3.Connection,
    user_id: int,
    state: str | None,
    data: dict,
    tz: str | None = None,
) -> None:
    """Persist user's FSM state.

    tz is optional for backward-compatibility with handlers that were written
    before we introduced timezone-aware timestamps.
    """
    if tz is None:
        tz = _default_tz()

    payload = json.dumps(data or {}, ensure_ascii=False)
    ts = iso(now(tz))
    conn.execute(
        "INSERT INTO user_states(user_id, state, data_json, updated_at) VALUES(?,?,?,?) "
        "ON CONFLICT(user_id) DO UPDATE SET state=excluded.state, data_json=excluded.data_json, updated_at=excluded.updated_at",
        (user_id, state, payload, ts),
    )
    conn.commit()


def clear_state(conn: sqlite3.Connection, user_id: int, tz: str | None = None) -> None:
    if tz is None:
        tz = _default_tz()
    set_state(conn, user_id, None, {}, tz)
