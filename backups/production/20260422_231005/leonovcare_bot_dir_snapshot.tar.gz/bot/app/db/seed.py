from __future__ import annotations
import sqlite3
import datetime as dt

DEFAULT_DIRECTIONS = [
    ("java", 10),
    ("golang", 20),
    ("frontend", 30),
    ("python", 40),
    ("c++", 50),
]

DEFAULT_STAGES = [
    # базовые этапы (можно расширять)
    ("С нуля", 10),
    ("Дообучение", 20),
    ("Собеседования", 30),
    ("Дипфейк", 40),

    # старые/дополнительные (оставляем для совместимости)
    ("Вступил", 100),
    ("Проект", 110),
    ("Моки", 120),
    ("Вышел на рынок", 130),
    ("Оффер", 140),
]


def ensure_seed(conn: sqlite3.Connection) -> None:
    cur = conn.cursor()

    cur.execute("SELECT COUNT(*) AS c FROM directions")
    if cur.fetchone()["c"] == 0:
        cur.executemany("INSERT INTO directions(name, sort) VALUES (?,?)", DEFAULT_DIRECTIONS)

    # directions/stages: always ensure defaults exist (older DBs may already have rows)
    cur.executemany(
        "INSERT OR IGNORE INTO stages(name, sort) VALUES (?,?)",
        DEFAULT_STAGES,
    )

    # Stage reminder rules defaults
    ts = dt.datetime.now().replace(microsecond=0).isoformat()
    stages = conn.execute("SELECT id, name FROM stages").fetchall()
    for st in stages:
        exists = conn.execute("SELECT 1 FROM stage_reminder_rules WHERE stage_id=? LIMIT 1", (st["id"],)).fetchone()
        if exists:
            continue

        title = "Пинг"
        note = "Списаться, спросить прогресс и трудности."
        if (st["name"] or "").strip().lower() == "дипфейк":
            title = "Дипфейк: контроль"
            note = "Проверить прогресс по дипфейку, сложности, договориться о следующем шаге."

        conn.execute(
            "INSERT INTO stage_reminder_rules(stage_id, enabled, title, note, freq_type, freq_value, days_of_week, time_of_day, updated_at) "
            "VALUES(?,?,?,?,?,?,?,?,?)",
            (st["id"], 1, title, note, "daily", 1, None, "12:00", ts)
        )

    conn.commit()
