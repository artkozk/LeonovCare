from __future__ import annotations

import datetime as dt
import sqlite3

from app.services.timeutils import iso, now

SCOPE_ALL = "all"
SCOPE_STUDENT = "student"
SCOPE_REGULAR = "regular"
SCOPE_ADMIN = "admin"

STATUS_SENT = "sent"
STATUS_FAILED = "failed"
STATUS_DELETED = "deleted"

KIND_MANUAL = "manual"
KIND_AUTO = "auto"


def _norm_scope(scope: str | None) -> str:
    s = (scope or "").strip().lower()
    if s in {SCOPE_ALL, SCOPE_STUDENT, SCOPE_REGULAR, SCOPE_ADMIN}:
        return s
    return SCOPE_ALL


def _base_recipients_sql(scope: str) -> tuple[str, tuple]:
    scope = _norm_scope(scope)
    where = "1=1"
    args: list[object] = []
    if scope == SCOPE_STUDENT:
        where = "up.role_type='student'"
    elif scope == SCOPE_REGULAR:
        where = "up.role_type='regular'"
    elif scope == SCOPE_ADMIN:
        where = "up.role_type='admin'"
    else:
        where = "up.role_type IN ('student','regular','admin')"
    sql = (
        "SELECT "
        "up.user_id, up.role_type, up.last_seen_at, "
        "COALESCE(("
        "  SELECT s.owner_chat_id FROM students s "
        "  WHERE s.owner_tg_id=up.user_id AND s.archived=0 "
        "  ORDER BY s.id DESC LIMIT 1"
        "), up.user_id) AS chat_id "
        "FROM user_profiles up "
        f"WHERE {where}"
    )
    return sql, tuple(args)


def list_recipients(conn: sqlite3.Connection, scope: str) -> list[sqlite3.Row]:
    sql, args = _base_recipients_sql(scope)
    rows = conn.execute(sql, args).fetchall()
    out: list[sqlite3.Row] = []
    seen_chat_ids: set[int] = set()
    for r in rows:
        chat_id = r["chat_id"]
        if chat_id is None:
            continue
        cid = int(chat_id)
        if cid in seen_chat_ids:
            continue
        seen_chat_ids.add(cid)
        out.append(r)
    return out


def list_inactive_recipients(conn: sqlite3.Connection, tz: str, scope: str, inactivity_days: int) -> list[sqlite3.Row]:
    rows = list_recipients(conn, scope)
    threshold = now(tz) - dt.timedelta(days=max(1, int(inactivity_days)))
    out: list[sqlite3.Row] = []
    for r in rows:
        ls = (r["last_seen_at"] or "").strip()
        try:
            d = dt.datetime.fromisoformat(ls)
        except Exception:
            continue
        if d.tzinfo is None:
            d = d.replace(tzinfo=threshold.tzinfo)
        if d <= threshold:
            out.append(r)
    return out


def create_campaign(
    conn: sqlite3.Connection,
    tz: str,
    created_by_admin_id: int,
    scope: str,
    source_chat_id: int,
    source_message_id: int,
    total_targets: int,
    template_kind: str = KIND_MANUAL,
    auto_rule_id: int | None = None,
) -> int:
    ts = iso(now(tz))
    cur = conn.execute(
        "INSERT INTO broadcast_campaigns("
        "created_by_admin_id, scope, template_kind, source_chat_id, source_message_id, auto_rule_id, "
        "total_targets, sent_count, failed_count, status, created_at, sent_at, deleted_at"
        ") VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (
            int(created_by_admin_id),
            _norm_scope(scope),
            (template_kind or KIND_MANUAL).strip().lower(),
            int(source_chat_id),
            int(source_message_id),
            int(auto_rule_id) if auto_rule_id is not None else None,
            int(total_targets),
            0,
            0,
            "created",
            ts,
            None,
            None,
        ),
    )
    conn.commit()
    return int(cur.lastrowid)


def add_delivery(
    conn: sqlite3.Connection,
    campaign_id: int,
    user_id: int,
    chat_id: int,
    message_id: int | None,
    status: str,
    error_text: str | None,
    sent_at: str | None,
) -> None:
    conn.execute(
        "INSERT INTO broadcast_deliveries(campaign_id, user_id, chat_id, message_id, status, error_text, sent_at, deleted_at) "
        "VALUES(?,?,?,?,?,?,?,NULL)",
        (
            int(campaign_id),
            int(user_id),
            int(chat_id),
            int(message_id) if message_id is not None else None,
            (status or STATUS_FAILED).strip().lower(),
            (error_text or "").strip()[:1000] if error_text else None,
            sent_at,
        ),
    )
    conn.commit()


def finalize_campaign(conn: sqlite3.Connection, tz: str, campaign_id: int, sent_count: int, failed_count: int) -> None:
    conn.execute(
        "UPDATE broadcast_campaigns SET sent_count=?, failed_count=?, status='sent', sent_at=? WHERE id=?",
        (int(sent_count), int(failed_count), iso(now(tz)), int(campaign_id)),
    )
    conn.commit()


def list_campaigns(conn: sqlite3.Connection, limit: int = 20) -> list[sqlite3.Row]:
    return conn.execute(
        "SELECT * FROM broadcast_campaigns ORDER BY id DESC LIMIT ?",
        (int(limit),),
    ).fetchall()


def get_campaign(conn: sqlite3.Connection, campaign_id: int) -> sqlite3.Row | None:
    return conn.execute(
        "SELECT * FROM broadcast_campaigns WHERE id=?",
        (int(campaign_id),),
    ).fetchone()


def list_deliveries(conn: sqlite3.Connection, campaign_id: int, status: str | None = None) -> list[sqlite3.Row]:
    if status:
        return conn.execute(
            "SELECT * FROM broadcast_deliveries WHERE campaign_id=? AND status=? ORDER BY id",
            (int(campaign_id), (status or "").strip().lower()),
        ).fetchall()
    return conn.execute(
        "SELECT * FROM broadcast_deliveries WHERE campaign_id=? ORDER BY id",
        (int(campaign_id),),
    ).fetchall()


def mark_delivery_deleted(conn: sqlite3.Connection, tz: str, delivery_id: int) -> None:
    conn.execute(
        "UPDATE broadcast_deliveries SET status=?, deleted_at=? WHERE id=?",
        (STATUS_DELETED, iso(now(tz)), int(delivery_id)),
    )
    conn.commit()


def mark_campaign_deleted(conn: sqlite3.Connection, tz: str, campaign_id: int) -> None:
    conn.execute(
        "UPDATE broadcast_campaigns SET status='deleted', deleted_at=? WHERE id=?",
        (iso(now(tz)), int(campaign_id)),
    )
    conn.commit()


def create_auto_rule(
    conn: sqlite3.Connection,
    tz: str,
    created_by_admin_id: int,
    scope: str,
    inactivity_days: int,
    source_chat_id: int,
    source_message_id: int,
    template_payload_json: str | None = None,
) -> int:
    ts = iso(now(tz))
    cur = conn.execute(
        "INSERT INTO auto_broadcast_rules("
        "created_by_admin_id, scope, inactivity_days, source_chat_id, source_message_id, template_payload_json, enabled, last_run_at, created_at, updated_at"
        ") VALUES(?,?,?,?,?,?,1,NULL,?,?)",
        (
            int(created_by_admin_id),
            _norm_scope(scope),
            max(1, int(inactivity_days)),
            int(source_chat_id),
            int(source_message_id),
            (template_payload_json or "").strip() if template_payload_json else None,
            ts,
            ts,
        ),
    )
    conn.commit()
    return int(cur.lastrowid)


def list_auto_rules(conn: sqlite3.Connection, only_enabled: bool = False, limit: int = 50) -> list[sqlite3.Row]:
    if only_enabled:
        return conn.execute(
            "SELECT * FROM auto_broadcast_rules WHERE enabled=1 ORDER BY id DESC LIMIT ?",
            (int(limit),),
        ).fetchall()
    return conn.execute(
        "SELECT * FROM auto_broadcast_rules ORDER BY id DESC LIMIT ?",
        (int(limit),),
    ).fetchall()


def get_auto_rule(conn: sqlite3.Connection, rule_id: int) -> sqlite3.Row | None:
    return conn.execute(
        "SELECT * FROM auto_broadcast_rules WHERE id=?",
        (int(rule_id),),
    ).fetchone()


def set_auto_rule_enabled(conn: sqlite3.Connection, tz: str, rule_id: int, enabled: bool) -> None:
    conn.execute(
        "UPDATE auto_broadcast_rules SET enabled=?, updated_at=? WHERE id=?",
        (1 if enabled else 0, iso(now(tz)), int(rule_id)),
    )
    conn.commit()


def delete_auto_rule(conn: sqlite3.Connection, rule_id: int) -> None:
    conn.execute("DELETE FROM auto_broadcast_rules WHERE id=?", (int(rule_id),))
    conn.commit()


def set_auto_rule_last_run(conn: sqlite3.Connection, tz: str, rule_id: int) -> None:
    conn.execute(
        "UPDATE auto_broadcast_rules SET last_run_at=?, updated_at=? WHERE id=?",
        (iso(now(tz)), iso(now(tz)), int(rule_id)),
    )
    conn.commit()


def last_auto_send_at(conn: sqlite3.Connection, rule_id: int, user_id: int) -> str | None:
    row = conn.execute(
        "SELECT bd.sent_at "
        "FROM broadcast_deliveries bd "
        "JOIN broadcast_campaigns bc ON bc.id=bd.campaign_id "
        "WHERE bc.auto_rule_id=? AND bd.user_id=? AND bd.status=? AND bd.sent_at IS NOT NULL "
        "ORDER BY bd.sent_at DESC LIMIT 1",
        (int(rule_id), int(user_id), STATUS_SENT),
    ).fetchone()
    if not row:
        return None
    return row["sent_at"]
