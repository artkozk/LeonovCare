from __future__ import annotations

import sqlite3

from telebot import TeleBot
from telebot.apihelper import ApiTelegramException

from app.config import Config
from app.handlers.registry import init_handlers


def build_app(cfg: Config, conn: sqlite3.Connection) -> tuple[TeleBot, dict]:
    bot = TeleBot(cfg.BOT_TOKEN, parse_mode="HTML", worker_threads=cfg.BOT_WORKER_THREADS)

    # Telegram may return: "Bad Request: message is not modified" when we try to edit
    # an already identical message (common on repeated button taps). Swallow it globally.
    _orig_edit_message_text = bot.edit_message_text

    def _safe_edit_message_text(text, chat_id, message_id, *args, **kwargs):
        try:
            return _orig_edit_message_text(text, chat_id, message_id, *args, **kwargs)
        except ApiTelegramException as e:
            if getattr(e, "error_code", None) == 400 and "message is not modified" in str(e):
                return None
            raise

    bot.edit_message_text = _safe_edit_message_text  # type: ignore

    _orig_edit_reply_markup = bot.edit_message_reply_markup

    def _safe_edit_message_reply_markup(chat_id, message_id, *args, **kwargs):
        try:
            return _orig_edit_reply_markup(chat_id, message_id, *args, **kwargs)
        except ApiTelegramException as e:
            if getattr(e, "error_code", None) == 400 and "message is not modified" in str(e):
                return None
            raise

    bot.edit_message_reply_markup = _safe_edit_message_reply_markup  # type: ignore

    ctx = {
        "cfg": cfg,
        "conn": conn,
    }

    init_handlers(bot, ctx)

    return bot, ctx
