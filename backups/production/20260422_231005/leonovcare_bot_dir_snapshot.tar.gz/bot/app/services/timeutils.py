from __future__ import annotations
import datetime as dt
from zoneinfo import ZoneInfo
from typing import Optional

def tzinfo(tz: str) -> ZoneInfo:
    return ZoneInfo(tz)

def now(tz: str) -> dt.datetime:
    return dt.datetime.now(tzinfo(tz)).replace(microsecond=0)

def iso(dt_obj: dt.datetime) -> str:
    return dt_obj.replace(microsecond=0).isoformat()

def parse_date_ddmmyyyy(s: str) -> Optional[dt.date]:
    s = (s or '').strip()
    try:
        d, m, y = s.split(".")
        return dt.date(int(y), int(m), int(d))
    except Exception:
        return None


def parse_date_ddmm_future(s: str, tz: str) -> Optional[dt.date]:
    """Parse date in 'dd.mm' (year auto, next future/now) or 'dd.mm.yyyy'."""
    s = (s or "").strip()
    if not s:
        return None
    if s.count(".") == 2:
        return parse_date_ddmmyyyy(s)
    if s.count(".") != 1:
        return None
    try:
        d_s, m_s = s.split(".")
        d = int(d_s)
        m = int(m_s)
        y = now(tz).date().year
        candidate = dt.date(y, m, d)
        if candidate < now(tz).date():
            candidate = dt.date(y + 1, m, d)
        return candidate
    except Exception:
        return None


def parse_date_ddmm_past(s: str, tz: str) -> Optional[dt.date]:
    """Parse date in 'dd.mm' (year auto, past/now) or 'dd.mm.yyyy'."""
    s = (s or "").strip()
    if not s:
        return None
    if s.count(".") == 2:
        return parse_date_ddmmyyyy(s)
    if s.count(".") != 1:
        return None
    try:
        d_s, m_s = s.split(".")
        d = int(d_s)
        m = int(m_s)
        y = now(tz).date().year
        candidate = dt.date(y, m, d)
        if candidate > now(tz).date():
            candidate = dt.date(y - 1, m, d)
        return candidate
    except Exception:
        return None

def format_date_ddmmyyyy(d: dt.date) -> str:
    return f"{d.day:02d}.{d.month:02d}.{d.year:04d}"

def parse_time_hhmm(s: str) -> Optional[dt.time]:
    s=(s or '').strip()
    try:
        hh, mm = s.split(":")
        return dt.time(int(hh), int(mm))
    except Exception:
        return None

def parse_datetime_ddmmyyyy_hhmm(s: str, tz: str) -> Optional[dt.datetime]:
    s=(s or '').strip()
    # accept "dd.mm HH:MM" (year auto) or "dd.mm.yyyy HH:MM"
    try:
        date_part, time_part = s.split()
        d = parse_date_ddmm_future(date_part, tz)
        t = parse_time_hhmm(time_part)
        if not d or not t:
            return None
        return dt.datetime.combine(d, t, tzinfo=tzinfo(tz)).replace(microsecond=0)
    except Exception:
        return None


def parse_datetime_ddmm_past_hhmm(s: str, tz: str) -> Optional[dt.datetime]:
    """Parse datetime for past/now context: 'dd.mm HH:MM' or 'dd.mm.yyyy HH:MM'."""
    s = (s or "").strip()
    try:
        date_part, time_part = s.split()
        d = parse_date_ddmm_past(date_part, tz)
        t = parse_time_hhmm(time_part)
        if not d or not t:
            return None
        return dt.datetime.combine(d, t, tzinfo=tzinfo(tz)).replace(microsecond=0)
    except Exception:
        return None


def parse_iso_datetime(s: str, tz: str) -> Optional[dt.datetime]:
    try:
        x = dt.datetime.fromisoformat((s or "").strip())
        if x.tzinfo is None:
            x = x.replace(tzinfo=tzinfo(tz))
        return x.astimezone(tzinfo(tz)).replace(microsecond=0)
    except Exception:
        return None


def format_dt_ddmmyyyy_hhmm(s_or_dt: str | dt.datetime, tz: str) -> str:
    if isinstance(s_or_dt, dt.datetime):
        x = s_or_dt
        if x.tzinfo is None:
            x = x.replace(tzinfo=tzinfo(tz))
        x = x.astimezone(tzinfo(tz))
    else:
        x = parse_iso_datetime(s_or_dt, tz)
    if not x:
        return "—"
    return x.strftime("%d.%m.%Y %H:%M")

def start_of_day(d: dt.date, tz: str) -> dt.datetime:
    return dt.datetime.combine(d, dt.time(0,0), tzinfo=tzinfo(tz)).replace(microsecond=0)

def end_of_day(d: dt.date, tz: str) -> dt.datetime:
    return dt.datetime.combine(d, dt.time(23,59,59), tzinfo=tzinfo(tz)).replace(microsecond=0)

def add_days(dt_obj: dt.datetime, days: int) -> dt.datetime:
    return (dt_obj + dt.timedelta(days=days)).replace(microsecond=0)

def add_months(d: dt.date, months: int) -> dt.date:
    # simple calendar add months
    y = d.year + (d.month - 1 + months) // 12
    m = (d.month - 1 + months) % 12 + 1
    day = min(d.day, [31, 29 if (y%4==0 and (y%100!=0 or y%400==0)) else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][m-1])
    return dt.date(y, m, day)
