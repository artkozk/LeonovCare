from __future__ import annotations

import json
from typing import Any

from telebot import TeleBot
from telebot.types import Message


ALLOWED_TEMPLATE_TYPES = {
    "text",
    "photo",
    "video",
    "document",
    "animation",
    "audio",
    "voice",
}


def message_id_from_result(result: object) -> int | None:
    if result is None:
        return None
    mid = getattr(result, "message_id", None)
    if mid is not None:
        try:
            return int(mid)
        except Exception:
            return None
    try:
        return int(result)
    except Exception:
        return None


def encode_template_payload(payload: dict | None) -> str | None:
    if not payload:
        return None
    return json.dumps(payload, ensure_ascii=False)


def decode_template_payload(raw: str | None) -> dict | None:
    if not raw:
        return None
    try:
        val = json.loads(raw)
    except Exception:
        return None
    if not isinstance(val, dict):
        return None
    t = (val.get("type") or "").strip().lower()
    if t not in ALLOWED_TEMPLATE_TYPES:
        return None
    return val


def template_from_message(m: Message) -> dict | None:
    ctype = (getattr(m, "content_type", "") or "").strip().lower()
    if ctype not in ALLOWED_TEMPLATE_TYPES:
        return None

    html = (getattr(m, "html_text", "") or "").strip()
    payload: dict[str, Any] = {
        "type": ctype,
        "html": html,
    }
    if ctype == "text":
        payload["text"] = (m.text or "").strip()
        return payload

    if ctype == "photo":
        photos = getattr(m, "photo", None) or []
        if not photos:
            return None
        payload["file_id"] = getattr(photos[-1], "file_id", None)
        return payload if payload["file_id"] else None

    media = getattr(m, ctype, None)
    file_id = getattr(media, "file_id", None) if media is not None else None
    if not file_id:
        return None
    payload["file_id"] = file_id
    return payload


def send_template(
    bot: TeleBot,
    chat_id: int,
    payload: dict | None,
    *,
    fallback_source_chat_id: int | None = None,
    fallback_source_message_id: int | None = None,
) -> int | None:
    p = payload or {}
    kind = (p.get("type") or "").strip().lower()
    html = (p.get("html") or "").strip()
    file_id = (p.get("file_id") or "").strip()

    if kind == "text":
        text = html or (p.get("text") or "").strip()
        if text:
            result = bot.send_message(chat_id, text)
            return message_id_from_result(result)

    if kind == "photo" and file_id:
        result = bot.send_photo(chat_id, file_id, caption=html or None)
        return message_id_from_result(result)
    if kind == "video" and file_id:
        result = bot.send_video(chat_id, file_id, caption=html or None)
        return message_id_from_result(result)
    if kind == "document" and file_id:
        result = bot.send_document(chat_id, file_id, caption=html or None)
        return message_id_from_result(result)
    if kind == "animation" and file_id:
        result = bot.send_animation(chat_id, file_id, caption=html or None)
        return message_id_from_result(result)
    if kind == "audio" and file_id:
        result = bot.send_audio(chat_id, file_id, caption=html or None)
        return message_id_from_result(result)
    if kind == "voice" and file_id:
        result = bot.send_voice(chat_id, file_id, caption=html or None)
        return message_id_from_result(result)

    if fallback_source_chat_id is not None and fallback_source_message_id is not None:
        result = bot.copy_message(
            chat_id=chat_id,
            from_chat_id=int(fallback_source_chat_id),
            message_id=int(fallback_source_message_id),
        )
        return message_id_from_result(result)

    return None
