from __future__ import annotations
import logging
import threading
import time
import sqlite3
import datetime as dt
from dataclasses import dataclass
from telebot import TeleBot

from app.db import (
    repo_alerts,
    repo_analytics,
    repo_broadcasts,
    repo_events,
    repo_payments,
    repo_postpay,
    repo_reminders,
    repo_settings,
    repo_students,
)
from app.services.timeutils import now, iso, format_date_ddmmyyyy, start_of_day, end_of_day, add_days, add_months, format_dt_ddmmyyyy_hhmm
from app.services.broadcast_delivery import decode_template_payload, send_template
from app.services.postpay import post_total, recommended_payment
from app.ui import texts
from app.ui.keyboards import alert_kb

ADMIN_CHAT_KEY = "ADMIN_CHAT_ID"

EVENT_TYPE_LABEL = {
    "HR": "HR",
    "TECH": "Тех",
    "CALL": "Созвон",
    "OTHER": "Другое",
}
AUTO_BROADCAST_MIN_INTERVAL_HOURS = 24
logger = logging.getLogger(__name__)

@dataclass
class SchedulerHandle:
    _thread: threading.Thread
    _stop_event: threading.Event

    def stop(self, timeout: float = 5.0) -> None:
        self._stop_event.set()
        self._thread.join(timeout=timeout)


def start_scheduler(bot: TeleBot, ctx: dict) -> SchedulerHandle:
    stop_event = threading.Event()
    t = threading.Thread(target=_loop, args=(bot, ctx, stop_event), daemon=True)
    t.start()
    return SchedulerHandle(_thread=t, _stop_event=stop_event)


def _loop(bot: TeleBot, ctx: dict, stop_event: threading.Event) -> None:
    conn: sqlite3.Connection = ctx["conn"]
    cfg = ctx["cfg"]
    tz = cfg.TZ
    tick = cfg.SCHEDULER_TICK_SEC
    repeat_min = cfg.ALERT_REPEAT_MIN

    while not stop_event.is_set():
        try:
            _run_auto_broadcasts(bot, conn, tz)

            chat_id_raw = repo_settings.get(conn, ADMIN_CHAT_KEY, None)
            if not chat_id_raw:
                stop_event.wait(timeout=tick)
                continue
            chat_id = int(chat_id_raw)

            _generate_due_alerts(conn, tz, chat_id, repeat_min)
            # send for all chats that have pending alerts
            n = now(tz)
            now_iso = iso(n)
            for cid in repo_alerts.list_chat_ids_to_send(conn, now_iso):
                _send_pending(bot, conn, tz, int(cid), repeat_min)
        except Exception:
            # don't crash scheduler, but keep diagnostics
            logger.exception("Scheduler loop iteration failed")
            try:
                repo_analytics.log_event(conn, tz, 0, "ops.scheduler_error")
            except Exception:
                logger.debug("Failed to log scheduler_error event", exc_info=True)
        stop_event.wait(timeout=tick)


def _run_auto_broadcasts(bot: TeleBot, conn: sqlite3.Connection, tz: str) -> None:
    rules = repo_broadcasts.list_auto_rules(conn, only_enabled=True, limit=100)
    if not rules:
        return

    now_dt = now(tz)
    now_iso = iso(now_dt)
    min_interval = dt.timedelta(hours=AUTO_BROADCAST_MIN_INTERVAL_HOURS)

    for rule in rules:
        rid = int(rule["id"])
        last_run_raw = (rule["last_run_at"] or "").strip()
        if last_run_raw:
            try:
                last_run_dt = dt.datetime.fromisoformat(last_run_raw)
                if last_run_dt.tzinfo is None:
                    last_run_dt = last_run_dt.replace(tzinfo=now_dt.tzinfo)
                if now_dt - last_run_dt < min_interval:
                    continue
            except Exception:
                pass

        inactivity_days = max(1, int(rule["inactivity_days"] or 1))
        recipients = repo_broadcasts.list_inactive_recipients(
            conn,
            tz,
            scope=rule["scope"],
            inactivity_days=inactivity_days,
        )

        cooldown = dt.timedelta(days=inactivity_days)
        filtered: list[sqlite3.Row] = []
        for r in recipients:
            uid = int(r["user_id"])
            last_sent = repo_broadcasts.last_auto_send_at(conn, rid, uid)
            if not last_sent:
                filtered.append(r)
                continue
            try:
                sent_dt = dt.datetime.fromisoformat(last_sent)
                if sent_dt.tzinfo is None:
                    sent_dt = sent_dt.replace(tzinfo=now_dt.tzinfo)
            except Exception:
                filtered.append(r)
                continue
            if now_dt - sent_dt >= cooldown:
                filtered.append(r)

        sent = 0
        failed = 0
        campaign_id: int | None = None
        payload = decode_template_payload(rule["template_payload_json"] if "template_payload_json" in rule.keys() else None)
        if filtered:
            campaign_id = repo_broadcasts.create_campaign(
                conn,
                tz,
                created_by_admin_id=int(rule["created_by_admin_id"]),
                scope=rule["scope"],
                source_chat_id=int(rule["source_chat_id"]),
                source_message_id=int(rule["source_message_id"]),
                total_targets=len(filtered),
                template_kind=repo_broadcasts.KIND_AUTO,
                auto_rule_id=rid,
            )
            for r in filtered:
                uid = int(r["user_id"])
                chat_id = int(r["chat_id"])
                try:
                    msg_id = send_template(
                        bot,
                        chat_id,
                        payload,
                        fallback_source_chat_id=int(rule["source_chat_id"]),
                        fallback_source_message_id=int(rule["source_message_id"]),
                    )
                    repo_broadcasts.add_delivery(
                        conn,
                        campaign_id=campaign_id,
                        user_id=uid,
                        chat_id=chat_id,
                        message_id=msg_id,
                        status=repo_broadcasts.STATUS_SENT,
                        error_text=None,
                        sent_at=now_iso,
                    )
                    sent += 1
                except Exception as e:
                    repo_broadcasts.add_delivery(
                        conn,
                        campaign_id=campaign_id,
                        user_id=uid,
                        chat_id=chat_id,
                        message_id=None,
                        status=repo_broadcasts.STATUS_FAILED,
                        error_text=str(e),
                        sent_at=None,
                    )
                    failed += 1
            repo_broadcasts.finalize_campaign(conn, tz, campaign_id, sent, failed)

        repo_broadcasts.set_auto_rule_last_run(conn, tz, rid)
        try:
            repo_analytics.log_event(
                conn,
                tz,
                0,
                "ops.auto_broadcast_run",
                {
                    "rule_id": rid,
                    "targets": len(filtered),
                    "sent": sent,
                    "failed": failed,
                    "campaign_id": campaign_id,
                },
            )
        except Exception:
            logger.debug("Failed to log auto broadcast run", exc_info=True)

def _generate_due_alerts(conn: sqlite3.Connection, tz: str, chat_id: int, repeat_min: int) -> None:
    n = now(tz)
    now_iso = iso(n)

    # Reminders
    rem_rows = conn.execute(
        "SELECT r.*, s.fio, s.username FROM reminders r LEFT JOIN students s ON s.id=r.student_id "
        "WHERE r.enabled=1 AND r.next_run_at <= ?",
        (now_iso,)
    ).fetchall()
    for r in rem_rows:
        rid = int(r["id"])
        if repo_alerts.exists_pending(conn, "reminders", rid, "REMINDER", chat_id=chat_id):
            continue
        fio = r["fio"] or "Персонально"
        title = f"{r['title']} — {fio}"
        body = r["note"] or ""
        a_id = repo_alerts.create(conn, tz, chat_id, "REMINDER", "reminders", rid, r["student_id"], title, body, r["next_run_at"], repeat_min)
        # advance reminder immediately; alert will repeat until seen
        nxt = repo_reminders.compute_next_run(r["next_run_at"], tz, r["freq_type"], r["freq_value"], r["time_of_day"], r["days_of_week"])
        repo_reminders.update(conn, rid, tz, next_run_at=nxt)

    # Events
    ev_rows = conn.execute(
        "SELECT e.*, s.fio, s.username, d.name as student_direction "
        "FROM events e "
        "LEFT JOIN students s ON s.id=e.student_id "
        "LEFT JOIN directions d ON d.id=s.direction_id "
        "WHERE e.active=1 AND e.alerted=0 AND e.next_alert_at <= ?",
        (now_iso,)
    ).fetchall()
    for e in ev_rows:
        eid = int(e["id"])
        if repo_alerts.exists_pending(conn, "events", eid, "EVENT", chat_id=chat_id):
            continue
        fio = e["fio"] or "—"
        et = EVENT_TYPE_LABEL.get(e["event_type"], e["event_type"])
        title = f"{et} • {fio}"
        link = e["link"] or ""
        company = e["company"] if (hasattr(e, "keys") and "company" in e.keys() and e["company"]) else ""
        direction = e["direction"] if (hasattr(e, "keys") and "direction" in e.keys() and e["direction"]) else (e["student_direction"] or "")
        role = e["role"] if (hasattr(e, "keys") and "role" in e.keys() and e["role"]) else ""
        extra=[]
        if company: extra.append(f"Компания: {company}")
        if direction: extra.append(f"Направление: {direction}")
        if role: extra.append(f"Позиция/этап: {role}")
        extra_str = ("\n" + "\n".join(extra)) if extra else ""
        when = format_dt_ddmmyyyy_hhmm(e["start_at"], tz)
        body = f"Время: {when}\nДлительность: {e['duration_min']} мин\nСсылка: {link}{extra_str}"
        repo_alerts.create(conn, tz, chat_id, "EVENT", "events", eid, e["student_id"], title, body, e["next_alert_at"], repeat_min)
        repo_events.mark_alerted(conn, eid, tz)

    # Payments due (postpay)
    # По ТЗ постоплата начинается только после добавления оффера.
    # Напоминалки о платеже приходят УЧЕНИКУ (если привязан owner_chat_id).
    # У ментора платежи видны в разделе «Платежи/Бухгалтерия», без спама алертами.
    # Если оффера нет — сбрасываем даты, чтобы не спамить.
    try:
        conn.execute(
            "UPDATE student_postpay SET start_date=NULL, next_due_date=NULL, student_next_notify_date=NULL "
            "WHERE student_id IN (SELECT id FROM students WHERE offer_amount IS NULL)"
        )
        conn.commit()
    except Exception:
        logger.exception("Failed to reset postpay dates for students without offer")

    # Если оффер уже задан, а next_due_date ещё не выставлен —
    # ставим первый платёж через 1 месяц от текущей даты.
    try:
        today_str = format_date_ddmmyyyy(n.date())
        first_due = format_date_ddmmyyyy(add_months(n.date(), 1))
        conn.execute(
            "UPDATE student_postpay SET start_date=COALESCE(start_date, ?), next_due_date=COALESCE(next_due_date, ?), "
            "student_next_notify_date=COALESCE(student_next_notify_date, COALESCE(next_due_date, ?)) "
            "WHERE enabled=1 AND total_percent IS NOT NULL AND student_id IN (SELECT id FROM students WHERE offer_amount IS NOT NULL)",
            (today_str, first_due, first_due)
        )
        conn.commit()
    except Exception:
        logger.exception("Failed to initialize first due date for postpay students")

    today = n.date()
    today_str = format_date_ddmmyyyy(today)

    pp_rows = conn.execute(
        "SELECT pp.*, s.fio, s.username, s.offer_amount, s.archived, s.owner_chat_id "
        "FROM student_postpay pp JOIN students s ON s.id=pp.student_id "
        "WHERE s.archived=0 AND pp.enabled=1 "
        "  AND pp.next_due_date IS NOT NULL AND pp.next_due_date <= ? "
        "  AND (pp.student_next_notify_date IS NULL OR pp.student_next_notify_date <= ?)",
        (today_str, today_str)
    ).fetchall()

    for pp in pp_rows:
        sid = int(pp["student_id"])
        due = pp["next_due_date"]
        # Напоминалки о платеже: только ученику (если привязан чат)
        offer = pp["offer_amount"]
        total = post_total(offer, pp["total_percent"])
        if total is None:
            continue
        paid = repo_payments.sum_payments(conn, sid, "postpay")
        remaining = max(0, total - paid)
        if remaining <= 0:
            # disable
            repo_postpay.disable(conn, sid)
            continue
        rec = recommended_payment(offer, pp["schedule_type"], pp["per_period_value"])
        rec_str = f"Рекомендовано: {rec} ₽" if rec else ""
        title = f"Платёж • {pp['fio']}"
        body = f"Срок: {due}\nОсталось по постоплате: {remaining} ₽\n{rec_str}".strip()

        try:
            student_chat = int(pp["owner_chat_id"]) if pp["owner_chat_id"] else None
        except Exception:
            student_chat = None

        notify_enabled = int(pp["student_notify_enabled"] or 0) if "student_notify_enabled" in pp.keys() else 1
        rep = int(pp["student_notify_repeat_min"]) if ("student_notify_repeat_min" in pp.keys() and pp["student_notify_repeat_min"] is not None) else repeat_min

        if student_chat and notify_enabled:
            if not repo_alerts.exists_pending(conn, "students", sid, "PAYMENT", chat_id=student_chat):
                repo_alerts.create(conn, tz, student_chat, "PAYMENT", "students", sid, sid, title, body, now_iso, rep)

def _send_pending(bot: TeleBot, conn: sqlite3.Connection, tz: str, chat_id: int, repeat_min: int) -> None:
    n = now(tz)
    now_iso = iso(n)
    rows = repo_alerts.list_to_send(conn, now_iso, chat_id)
    for a in rows:
        aid = int(a["id"])
        alert_type = a["alert_type"]
        title = a["title"]
        body = a["body"]
        student_id = a["student_id"]
        related_table = a["related_table"]
        related_id = int(a["related_id"])
        text = body
        if alert_type == "REMINDER":
            msg = texts.reminder_alert(title, body)
        elif alert_type == "EVENT":
            msg = texts.event_alert(title, body)
        else:
            msg = texts.payment_alert(title, body)

        # delete previous message to avoid clutter
        try:
            if a["message_id"]:
                bot.delete_message(chat_id, int(a["message_id"]))
        except Exception:
            logger.debug("Could not delete previous alert message", exc_info=True)

        # student chats should not see admin-only buttons
        try:
            admin_chat_raw = repo_settings.get(conn, ADMIN_CHAT_KEY, None)
            is_admin_chat = admin_chat_raw and int(admin_chat_raw) == int(chat_id)
        except Exception:
            logger.debug("Could not resolve admin chat id from settings", exc_info=True)
            is_admin_chat = False
        event_id = related_id if related_table == "events" else None
        kb = alert_kb(aid, student_id=student_id if is_admin_chat else None, event_id=event_id if is_admin_chat else None)

        try:
            sent = bot.send_message(chat_id, msg, reply_markup=kb)
            # schedule next retry
            next_retry = n + dt.timedelta(minutes=int(a["retry_after_min"] or repeat_min))
            repo_alerts.update_after_send(conn, aid, tz, int(sent.message_id), iso(next_retry))
            try:
                repo_analytics.log_event(
                    conn,
                    tz,
                    0,
                    "ops.alert_sent",
                    {"alert_type": alert_type, "related_table": related_table},
                )
            except Exception:
                logger.debug("Failed to log alert sent event", exc_info=True)
        except Exception:
            logger.exception("Failed to send alert id=%s", aid)
            # prevent tight retry loop when Telegram/API is unstable
            next_retry = n + dt.timedelta(minutes=int(a["retry_after_min"] or repeat_min))
            try:
                repo_alerts.snooze(conn, aid, tz, iso(next_retry))
            except Exception:
                logger.debug("Failed to schedule retry after send failure", exc_info=True)
            try:
                repo_analytics.log_event(
                    conn,
                    tz,
                    0,
                    "ops.alert_send_error",
                    {"alert_type": alert_type, "related_table": related_table},
                )
            except Exception:
                logger.debug("Failed to log alert send error event", exc_info=True)
