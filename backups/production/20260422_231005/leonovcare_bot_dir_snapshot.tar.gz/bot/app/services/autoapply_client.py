from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import requests


@dataclass(slots=True)
class AutoApplyClientError(RuntimeError):
    message: str
    status_code: int | None = None
    body: str = ""

    def __str__(self) -> str:
        code = f" (HTTP {self.status_code})" if self.status_code is not None else ""
        tail = f": {self.body}" if self.body else ""
        return f"{self.message}{code}{tail}"


class AutoApplyClient:
    def __init__(self, base_url: str, internal_token: str, timeout_sec: int = 45) -> None:
        self.base_url = (base_url or "").strip().rstrip("/")
        self.internal_token = (internal_token or "").strip()
        self.timeout_sec = max(int(timeout_sec or 45), 5)

    @property
    def enabled(self) -> bool:
        return bool(self.base_url and self.internal_token)

    def _headers(self) -> dict[str, str]:
        return {
            "Content-Type": "application/json",
            "X-Internal-Token": self.internal_token,
        }

    def _request(self, method: str, path: str, payload: dict[str, Any] | None = None) -> dict[str, Any]:
        if not self.enabled:
            raise AutoApplyClientError("Интеграция автооткликов не настроена")
        url = f"{self.base_url}{path}"
        try:
            resp = requests.request(
                method=method.upper(),
                url=url,
                headers=self._headers(),
                json=payload,
                timeout=self.timeout_sec,
            )
        except requests.RequestException as exc:
            raise AutoApplyClientError("Не удалось связаться с сервисом автооткликов") from exc

        body = (resp.text or "").strip()
        if resp.status_code >= 400:
            raise AutoApplyClientError(
                "Сервис автооткликов вернул ошибку",
                status_code=resp.status_code,
                body=body[:500],
            )
        if not body:
            return {}
        try:
            data = resp.json()
        except Exception as exc:
            raise AutoApplyClientError("Сервис автооткликов вернул не-JSON ответ", status_code=resp.status_code, body=body[:500]) from exc
        if isinstance(data, dict):
            return data
        return {"data": data}

    def create_account(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self._request("POST", "/api/internal/accounts", payload)

    def delete_account(self, login: str) -> dict[str, Any]:
        return self._request("DELETE", f"/api/internal/accounts/{login}")

    def account_stats(self, login: str) -> dict[str, Any]:
        return self._request("GET", f"/api/internal/accounts/{login}/stats")

    def run_account(self, login: str) -> dict[str, Any]:
        return self._request("POST", f"/api/internal/accounts/{login}/run")
