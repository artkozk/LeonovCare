from __future__ import annotations
from typing import Optional, Tuple
import datetime as dt
from app.services.timeutils import parse_date_ddmmyyyy, format_date_ddmmyyyy, add_months

def post_total(offer_amount: int | None, total_percent: float | None) -> Optional[int]:
    if offer_amount is None or total_percent is None:
        return None
    try:
        return int(round(offer_amount * float(total_percent) / 100.0))
    except Exception:
        return None

def recommended_payment(offer_amount: int | None, schedule_type: str, per_period_value: float | None) -> Optional[int]:
    if per_period_value is None:
        return None
    if schedule_type == "fixed_per_month":
        return int(round(float(per_period_value)))
    if schedule_type == "percent_per_month":
        if offer_amount is None:
            return None
        return int(round(offer_amount * float(per_period_value) / 100.0))
    # custom: no recommendation
    return None

def next_due_after_payment(current_due: str | None, pay_date_str: str,
                           schedule_type: str = "percent_per_month",
                           per_period_value: float | None = None) -> str:
    """Return next due date after a payment.

    Supported schedule_type:
      - percent_per_month / fixed_per_month: +1 month
      - every_n_days: +N days (per_period_value is days)
    """
    base = parse_date_ddmmyyyy(current_due) or parse_date_ddmmyyyy(pay_date_str)
    if not base:
        base = dt.date.today()
    if schedule_type == "every_n_days":
        try:
            days = int(round(float(per_period_value or 14)))
        except Exception:
            days = 14
        if days < 1:
            days = 1
        nxt = base + dt.timedelta(days=days)
        return format_date_ddmmyyyy(nxt)
    nxt = add_months(base, 1)
    return format_date_ddmmyyyy(nxt)
