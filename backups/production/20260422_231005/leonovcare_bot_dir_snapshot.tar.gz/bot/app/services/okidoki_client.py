from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import requests


@dataclass(slots=True)
class OkiDokiClientError(RuntimeError):
    message: str
    status_code: int | None = None
    body: str = ""

    def __str__(self) -> str:
        code = f" (HTTP {self.status_code})" if self.status_code is not None else ""
        tail = f": {self.body}" if self.body else ""
        return f"{self.message}{code}{tail}"


class OkiDokiClient:
    def __init__(self, create_contract_url: str, api_token: str, timeout_sec: int = 30) -> None:
        self.create_contract_url = (create_contract_url or "").strip()
        self.api_token = (api_token or "").strip()
        self.timeout_sec = max(int(timeout_sec or 30), 5)

    @property
    def enabled(self) -> bool:
        return bool(self.create_contract_url)

    def create_contract(self, payload: dict[str, Any]) -> dict[str, Any]:
        if not self.enabled:
            raise OkiDokiClientError("Интеграция OkiDoki не настроена")
        headers = {"Content-Type": "application/json"}
        if self.api_token:
            headers["Authorization"] = f"Bearer {self.api_token}"
        try:
            resp = requests.post(
                self.create_contract_url,
                json=payload,
                headers=headers,
                timeout=self.timeout_sec,
            )
        except requests.RequestException as exc:
            raise OkiDokiClientError("Не удалось связаться с OkiDoki-интеграцией") from exc

        body = (resp.text or "").strip()
        if resp.status_code >= 400:
            raise OkiDokiClientError(
                "OkiDoki-интеграция вернула ошибку",
                status_code=resp.status_code,
                body=body[:500],
            )
        if not body:
            return {}
        try:
            data = resp.json()
        except Exception as exc:
            raise OkiDokiClientError("OkiDoki-интеграция вернула не-JSON ответ", status_code=resp.status_code, body=body[:500]) from exc
        if isinstance(data, dict):
            return data
        return {"data": data}
