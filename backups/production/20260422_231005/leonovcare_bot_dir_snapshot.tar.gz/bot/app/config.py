from __future__ import annotations

import os
from dataclasses import dataclass

# Static defaults (can be overridden by env vars)
BOT_TOKEN = "8712567086:AAHoPUafABXE0qJkfq4x9wloK8tHSXwHUnY"
ADMIN_IDS = [ 6553771455, 7547392230, 581827609
]
DB_PATH = "mentor_bot.db"
TZ = "Europe/Moscow"
ALERT_REPEAT_MIN = 10
SCHEDULER_TICK_SEC = 20
BOT_WORKER_THREADS = 16
DB_BUSY_TIMEOUT_SEC = 15
# Optional fallback for materials subscription gate.
# If DB setting is empty, this chat_id will be used for get_chat_member checks.
MATERIALS_GROUP_CHAT_ID = -1003730365848
MATERIALS_GROUP_INVITE_URL = "https://t.me/+pb_tR_aJNzo3YmQy"
AUTOAPPLY_API_BASE_URL = "http://localhost:8081"
AUTOAPPLY_INTERNAL_TOKEN = "super-secret-token"
AUTOAPPLY_TIMEOUT_SEC = 45
AUTOAPPLY_DEFAULT_HEADLESS = False
AUTOAPPLY_DEFAULT_SLOWMO_MS = 150
AUTOAPPLY_DEFAULT_QUERY_TEXT = ""
OKIDOKI_SIGN_URL = ""
OKIDOKI_CREATE_CONTRACT_URL = ""
OKIDOKI_API_TOKEN = ""
CONTRACT_FILE_PATH = ""
MENTOR_CONTACT_URL = "https://t.me/leonovcare"
PAYMENT_EXPECTED_INN = "290125717910"
PAYMENT_MAX_AGE_DAYS = 90
PAYMENT_RECEIVER_NAME = "IP Oleg Leonov"
PAYMENT_BANK_NAME = ""
PAYMENT_ACCOUNT_NUMBER = ""
PAYMENT_CORR_ACCOUNT = ""
PAYMENT_BIK = ""
PAYMENT_LINK_URL = ""


@dataclass(frozen=True)
class Config:
    BOT_TOKEN: str
    ADMIN_IDS: list[int]
    DB_PATH: str
    TZ: str
    ALERT_REPEAT_MIN: int
    SCHEDULER_TICK_SEC: int
    BOT_WORKER_THREADS: int
    DB_BUSY_TIMEOUT_SEC: int
    MATERIALS_GROUP_CHAT_ID: int | None = None
    MATERIALS_GROUP_INVITE_URL: str = ""
    AUTOAPPLY_API_BASE_URL: str = ""
    AUTOAPPLY_INTERNAL_TOKEN: str = ""
    AUTOAPPLY_TIMEOUT_SEC: int = 45
    AUTOAPPLY_DEFAULT_HEADLESS: bool = False
    AUTOAPPLY_DEFAULT_SLOWMO_MS: int = 150
    AUTOAPPLY_DEFAULT_QUERY_TEXT: str = ""
    OKIDOKI_SIGN_URL: str = ""
    OKIDOKI_CREATE_CONTRACT_URL: str = ""
    OKIDOKI_API_TOKEN: str = ""
    CONTRACT_FILE_PATH: str = ""
    MENTOR_CONTACT_URL: str = ""
    PAYMENT_EXPECTED_INN: str = ""
    PAYMENT_MAX_AGE_DAYS: int = 90
    PAYMENT_RECEIVER_NAME: str = ""
    PAYMENT_BANK_NAME: str = ""
    PAYMENT_ACCOUNT_NUMBER: str = ""
    PAYMENT_CORR_ACCOUNT: str = ""
    PAYMENT_BIK: str = ""
    PAYMENT_LINK_URL: str = ""


def _env_str(name: str, default: str) -> str:
    raw = os.getenv(name)
    return (raw.strip() if raw is not None else default).strip()


def _env_int(name: str, default: int, min_value: int = 1) -> int:
    raw = os.getenv(name)
    if raw is None or not raw.strip():
        return max(min_value, int(default))
    try:
        return max(min_value, int(raw.strip()))
    except Exception:
        return max(min_value, int(default))


def _env_bool(name: str, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None or not raw.strip():
        return bool(default)
    val = raw.strip().lower()
    if val in {"1", "true", "yes", "y", "on"}:
        return True
    if val in {"0", "false", "no", "n", "off"}:
        return False
    return bool(default)


def _parse_admin_ids(default_admins: list[int]) -> list[int]:
    # ADMIN_IDS env format: "123,456,789"
    raw = os.getenv("ADMIN_IDS")
    source = default_admins
    if raw and raw.strip():
        source = [x.strip() for x in raw.split(",") if x.strip()]

    admins: list[int] = []
    for x in source or []:
        try:
            admins.append(int(x))
        except Exception:
            pass
    return admins


def _env_opt_int(name: str, default: int | None = None) -> int | None:
    raw = os.getenv(name)
    if raw is None or not raw.strip():
        return default
    try:
        return int(raw.strip())
    except Exception:
        return default


def load_config() -> Config:
    token = _env_str("BOT_TOKEN", BOT_TOKEN)
    if not token or token == "PASTE_YOUR_BOT_TOKEN_HERE":
        raise RuntimeError("Set BOT_TOKEN in app/config.py or BOT_TOKEN env var.")

    admins = _parse_admin_ids(ADMIN_IDS)
    if not admins or admins == [123456789]:
        raise RuntimeError("Set ADMIN_IDS in app/config.py or ADMIN_IDS env var.")

    return Config(
        BOT_TOKEN=token,
        ADMIN_IDS=admins,
        DB_PATH=_env_str("DB_PATH", DB_PATH),
        TZ=_env_str("TZ", TZ),
        ALERT_REPEAT_MIN=_env_int("ALERT_REPEAT_MIN", ALERT_REPEAT_MIN, min_value=1),
        SCHEDULER_TICK_SEC=_env_int("SCHEDULER_TICK_SEC", SCHEDULER_TICK_SEC, min_value=1),
        BOT_WORKER_THREADS=_env_int("BOT_WORKER_THREADS", BOT_WORKER_THREADS, min_value=2),
        DB_BUSY_TIMEOUT_SEC=_env_int("DB_BUSY_TIMEOUT_SEC", DB_BUSY_TIMEOUT_SEC, min_value=1),
        MATERIALS_GROUP_CHAT_ID=_env_opt_int("MATERIALS_GROUP_CHAT_ID", MATERIALS_GROUP_CHAT_ID),
        MATERIALS_GROUP_INVITE_URL=_env_str("MATERIALS_GROUP_INVITE_URL", MATERIALS_GROUP_INVITE_URL),
        AUTOAPPLY_API_BASE_URL=_env_str("AUTOAPPLY_API_BASE_URL", AUTOAPPLY_API_BASE_URL),
        AUTOAPPLY_INTERNAL_TOKEN=_env_str("AUTOAPPLY_INTERNAL_TOKEN", AUTOAPPLY_INTERNAL_TOKEN),
        AUTOAPPLY_TIMEOUT_SEC=_env_int("AUTOAPPLY_TIMEOUT_SEC", AUTOAPPLY_TIMEOUT_SEC, min_value=5),
        AUTOAPPLY_DEFAULT_HEADLESS=_env_bool("AUTOAPPLY_DEFAULT_HEADLESS", AUTOAPPLY_DEFAULT_HEADLESS),
        AUTOAPPLY_DEFAULT_SLOWMO_MS=_env_int("AUTOAPPLY_DEFAULT_SLOWMO_MS", AUTOAPPLY_DEFAULT_SLOWMO_MS, min_value=0),
        AUTOAPPLY_DEFAULT_QUERY_TEXT=_env_str("AUTOAPPLY_DEFAULT_QUERY_TEXT", AUTOAPPLY_DEFAULT_QUERY_TEXT),
        OKIDOKI_SIGN_URL=_env_str("OKIDOKI_SIGN_URL", OKIDOKI_SIGN_URL),
        OKIDOKI_CREATE_CONTRACT_URL=_env_str("OKIDOKI_CREATE_CONTRACT_URL", OKIDOKI_CREATE_CONTRACT_URL),
        OKIDOKI_API_TOKEN=_env_str("OKIDOKI_API_TOKEN", OKIDOKI_API_TOKEN),
        CONTRACT_FILE_PATH=_env_str("CONTRACT_FILE_PATH", CONTRACT_FILE_PATH),
        MENTOR_CONTACT_URL=_env_str("MENTOR_CONTACT_URL", MENTOR_CONTACT_URL),
        PAYMENT_EXPECTED_INN=_env_str("PAYMENT_EXPECTED_INN", PAYMENT_EXPECTED_INN),
        PAYMENT_MAX_AGE_DAYS=_env_int("PAYMENT_MAX_AGE_DAYS", PAYMENT_MAX_AGE_DAYS, min_value=1),
        PAYMENT_RECEIVER_NAME=_env_str("PAYMENT_RECEIVER_NAME", PAYMENT_RECEIVER_NAME),
        PAYMENT_BANK_NAME=_env_str("PAYMENT_BANK_NAME", PAYMENT_BANK_NAME),
        PAYMENT_ACCOUNT_NUMBER=_env_str("PAYMENT_ACCOUNT_NUMBER", PAYMENT_ACCOUNT_NUMBER),
        PAYMENT_CORR_ACCOUNT=_env_str("PAYMENT_CORR_ACCOUNT", PAYMENT_CORR_ACCOUNT),
        PAYMENT_BIK=_env_str("PAYMENT_BIK", PAYMENT_BIK),
        PAYMENT_LINK_URL=_env_str("PAYMENT_LINK_URL", PAYMENT_LINK_URL),
    )
