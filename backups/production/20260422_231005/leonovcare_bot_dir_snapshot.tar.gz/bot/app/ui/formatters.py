from __future__ import annotations
import html

def esc(s: str | None) -> str:
    return html.escape(s or "")

def money(amount: int | None) -> str:
    if amount is None:
        return "—"
    return f"{amount:,}".replace(",", " ") + " ₽"

def yesno(v: bool) -> str:
    return "да" if v else "нет"
