from __future__ import annotations
from app.ui.formatters import esc, money

def main_title() -> str:
    return "<b>Панель ментора</b>\nВыбери раздел:"


def regular_title() -> str:
    return "<b>Стартовое меню</b>\nВыбери раздел:"


def user_title() -> str:
    return "<b>Личный кабинет ученика</b>\nВыбери действие:"


def request_title(req_type: str) -> str:
    mapping = {
        "PROFILE": "Анкета ученика",
        "ACCOUNTS": "Доступы HH",
        "PAYMENT": "Подтверждение платежа",
        "SITE_INTENT": "Лид с сайта",
        "AUTOAPPLY": "Запуск автооткликов",
        "AUTOAPPLY_PAYMENT": "Оплата автооткликов",
        "ENROLLMENT": "Вступление на обучение",
        "ENROLLMENT_PAYMENT": "Оплата после договора",
    }
    return mapping.get(req_type, req_type)

def students_title(filters: dict) -> str:
    parts = []
    if filters.get("direction_name"):
        parts.append(f"Направление: <b>{esc(filters['direction_name'])}</b>")
    if filters.get("stage_name"):
        parts.append(f"Этап: <b>{esc(filters['stage_name'])}</b>")
    if filters.get("archived") is True:
        parts.append("Режим: <b>Архив</b>")
    if not parts:
        return "<b>Ученики</b>"
    return "<b>Ученики</b>\n" + " | ".join(parts)

def student_list_item(fio: str, username: str | None, direction: str | None, stage: str | None) -> str:
    u = f"@{username.lstrip('@')}" if username else "—"
    return f"<b>{esc(fio)}</b>\n{esc(u)}\n{esc(direction or '—')}\n{esc(stage or '—')}"

def student_card(data: dict) -> str:
    # data already contains strings
    lines = []
    lines.append(f"<b>{esc(data.get('fio',''))}</b>")
    lines.append(f"Направление: <b>{esc(data.get('direction_name') or '—')}</b>")
    lines.append(f"Этап: <b>{esc(data.get('stage_name') or '—')}</b>")
    username = data.get("username")
    lines.append(f"Username: {esc('@'+username.lstrip('@')) if username else '—'}")
    lines.append(f"Тариф: <b>{esc(data.get('tariff_label',''))}</b>")
    if data.get("comment"):
        lines.append(f"Комментарий: {esc(data['comment'])}")
    # money
    prepay = data.get("prepay_paid")
    lines.append(f"Предоплата: <b>{money(prepay)}</b>")
    offer = data.get("offer_amount")
    if offer:
        lines.append(f"Оффер: <b>{money(offer)}</b>")
    post_total = data.get("post_total")
    post_paid = data.get("post_paid")
    if post_total is not None:
        lines.append(f"Постоплата: <b>{money(post_paid)}</b> / <b>{money(post_total)}</b>")
        if data.get("post_next_due"):
            lines.append(f"Следующий платёж: <b>{esc(data['post_next_due'])}</b>")
    else:
        # show rule if exists
        if data.get("post_rule"):
            lines.append(f"Постоплата правило: {esc(data['post_rule'])}")
        if data.get("offer_amount") is None and data.get("post_rule"):
            lines.append("Постоплата: <b>ожидает оффер</b> (первый платёж через 1 месяц после оффера)")
        else:
            lines.append("Постоплата: —")
    if data.get("join_date"):
        lines.append(f"На обучении с: <b>{esc(data['join_date'])}</b>")
    interviews = "идут" if data.get("interviews_active") else "нет"
    lines.append(f"Собесы: <b>{esc(interviews)}</b>")
    return "\n".join(lines)

def reminder_alert(title: str, body: str) -> str:
    return f"<b>[НАПОМИНАЛКА]</b> {esc(title)}\n\n{esc(body)}"

def event_alert(title: str, body: str) -> str:
    return f"<b>[УВЕДОМЛЕНИЕ]</b> {esc(title)}\n\n{esc(body)}"

def payment_alert(title: str, body: str) -> str:
    return f"<b>[ПЛАТЕЖ]</b> {esc(title)}\n\n{esc(body)}"
