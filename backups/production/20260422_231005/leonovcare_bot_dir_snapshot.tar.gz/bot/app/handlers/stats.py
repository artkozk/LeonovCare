from __future__ import annotations

import csv
import io
import json
import sqlite3
from datetime import date

from telebot import TeleBot
from telebot.types import CallbackQuery

from app.db import repo_analytics
from app.handlers.common import is_admin
from app.services.timeutils import now, parse_date_ddmmyyyy
from app.ui.formatters import esc
from app.ui.keyboards import stats_menu_kb


def _sum_payments_in_period(conn: sqlite3.Connection, d_from: date | None, d_to: date | None) -> int:
    rows = conn.execute("SELECT amount, pay_date FROM payments").fetchall()
    total = 0
    for r in rows:
        d = parse_date_ddmmyyyy(r["pay_date"])
        if not d:
            continue
        if d_from and d < d_from:
            continue
        if d_to and d > d_to:
            continue
        total += int(r["amount"] or 0)
    return total


def _payments_breakdown(conn: sqlite3.Connection) -> dict:
    pre = conn.execute("SELECT COALESCE(SUM(amount),0) AS s FROM payments WHERE pay_type='prepay'").fetchone()
    post = conn.execute("SELECT COALESCE(SUM(amount),0) AS s FROM payments WHERE pay_type='postpay'").fetchone()
    month_start = date.today().replace(day=1)
    month_total = _sum_payments_in_period(conn, month_start, date.today())
    return {
        "prepay_total": int(pre["s"] or 0) if pre else 0,
        "postpay_total": int(post["s"] or 0) if post else 0,
        "month_total": int(month_total),
    }


def _role_label(role: str) -> str:
    r = (role or "").strip().lower()
    if r == "admin":
        return "админ"
    if r == "student":
        return "ученик"
    return "обычный"


def _overview_text(conn: sqlite3.Connection, tz: str) -> str:
    totals = repo_analytics.user_totals(conn)
    act = repo_analytics.dau_wau_mau(conn, tz)
    ret = repo_analytics.retention(conn)
    new_day = repo_analytics.new_users(conn, tz, 1)
    new_week = repo_analytics.new_users(conn, tz, 7)
    new_month = repo_analytics.new_users(conn, tz, 30)
    return (
        "<b>Статистика: Обзор</b>\n\n"
        f"Пользователей всего: <b>{totals['all']}</b>\n"
        f"Новых за день/неделю/30д: <b>{new_day}</b> / <b>{new_week}</b> / <b>{new_month}</b>\n\n"
        f"Активные за 1/7/30 дней: <b>{act['dau']}</b> / <b>{act['wau']}</b> / <b>{act['mau']}</b>\n"
        f"Коэффициент активности (1д к 30д): <b>{act['stickiness']}%</b>\n\n"
        f"Удержание на 1/7/30 день: <b>{ret['d1']}%</b> / <b>{ret['d7']}%</b> / <b>{ret['d30']}%</b>\n"
        f"Размер когорты: <b>{ret['cohort']}</b>"
    )


def _users_text(conn: sqlite3.Connection, tz: str) -> str:
    totals = repo_analytics.user_totals(conn)
    rows = conn.execute(
        "SELECT "
        "up.user_id, "
        "COALESCE(up.username, ("
        "  SELECT s.owner_username FROM students s "
        "  WHERE s.owner_tg_id=up.user_id "
        "  ORDER BY s.id DESC LIMIT 1"
        ")) AS username, "
        "up.role_type, up.first_seen_at, up.last_seen_at, up.last_start_at "
        "FROM user_profiles up "
        "ORDER BY up.last_seen_at DESC LIMIT 10"
    ).fetchall()
    lines = [
        "<b>Статистика: Пользователи</b>",
        "",
        f"Всего: <b>{totals['all']}</b>",
        f"Роли (админы/ученики/обычные): <b>{totals['admin']}</b> / <b>{totals['student']}</b> / <b>{totals['regular']}</b>",
        "",
        "Последние 10 активных:",
    ]
    for r in rows:
        uid = int(r["user_id"])
        role = _role_label(r["role_type"] or "regular")
        username = (r["username"] or "").strip()
        uname = f"@{username}" if username else "—"
        ls = r["last_seen_at"] or "—"
        fs = r["first_seen_at"] or "—"
        st = r["last_start_at"] or "—"
        lines.append(f"• {uid} [{role}] {uname}")
        lines.append(f"  первый вход: {fs}")
        lines.append(f"  последний вход: {ls}")
        lines.append(f"  последний /start: {st}")
    return "\n".join(lines)


def _users_list_csv(conn: sqlite3.Connection) -> str:
    rows = conn.execute(
        "SELECT "
        "up.user_id, "
        "COALESCE(up.username, ("
        "  SELECT s.owner_username FROM students s "
        "  WHERE s.owner_tg_id=up.user_id "
        "  ORDER BY s.id DESC LIMIT 1"
        ")) AS username, "
        "up.role_type, up.first_seen_at, up.last_seen_at, up.last_start_at "
        "FROM user_profiles up "
        "ORDER BY up.last_seen_at DESC, up.user_id DESC"
    ).fetchall()
    buf = io.StringIO()
    wr = csv.writer(buf)
    wr.writerow(["user_id", "username", "role_type", "first_seen_at", "last_seen_at", "last_start_at"])
    for r in rows:
        username = (r["username"] or "").strip()
        wr.writerow(
            [
                int(r["user_id"]),
                f"@{username}" if username else "",
                (r["role_type"] or "").strip(),
                r["first_seen_at"] or "",
                r["last_seen_at"] or "",
                r["last_start_at"] or "",
            ]
        )
    return buf.getvalue()


def _materials_text(conn: sqlite3.Connection) -> str:
    funnel = repo_analytics.funnel_distinct_users(
        conn,
        [
            "funnel.materials.open",
            "funnel.materials.subscription_ok",
            "funnel.materials.direction_selected",
            "funnel.materials.step_open",
            "funnel.materials.step_done",
        ],
    )
    rows = repo_analytics.direction_progress(conn)
    drop = repo_analytics.material_step_dropoff(conn)[:8]
    lines = [
        "<b>Статистика: Материалы</b>",
        "",
        "Воронка (уникальные пользователи):",
        f"• открыли раздел: {funnel['funnel.materials.open']}",
        f"• прошли проверку подписки: {funnel['funnel.materials.subscription_ok']}",
        f"• выбрали направление: {funnel['funnel.materials.direction_selected']}",
        f"• открыли шаг: {funnel['funnel.materials.step_open']}",
        f"• отметили шаг как пройденный: {funnel['funnel.materials.step_done']}",
        "",
        "Прогресс по направлениям:",
    ]
    for r in rows:
        lines.append(
            f"• {r['direction']}: начали={r['started']}, в процессе={r['in_progress']}, "
            f"завершили={r['completed']}, средний прогресс={r['avg_percent']}%"
        )
    lines.append("")
    lines.append("Шаги с наибольшим оттоком:")
    if not drop:
        lines.append("• данных пока нет")
    else:
        for d in drop:
            lines.append(
                f"• {d['direction']} #{d['position']} ({esc(d['title'])}): открытий={d['opens']}, "
                f"падение={d['drop_abs']} ({d['drop_pct']}%)"
            )
    return "\n".join(lines)


def _student_funnel_text(conn: sqlite3.Connection) -> str:
    funnel = repo_analytics.funnel_distinct_users(
        conn,
        [
            "funnel.student.entry_click",
            "funnel.student.code_valid",
            "funnel.student.profile_submitted",
            "funnel.student.profile_approved",
            "funnel.student.code_invalid",
        ],
    )
    return (
        "<b>Статистика: Я ученик (воронка)</b>\n\n"
        f"Нажали «Я ученик»: <b>{funnel['funnel.student.entry_click']}</b>\n"
        f"Код валиден: <b>{funnel['funnel.student.code_valid']}</b>\n"
        f"Анкета отправлена: <b>{funnel['funnel.student.profile_submitted']}</b>\n"
        f"Анкета одобрена: <b>{funnel['funnel.student.profile_approved']}</b>\n"
        f"Невалидный код (попытки): <b>{funnel['funnel.student.code_invalid']}</b>"
    )


def _payments_text(conn: sqlite3.Connection) -> str:
    p = _payments_breakdown(conn)
    students_active = conn.execute("SELECT COUNT(1) AS c FROM students WHERE archived=0").fetchone()
    return (
        "<b>Статистика: Платежи</b>\n\n"
        f"Предоплата (всего): <b>{p['prepay_total']} ₽</b>\n"
        f"Постоплата (всего): <b>{p['postpay_total']} ₽</b>\n"
        f"Платежи за текущий месяц: <b>{p['month_total']} ₽</b>\n"
        f"Активных учеников: <b>{int(students_active['c'] or 0) if students_active else 0}</b>"
    )


def _ops_text(conn: sqlite3.Connection) -> str:
    m = repo_analytics.operational_metrics(conn)
    return (
        "<b>Статистика: Операционка</b>\n\n"
        f"Алертов всего: <b>{m['alerts_total']}</b>\n"
        f"Алерты в ожидании/закрыты: <b>{m['alerts_pending']}</b> / <b>{m['alerts_seen']}</b>\n"
        f"Алертов доставлено: <b>{m['alerts_delivered']}</b>\n"
        f"Средняя задержка от срока до обновления: <b>{m['avg_alert_delay_min']} мин</b>\n"
        f"Ошибки планировщика: <b>{m['scheduler_errors']}</b>\n"
        f"Ошибки отправки алертов: <b>{m['alert_send_errors']}</b>"
    )


def _report_dict(conn: sqlite3.Connection, tz: str) -> dict:
    return {
        "generated_at": now(tz).isoformat(),
        "users": {
            "totals": repo_analytics.user_totals(conn),
            "new_users": {
                "day": repo_analytics.new_users(conn, tz, 1),
                "week": repo_analytics.new_users(conn, tz, 7),
                "month": repo_analytics.new_users(conn, tz, 30),
            },
            "activity": repo_analytics.dau_wau_mau(conn, tz),
            "retention": repo_analytics.retention(conn),
        },
        "funnels": {
            "materials": repo_analytics.funnel_distinct_users(
                conn,
                [
                    "funnel.materials.open",
                    "funnel.materials.subscription_ok",
                    "funnel.materials.direction_selected",
                    "funnel.materials.step_open",
                    "funnel.materials.step_done",
                ],
            ),
            "student": repo_analytics.funnel_distinct_users(
                conn,
                [
                    "funnel.student.entry_click",
                    "funnel.student.code_valid",
                    "funnel.student.profile_submitted",
                    "funnel.student.profile_approved",
                    "funnel.student.code_invalid",
                ],
            ),
        },
        "materials": {
            "direction_progress": repo_analytics.direction_progress(conn),
            "step_dropoff_top": repo_analytics.material_step_dropoff(conn)[:20],
        },
        "payments": _payments_breakdown(conn),
        "operations": repo_analytics.operational_metrics(conn),
    }


def _report_csv(report: dict) -> str:
    buf = io.StringIO()
    wr = csv.writer(buf)
    wr.writerow(["section", "metric", "value"])
    users = report["users"]
    totals = users["totals"]
    wr.writerow(["users", "total", totals["all"]])
    wr.writerow(["users", "admin", totals["admin"]])
    wr.writerow(["users", "student", totals["student"]])
    wr.writerow(["users", "regular", totals["regular"]])

    for k, v in users["activity"].items():
        wr.writerow(["activity", k, v])
    for k, v in users["retention"].items():
        wr.writerow(["retention", k, v])

    for k, v in report["funnels"]["materials"].items():
        wr.writerow(["funnel_materials", k, v])
    for k, v in report["funnels"]["student"].items():
        wr.writerow(["funnel_student", k, v])

    for row in report["materials"]["direction_progress"]:
        wr.writerow(
            [
                "direction_progress",
                row["direction"],
                f"started={row['started']};in_progress={row['in_progress']};completed={row['completed']};avg_percent={row['avg_percent']}",
            ]
        )

    pay = report["payments"]
    for k in ("prepay_total", "postpay_total", "month_total"):
        wr.writerow(["payments", k, pay[k]])

    for k, v in report["operations"].items():
        wr.writerow(["operations", k, v])

    return buf.getvalue()


def init(bot: TeleBot, ctx: dict) -> None:
    conn: sqlite3.Connection = ctx["conn"]
    tz = ctx["cfg"].TZ

    def _show(c: CallbackQuery, text: str) -> None:
        bot.edit_message_text(text, c.message.chat.id, c.message.message_id, reply_markup=stats_menu_kb())
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data in {"stt:overview", "stt:month", "stt:all"})
    def st_overview(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        _show(c, _overview_text(conn, tz))

    @bot.callback_query_handler(func=lambda c: c.data == "stt:users")
    def st_users(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        _show(c, _users_text(conn, tz))
        payload = _users_list_csv(conn)
        f = io.BytesIO(payload.encode("utf-8"))
        f.name = "users_list.csv"
        bot.send_document(c.message.chat.id, f, caption="Список пользователей (CSV)")

    @bot.callback_query_handler(func=lambda c: c.data == "stt:materials")
    def st_materials(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        _show(c, _materials_text(conn))

    @bot.callback_query_handler(func=lambda c: c.data == "stt:student_funnel")
    def st_student_funnel(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        _show(c, _student_funnel_text(conn))

    @bot.callback_query_handler(func=lambda c: c.data == "stt:payments")
    def st_payments(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        _show(c, _payments_text(conn))

    @bot.callback_query_handler(func=lambda c: c.data == "stt:ops")
    def st_ops(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        _show(c, _ops_text(conn))

    @bot.callback_query_handler(func=lambda c: c.data.startswith("stt:export:"))
    def st_export(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        fmt = c.data.split(":")[2]
        report = _report_dict(conn, tz)
        if fmt == "json":
            payload = json.dumps(report, ensure_ascii=False, indent=2)
            name = "stats_report.json"
        else:
            payload = _report_csv(report)
            name = "stats_report.csv"

        f = io.BytesIO(payload.encode("utf-8"))
        f.name = name
        bot.send_document(c.message.chat.id, f, caption="Экспорт статистики")
        _show(c, "<b>Статистика</b>\nЭкспорт отправлен файлом.")
