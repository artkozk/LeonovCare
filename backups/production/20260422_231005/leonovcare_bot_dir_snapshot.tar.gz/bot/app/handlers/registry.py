from __future__ import annotations

import importlib
from typing import Any


DEFAULT_HANDLER_MODULES: tuple[str, ...] = (
    "app.handlers.common",
    "app.handlers.user",
    "app.handlers.materials",
    "app.handlers.broadcasts",
    "app.handlers.main_menu",
    "app.handlers.student_codes",
    "app.handlers.hh",
    "app.handlers.students",
    "app.handlers.reminders",
    "app.handlers.events",
    "app.handlers.payments",
    "app.handlers.stats",
    "app.handlers.alerts",
    "app.handlers.requests",
)


def init_handlers(bot: Any, ctx: dict, modules: tuple[str, ...] | None = None) -> None:
    for mod_name in modules or DEFAULT_HANDLER_MODULES:
        module = importlib.import_module(mod_name)
        if not hasattr(module, "init"):
            raise RuntimeError(f"Handler module {mod_name} has no init(bot, ctx)")
        module.init(bot, ctx)
