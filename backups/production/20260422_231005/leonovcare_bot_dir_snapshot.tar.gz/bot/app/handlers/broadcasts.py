from __future__ import annotations

import datetime as dt
import sqlite3

from telebot import TeleBot
from telebot.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from app.db import repo_broadcasts, repo_states
from app.services.broadcast_delivery import (
    decode_template_payload,
    encode_template_payload,
    send_template,
    template_from_message,
)
from app.services.timeutils import now

STATE_MANUAL_WAIT_MESSAGE = "BR_MANUAL_WAIT_MESSAGE"
STATE_AUTO_WAIT_DAYS = "BR_AUTO_WAIT_DAYS"
STATE_AUTO_WAIT_MESSAGE = "BR_AUTO_WAIT_MESSAGE"


def _is_admin(ctx: dict, user_id: int) -> bool:
    return int(user_id) in ctx["cfg"].ADMIN_IDS


def _scope_label(scope: str) -> str:
    return {
        repo_broadcasts.SCOPE_ALL: "Все пользователи",
        repo_broadcasts.SCOPE_STUDENT: "Только ученики",
        repo_broadcasts.SCOPE_REGULAR: "Только обычные",
        repo_broadcasts.SCOPE_ADMIN: "Только админы",
    }.get(scope, scope)


def _menu_kb() -> InlineKeyboardMarkup:
    kb = InlineKeyboardMarkup()
    kb.row(InlineKeyboardButton("✉️ Новая рассылка", callback_data="br:new"))
    kb.row(InlineKeyboardButton("🤖 Новое автосообщение", callback_data="br:auto:new"))
    kb.row(
        InlineKeyboardButton("📚 История рассылок", callback_data="br:history"),
        InlineKeyboardButton("⚙️ Автосообщения", callback_data="br:auto:list"),
    )
    kb.row(InlineKeyboardButton("🏠 Main", callback_data="m:main"))
    return kb


def _scope_kb(prefix: str, back_cb: str) -> InlineKeyboardMarkup:
    kb = InlineKeyboardMarkup()
    kb.row(
        InlineKeyboardButton("Все", callback_data=f"{prefix}:{repo_broadcasts.SCOPE_ALL}"),
        InlineKeyboardButton("Ученики", callback_data=f"{prefix}:{repo_broadcasts.SCOPE_STUDENT}"),
    )
    kb.row(
        InlineKeyboardButton("Обычные", callback_data=f"{prefix}:{repo_broadcasts.SCOPE_REGULAR}"),
        InlineKeyboardButton("Админы", callback_data=f"{prefix}:{repo_broadcasts.SCOPE_ADMIN}"),
    )
    kb.row(InlineKeyboardButton("⬅️ Назад", callback_data=back_cb))
    return kb


def init(bot: TeleBot, ctx: dict) -> None:
    conn: sqlite3.Connection = ctx["conn"]
    tz = ctx["cfg"].TZ

    def _render_menu(c: CallbackQuery) -> None:
        bot.edit_message_text(
            "<b>Сообщения и рассылки</b>\nВыбери действие:",
            c.message.chat.id,
            c.message.message_id,
            reply_markup=_menu_kb(),
        )

    def _send_campaign(
        admin_id: int,
        source_chat_id: int,
        source_message_id: int,
        scope: str,
        kind: str,
        auto_rule_id: int | None,
        template_payload: dict | None = None,
    ) -> tuple[int, int, int]:
        recipients = repo_broadcasts.list_recipients(conn, scope)
        campaign_id = repo_broadcasts.create_campaign(
            conn,
            tz,
            created_by_admin_id=admin_id,
            scope=scope,
            source_chat_id=source_chat_id,
            source_message_id=source_message_id,
            total_targets=len(recipients),
            template_kind=kind,
            auto_rule_id=auto_rule_id,
        )
        sent = 0
        failed = 0
        sent_at = now(tz).isoformat()
        for r in recipients:
            uid = int(r["user_id"])
            chat_id = int(r["chat_id"])
            try:
                mid = send_template(
                    bot,
                    chat_id,
                    template_payload,
                    fallback_source_chat_id=source_chat_id,
                    fallback_source_message_id=source_message_id,
                )
                repo_broadcasts.add_delivery(
                    conn,
                    campaign_id=campaign_id,
                    user_id=uid,
                    chat_id=chat_id,
                    message_id=mid,
                    status=repo_broadcasts.STATUS_SENT,
                    error_text=None,
                    sent_at=sent_at,
                )
                sent += 1
            except Exception as e:
                repo_broadcasts.add_delivery(
                    conn,
                    campaign_id=campaign_id,
                    user_id=uid,
                    chat_id=chat_id,
                    message_id=None,
                    status=repo_broadcasts.STATUS_FAILED,
                    error_text=str(e),
                    sent_at=None,
                )
                failed += 1
        repo_broadcasts.finalize_campaign(conn, tz, campaign_id, sent, failed)
        return campaign_id, sent, failed

    def _render_history(chat_id: int, message_id: int) -> None:
        rows = repo_broadcasts.list_campaigns(conn, limit=12)
        if not rows:
            text = "<b>История рассылок</b>\n\nПока пусто."
            kb = InlineKeyboardMarkup()
            kb.row(InlineKeyboardButton("⬅️ В меню рассылок", callback_data="m:broadcasts"))
            bot.edit_message_text(text, chat_id, message_id, reply_markup=kb)
            return
        text = "<b>История рассылок</b>\n\nВыбери кампанию:"
        kb = InlineKeyboardMarkup()
        for r in rows:
            label = (
                f"#{int(r['id'])} {r['template_kind']} / {_scope_label(r['scope'])} "
                f"({int(r['sent_count'])}/{int(r['total_targets'])})"
            )
            kb.row(InlineKeyboardButton(label, callback_data=f"br:open:{int(r['id'])}"))
        kb.row(InlineKeyboardButton("⬅️ В меню рассылок", callback_data="m:broadcasts"))
        bot.edit_message_text(text, chat_id, message_id, reply_markup=kb)

    def _render_campaign(chat_id: int, message_id: int, campaign_id: int) -> None:
        c = repo_broadcasts.get_campaign(conn, campaign_id)
        if not c:
            bot.edit_message_text("Кампания не найдена.", chat_id, message_id)
            return
        text = (
            f"<b>Кампания #{int(c['id'])}</b>\n"
            f"Тип: <b>{c['template_kind']}</b>\n"
            f"Сегмент: <b>{_scope_label(c['scope'])}</b>\n"
            f"Получатели: <b>{int(c['total_targets'])}</b>\n"
            f"Отправлено: <b>{int(c['sent_count'])}</b>\n"
            f"Ошибки: <b>{int(c['failed_count'])}</b>\n"
            f"Статус: <b>{c['status']}</b>"
        )
        kb = InlineKeyboardMarkup()
        if c["status"] != "deleted":
            kb.row(InlineKeyboardButton("🗑 Удалить отправленные", callback_data=f"br:delete_sent:{int(c['id'])}"))
        kb.row(InlineKeyboardButton("⬅️ К истории", callback_data="br:history"))
        bot.edit_message_text(text, chat_id, message_id, reply_markup=kb)

    def _render_auto_rules(chat_id: int, message_id: int) -> None:
        rows = repo_broadcasts.list_auto_rules(conn, only_enabled=False, limit=20)
        text = "<b>Автосообщения</b>"
        kb = InlineKeyboardMarkup()
        if not rows:
            text += "\n\nПока нет правил."
        else:
            text += "\n\nВыбери правило:"
            for r in rows:
                label = (
                    f"#{int(r['id'])} {_scope_label(r['scope'])} / {int(r['inactivity_days'])}д "
                    f"/ {'ON' if int(r['enabled'] or 0)==1 else 'OFF'}"
                )
                kb.row(InlineKeyboardButton(label, callback_data=f"br:auto:open:{int(r['id'])}"))
        kb.row(InlineKeyboardButton("⬅️ В меню рассылок", callback_data="m:broadcasts"))
        bot.edit_message_text(text, chat_id, message_id, reply_markup=kb)

    def _render_auto_rule(chat_id: int, message_id: int, rule_id: int) -> None:
        r = repo_broadcasts.get_auto_rule(conn, rule_id)
        if not r:
            bot.edit_message_text("Правило не найдено.", chat_id, message_id)
            return
        text = (
            f"<b>Автоправило #{int(r['id'])}</b>\n"
            f"Сегмент: <b>{_scope_label(r['scope'])}</b>\n"
            f"Неактивность: <b>{int(r['inactivity_days'])} дн</b>\n"
            f"Статус: <b>{'ON' if int(r['enabled'] or 0)==1 else 'OFF'}</b>\n"
            f"Последний прогон: <b>{r['last_run_at'] or '—'}</b>"
        )
        kb = InlineKeyboardMarkup()
        kb.row(
            InlineKeyboardButton("Вкл/Выкл", callback_data=f"br:auto:toggle:{int(r['id'])}"),
            InlineKeyboardButton("▶️ Запустить сейчас", callback_data=f"br:auto:run:{int(r['id'])}"),
        )
        kb.row(InlineKeyboardButton("🗑 Удалить правило", callback_data=f"br:auto:del:{int(r['id'])}"))
        kb.row(InlineKeyboardButton("⬅️ К правилам", callback_data="br:auto:list"))
        bot.edit_message_text(text, chat_id, message_id, reply_markup=kb)

    @bot.callback_query_handler(func=lambda c: c.data == "m:broadcasts")
    def br_menu(c: CallbackQuery):
        if not _is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        repo_states.clear_state(conn, c.from_user.id, tz)
        _render_menu(c)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data == "br:new")
    def br_new(c: CallbackQuery):
        if not _is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        bot.edit_message_text(
            "<b>Новая рассылка</b>\nВыбери сегмент получателей:",
            c.message.chat.id,
            c.message.message_id,
            reply_markup=_scope_kb("br:new:scope", "m:broadcasts"),
        )
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("br:new:scope:"))
    def br_new_scope(c: CallbackQuery):
        if not _is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        scope = c.data.split(":")[3]
        rec = repo_broadcasts.list_recipients(conn, scope)
        repo_states.set_state(
            conn,
            c.from_user.id,
            STATE_MANUAL_WAIT_MESSAGE,
            {"scope": scope},
            tz,
        )
        bot.send_message(
            c.message.chat.id,
            f"Сегмент: <b>{_scope_label(scope)}</b>\n"
            f"Потенциальных получателей: <b>{len(rec)}</b>\n\n"
            "Пришли сообщение (текст с форматированием или медиа).\n"
            "Бот отправит копию, сохранив стиль/markdown/вложения.",
        )
        bot.answer_callback_query(c.id)

    @bot.message_handler(
        func=lambda m: repo_states.get_state(conn, m.from_user.id)[0] == STATE_MANUAL_WAIT_MESSAGE,
        content_types=["text", "photo", "video", "document", "animation", "audio", "voice"],
    )
    def br_manual_receive(m: Message):
        if not _is_admin(ctx, m.from_user.id):
            return
        st, data = repo_states.get_state(conn, m.from_user.id)
        data = data or {}
        scope = data.get("scope") or repo_broadcasts.SCOPE_ALL
        rec = repo_broadcasts.list_recipients(conn, scope)
        payload = template_from_message(m)
        if not payload:
            bot.send_message(
                m.chat.id,
                "Этот тип сообщения пока не поддерживается для рассылки.\n"
                "Поддерживаются: текст, фото, видео, документ, GIF, аудио, голос.",
            )
            return
        repo_states.set_state(
            conn,
            m.from_user.id,
            "BR_CONFIRM",
            {
                "scope": scope,
                "source_chat_id": m.chat.id,
                "source_message_id": m.message_id,
                "template_payload": payload,
                "targets": len(rec),
            },
            tz,
        )
        kb = InlineKeyboardMarkup()
        kb.row(
            InlineKeyboardButton("✅ Отправить", callback_data="br:confirm_send"),
            InlineKeyboardButton("❌ Отмена", callback_data="m:broadcasts"),
        )
        bot.send_message(
            m.chat.id,
            f"Готово к отправке.\n"
            f"Сегмент: <b>{_scope_label(scope)}</b>\n"
            f"Получателей: <b>{len(rec)}</b>",
            reply_markup=kb,
        )

    @bot.callback_query_handler(func=lambda c: c.data == "br:confirm_send")
    def br_confirm_send(c: CallbackQuery):
        if not _is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        st, data = repo_states.get_state(conn, c.from_user.id)
        if st != "BR_CONFIRM":
            bot.answer_callback_query(c.id, "Сессия истекла")
            return
        scope = data.get("scope") or repo_broadcasts.SCOPE_ALL
        source_chat_id = int(data.get("source_chat_id"))
        source_message_id = int(data.get("source_message_id"))
        template_payload = data.get("template_payload") if isinstance(data.get("template_payload"), dict) else None
        campaign_id, sent, failed = _send_campaign(
            admin_id=c.from_user.id,
            source_chat_id=source_chat_id,
            source_message_id=source_message_id,
            scope=scope,
            kind=repo_broadcasts.KIND_MANUAL,
            auto_rule_id=None,
            template_payload=template_payload,
        )
        repo_states.clear_state(conn, c.from_user.id, tz)
        bot.edit_message_text(
            f"Рассылка отправлена.\n"
            f"Кампания: <b>#{campaign_id}</b>\n"
            f"Успешно: <b>{sent}</b>\n"
            f"Ошибки: <b>{failed}</b>",
            c.message.chat.id,
            c.message.message_id,
            reply_markup=InlineKeyboardMarkup().add(InlineKeyboardButton("📚 Открыть кампанию", callback_data=f"br:open:{campaign_id}")),
        )
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data == "br:history")
    def br_history(c: CallbackQuery):
        if not _is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        _render_history(c.message.chat.id, c.message.message_id)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("br:open:"))
    def br_open(c: CallbackQuery):
        if not _is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        cid = int(c.data.split(":")[2])
        _render_campaign(c.message.chat.id, c.message.message_id, cid)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("br:delete_sent:"))
    def br_delete_sent(c: CallbackQuery):
        if not _is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        cid = int(c.data.split(":")[2])
        deliveries = repo_broadcasts.list_deliveries(conn, cid, status=repo_broadcasts.STATUS_SENT)
        deleted = 0
        failed = 0
        for d in deliveries:
            msg_id = d["message_id"]
            if msg_id is None:
                continue
            try:
                bot.delete_message(int(d["chat_id"]), int(msg_id))
                repo_broadcasts.mark_delivery_deleted(conn, tz, int(d["id"]))
                deleted += 1
            except Exception:
                failed += 1
        repo_broadcasts.mark_campaign_deleted(conn, tz, cid)
        _render_campaign(c.message.chat.id, c.message.message_id, cid)
        bot.answer_callback_query(c.id, f"Удалено: {deleted}, ошибки: {failed}")

    @bot.callback_query_handler(func=lambda c: c.data == "br:auto:new")
    def br_auto_new(c: CallbackQuery):
        if not _is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        bot.edit_message_text(
            "<b>Новое автосообщение</b>\nВыбери сегмент:",
            c.message.chat.id,
            c.message.message_id,
            reply_markup=_scope_kb("br:auto:scope", "m:broadcasts"),
        )
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("br:auto:scope:"))
    def br_auto_scope(c: CallbackQuery):
        if not _is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        scope = c.data.split(":")[3]
        repo_states.set_state(conn, c.from_user.id, STATE_AUTO_WAIT_DAYS, {"scope": scope}, tz)
        bot.send_message(
            c.message.chat.id,
            f"Сегмент: <b>{_scope_label(scope)}</b>\n"
            "Введи неактивность в днях (например 7).",
        )
        bot.answer_callback_query(c.id)

    @bot.message_handler(
        func=lambda m: repo_states.get_state(conn, m.from_user.id)[0] == STATE_AUTO_WAIT_DAYS,
        content_types=["text"],
    )
    def br_auto_days(m: Message):
        if not _is_admin(ctx, m.from_user.id):
            return
        st, data = repo_states.get_state(conn, m.from_user.id)
        data = data or {}
        try:
            days = max(1, int((m.text or "").strip()))
        except Exception:
            bot.send_message(m.chat.id, "Нужно целое число дней (например 7).")
            return
        data["inactivity_days"] = days
        repo_states.set_state(conn, m.from_user.id, STATE_AUTO_WAIT_MESSAGE, data, tz)
        bot.send_message(
            m.chat.id,
            f"Ок, неактивность: <b>{days}</b> дн.\n"
            "Теперь пришли шаблон сообщения (текст/медиа), который бот будет копировать автоматически.",
        )

    @bot.message_handler(
        func=lambda m: repo_states.get_state(conn, m.from_user.id)[0] == STATE_AUTO_WAIT_MESSAGE,
        content_types=["text", "photo", "video", "document", "animation", "audio", "voice"],
    )
    def br_auto_message(m: Message):
        if not _is_admin(ctx, m.from_user.id):
            return
        st, data = repo_states.get_state(conn, m.from_user.id)
        data = data or {}
        scope = data.get("scope") or repo_broadcasts.SCOPE_ALL
        inactivity_days = int(data.get("inactivity_days") or 7)
        payload = template_from_message(m)
        if not payload:
            bot.send_message(
                m.chat.id,
                "Этот тип сообщения пока не поддерживается для автосообщений.\n"
                "Поддерживаются: текст, фото, видео, документ, GIF, аудио, голос.",
            )
            return
        rule_id = repo_broadcasts.create_auto_rule(
            conn,
            tz,
            created_by_admin_id=m.from_user.id,
            scope=scope,
            inactivity_days=inactivity_days,
            source_chat_id=m.chat.id,
            source_message_id=m.message_id,
            template_payload_json=encode_template_payload(payload),
        )
        repo_states.clear_state(conn, m.from_user.id, tz)
        kb = InlineKeyboardMarkup()
        kb.row(InlineKeyboardButton("Открыть правило", callback_data=f"br:auto:open:{rule_id}"))
        kb.row(InlineKeyboardButton("⬅️ В меню рассылок", callback_data="m:broadcasts"))
        bot.send_message(
            m.chat.id,
            f"Автосообщение создано.\n"
            f"Правило: <b>#{rule_id}</b>\n"
            f"Сегмент: <b>{_scope_label(scope)}</b>\n"
            f"Порог неактивности: <b>{inactivity_days}</b> дн",
            reply_markup=kb,
        )

    @bot.callback_query_handler(func=lambda c: c.data == "br:auto:list")
    def br_auto_list(c: CallbackQuery):
        if not _is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        _render_auto_rules(c.message.chat.id, c.message.message_id)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("br:auto:open:"))
    def br_auto_open(c: CallbackQuery):
        if not _is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        rid = int(c.data.split(":")[3])
        _render_auto_rule(c.message.chat.id, c.message.message_id, rid)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("br:auto:toggle:"))
    def br_auto_toggle(c: CallbackQuery):
        if not _is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        rid = int(c.data.split(":")[3])
        r = repo_broadcasts.get_auto_rule(conn, rid)
        if not r:
            bot.answer_callback_query(c.id, "Не найдено")
            return
        enabled = int(r["enabled"] or 0) != 1
        repo_broadcasts.set_auto_rule_enabled(conn, tz, rid, enabled)
        _render_auto_rule(c.message.chat.id, c.message.message_id, rid)
        bot.answer_callback_query(c.id, "Обновлено")

    @bot.callback_query_handler(func=lambda c: c.data.startswith("br:auto:del:"))
    def br_auto_del(c: CallbackQuery):
        if not _is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        rid = int(c.data.split(":")[3])
        repo_broadcasts.delete_auto_rule(conn, rid)
        _render_auto_rules(c.message.chat.id, c.message.message_id)
        bot.answer_callback_query(c.id, "Удалено")

    @bot.callback_query_handler(func=lambda c: c.data.startswith("br:auto:run:"))
    def br_auto_run(c: CallbackQuery):
        if not _is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        rid = int(c.data.split(":")[3])
        rule = repo_broadcasts.get_auto_rule(conn, rid)
        if not rule:
            bot.answer_callback_query(c.id, "Не найдено")
            return
        recipients = repo_broadcasts.list_inactive_recipients(
            conn,
            tz,
            scope=rule["scope"],
            inactivity_days=int(rule["inactivity_days"]),
        )
        # Anti-spam: do not resend to same user more often than inactivity_days.
        filtered: list[sqlite3.Row] = []
        cooldown = dt.timedelta(days=max(1, int(rule["inactivity_days"])))
        now_dt = now(tz)
        for r in recipients:
            last_sent = repo_broadcasts.last_auto_send_at(conn, rid, int(r["user_id"]))
            if not last_sent:
                filtered.append(r)
                continue
            try:
                sent_dt = dt.datetime.fromisoformat(last_sent)
                if sent_dt.tzinfo is None:
                    sent_dt = sent_dt.replace(tzinfo=now_dt.tzinfo)
            except Exception:
                filtered.append(r)
                continue
            if now_dt - sent_dt >= cooldown:
                filtered.append(r)

        campaign_id = repo_broadcasts.create_campaign(
            conn,
            tz,
            created_by_admin_id=c.from_user.id,
            scope=rule["scope"],
            source_chat_id=int(rule["source_chat_id"]),
            source_message_id=int(rule["source_message_id"]),
            total_targets=len(filtered),
            template_kind=repo_broadcasts.KIND_AUTO,
            auto_rule_id=rid,
        )
        sent = 0
        failed = 0
        sent_at = now(tz).isoformat()
        payload = decode_template_payload(rule["template_payload_json"] if "template_payload_json" in rule.keys() else None)
        for r in filtered:
            uid = int(r["user_id"])
            chat_id = int(r["chat_id"])
            try:
                mid = send_template(
                    bot,
                    chat_id,
                    payload,
                    fallback_source_chat_id=int(rule["source_chat_id"]),
                    fallback_source_message_id=int(rule["source_message_id"]),
                )
                repo_broadcasts.add_delivery(
                    conn, campaign_id, uid, chat_id, mid, repo_broadcasts.STATUS_SENT, None, sent_at
                )
                sent += 1
            except Exception as e:
                repo_broadcasts.add_delivery(
                    conn, campaign_id, uid, chat_id, None, repo_broadcasts.STATUS_FAILED, str(e), None
                )
                failed += 1
        repo_broadcasts.finalize_campaign(conn, tz, campaign_id, sent, failed)
        repo_broadcasts.set_auto_rule_last_run(conn, tz, rid)
        _render_auto_rule(c.message.chat.id, c.message.message_id, rid)
        bot.answer_callback_query(c.id, f"Отправлено: {sent}, ошибки: {failed}")
