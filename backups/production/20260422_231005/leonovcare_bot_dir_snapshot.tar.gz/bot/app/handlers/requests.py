from __future__ import annotations

import sqlite3

from telebot import TeleBot
from telebot.types import CallbackQuery

from app.db import (
    repo_requests,
    repo_students,
    repo_payments,
    repo_settings,
    repo_postpay,
    repo_alerts,
    repo_analytics,
    repo_enrollment_contracts,
)
from app.services.timeutils import now, format_date_ddmmyyyy, iso
from app.services.postpay import post_total, next_due_after_payment
from app.ui import texts
from app.ui.keyboards import request_reject_confirm_kb


def init(bot: TeleBot, ctx: dict) -> None:
    conn: sqlite3.Connection = ctx["conn"]
    tz = ctx["cfg"].TZ

    def is_admin(user_id: int) -> bool:
        return int(user_id) in ctx["cfg"].ADMIN_IDS

    def _admin_only(c: CallbackQuery) -> bool:
        if not is_admin(c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа")
            return False
        return True

    def _row_id(row) -> int | None:
        if not row:
            return None
        try:
            return int(row["id"])
        except Exception:
            try:
                return int(row[0])
            except Exception:
                return None

    def _ensure_ref(table: str, name: str | None) -> int | None:
        name = (name or "").strip()
        if not name:
            return None
        row = conn.execute(f"SELECT id FROM {table} WHERE lower(name)=lower(?) LIMIT 1", (name,)).fetchone()
        rid = _row_id(row)
        if rid:
            return rid
        # create if missing
        if table == "directions":
            conn.execute("INSERT OR IGNORE INTO directions(name, sort) VALUES(?, 999)", (name,))
        elif table == "stages":
            conn.execute("INSERT OR IGNORE INTO stages(name, sort) VALUES(?, 999)", (name,))
        conn.commit()
        row = conn.execute(f"SELECT id FROM {table} WHERE lower(name)=lower(?) LIMIT 1", (name,)).fetchone()
        return _row_id(row)

    def _notify_student(owner_tg_id: int, payload: dict, text: str) -> None:
        chat_id = payload.get("owner_chat_id") or owner_tg_id
        try:
            bot.send_message(int(chat_id), text)
        except Exception:
            pass

    @bot.callback_query_handler(func=lambda c: c.data.startswith("req:open:"))
    def cb_open(c: CallbackQuery):
        if not _admin_only(c):
            return
        req_id = int(c.data.split(":")[2])
        r = repo_requests.get(conn, req_id)
        if not r:
            bot.answer_callback_query(c.id, "Не найдено")
            return
        p = repo_requests.payload(r)
        txt = f"<b>[ЗАЯВКА]</b> {texts.request_title(r['req_type'])}\nID: {req_id}\nСтатус: {r['status']}\n" \
              f"От TG: {r['owner_tg_id']}\n\n" + "\n".join([f"{k}: {v}" for k, v in p.items() if k not in ("hh_password",)])
        bot.send_message(c.message.chat.id, txt)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("req:ok:"))
    def cb_ok(c: CallbackQuery):
        if not _admin_only(c):
            return
        req_id = int(c.data.split(":")[2])
        r = repo_requests.get(conn, req_id)
        if not r or r["status"] != "PENDING":
            bot.answer_callback_query(c.id, "Неактуально")
            return
        p = repo_requests.payload(r)
        owner_tg_id = int(r["owner_tg_id"])
        # Find existing student by owner or by username
        s = repo_students.get_by_owner(conn, owner_tg_id)
        if r["req_type"] == "PROFILE":
            # ensure student exists
            if not s:
                # create minimal student using existing admin flow helper
                # We will insert directly
                from app.services.timeutils import iso
                ts = iso(now(tz))
                direction_id = _ensure_ref("directions", p.get("direction"))
                stage_id = _ensure_ref("stages", p.get("stage"))
                cur = conn.execute(
                    "INSERT INTO students(fio, username, direction_id, stage_id, tariff, comment, join_date, contract_url, created_at, updated_at, owner_tg_id, owner_chat_id, owner_username) "
                    "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    (
                        p.get("fio") or "—",
                        (p.get("username") or "").lstrip("@") or None,
                        direction_id,
                        stage_id,
                        p.get("tariff") or "post",
                        p.get("comment") or "",
                        p.get("join_date") or format_date_ddmmyyyy(now(tz).date()),
                        p.get("contract_url"),
                        ts,
                        ts,
                        owner_tg_id,
                        int(p.get("owner_chat_id") or 0) or None,
                        p.get("owner_username"),
                    ),
                )
                conn.commit()
                student_id = int(cur.lastrowid)
            else:
                student_id = int(s["id"])
                direction_id = _ensure_ref("directions", p.get("direction")) or s["direction_id"]
                stage_id = _ensure_ref("stages", p.get("stage")) or s["stage_id"]
                repo_students.update_student(
                    conn,
                    student_id,
                    tz,
                    fio=p.get("fio") or s["fio"],
                    username=(p.get("username") or s["username"] or "").lstrip("@") or None,
                    direction_id=direction_id,
                    stage_id=stage_id,
                    tariff=p.get("tariff") or s["tariff"],
                    contract_url=p.get("contract_url") or s["contract_url"],
                    join_date=p.get("join_date") or s["join_date"],
                    comment=p.get("comment") or s["comment"],
                )
                # owner info
                repo_students.set_owner(conn, tz, student_id, owner_tg_id, int(p.get("owner_chat_id") or c.message.chat.id), p.get("owner_username"))

            # если ученик указал предоплату — добавим как платёж (один раз)
            try:
                prepay = int(float(p.get("prepay") or 0))
            except Exception:
                prepay = 0
            if prepay > 0 and repo_payments.sum_payments(conn, student_id, "prepay") == 0:
                repo_payments.add_payment(
                    conn,
                    student_id,
                    "prepay",
                    prepay,
                    format_date_ddmmyyyy(now(tz).date()),
                    tz,
                    source="student",
                    note="prepay from form",
                )

            # postpay rule on student_postpay
            try:
                total_percent = float(p.get("post_total_percent") or 0)
                per_month = float(p.get("post_monthly_percent") or 50)
                if total_percent > 0:
                    conn.execute(
                        "INSERT INTO student_postpay(student_id,total_percent,schedule_type,per_period_value,period_unit,enabled) "
                        "VALUES(?,?,?,?,?,1) ON CONFLICT(student_id) DO UPDATE SET total_percent=excluded.total_percent, schedule_type=excluded.schedule_type, per_period_value=excluded.per_period_value, enabled=1",
                        (student_id, total_percent, "percent_per_month", per_month, "month"),
                    )
                    conn.commit()
            except Exception:
                pass

        elif r["req_type"] == "ACCOUNTS":
            if not s:
                bot.answer_callback_query(c.id, "Сначала одобри анкету")
                return
            student_id = int(s["id"])
            repo_students.update_student(
                conn,
                student_id,
                tz,
                hh_phone=p.get("hh_phone"),
                hh_email=p.get("hh_email"),
                hh_password=p.get("hh_password"),
                hh_birth_date=p.get("hh_birth_date"),
                hh_location=p.get("hh_location"),
                hh_salary_min=p.get("hh_salary_min"),
                hh_salary_comfort=p.get("hh_salary_comfort"),
            )

        elif r["req_type"] == "PAYMENT":
            if not s:
                bot.answer_callback_query(c.id, "Сначала одобри анкету")
                return
            student_id = int(s["id"])
            amount = int(p.get("amount") or 0)
            if amount > 0:
                pay_date_raw = str(p.get("pay_date") or "").strip()
                if len(pay_date_raw) == 10 and pay_date_raw[2] == "." and pay_date_raw[5] == ".":
                    pay_date = pay_date_raw
                else:
                    pay_date = format_date_ddmmyyyy(now(tz).date())
                verification = p.get("verification") if isinstance(p.get("verification"), dict) else {}
                note = "proof" if verification.get("ok", True) else "proof:review"
                repo_payments.add_payment(
                    conn,
                    student_id,
                    "postpay",
                    amount,
                    pay_date,
                    tz,
                    source="student",
                    proof_file_id=p.get("proof_file_id"),
                    note=note,
                )

                # advance schedule and reset student notifications to next due
                pp = repo_postpay.get(conn, student_id)
                if pp and pp["enabled"]:
                    new_due = next_due_after_payment(pp["next_due_date"], pay_date, pp["schedule_type"], pp["per_period_value"])
                    repo_postpay.upsert(conn, student_id, next_due_date=new_due, student_next_notify_date=new_due, enabled=1)

                    # auto-disable if fully paid
                    total = post_total(s["offer_amount"], pp["total_percent"])
                    if total is not None:
                        paid = repo_payments.sum_payments(conn, student_id, "postpay")
                        if paid >= total:
                            repo_postpay.disable(conn, student_id)

                # close any pending PAYMENT alerts in student's chat
                try:
                    schat = int(s["owner_chat_id"]) if s["owner_chat_id"] else None
                except Exception:
                    schat = None
                if schat:
                    conn.execute(
                        "UPDATE alerts SET status='SEEN', updated_at=? WHERE status='PENDING' AND alert_type='PAYMENT' AND related_table='students' AND related_id=? AND chat_id=?",
                        (iso(now(tz)), student_id, schat),
                    )
                    conn.commit()
        elif r["req_type"] == "ENROLLMENT_PAYMENT":
            amount = int(p.get("amount") or 0)
            pay_date_raw = str(p.get("pay_date") or "").strip()
            if len(pay_date_raw) == 10 and pay_date_raw[2] == "." and pay_date_raw[5] == ".":
                pay_date = pay_date_raw
            else:
                pay_date = format_date_ddmmyyyy(now(tz).date())

            verification = p.get("verification") if isinstance(p.get("verification"), dict) else {}
            note = "enrollment_proof" if verification.get("ok", True) else "enrollment_proof:review"
            if s and amount > 0:
                repo_payments.add_payment(
                    conn,
                    int(s["id"]),
                    "prepay",
                    amount,
                    pay_date,
                    tz,
                    source="student",
                    proof_file_id=p.get("proof_file_id"),
                    note=note,
                )

            contract = repo_enrollment_contracts.get_by_owner(conn, owner_tg_id)
            if contract:
                repo_enrollment_contracts.set_status(
                    conn,
                    tz,
                    owner_tg_id,
                    status="paid",
                    note=f"payment_req:{req_id}",
                )
        repo_requests.set_status(conn, tz, req_id, "APPROVED")
        if r["req_type"] == "PROFILE":
            repo_analytics.set_role(conn, tz, owner_tg_id, repo_analytics.ROLE_STUDENT)
            repo_analytics.log_event(conn, tz, owner_tg_id, "funnel.student.profile_approved", {"req_id": req_id})
        _notify_student(owner_tg_id, p, "Заявка подтверждена ментором ✅")
        bot.answer_callback_query(c.id, "Одобрено")

    @bot.callback_query_handler(func=lambda c: c.data.startswith("req:ask_no:"))
    def cb_ask_no(c: CallbackQuery):
        if not _admin_only(c):
            return
        req_id = int(c.data.split(":")[2])
        r = repo_requests.get(conn, req_id)
        if not r or r["status"] != "PENDING":
            bot.answer_callback_query(c.id, "Неактуально")
            return
        bot.send_message(c.message.chat.id, "Точно отклонить заявку?", reply_markup=request_reject_confirm_kb(req_id))
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("req:no:"))
    def cb_no(c: CallbackQuery):
        if not _admin_only(c):
            return
        req_id = int(c.data.split(":")[2])
        r = repo_requests.get(conn, req_id)
        if not r or r["status"] != "PENDING":
            bot.answer_callback_query(c.id, "Неактуально")
            return
        p = repo_requests.payload(r)
        repo_requests.set_status(conn, tz, req_id, "REJECTED")
        if r["req_type"] == "PROFILE":
            repo_analytics.log_event(conn, tz, int(r["owner_tg_id"]), "funnel.student.profile_rejected", {"req_id": req_id})
        _notify_student(int(r["owner_tg_id"]), p, "Заявка отклонена ментором ❌\nИсправь и отправь заново через кнопку «Моя анкета».")
        bot.answer_callback_query(c.id, "Отклонено")
