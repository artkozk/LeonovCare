from __future__ import annotations
import sqlite3
from typing import Any
from telebot import TeleBot
from telebot.types import Message, CallbackQuery

from app.db import repo_settings, repo_states, repo_students, repo_student_codes, repo_analytics
from app.ui.keyboards import main_menu_kb, regular_menu_kb
from app.ui import texts

ADMIN_CHAT_KEY = "ADMIN_CHAT_ID"
ROUTE_LABELS = {
    "home": "Главное меню",
    "student": "Раздел «Я ученик»",
    "enroll": "Раздел «Вступить на обучение»",
    "materials": "Раздел «Бесплатные материалы»",
    "auto": "Раздел «Автоотклики»",
}

def is_admin(ctx: dict, user_id: int) -> bool:
    return int(user_id) in ctx["cfg"].ADMIN_IDS

def _save_admin_chat(conn: sqlite3.Connection, chat_id: int):
    repo_settings.set(conn, ADMIN_CHAT_KEY, str(chat_id))

def send_main(bot: TeleBot, ctx: dict, chat_id: int):
    bot.send_message(chat_id, texts.main_title(), reply_markup=main_menu_kb())


def send_regular_main(bot: TeleBot, ctx: dict, chat_id: int):
    bot.send_message(chat_id, texts.regular_title(), reply_markup=regular_menu_kb())


def _extract_start_payload(text: str | None) -> str:
    raw = (text or "").strip()
    if not raw:
        return ""
    parts = raw.split(maxsplit=1)
    if len(parts) < 2:
        return ""
    payload = parts[1].strip()
    return payload[:128]


def _normalize_route(route: str | None) -> str:
    val = (route or "").strip().lower()
    if val in {"home", "student", "enroll", "materials", "auto"}:
        return val
    return "home"


def _legacy_route_from_service(service: str | None) -> str:
    token = (service or "").strip().lower()
    mapping = {
        "autoapply": "auto",
        "zerooffer": "enroll",
        "interviewprep": "enroll",
        "gradesalary": "enroll",
    }
    return mapping.get(token, "home")


def _parse_deeplink_payload(payload: str) -> dict[str, Any]:
    out: dict[str, Any] = {"raw": payload}
    token = (payload or "").strip()
    if not token:
        return out

    if token.startswith("lc2_"):
        parts = token.split("_")
        out["version"] = "lc2"
        out["route"] = _normalize_route(parts[1] if len(parts) > 1 else "home")
        out["service"] = parts[2] if len(parts) > 2 else ""
        out["plan"] = parts[3] if len(parts) > 3 else ""
        out["source"] = parts[4] if len(parts) > 4 else ""
        if len(parts) > 5 and parts[5].startswith("c"):
            digits = "".join(ch for ch in parts[5][1:] if ch.isdigit())
            if digits:
                out["clicks"] = int(digits)
        return out

    if token.startswith("lc1_"):
        parts = token.split("_")
        out["version"] = "lc1"
        out["route"] = _normalize_route(parts[1] if len(parts) > 1 else "home")
        out["service"] = parts[2] if len(parts) > 2 else ""
        out["plan"] = ""
        out["source"] = parts[3] if len(parts) > 3 else ""
        if len(parts) > 4 and parts[4].startswith("c"):
            digits = "".join(ch for ch in parts[4][1:] if ch.isdigit())
            if digits:
                out["clicks"] = int(digits)
        return out

    if token.startswith("lc_"):
        parts = token.split("_")
        out["version"] = "legacy"
        out["service"] = parts[1] if len(parts) > 1 else ""
        out["plan"] = ""
        out["source"] = parts[2] if len(parts) > 2 else ""
        out["route"] = _legacy_route_from_service(out["service"])
        if len(parts) > 3:
            digits = "".join(ch for ch in parts[3] if ch.isdigit())
            if digits:
                out["clicks"] = int(digits)
        return out

    out["version"] = "unknown"
    out["route"] = "home"
    return out


def _dispatch_public_route(ctx: dict, chat_id: int, user_id: int, meta: dict[str, Any]) -> bool:
    routes = ctx.get("public_routes")
    if not isinstance(routes, dict):
        return False
    route = _normalize_route(meta.get("route"))
    handler = routes.get(route)
    if not callable(handler):
        return False
    try:
        handler(chat_id, int(user_id), meta)
        return True
    except Exception:
        return False

def init(bot: TeleBot, ctx: dict) -> None:
    conn: sqlite3.Connection = ctx["conn"]
    tz = ctx["cfg"].TZ

    def _build_site_intent_payload(meta: dict[str, Any], start_payload: str, role: str, chat_id: int, username: str | None) -> dict[str, Any]:
        route = _normalize_route(meta.get("route"))
        clicks_raw = meta.get("clicks", 0)
        try:
            clicks = max(int(clicks_raw), 0)
        except Exception:
            clicks = 0
        service = str(meta.get("service") or "").strip().lower()
        plan = str(meta.get("plan") or "").strip().lower()
        source = str(meta.get("source") or "").strip().lower()
        auto_possible = route == "auto"
        return {
            "entry": "site_deeplink",
            "version": str(meta.get("version") or ""),
            "route": route,
            "route_label": ROUTE_LABELS.get(route, ROUTE_LABELS["home"]),
            "service": service,
            "plan": plan,
            "source": source,
            "clicks": clicks,
            "raw_payload": start_payload,
            "owner_chat_id": int(chat_id),
            "owner_username": username,
            "role_on_start": role,
            "auto_possible": auto_possible,
            "requires_mentor": not auto_possible,
        }

    def _save_site_intent_if_needed(m: Message, role: str, start_payload: str, deeplink_meta: dict[str, Any]) -> int | None:
        version = str(deeplink_meta.get("version") or "").strip().lower()
        if version not in {"lc2", "lc1", "legacy"}:
            return None

        payload = _build_site_intent_payload(
            deeplink_meta,
            start_payload,
            role,
            m.chat.id,
            m.from_user.username,
        )
        repo_analytics.log_event(
            conn,
            tz,
            m.from_user.id,
            "lead.site_intent_saved",
            {
                "route": payload["route"],
                "service": payload["service"],
                "plan": payload["plan"],
                "source": payload["source"],
                "clicks": payload["clicks"],
                "requires_mentor": payload["requires_mentor"],
            },
            username=m.from_user.username,
        )
        return None

    def _role_for_user(user_id: int) -> str:
        if is_admin(ctx, user_id):
            return repo_analytics.ROLE_ADMIN
        latest_student = repo_students.get_latest_by_owner(conn, int(user_id))
        if latest_student and int(latest_student["archived"] or 0) == 1:
            return repo_analytics.ROLE_REGULAR
        if latest_student or repo_student_codes.has_used_code(conn, int(user_id)):
            return repo_analytics.ROLE_STUDENT
        return repo_analytics.ROLE_REGULAR

    @bot.message_handler(commands=["start"])
    def on_start(m: Message):
        role = _role_for_user(m.from_user.id)
        start_payload = _extract_start_payload(getattr(m, "text", None))
        deeplink_meta = _parse_deeplink_payload(start_payload) if start_payload else {}
        repo_analytics.touch_user(
            conn,
            tz,
            m.from_user.id,
            role_type=role,
            username=m.from_user.username,
            is_start=True,
        )
        repo_analytics.log_event(
            conn,
            tz,
            m.from_user.id,
            "app.start",
            {
                "role": role,
                "payload": start_payload,
                **deeplink_meta,
            },
            username=m.from_user.username,
        )
        if start_payload:
            repo_analytics.log_event(
                conn,
                tz,
                m.from_user.id,
                "app.start_deeplink",
                deeplink_meta,
                username=m.from_user.username,
            )
            if not is_admin(ctx, m.from_user.id):
                _save_site_intent_if_needed(m, role, start_payload, deeplink_meta)
        if is_admin(ctx, m.from_user.id):
            _save_admin_chat(conn, m.chat.id)
            repo_states.clear_state(conn, m.from_user.id, tz)
            send_main(bot, ctx, m.chat.id)
        else:
            repo_states.clear_state(conn, m.from_user.id, tz)
            if deeplink_meta and _dispatch_public_route(ctx, m.chat.id, m.from_user.id, deeplink_meta):
                return
            send_regular_main(bot, ctx, m.chat.id)

    @bot.callback_query_handler(func=lambda c: c.data == "m:main")
    def cb_main(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        _save_admin_chat(conn, c.message.chat.id)
        repo_states.clear_state(conn, c.from_user.id, tz)
        bot.edit_message_text(texts.main_title(), c.message.chat.id, c.message.message_id, reply_markup=main_menu_kb())
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data == "noop")
    def cb_noop(c: CallbackQuery):
        bot.answer_callback_query(c.id)
