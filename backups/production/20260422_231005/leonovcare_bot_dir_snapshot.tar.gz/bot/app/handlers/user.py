from __future__ import annotations

import html
import os
import sqlite3
from datetime import datetime, timedelta

from telebot import TeleBot
from telebot.types import CallbackQuery, Message, InlineKeyboardMarkup, InlineKeyboardButton

from app.db import (
    repo_states,
    repo_students,
    repo_requests,
    repo_settings,
    repo_postpay,
    repo_student_codes,
    repo_analytics,
    repo_payments,
    repo_enrollment_contracts,
    repo_autoapply_runs,
)
from app.services.autoapply_client import AutoApplyClient, AutoApplyClientError
from app.services.okidoki_client import OkiDokiClient, OkiDokiClientError
from app.services.postpay import recommended_payment
from app.services.timeutils import now, format_date_ddmmyyyy
from app.ui import texts
from app.ui.keyboards import (
    regular_menu_kb,
    user_menu_kb,
    user_direction_kb,
    user_stage_kb,
    user_tariff_kb,
    user_prepay_kb,
    user_post_total_kb,
    user_post_monthly_kb,
    request_admin_kb,
    request_open_kb,
)


STATE_PROFILE = "u_profile"
STATE_ACCOUNTS = "u_accounts"
STATE_PAYMENT = "u_payment"
STATE_ENROLL_PAYMENT = "u_enroll_payment"
STATE_STUDENT_CODE = "u_student_code"
STATE_AUTOAPPLY = "u_autoapply"
STATE_ENROLL = "u_enroll"

AUTO_DIRECTIONS = ("java", "golang", "frontend", "python")
AUTOAPPLY_FREE50_KEY_PREFIX = "autoapply.free50.used:"

ENROLL_TRACKS: dict[str, dict] = {
    "zero-offer": {
        "alias": "zero",
        "title": "С нуля до оффера",
        "level": "zero",
        "plans": [
            {
                "key": "a100",
                "title": "Сопровождение до работы",
                "subtitle": "С нуля до оффера",
                "price": "60 000 ₽ + 100% от оффера / 30 000 ₽ + 150% от оффера",
            },
            {
                "key": "month",
                "title": "Сопровождение 1 месяц",
                "subtitle": "Фиксированный тариф",
                "price": "27 900 ₽",
            },
            {
                "key": "diag",
                "title": "Диагностика и roadmap",
                "subtitle": "Разовый формат",
                "price": "8 900 ₽",
            },
        ],
    },
    "interview-prep": {
        "alias": "prep",
        "title": "После курсов до оффера",
        "level": "not_zero",
        "plans": [
            {
                "key": "a100",
                "title": "Сопровождение до работы",
                "subtitle": "После курсов до оффера",
                "price": "60 000 ₽ + 100% от оффера / 30 000 ₽ + 150% от оффера",
            },
            {
                "key": "int2w",
                "title": "Интенсив 2 недели",
                "subtitle": "Фиксированный тариф",
                "price": "16 900 ₽",
            },
            {
                "key": "mock",
                "title": "1 mock-собеседование",
                "subtitle": "Разовый формат",
                "price": "4 990 ₽",
            },
        ],
    },
    "grade-salary": {
        "alias": "grade",
        "title": "Увеличение зарплаты",
        "level": "not_zero",
        "plans": [
            {
                "key": "a100",
                "title": "Сопровождение до работы",
                "subtitle": "Рост дохода",
                "price": "60 000 ₽ + 100% от оффера / 30 000 ₽ + 150% от оффера",
            },
            {
                "key": "sprint",
                "title": "Рост-спринт 4 недели",
                "subtitle": "Фиксированный тариф",
                "price": "24 900 ₽",
            },
            {
                "key": "mock",
                "title": "1 mock-собеседование",
                "subtitle": "Разовый формат",
                "price": "4 990 ₽",
            },
            {
                "key": "audit",
                "title": "Аудит грейда",
                "subtitle": "Разовый формат",
                "price": "8 900 ₽",
            },
        ],
    },
}

ENROLL_TRACK_BY_ALIAS = {v["alias"]: k for k, v in ENROLL_TRACKS.items()}


def init(bot: TeleBot, ctx: dict) -> None:
    cfg = ctx["cfg"]
    conn: sqlite3.Connection = ctx["conn"]
    tz = cfg.TZ
    auto_client = AutoApplyClient(
        base_url=cfg.AUTOAPPLY_API_BASE_URL,
        internal_token=cfg.AUTOAPPLY_INTERNAL_TOKEN,
        timeout_sec=cfg.AUTOAPPLY_TIMEOUT_SEC,
    )
    okidoki_client = OkiDokiClient(
        create_contract_url=cfg.OKIDOKI_CREATE_CONTRACT_URL,
        api_token=cfg.OKIDOKI_API_TOKEN,
        timeout_sec=30,
    )

    def is_admin(user_id: int) -> bool:
        return int(user_id) in ctx["cfg"].ADMIN_IDS

    def _parse_money(text: str) -> int:
        digits = "".join(ch for ch in (text or "") if ch.isdigit())
        return int(digits) if digits else 0

    def _user_show_pay_button(owner_tg_id: int) -> bool:
        s = repo_students.get_by_owner(conn, int(owner_tg_id))
        if not s or not s["offer_amount"]:
            return False
        pp = repo_postpay.get(conn, int(s["id"]))
        return bool(pp and int(pp["enabled"] or 0) == 1)

    def _has_student_access(owner_tg_id: int) -> bool:
        latest_student = repo_students.get_latest_by_owner(conn, int(owner_tg_id))
        if latest_student:
            return int(latest_student["archived"] or 0) == 0
        return repo_student_codes.has_used_code(conn, int(owner_tg_id))

    def send_regular_home(chat_id: int, owner_tg_id: int) -> None:
        repo_states.clear_state(conn, owner_tg_id, tz)
        repo_analytics.touch_user(conn, tz, owner_tg_id, role_type=repo_analytics.ROLE_REGULAR)
        bot.send_message(chat_id, texts.regular_title(), reply_markup=regular_menu_kb())

    def send_user_home(chat_id: int, owner_tg_id: int) -> None:
        repo_states.clear_state(conn, owner_tg_id, tz)
        repo_analytics.touch_user(conn, tz, owner_tg_id, role_type=repo_analytics.ROLE_STUDENT)
        bot.send_message(chat_id, texts.user_title(), reply_markup=user_menu_kb(show_pay=_user_show_pay_button(owner_tg_id)))

    def _v2_back_kb() -> InlineKeyboardMarkup:
        kb = InlineKeyboardMarkup()
        kb.row(InlineKeyboardButton("⬅️ В меню", callback_data="v2:home"))
        return kb

    def _send_student_access_required(chat_id: int) -> None:
        kb = InlineKeyboardMarkup()
        kb.row(InlineKeyboardButton("Я ученик", callback_data="v2:student"))
        kb.row(InlineKeyboardButton("⬅️ В меню", callback_data="v2:home"))
        bot.send_message(
            chat_id,
            "Доступ к кабинету ученика закрыт.\nНажми «Я ученик» и введи одноразовый код от ментора.",
            reply_markup=kb,
        )

    def _admin_targets() -> list[int]:
        targets: set[int] = set()
        for x in ctx["cfg"].ADMIN_IDS or []:
            try:
                targets.add(int(x))
            except Exception:
                pass
        raw = repo_settings.get(conn, "ADMIN_CHAT_ID", None)
        if raw:
            try:
                targets.add(int(raw))
            except Exception:
                pass
        return list(targets)

    def notify_admins(text: str, kb: InlineKeyboardMarkup | None = None) -> None:
        for chat_id in _admin_targets():
            try:
                bot.send_message(int(chat_id), text, reply_markup=kb)
            except Exception:
                # admin may not have started the bot in this chat yet
                pass

    def _digits_only(value: str | None) -> str:
        return "".join(ch for ch in str(value or "") if ch.isdigit())

    def _parse_date_ru(text: str | None):
        raw = (text or "").strip()
        if not raw:
            return None
        try:
            return datetime.strptime(raw, "%d.%m.%Y").date()
        except Exception:
            return None

    def _format_money_value(value: int | None) -> str:
        try:
            n = int(value or 0)
        except Exception:
            n = 0
        return f"{n:,}".replace(",", " ")

    def _auto_free50_key(owner_tg_id: int) -> str:
        return f"{AUTOAPPLY_FREE50_KEY_PREFIX}{int(owner_tg_id)}"

    def _auto_free50_used_count(owner_tg_id: int) -> int:
        marker = str(repo_settings.get(conn, _auto_free50_key(owner_tg_id), None) or "").strip()
        if not marker:
            return 0

        tail = marker.rsplit("|", 1)[-1] if "|" in marker else marker
        digits = "".join(ch for ch in tail if ch.isdigit())
        if digits:
            try:
                used = int(digits)
                return max(0, min(used, 50))
            except Exception:
                pass
        # Legacy marker without numeric payload -> treat as fully used.
        return 50

    def _auto_free50_remaining(owner_tg_id: int) -> int:
        return max(50 - _auto_free50_used_count(owner_tg_id), 0)

    def _auto_free50_already_used(owner_tg_id: int) -> bool:
        return _auto_free50_remaining(owner_tg_id) <= 0

    def _auto_mark_free50_used(owner_tg_id: int, free_clicks_granted: int) -> None:
        granted = max(int(free_clicks_granted or 0), 0)
        if granted <= 0:
            return
        used_total = min(_auto_free50_used_count(owner_tg_id) + granted, 50)
        marker = f"{format_date_ddmmyyyy(now(tz).date())}|{used_total}"
        repo_settings.set(conn, _auto_free50_key(owner_tg_id), marker)

    def _auto_price_breakdown(owner_tg_id: int, raw_clicks: int) -> dict:
        clicks = max(int(raw_clicks or 0), 0)
        per_click = 7
        if 200 <= clicks < 500:
            per_click = 6
        elif clicks >= 500:
            per_click = 5

        free_remaining = _auto_free50_remaining(owner_tg_id)
        free_available = free_remaining > 0
        free_clicks = 0
        if free_available and clicks < 200:
            free_clicks = min(clicks, free_remaining)

        paid_clicks = max(clicks - free_clicks, 0)
        total_price = int(paid_clicks * per_click)
        return {
            "clicks": clicks,
            "per_click": per_click,
            "free_clicks": free_clicks,
            "free_remaining": free_remaining,
            "free_used": 50 - free_remaining,
            "paid_clicks": paid_clicks,
            "total_price": total_price,
            "free_available": free_available,
        }

    def _auto_price_for_user(owner_tg_id: int, raw_clicks: int) -> int:
        return int(_auto_price_breakdown(owner_tg_id, raw_clicks).get("total_price") or 0)

    def _payment_due_context(owner_tg_id: int) -> dict:
        out = {
            "has_student": False,
            "student_id": None,
            "offer_amount": 0,
            "postpay_enabled": False,
            "schedule_type": "",
            "per_period_value": None,
            "total_postpay": None,
            "paid_postpay": 0,
            "remaining_postpay": None,
            "recommended_amount": None,
            "invoice_amount": 0,
            "closed": False,
        }
        s = repo_students.get_by_owner(conn, int(owner_tg_id))
        if not s:
            return out
        out["has_student"] = True
        sid = int(s["id"])
        out["student_id"] = sid
        offer_amount = int(s["offer_amount"] or 0)
        out["offer_amount"] = offer_amount

        pp = repo_postpay.get(conn, sid)
        if not pp:
            return out
        out["postpay_enabled"] = int(pp["enabled"] or 0) == 1
        out["schedule_type"] = str(pp["schedule_type"] or "").strip()
        out["per_period_value"] = pp["per_period_value"]

        total_postpay = None
        try:
            if offer_amount > 0 and pp["total_percent"]:
                total_postpay = int(round(float(offer_amount) * float(pp["total_percent"]) / 100))
        except Exception:
            total_postpay = None
        out["total_postpay"] = total_postpay

        paid_postpay = repo_payments.sum_payments(conn, sid, "postpay")
        out["paid_postpay"] = int(paid_postpay or 0)

        remaining_postpay = None
        if total_postpay is not None:
            remaining_postpay = max(int(total_postpay) - int(out["paid_postpay"]), 0)
        out["remaining_postpay"] = remaining_postpay

        rec = None
        try:
            rec = recommended_payment(
                offer_amount if offer_amount > 0 else None,
                out["schedule_type"],
                out["per_period_value"],
            )
        except Exception:
            rec = None
        if rec is not None and rec > 0:
            out["recommended_amount"] = int(rec)

        invoice_amount = 0
        if remaining_postpay is not None and remaining_postpay > 0:
            if out["recommended_amount"] and out["recommended_amount"] > 0:
                invoice_amount = min(int(out["recommended_amount"]), int(remaining_postpay))
            else:
                invoice_amount = int(remaining_postpay)
        out["invoice_amount"] = max(int(invoice_amount or 0), 0)
        out["closed"] = remaining_postpay is not None and int(remaining_postpay) <= 0
        return out

    def _payment_invoice_text(amount: int, purpose: str, due: dict | None = None) -> str:
        due = due or {}
        expected_inn = _digits_only(cfg.PAYMENT_EXPECTED_INN)
        receiver = str(cfg.PAYMENT_RECEIVER_NAME or "").strip()
        bank_name = str(cfg.PAYMENT_BANK_NAME or "").strip()
        account_number = _digits_only(cfg.PAYMENT_ACCOUNT_NUMBER)
        corr_account = _digits_only(cfg.PAYMENT_CORR_ACCOUNT)
        bik = _digits_only(cfg.PAYMENT_BIK)
        payment_link = str(cfg.PAYMENT_LINK_URL or "").strip()

        lines = ["<b>Счёт на оплату</b>"]
        if receiver:
            lines.append(f"Получатель: <b>{html.escape(receiver)}</b>")
        if expected_inn:
            lines.append(f"ИНН: <code>{expected_inn}</code>")
        if bank_name:
            lines.append(f"Банк: <b>{html.escape(bank_name)}</b>")
        if bik:
            lines.append(f"БИК: <code>{bik}</code>")
        if account_number:
            lines.append(f"Р/с: <code>{account_number}</code>")
        if corr_account:
            lines.append(f"К/с: <code>{corr_account}</code>")
        if amount > 0:
            lines.append(f"Сумма к оплате: <b>{_format_money_value(amount)} ₽</b>")
        else:
            lines.append("Сумма к оплате: <b>уточняется</b>")

        remaining = due.get("remaining_postpay")
        if remaining is not None:
            lines.append(f"Остаток постоплаты: <b>{_format_money_value(int(remaining))} ₽</b>")
        rec_amount = due.get("recommended_amount")
        if rec_amount:
            lines.append(f"Рекомендованный платеж: <b>{_format_money_value(int(rec_amount))} ₽</b>")

        lines.append(f"Назначение: <code>{html.escape(str(purpose or '').strip())}</code>")
        if payment_link:
            lines.append(f"Ссылка на оплату: {html.escape(payment_link)}")

        if not any([receiver, expected_inn, bank_name, account_number, payment_link]):
            lines.append("Реквизиты счёта не настроены. Перед оплатой уточни их у ментора.")
            if cfg.MENTOR_CONTACT_URL:
                lines.append(f"Связь с ментором: {html.escape(str(cfg.MENTOR_CONTACT_URL))}")
        return "\n".join(lines)

    def _send_manual_payment_handoff(
        owner_tg_id: int,
        owner_chat_id: int,
        owner_username: str | None,
        req_type: str,
        service_title: str,
        amount: int,
        purpose: str,
        extra_payload: dict | None = None,
    ) -> int:
        amount = max(int(amount or 0), 0)
        expected_inn = _digits_only(cfg.PAYMENT_EXPECTED_INN)
        payload = {
            "owner_chat_id": int(owner_chat_id),
            "owner_username": owner_username,
            "service_title": str(service_title or "").strip(),
            "purpose": str(purpose or "").strip(),
            "manual_handoff": True,
            "source": "mentor_handoff",
            "pay_date": format_date_ddmmyyyy(now(tz).date()),
        }
        if amount > 0:
            payload["amount"] = amount
        if expected_inn:
            payload["recipient_inn"] = expected_inn
        if isinstance(extra_payload, dict):
            payload.update(extra_payload)

        req_id = repo_requests.create(conn, tz, owner_tg_id, req_type, payload, None)
        notify_admins(
            f"<b>[ЗАЯВКА]</b> {texts.request_title(req_type)}\n"
            f"От: @{owner_username or owner_tg_id}\n"
            f"ID: {req_id}\n"
            f"Услуга: {html.escape(str(service_title or '—'))}\n"
            f"Сумма: {amount if amount > 0 else 'уточнить'}\n"
            "Оплата принимается вручную у ментора.",
            kb=request_admin_kb(req_id),
        )

        mentor_url = (cfg.MENTOR_CONTACT_URL or "").strip()
        user_lines = [
            "<b>Оплата через ментора</b>",
            f"Услуга: <b>{html.escape(str(service_title or '—'))}</b>",
            f"Сумма к оплате: <b>{_format_money_value(amount)} ₽</b>" if amount > 0 else "Сумма к оплате: <b>уточняется ментором</b>",
            "Ментор уже получил уведомление с суммой и выбранной услугой.",
            "Оплата проводится напрямую у ментора.",
        ]
        if mentor_url:
            user_lines.append(f"Контакт ментора: {html.escape(mentor_url)}")
        else:
            user_lines.append("Контакт ментора не настроен в боте. Напиши в поддержку.")
        user_lines.append("После оплаты отправь чек напрямую ментору в этот диалог.")
        bot.send_message(owner_chat_id, "\n".join(user_lines))
        return req_id

    def _receipt_media_verification(m: Message) -> tuple[str | None, dict]:
        file_id = None
        media_type = "unknown"
        mime_type = ""
        file_name = ""
        if m.photo:
            media_type = "photo"
            file_id = m.photo[-1].file_id
        elif m.document:
            media_type = "document"
            file_id = m.document.file_id
            mime_type = str(m.document.mime_type or "").strip().lower()
            file_name = str(m.document.file_name or "").strip().lower()

        caption = str(getattr(m, "caption", "") or "").strip().lower()
        hint_tokens = ("чек", "квитан", "receipt", "payment", "оплат", "сбп")
        caption_hint = any(token in caption for token in hint_tokens)
        file_name_hint = any(token in file_name for token in hint_tokens)
        format_supported = bool(m.photo) or mime_type.startswith("image/") or mime_type == "application/pdf"
        checks = {
            "file_present": bool(file_id),
            "format_supported": bool(format_supported),
            "receipt_hint_detected": bool(caption_hint or file_name_hint),
        }
        warnings: list[str] = []
        if not checks["format_supported"]:
            warnings.append("Файл не похож на чек: нужен скрин/фото или PDF.")
        if not checks["receipt_hint_detected"]:
            warnings.append("Не найден явный признак чека (добавь подпись «чек»/«квитанция»/«receipt»).")

        return file_id, {
            "ok": bool(checks["file_present"] and checks["format_supported"] and checks["receipt_hint_detected"]),
            "checks": checks,
            "warnings": warnings,
            "media_type": media_type,
            "mime_type": mime_type,
            "file_name": file_name,
        }

    def _service_token_to_track(service: str | None) -> str | None:
        token = (service or "").strip().lower()
        if token in {"zerooffer", "zero"}:
            return "zero-offer"
        if token.startswith("interview") or token in {"prep", "interviewprep"}:
            return "interview-prep"
        if token.startswith("gradesal") or token in {"grade", "gradesalary"}:
            return "grade-salary"
        return None

    def _get_plan(track_key: str, plan_key: str) -> dict | None:
        track = ENROLL_TRACKS.get(track_key)
        if not track:
            return None
        for plan in track.get("plans") or []:
            if (plan.get("key") or "").strip() == (plan_key or "").strip():
                return plan
        return None

    def _enroll_expected_amount(price_label: str | None) -> int:
        raw = str(price_label or "").strip()
        if not raw:
            return 0
        # For combo tariffs like "60 000 ₽ + 100%..." invoice the fixed upfront part.
        first_part = raw.split("+", 1)[0]
        amount = _parse_money(first_part)
        if amount > 0:
            return amount
        return _parse_money(raw)

    def _enroll_contract_context(owner_tg_id: int) -> dict:
        out = {
            "has_contract": False,
            "contract_id": None,
            "track_key": "",
            "track_title": "",
            "plan_key": "",
            "plan_title": "",
            "price_label": "",
            "expected_amount": 0,
            "purpose": f"Оплата обучения (TG {owner_tg_id})",
        }
        contract = repo_enrollment_contracts.get_by_owner(conn, int(owner_tg_id))
        if not contract:
            return out

        track_key = str(contract["track_key"] or "").strip()
        plan_key = str(contract["tariff_key"] or "").strip()
        plan = _get_plan(track_key, plan_key) or {}

        track_title = str(plan.get("track_title") or contract["track_title"] or "").strip()
        plan_title = str(plan.get("title") or contract["tariff_title"] or "").strip()
        price_label = str(plan.get("price") or contract["tariff_price"] or "").strip()

        purpose_parts = [x for x in [track_title, plan_title] if x]
        purpose_tail = " / ".join(purpose_parts) if purpose_parts else "оплата по договору"

        out.update(
            {
                "has_contract": True,
                "contract_id": int(contract["id"]),
                "track_key": track_key,
                "track_title": track_title or str(contract["track_title"] or "").strip(),
                "plan_key": plan_key,
                "plan_title": plan_title or str(contract["tariff_title"] or "").strip(),
                "price_label": price_label or str(contract["tariff_price"] or "").strip(),
                "expected_amount": _enroll_expected_amount(price_label or contract["tariff_price"]),
                "purpose": f"Оплата по договору: {purpose_tail} (TG {owner_tg_id})",
            }
        )
        return out

    def _start_enroll_payment_wizard(owner_tg_id: int, chat_id: int, owner_username: str | None = None) -> None:
        enroll_ctx = _enroll_contract_context(owner_tg_id)
        if not enroll_ctx.get("has_contract"):
            bot.send_message(
                chat_id,
                "Не найден активный договор. Сначала выбери тариф в разделе «Вступить на обучение».",
            )
            return

        invoice_amount = int(enroll_ctx.get("expected_amount") or 0)
        _send_manual_payment_handoff(
            owner_tg_id=owner_tg_id,
            owner_chat_id=chat_id,
            owner_username=owner_username,
            req_type="ENROLLMENT_PAYMENT",
            service_title=f"Оплата после договора: {enroll_ctx.get('track_title') or 'обучение'} / {enroll_ctx.get('plan_title') or 'тариф'}",
            amount=invoice_amount,
            purpose=str(enroll_ctx.get("purpose") or "").strip(),
            extra_payload={
                "contract_id": enroll_ctx.get("contract_id"),
                "track_key": enroll_ctx.get("track_key"),
                "track_title": enroll_ctx.get("track_title"),
                "plan_key": enroll_ctx.get("plan_key"),
                "plan_title": enroll_ctx.get("plan_title"),
                "price_label": enroll_ctx.get("price_label"),
                "expected_amount": invoice_amount,
            },
        )
        repo_states.clear_state(conn, owner_tg_id, tz)

    def _enroll_payment_verification(owner_tg_id: int, pay: dict, expected_amount: int, receipt_check: dict | None = None) -> dict:
        base = _payment_verification(owner_tg_id, pay, receipt_check=receipt_check)
        checks = base.get("checks") if isinstance(base.get("checks"), dict) else {}
        warnings = [str(w).strip() for w in (base.get("warnings") or []) if str(w).strip()]
        amount = int(pay.get("amount") or 0)
        expected = int(expected_amount or 0)
        if expected > 0:
            checks["amount_match_expected"] = amount == expected
            if not checks["amount_match_expected"]:
                warnings.append(f"Сумма в чеке ({amount}) не совпадает с суммой по договору ({expected}).")
        base["checks"] = checks
        base["warnings"] = warnings
        base["ok"] = all(bool(v) for v in checks.values())
        base["expected_amount"] = expected
        return base

    def _safe_edit(chat_id: int, message_id: int | None, text: str, kb: InlineKeyboardMarkup | None = None) -> None:
        if message_id is None:
            bot.send_message(chat_id, text, reply_markup=kb)
            return
        bot.edit_message_text(text, chat_id, message_id, reply_markup=kb)

    def _auto_menu_kb() -> InlineKeyboardMarkup:
        kb = InlineKeyboardMarkup()
        kb.row(InlineKeyboardButton("🚀 Запустить автоотклики", callback_data="auto:start"))
        kb.row(InlineKeyboardButton("📊 Последний запуск", callback_data="auto:last"))
        kb.row(InlineKeyboardButton("⬅️ В меню", callback_data="v2:home"))
        return kb

    def _auto_direction_kb() -> InlineKeyboardMarkup:
        kb = InlineKeyboardMarkup()
        kb.row(
            InlineKeyboardButton("java", callback_data="auto:dir:java"),
            InlineKeyboardButton("golang", callback_data="auto:dir:golang"),
        )
        kb.row(
            InlineKeyboardButton("frontend", callback_data="auto:dir:frontend"),
            InlineKeyboardButton("python", callback_data="auto:dir:python"),
        )
        kb.row(InlineKeyboardButton("✍️ Другое направление", callback_data="auto:dir:manual"))
        kb.row(InlineKeyboardButton("✖️ Отмена", callback_data="v2:home"))
        return kb

    def _auto_query_kb() -> InlineKeyboardMarkup:
        kb = InlineKeyboardMarkup()
        kb.row(InlineKeyboardButton("Использовать такое же слово, как направление", callback_data="auto:query:default"))
        kb.row(InlineKeyboardButton("Оставить пустым (поиск по направлению)", callback_data="auto:query:skip"))
        kb.row(InlineKeyboardButton("✖️ Отмена", callback_data="v2:home"))
        return kb

    def _auto_login_pick_kb(saved_login: str) -> InlineKeyboardMarkup:
        kb = InlineKeyboardMarkup()
        label = f"Использовать сохранённый HH: {saved_login}"
        if len(label) > 64:
            label = label[:63] + "…"
        kb.row(InlineKeyboardButton(label, callback_data="auto:login:saved"))
        kb.row(InlineKeyboardButton("Ввести другой логин", callback_data="auto:login:manual"))
        kb.row(InlineKeyboardButton("✖️ Отмена", callback_data="v2:home"))
        return kb

    def _auto_confirm_kb() -> InlineKeyboardMarkup:
        kb = InlineKeyboardMarkup()
        kb.row(InlineKeyboardButton("✅ Запустить автоотклики", callback_data="auto:run"))
        kb.row(InlineKeyboardButton("✏️ Начать заново", callback_data="auto:start"))
        kb.row(InlineKeyboardButton("⬅️ В меню", callback_data="v2:home"))
        return kb

    def _enroll_level_kb() -> InlineKeyboardMarkup:
        kb = InlineKeyboardMarkup()
        kb.row(
            InlineKeyboardButton("С нуля", callback_data="enr:level:zero"),
            InlineKeyboardButton("Есть база", callback_data="enr:level:not_zero"),
        )
        kb.row(InlineKeyboardButton("⬅️ В меню", callback_data="v2:home"))
        return kb

    def _enroll_track_kb() -> InlineKeyboardMarkup:
        kb = InlineKeyboardMarkup()
        kb.row(InlineKeyboardButton("После курсов", callback_data="enr:track:prep"))
        kb.row(InlineKeyboardButton("Увеличение зарплаты", callback_data="enr:track:grade"))
        kb.row(InlineKeyboardButton("⬅️ Назад", callback_data="enr:back:level"))
        return kb

    def _enroll_plans_kb(track_key: str) -> InlineKeyboardMarkup:
        kb = InlineKeyboardMarkup()
        track = ENROLL_TRACKS.get(track_key) or {}
        alias = track.get("alias") or ""
        for plan in track.get("plans") or []:
            label = f"{plan.get('title')} • {plan.get('price')}"
            if len(label) > 60:
                label = label[:59] + "…"
            kb.row(InlineKeyboardButton(label, callback_data=f"enr:plan:{alias}:{plan.get('key')}"))
        if (track.get("level") or "") == "zero":
            kb.row(InlineKeyboardButton("⬅️ Назад", callback_data="enr:back:level"))
        else:
            kb.row(InlineKeyboardButton("⬅️ Назад", callback_data="enr:back:track"))
        return kb

    def _enroll_confirm_kb(track_key: str) -> InlineKeyboardMarkup:
        kb = InlineKeyboardMarkup()
        alias = (ENROLL_TRACKS.get(track_key) or {}).get("alias") or ""
        kb.row(InlineKeyboardButton("✅ Продолжить с этим тарифом", callback_data="enr:confirm"))
        kb.row(InlineKeyboardButton("⬅️ К списку тарифов", callback_data=f"enr:back:plans:{alias}"))
        kb.row(InlineKeyboardButton("✖️ В меню", callback_data="v2:home"))
        return kb

    def _auto_cover_letter(direction: str) -> str:
        d = (direction or "").strip().lower()
        if d == "java":
            role = "Java Developer"
        elif d == "golang":
            role = "Golang Developer"
        elif d == "frontend":
            role = "Frontend Developer"
        elif d == "python":
            role = "Python Developer"
        else:
            role = f"{(direction or 'Software').strip().title()} Developer"
        return (
            f"Здравствуйте!\n\n"
            f"Откликаюсь на позицию {role}. Готов(а) пройти техническое интервью, быстро погрузиться в стек команды "
            f"и закрывать задачи в срок. Буду рад(а) пообщаться."
        )

    def _build_candidate_context(owner_tg_id: int, direction: str) -> dict:
        s = repo_students.get_by_owner(conn, owner_tg_id)
        tg_username = ""
        if s and s["username"]:
            tg_username = "@" + str(s["username"]).lstrip("@")
        elif s and s["owner_username"]:
            tg_username = "@" + str(s["owner_username"]).lstrip("@")
        role_map = {
            "java": "Java Developer",
            "golang": "Golang Developer",
            "frontend": "Frontend Developer",
            "python": "Python Developer",
        }
        role = role_map.get((direction or "").strip().lower())
        if not role:
            raw = (direction or "").strip()
            role = f"{raw.title()} Developer" if raw else "Software Developer"
        salary = None
        location = None
        if s:
            salary = s["hh_salary_comfort"] or s["hh_salary_min"]
            location = s["hh_location"]
        payload = {
            "role": role,
            "salary_expectation": f"от {int(salary)} ₽ net" if salary else "",
            "work_format": "удалённо",
            "location": str(location or "").strip(),
            "telegram": tg_username,
        }
        return {k: v for k, v in payload.items() if str(v or "").strip()}

    def _auto_requires_site_payment(auto: dict) -> bool:
        source = str(auto.get("source") or "").strip().lower()
        expected = int(auto.get("price_total") or 0)
        return source == "site" and expected > 0

    def _auto_payment_verification(auto: dict, pay: dict, receipt_check: dict | None = None) -> dict:
        expected_amount = int(auto.get("price_total") or 0)
        amount = int(pay.get("amount") or 0)
        pay_date_raw = str(pay.get("pay_date") or "").strip()
        pay_date = _parse_date_ru(pay_date_raw)
        inn = _digits_only(pay.get("recipient_inn"))
        expected_inn = _digits_only(cfg.PAYMENT_EXPECTED_INN)
        today = now(tz).date()
        max_age_days = max(int(cfg.PAYMENT_MAX_AGE_DAYS or 90), 1)
        checks: dict[str, bool] = {
            "amount_positive": amount > 0,
            "amount_match_expected": amount == expected_amount if expected_amount > 0 else amount > 0,
            "date_valid": pay_date is not None,
            "date_not_future": bool(pay_date and pay_date <= today),
            "date_recent": bool(pay_date and pay_date >= (today - timedelta(days=max_age_days))),
            "recipient_inn_match": bool(not expected_inn or inn == expected_inn),
        }
        warnings: list[str] = []
        if not checks["amount_match_expected"] and expected_amount > 0:
            warnings.append(f"Сумма в чеке ({amount}) не совпадает с ожидаемой ({expected_amount}).")
        if not checks["recipient_inn_match"]:
            warnings.append("ИНН получателя не совпадает с расчётным счётом.")
        if not checks["date_recent"]:
            warnings.append("Дата платежа выходит за допустимый интервал проверки.")
        receipt_check = receipt_check if isinstance(receipt_check, dict) else {}
        if receipt_check:
            receipt_checks = receipt_check.get("checks") if isinstance(receipt_check.get("checks"), dict) else {}
            checks["receipt_format_supported"] = bool(receipt_checks.get("format_supported", False))
            checks["receipt_hint_detected"] = bool(receipt_checks.get("receipt_hint_detected", False))
            for w in (receipt_check.get("warnings") or []):
                w = str(w or "").strip()
                if w and w not in warnings:
                    warnings.append(w)
        return {
            "expected_amount": expected_amount,
            "amount": amount,
            "pay_date": pay_date_raw,
            "recipient_inn": inn,
            "checks": checks,
            "ok": all(checks.values()),
            "warnings": warnings,
            "receipt_check": receipt_check,
        }

    def _payment_verification(owner_tg_id: int, pay: dict, receipt_check: dict | None = None) -> dict:
        amount = int(pay.get("amount") or 0)
        pay_date_raw = str(pay.get("pay_date") or "").strip()
        pay_date = _parse_date_ru(pay_date_raw)
        inn = _digits_only(pay.get("recipient_inn"))
        expected_inn = _digits_only(cfg.PAYMENT_EXPECTED_INN)
        today = now(tz).date()
        max_age_days = max(int(cfg.PAYMENT_MAX_AGE_DAYS or 90), 1)

        checks: dict[str, bool] = {
            "amount_positive": amount > 0,
            "date_valid": pay_date is not None,
            "date_not_future": bool(pay_date and pay_date <= today),
            "date_recent": bool(pay_date and pay_date >= (today - timedelta(days=max_age_days))),
            "recipient_inn_match": bool(not expected_inn or inn == expected_inn),
        }
        warnings: list[str] = []
        if not checks["recipient_inn_match"]:
            warnings.append("ИНН получателя не совпадает с расчётным счётом ментора.")
        if not checks["date_recent"]:
            warnings.append("Дата платежа выходит за допустимый интервал проверки.")

        s = repo_students.get_by_owner(conn, owner_tg_id)
        if s and s["offer_amount"]:
            pp = repo_postpay.get(conn, int(s["id"]))
            if pp and pp["enabled"] and pp["total_percent"]:
                total = int(round(float(s["offer_amount"]) * float(pp["total_percent"]) / 100))
                paid = repo_payments.sum_payments(conn, int(s["id"]), "postpay")
                remaining = max(total - paid, 0)
                checks["amount_reasonable"] = bool(remaining <= 0 or amount <= (remaining + 5000))
                if not checks["amount_reasonable"]:
                    warnings.append("Сумма сильно выше ожидаемого остатка постоплаты.")
        else:
            checks["amount_reasonable"] = True

        receipt_check = receipt_check if isinstance(receipt_check, dict) else {}
        if receipt_check:
            receipt_checks = receipt_check.get("checks") if isinstance(receipt_check.get("checks"), dict) else {}
            checks["receipt_format_supported"] = bool(receipt_checks.get("format_supported", False))
            checks["receipt_hint_detected"] = bool(receipt_checks.get("receipt_hint_detected", False))
            for w in (receipt_check.get("warnings") or []):
                w = str(w or "").strip()
                if w and w not in warnings:
                    warnings.append(w)

        ok = all(bool(v) for v in checks.values())
        return {
            "ok": ok,
            "checks": checks,
            "warnings": warnings,
            "expected_inn": expected_inn,
            "provided_inn": inn,
            "pay_date": pay_date_raw,
            "amount": amount,
            "receipt_check": receipt_check,
        }

    def _last_request(owner_tg_id: int, req_type: str) -> sqlite3.Row | None:
        return conn.execute(
            "SELECT * FROM student_requests WHERE owner_tg_id=? AND req_type=? ORDER BY id DESC LIMIT 1",
            (int(owner_tg_id), str(req_type)),
        ).fetchone()

    def _prefill_profile_from_student(owner_tg_id: int) -> dict:
        s = repo_students.get_by_owner(conn, int(owner_tg_id))
        if not s:
            return {}
        return {
            "fio": s["fio"],
            "username": ("@" + s["username"]) if s["username"] else None,
            "direction": s["direction_name"],
            "stage": s["stage_name"],
            "tariff": (s["tariff"] or "post").strip(),
            "contract_url": s["contract_url"],
            "prepay": 0,
        }

    def _start_profile_wizard(owner_tg_id: int, chat_id: int, prefill: dict | None = None) -> None:
        data = {"step": "fio", "profile": (prefill or {})}
        repo_states.set_state(conn, owner_tg_id, STATE_PROFILE, data, tz)
        bot.send_message(chat_id, "ФИО (как в договоре):")

    def _start_accounts_wizard(owner_tg_id: int, chat_id: int) -> None:
        repo_states.set_state(conn, owner_tg_id, STATE_ACCOUNTS, {"step": "phone", "acc": {}}, tz)
        bot.send_message(chat_id, "Телефон (для HH/контакта). Если нет — напиши '-':")

    def _start_payment_wizard(owner_tg_id: int, chat_id: int, owner_username: str | None = None) -> None:
        if not _user_show_pay_button(owner_tg_id):
            bot.send_message(
                chat_id,
                "Пока не могу оформить запрос на оплату: в карточке ученика не выставлен оффер или не включена постоплата.\n"
                "Напиши ментору, и после активации сможешь продолжить.",
            )
            return
        due = _payment_due_context(owner_tg_id)
        if due.get("closed"):
            bot.send_message(chat_id, "Постоплата уже закрыта. Если видишь несоответствие, напиши ментору.")
            return

        invoice_amount = int(due.get("invoice_amount") or 0)
        _send_manual_payment_handoff(
            owner_tg_id=owner_tg_id,
            owner_chat_id=chat_id,
            owner_username=owner_username,
            req_type="PAYMENT",
            service_title="Постоплата по обучению",
            amount=invoice_amount,
            purpose=f"Оплата обучения (TG {owner_tg_id})",
            extra_payload={
                "remaining_postpay": due.get("remaining_postpay"),
                "recommended_amount": due.get("recommended_amount"),
            },
        )
        repo_states.clear_state(conn, owner_tg_id, tz)

    def _deeplink_payload(meta: dict | None, route: str) -> dict:
        meta = meta or {}
        return {
            "route": route,
            "source": meta.get("source", ""),
            "service": meta.get("service", ""),
            "clicks": meta.get("clicks"),
            "version": meta.get("version", ""),
        }

    def _auto_text(owner_tg_id: int, meta: dict | None = None) -> str:
        clicks = 0
        if isinstance(meta, dict):
            try:
                clicks = max(int(meta.get("clicks") or 0), 0)
            except Exception:
                clicks = 0
        clicks_line = f"\nВыбор с сайта: <b>{clicks}</b> откликов." if clicks > 0 else ""
        target = clicks if clicks > 0 else 200
        price = _auto_price_breakdown(owner_tg_id, target) if target > 0 else {}
        price_total = int(price.get("total_price") or 0)
        free_clicks = int(price.get("free_clicks") or 0)
        free_remaining = int(price.get("free_remaining") or 0)
        if target < 200 and free_remaining > 0:
            promo_line = (
                f"\nПромо: в этом запуске бесплатно до <b>{free_clicks}</b> откликов "
                f"(остаток по аккаунту: <b>{free_remaining}</b> из 50)."
            )
        elif target < 200:
            promo_line = "\nПромо первых 50 откликов уже использовано для этого аккаунта."
        else:
            promo_line = ""
        price_line = f"\nОплата по калькулятору: <b>{price_total} ₽</b> (оплата у ментора)." if clicks > 0 else ""
        return (
            "<b>Автоотклики</b>\n"
            "Запуск выполняется прямо из бота через внутренний API.\n"
            "Шаги: направление -> HH логин -> HH пароль -> цель откликов -> запуск.\n"
            f"Стартовая цель: <b>{target}</b> откликов.{clicks_line}{promo_line}{price_line}"
        )

    def _open_auto_menu(chat_id: int, owner_tg_id: int, message_id: int | None = None, meta: dict | None = None) -> None:
        clicks = 0
        site_entry = False
        if isinstance(meta, dict):
            try:
                clicks = max(int(meta.get("clicks") or 0), 0)
            except Exception:
                clicks = 0
            site_entry = bool(meta.get("version") or meta.get("source") or meta.get("raw"))
        st, data = repo_states.get_state(conn, owner_tg_id)
        auto = (data.get("auto") if st == STATE_AUTOAPPLY else {}) or {}
        if clicks > 0:
            auto["target_applies"] = clicks
            auto["target_locked"] = True
            auto["price_total"] = _auto_price_for_user(owner_tg_id, clicks)
        auto.setdefault("target_applies", 200)
        auto.setdefault("target_locked", False)
        auto.setdefault("price_total", _auto_price_for_user(owner_tg_id, int(auto.get("target_applies") or 0)))
        if site_entry:
            auto["source"] = "site"
        else:
            auto["source"] = "menu"
            auto["target_locked"] = False
        repo_states.set_state(conn, owner_tg_id, STATE_AUTOAPPLY, {"step": "menu", "auto": auto}, tz)
        _safe_edit(chat_id, message_id, _auto_text(owner_tg_id, meta), _auto_menu_kb())

    def _open_enroll_level(chat_id: int, owner_tg_id: int, message_id: int | None = None) -> None:
        repo_states.set_state(conn, owner_tg_id, STATE_ENROLL, {"step": "level", "enroll": {}}, tz)
        _safe_edit(
            chat_id,
            message_id,
            "<b>Вступить на обучение</b>\nВыбери стартовую точку:",
            _enroll_level_kb(),
        )

    def _render_enroll_track(chat_id: int, owner_tg_id: int, message_id: int | None = None) -> None:
        st, data = repo_states.get_state(conn, owner_tg_id)
        enroll = (data.get("enroll") if st == STATE_ENROLL else {}) or {}
        enroll["level"] = "not_zero"
        repo_states.set_state(conn, owner_tg_id, STATE_ENROLL, {"step": "track", "enroll": enroll}, tz)
        _safe_edit(
            chat_id,
            message_id,
            "<b>Вступить на обучение</b>\nВыбери направление:",
            _enroll_track_kb(),
        )

    def _render_enroll_plans(chat_id: int, owner_tg_id: int, track_key: str, message_id: int | None = None) -> None:
        track = ENROLL_TRACKS.get(track_key)
        if not track:
            _safe_edit(chat_id, message_id, "Не удалось открыть тарифы. Попробуй снова через меню.", _v2_back_kb())
            return
        st, data = repo_states.get_state(conn, owner_tg_id)
        enroll = (data.get("enroll") if st == STATE_ENROLL else {}) or {}
        enroll["track_key"] = track_key
        enroll["level"] = track.get("level", enroll.get("level") or "not_zero")
        repo_states.set_state(conn, owner_tg_id, STATE_ENROLL, {"step": "plans", "enroll": enroll}, tz)
        _safe_edit(
            chat_id,
            message_id,
            f"<b>{track['title']}</b>\nВыбери тариф:",
            _enroll_plans_kb(track_key),
        )

    def _render_enroll_confirm(chat_id: int, owner_tg_id: int, track_key: str, plan_key: str, message_id: int | None = None) -> None:
        track = ENROLL_TRACKS.get(track_key)
        plan = _get_plan(track_key, plan_key)
        if not track or not plan:
            _safe_edit(chat_id, message_id, "Не удалось открыть тариф. Вернись и выбери снова.", _v2_back_kb())
            return
        st, data = repo_states.get_state(conn, owner_tg_id)
        enroll = (data.get("enroll") if st == STATE_ENROLL else {}) or {}
        enroll.update(
            {
                "level": track.get("level") or enroll.get("level") or "not_zero",
                "track_key": track_key,
                "plan_key": plan_key,
            }
        )
        repo_states.set_state(conn, owner_tg_id, STATE_ENROLL, {"step": "confirm", "enroll": enroll}, tz)
        text = (
            "<b>Подтверждение тарифа</b>\n"
            f"Направление: <b>{track['title']}</b>\n"
            f"Тариф: <b>{plan['title']}</b>\n"
            f"Формат: {plan['subtitle']}\n"
            f"Цена: <b>{plan['price']}</b>\n\n"
            "Если устраивает, нажми «Продолжить с этим тарифом»."
        )
        _safe_edit(chat_id, message_id, text, _enroll_confirm_kb(track_key))

    def _open_route_home(chat_id: int, owner_tg_id: int, meta: dict | None = None) -> None:
        repo_analytics.log_event(conn, tz, owner_tg_id, "deeplink.route_open", _deeplink_payload(meta, "home"))
        send_regular_home(chat_id, owner_tg_id)

    def _open_route_auto(chat_id: int, owner_tg_id: int, meta: dict | None = None) -> None:
        repo_states.clear_state(conn, owner_tg_id, tz)
        repo_analytics.log_event(conn, tz, owner_tg_id, "deeplink.route_open", _deeplink_payload(meta, "auto"))
        _open_auto_menu(chat_id, owner_tg_id, message_id=None, meta=meta)

    def _open_route_student(chat_id: int, owner_tg_id: int, meta: dict | None = None) -> None:
        repo_analytics.log_event(conn, tz, owner_tg_id, "deeplink.route_open", _deeplink_payload(meta, "student"))
        if _has_student_access(owner_tg_id):
            send_user_home(chat_id, owner_tg_id)
            return

        repo_states.set_state(conn, owner_tg_id, STATE_STUDENT_CODE, {}, tz)
        bot.send_message(
            chat_id,
            "Введи одноразовый код ученика от ментора.\n"
            "Пример: <code>STU-AB12CD34</code>",
            reply_markup=_v2_back_kb(),
        )

    def _open_route_enroll(chat_id: int, owner_tg_id: int, meta: dict | None = None) -> None:
        repo_analytics.log_event(conn, tz, owner_tg_id, "deeplink.route_open", _deeplink_payload(meta, "enroll"))
        service = (meta or {}).get("service")
        plan_token = str((meta or {}).get("plan") or "").strip().lower()
        track_key = _service_token_to_track(service)
        if not track_key:
            _open_enroll_level(chat_id, owner_tg_id, message_id=None)
            return
        track = ENROLL_TRACKS.get(track_key) or {}
        if track.get("level") == "not_zero":
            # not_zero route can come from two tracks; open specific list directly
            _render_enroll_plans(chat_id, owner_tg_id, track_key, message_id=None)
        else:
            _render_enroll_plans(chat_id, owner_tg_id, track_key, message_id=None)
        if plan_token:
            for p in track.get("plans") or []:
                if str(p.get("key") or "").startswith(plan_token[:4]):
                    _render_enroll_confirm(chat_id, owner_tg_id, track_key, p["key"], message_id=None)
                    break

    public_routes = ctx.setdefault("public_routes", {})
    if isinstance(public_routes, dict):
        public_routes["home"] = _open_route_home
        public_routes["auto"] = _open_route_auto
        public_routes["student"] = _open_route_student
        public_routes["enroll"] = _open_route_enroll

    # =========================
    # v2 start menu
    # =========================

    @bot.callback_query_handler(func=lambda c: c.data == "v2:home")
    def cb_v2_home(c: CallbackQuery):
        if is_admin(c.from_user.id):
            bot.answer_callback_query(c.id, "Это пользовательское меню")
            return
        repo_analytics.log_event(conn, tz, c.from_user.id, "menu.regular_home")
        repo_states.clear_state(conn, c.from_user.id, tz)
        bot.edit_message_text(
            texts.regular_title(),
            c.message.chat.id,
            c.message.message_id,
            reply_markup=regular_menu_kb(),
        )
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data == "v2:auto")
    def cb_v2_auto(c: CallbackQuery):
        if is_admin(c.from_user.id):
            bot.answer_callback_query(c.id, "Это пользовательское меню")
            return
        repo_analytics.log_event(conn, tz, c.from_user.id, "feature.auto_menu_open")
        _open_auto_menu(c.message.chat.id, int(c.from_user.id), message_id=c.message.message_id, meta=None)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data == "v2:enroll")
    def cb_v2_enroll(c: CallbackQuery):
        if is_admin(c.from_user.id):
            bot.answer_callback_query(c.id, "Это пользовательское меню")
            return
        repo_analytics.log_event(conn, tz, c.from_user.id, "funnel.enroll.entry_click")
        _open_enroll_level(c.message.chat.id, int(c.from_user.id), message_id=c.message.message_id)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data == "auto:start")
    def cb_auto_start(c: CallbackQuery):
        if is_admin(c.from_user.id):
            bot.answer_callback_query(c.id, "Это пользовательское меню")
            return
        st, data = repo_states.get_state(conn, c.from_user.id)
        auto = (data.get("auto") if st == STATE_AUTOAPPLY else {}) or {}
        s = repo_students.get_by_owner(conn, int(c.from_user.id))
        if s:
            auto.setdefault("login", (s["hh_email"] or "").strip())
            auto.setdefault("password", (s["hh_password"] or "").strip())
        auto.setdefault("target_applies", 200)
        auto.setdefault("target_locked", False)
        auto["price_total"] = _auto_price_for_user(int(c.from_user.id), int(auto.get("target_applies") or 0))
        repo_states.set_state(conn, c.from_user.id, STATE_AUTOAPPLY, {"step": "direction", "auto": auto}, tz)
        bot.edit_message_text(
            "<b>Автоотклики</b>\nВыбери направление поиска:",
            c.message.chat.id,
            c.message.message_id,
            reply_markup=_auto_direction_kb(),
        )
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("auto:dir:"))
    def cb_auto_dir(c: CallbackQuery):
        if is_admin(c.from_user.id):
            bot.answer_callback_query(c.id, "Это пользовательское меню")
            return
        direction = c.data.split(":")[2].strip().lower()
        st, data = repo_states.get_state(conn, c.from_user.id)
        auto = (data.get("auto") if st == STATE_AUTOAPPLY else {}) or {}
        if direction == "manual":
            repo_states.set_state(conn, c.from_user.id, STATE_AUTOAPPLY, {"step": "direction_manual", "auto": auto}, tz)
            bot.send_message(
                c.message.chat.id,
                "Напиши направление вручную.\nПримеры: qa, devops, analyst, product manager, 1c, mobile.",
            )
            bot.answer_callback_query(c.id)
            return
        if direction not in AUTO_DIRECTIONS:
            direction = direction or "software"
        auto["direction"] = direction
        saved_login = str(auto.get("login") or "").strip()
        saved_password = str(auto.get("password") or "").strip()
        if saved_login and saved_password:
            repo_states.set_state(conn, c.from_user.id, STATE_AUTOAPPLY, {"step": "login_pick", "auto": auto}, tz)
            bot.send_message(
                c.message.chat.id,
                "Нашёл сохранённые доступы HH. Использовать их или ввести новые?",
                reply_markup=_auto_login_pick_kb(saved_login),
            )
        else:
            repo_states.set_state(conn, c.from_user.id, STATE_AUTOAPPLY, {"step": "login", "auto": auto}, tz)
            bot.send_message(c.message.chat.id, "Логин HH (почта/телефон):")
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data in {"auto:login:saved", "auto:login:manual"})
    def cb_auto_login_pick(c: CallbackQuery):
        if is_admin(c.from_user.id):
            bot.answer_callback_query(c.id, "Это пользовательское меню")
            return
        st, data = repo_states.get_state(conn, c.from_user.id)
        if st != STATE_AUTOAPPLY or (data or {}).get("step") != "login_pick":
            bot.answer_callback_query(c.id)
            return
        auto = (data.get("auto") or {}).copy()
        if c.data.endswith("manual"):
            auto["login"] = ""
            auto["password"] = ""
            repo_states.set_state(conn, c.from_user.id, STATE_AUTOAPPLY, {"step": "login", "auto": auto}, tz)
            bot.send_message(c.message.chat.id, "Введи HH логин (почта/телефон):")
            bot.answer_callback_query(c.id)
            return
        if bool(auto.get("target_locked")):
            repo_states.set_state(conn, c.from_user.id, STATE_AUTOAPPLY, {"step": "query", "auto": auto}, tz)
            bot.send_message(
                c.message.chat.id,
                (
                    f"Цель откликов взята с сайта: <b>{int(auto.get('target_applies') or 0)}</b>.\n"
                    "Теперь укажи поисковый запрос HH.\n"
                    "Это слово/фраза для поиска вакансий.\n"
                    "Примеры: Java developer, Python backend, Frontend React, QA engineer, DevOps.\n"
                    "Можно отправить текст или выбрать кнопку ниже."
                ),
                reply_markup=_auto_query_kb(),
            )
            bot.answer_callback_query(c.id)
            return
        repo_states.set_state(conn, c.from_user.id, STATE_AUTOAPPLY, {"step": "target", "auto": auto}, tz)
        bot.send_message(c.message.chat.id, "Цель откликов (числом, например 200):")
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data in {"auto:query:default", "auto:query:skip"})
    def cb_auto_query_pick(c: CallbackQuery):
        if is_admin(c.from_user.id):
            bot.answer_callback_query(c.id, "Это пользовательское меню")
            return
        st, data = repo_states.get_state(conn, c.from_user.id)
        if st != STATE_AUTOAPPLY or (data or {}).get("step") != "query":
            bot.answer_callback_query(c.id)
            return
        auto = (data.get("auto") or {}).copy()
        if c.data.endswith("default"):
            auto["query_text"] = str(auto.get("direction") or "Java")
        else:
            auto["query_text"] = ""
        repo_states.set_state(conn, c.from_user.id, STATE_AUTOAPPLY, {"step": "confirm", "auto": auto}, tz)
        summary = (
            "<b>Проверка параметров автооткликов</b>\n"
            f"Направление: <b>{auto.get('direction')}</b>\n"
            f"Логин: <code>{auto.get('login')}</code>\n"
            f"Цель: <b>{int(auto.get('target_applies') or 0)}</b> откликов\n"
            f"Запрос: <code>{auto.get('query_text') or auto.get('direction')}</code>"
        )
        if _auto_requires_site_payment(auto):
            summary += f"\nОплата с сайта: <b>{int(auto.get('price_total') or 0)} ₽</b> (оплата у ментора)."
        bot.send_message(c.message.chat.id, summary, reply_markup=_auto_confirm_kb())
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data == "auto:last")
    def cb_auto_last(c: CallbackQuery):
        if is_admin(c.from_user.id):
            bot.answer_callback_query(c.id, "Это пользовательское меню")
            return
        row = repo_autoapply_runs.last_by_owner(conn, int(c.from_user.id))
        if not row:
            bot.edit_message_text(
                "<b>Автоотклики</b>\nПока запусков не было.",
                c.message.chat.id,
                c.message.message_id,
                reply_markup=_auto_menu_kb(),
            )
            bot.answer_callback_query(c.id)
            return
        text = (
            "<b>Последний запуск автооткликов</b>\n"
            f"Статус: <b>{row['status']}</b>\n"
            f"Логин: <code>{row['login']}</code>\n"
            f"Направление: <b>{row['direction']}</b>\n"
            f"Цель: <b>{int(row['target_applies'])}</b>\n"
            f"Создано: {row['created_at']}\n"
        )
        if row["error_text"]:
            text += f"\nОшибка: <code>{row['error_text']}</code>"
        bot.edit_message_text(text, c.message.chat.id, c.message.message_id, reply_markup=_auto_menu_kb())
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data == "auto:run")
    def cb_auto_run(c: CallbackQuery):
        if is_admin(c.from_user.id):
            bot.answer_callback_query(c.id, "Это пользовательское меню")
            return
        owner_id = int(c.from_user.id)
        st, data = repo_states.get_state(conn, c.from_user.id)
        if st != STATE_AUTOAPPLY or (data or {}).get("step") != "confirm":
            bot.answer_callback_query(c.id, "Сначала заполни параметры")
            return
        auto = (data.get("auto") or {}).copy()
        login = str(auto.get("login") or "").strip()
        password = str(auto.get("password") or "").strip()
        direction = str(auto.get("direction") or "").strip().lower()
        target = max(int(auto.get("target_applies") or 0), 1)
        query_text = str(auto.get("query_text") or direction).strip()
        if not login or not password or not direction:
            bot.answer_callback_query(c.id, "Не хватает данных для запуска")
            return
        price_info = _auto_price_breakdown(owner_id, target)
        auto["price_total"] = int(price_info.get("total_price") or 0)
        if _auto_requires_site_payment(auto):
            amount = int(auto.get("price_total") or 0)
            _send_manual_payment_handoff(
                owner_tg_id=owner_id,
                owner_chat_id=int(c.message.chat.id),
                owner_username=c.from_user.username,
                req_type="AUTOAPPLY_PAYMENT",
                service_title="Автоотклики",
                amount=amount,
                purpose=f"Оплата автооткликов (TG {owner_id})",
                extra_payload={
                    "source": "autoapply_site",
                    "login": login,
                    "direction": direction,
                    "target_applies": target,
                    "query_text": query_text,
                    "free_clicks": int(price_info.get("free_clicks") or 0),
                    "paid_clicks": int(price_info.get("paid_clicks") or 0),
                    "per_click": int(price_info.get("per_click") or 0),
                },
            )
            repo_states.clear_state(conn, owner_id, tz)
            bot.send_message(
                c.message.chat.id,
                "После оплаты напиши ментору, что оплата прошла. "
                "Ментор вручную запустит автоотклики по уже переданным параметрам.",
                reply_markup=_auto_menu_kb(),
            )
            bot.answer_callback_query(c.id, "Передано ментору")
            return

        payload = {
            "login": login,
            "password": password,
            "direction": direction,
            "headless": bool(cfg.AUTOAPPLY_DEFAULT_HEADLESS),
            "slowMoMs": int(cfg.AUTOAPPLY_DEFAULT_SLOWMO_MS),
            "queryText": query_text or direction,
            "targetApplies": target,
            "coverLetter": _auto_cover_letter(direction),
            "candidateContext": _build_candidate_context(int(c.from_user.id), direction),
            "active": True,
        }

        create_response: dict = {}
        run_response: dict = {}
        try:
            if not auto_client.enabled:
                raise AutoApplyClientError("Интеграция автооткликов выключена в конфиге")
            try:
                create_response = auto_client.create_account(payload)
            except AutoApplyClientError as exc:
                msg = str(exc).lower()
                if exc.status_code == 409 or "already" in msg or "существ" in msg:
                    create_response = {"warning": str(exc)}
                else:
                    raise
            run_response = auto_client.run_account(login)

            repo_autoapply_runs.create(
                conn,
                tz,
                owner_tg_id=owner_id,
                owner_chat_id=int(c.message.chat.id),
                login=login,
                direction=direction,
                target_applies=target,
                query_text=query_text,
                status="launched",
                create_response=create_response,
                run_response=run_response,
                error_text=None,
            )
            _auto_mark_free50_used(owner_id, int(price_info.get("free_clicks") or 0))
            repo_states.clear_state(conn, owner_id, tz)
            bot.send_message(
                c.message.chat.id,
                "✅ Автоотклики запущены.\n"
                "Статус запуска сохранён.",
                reply_markup=regular_menu_kb(),
            )
            bot.answer_callback_query(c.id, "Запуск выполнен")
        except Exception as exc:
            err_text = str(exc)
            repo_autoapply_runs.create(
                conn,
                tz,
                owner_tg_id=owner_id,
                owner_chat_id=int(c.message.chat.id),
                login=login,
                direction=direction or "unknown",
                target_applies=target,
                query_text=query_text,
                status="failed",
                create_response=create_response,
                run_response=run_response,
                error_text=err_text,
            )
            req_payload = {
                "owner_chat_id": c.message.chat.id,
                "owner_username": c.from_user.username,
                "login": login,
                "direction": direction,
                "target_applies": target,
                "query_text": query_text,
                "error": err_text,
            }
            req_id = repo_requests.create(conn, tz, owner_id, "AUTOAPPLY", req_payload, None)
            notify_admins(
                f"<b>[ЗАЯВКА]</b> {texts.request_title('AUTOAPPLY')} (ошибка)\n"
                f"От: @{c.from_user.username or c.from_user.id}\n"
                f"ID: {req_id}\n"
                f"Логин: <code>{login}</code>\n"
                f"Ошибка: <code>{err_text[:220]}</code>",
                kb=request_open_kb(req_id),
            )
            mentor_url = (cfg.MENTOR_CONTACT_URL or "").strip()
            if mentor_url:
                bot.send_message(
                    c.message.chat.id,
                    "Не удалось автоматически запустить автоотклики.\n"
                    f"Напиши ментору: {mentor_url}",
                    reply_markup=_auto_menu_kb(),
                )
            else:
                bot.send_message(
                    c.message.chat.id,
                    "Не удалось автоматически запустить автоотклики.\n"
                    "Напиши ментору для ручного запуска.",
                    reply_markup=_auto_menu_kb(),
                )
            bot.answer_callback_query(c.id, "Ошибка запуска")

    @bot.callback_query_handler(func=lambda c: c.data.startswith("enr:level:"))
    def cb_enroll_level(c: CallbackQuery):
        if is_admin(c.from_user.id):
            bot.answer_callback_query(c.id, "Это пользовательское меню")
            return
        level = c.data.split(":")[2]
        if level == "zero":
            _render_enroll_plans(c.message.chat.id, int(c.from_user.id), "zero-offer", message_id=c.message.message_id)
        else:
            _render_enroll_track(c.message.chat.id, int(c.from_user.id), message_id=c.message.message_id)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data == "enr:back:level")
    def cb_enroll_back_level(c: CallbackQuery):
        if is_admin(c.from_user.id):
            bot.answer_callback_query(c.id, "Это пользовательское меню")
            return
        _open_enroll_level(c.message.chat.id, int(c.from_user.id), message_id=c.message.message_id)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data == "enr:back:track")
    def cb_enroll_back_track(c: CallbackQuery):
        if is_admin(c.from_user.id):
            bot.answer_callback_query(c.id, "Это пользовательское меню")
            return
        _render_enroll_track(c.message.chat.id, int(c.from_user.id), message_id=c.message.message_id)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("enr:track:"))
    def cb_enroll_track(c: CallbackQuery):
        if is_admin(c.from_user.id):
            bot.answer_callback_query(c.id, "Это пользовательское меню")
            return
        alias = c.data.split(":")[2].strip().lower()
        track_key = ENROLL_TRACK_BY_ALIAS.get(alias)
        if not track_key:
            bot.answer_callback_query(c.id, "Неизвестное направление")
            return
        _render_enroll_plans(c.message.chat.id, int(c.from_user.id), track_key, message_id=c.message.message_id)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("enr:back:plans:"))
    def cb_enroll_back_plans(c: CallbackQuery):
        if is_admin(c.from_user.id):
            bot.answer_callback_query(c.id, "Это пользовательское меню")
            return
        alias = c.data.split(":")[3].strip().lower()
        track_key = ENROLL_TRACK_BY_ALIAS.get(alias)
        if not track_key:
            bot.answer_callback_query(c.id, "Не удалось открыть тарифы")
            return
        _render_enroll_plans(c.message.chat.id, int(c.from_user.id), track_key, message_id=c.message.message_id)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("enr:plan:"))
    def cb_enroll_plan(c: CallbackQuery):
        if is_admin(c.from_user.id):
            bot.answer_callback_query(c.id, "Это пользовательское меню")
            return
        parts = c.data.split(":")
        if len(parts) < 4:
            bot.answer_callback_query(c.id, "Ошибка данных")
            return
        alias = parts[2].strip().lower()
        plan_key = parts[3].strip().lower()
        track_key = ENROLL_TRACK_BY_ALIAS.get(alias)
        if not track_key:
            bot.answer_callback_query(c.id, "Неизвестный тариф")
            return
        _render_enroll_confirm(c.message.chat.id, int(c.from_user.id), track_key, plan_key, message_id=c.message.message_id)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data == "enr:confirm")
    def cb_enroll_confirm(c: CallbackQuery):
        if is_admin(c.from_user.id):
            bot.answer_callback_query(c.id, "Это пользовательское меню")
            return
        st, data = repo_states.get_state(conn, c.from_user.id)
        if st != STATE_ENROLL or (data or {}).get("step") != "confirm":
            bot.answer_callback_query(c.id, "Сначала выбери тариф")
            return
        enroll = (data.get("enroll") or {}).copy()
        track_key = str(enroll.get("track_key") or "").strip()
        plan_key = str(enroll.get("plan_key") or "").strip()
        track = ENROLL_TRACKS.get(track_key)
        plan = _get_plan(track_key, plan_key)
        if not track or not plan:
            bot.answer_callback_query(c.id, "Тариф не найден")
            return

        existing = repo_enrollment_contracts.get_by_owner(conn, int(c.from_user.id))
        if existing:
            mentor_url = (cfg.MENTOR_CONTACT_URL or "").strip()
            req_payload = {
                "owner_chat_id": c.message.chat.id,
                "owner_username": c.from_user.username,
                "event": "reissue_request",
                "reason": "contract_already_issued",
            }
            req_id = repo_requests.create(conn, tz, c.from_user.id, "ENROLLMENT", req_payload, None)
            notify_admins(
                f"<b>[ЗАЯВКА]</b> {texts.request_title('ENROLLMENT')}\n"
                f"От: @{c.from_user.username or c.from_user.id}\n"
                f"ID: {req_id}\n"
                "Запрошено пересоздание договора (one-time ограничение OkiDoki).",
                kb=request_open_kb(req_id),
            )
            text = (
                "Договор по OkiDoki уже формировался для этого аккаунта (по правилам — только один раз).\n"
                "Если нужно пересоздать договор, напиши ментору.\n"
                "Если текущий договор уже подписан, можно сразу перейти к оплате."
            )
            if mentor_url:
                text += f"\n{mentor_url}"
            existing_kb = InlineKeyboardMarkup()
            existing_sign_url = str(existing["sign_url"] or "").strip()
            if existing_sign_url:
                existing_kb.row(InlineKeyboardButton("✍️ Подписать текущий договор", url=existing_sign_url))
            existing_kb.row(InlineKeyboardButton("✅ Договор подписан, перейти к оплате", callback_data="enr:pay:start"))
            if mentor_url:
                existing_kb.row(InlineKeyboardButton("Написать ментору", url=mentor_url))
            bot.send_message(
                c.message.chat.id,
                text,
                reply_markup=existing_kb if existing_kb.inline_keyboard else regular_menu_kb(),
            )
            bot.answer_callback_query(c.id, "Договор уже выдавался")
            return

        contract_path = (cfg.CONTRACT_FILE_PATH or "").strip()
        if contract_path and not os.path.isabs(contract_path):
            contract_path = os.path.abspath(contract_path)
        sign_url = (cfg.OKIDOKI_SIGN_URL or "").strip()
        okidoki_response: dict = {}
        okidoki_error = ""
        if okidoki_client.enabled:
            okidoki_payload = {
                "user_id": int(c.from_user.id),
                "username": c.from_user.username,
                "chat_id": int(c.message.chat.id),
                "level": str(enroll.get("level") or track.get("level") or "not_zero"),
                "track_key": track_key,
                "track_title": track.get("title"),
                "tariff_key": plan_key,
                "tariff_title": plan.get("title"),
                "tariff_price": plan.get("price"),
            }
            try:
                okidoki_response = okidoki_client.create_contract(okidoki_payload)
                dynamic_sign_url = str(
                    okidoki_response.get("sign_url")
                    or okidoki_response.get("signUrl")
                    or okidoki_response.get("url")
                    or ""
                ).strip()
                if dynamic_sign_url:
                    sign_url = dynamic_sign_url
            except OkiDokiClientError as exc:
                okidoki_error = str(exc)

        repo_enrollment_contracts.create_once(
            conn,
            tz,
            owner_tg_id=int(c.from_user.id),
            owner_chat_id=int(c.message.chat.id),
            level_key=str(enroll.get("level") or track.get("level") or "not_zero"),
            track_key=track_key,
            track_title=str(track.get("title") or ""),
            tariff_key=plan_key,
            tariff_title=str(plan.get("title") or ""),
            tariff_price=str(plan.get("price") or ""),
            contract_file_path=contract_path,
            sign_url=sign_url,
            status="sent",
            note="issued_by_bot",
        )

        contract_sent = False
        if contract_path and os.path.isfile(contract_path):
            try:
                with open(contract_path, "rb") as f:
                    bot.send_document(
                        c.message.chat.id,
                        f,
                        caption=(
                            f"Договор по тарифу:\n"
                            f"{track['title']} -> {plan['title']}\n"
                            f"Цена: {plan['price']}"
                        ),
                    )
                contract_sent = True
            except Exception:
                contract_sent = False

        if not contract_sent:
            bot.send_message(
                c.message.chat.id,
                "Файл договора пока не прикреплён в конфиге бота.\n"
                "Ментор отправит документ вручную.",
            )

        sign_kb = InlineKeyboardMarkup()
        if sign_url:
            sign_kb.row(InlineKeyboardButton("✍️ Подписать договор", url=sign_url))
        sign_kb.row(InlineKeyboardButton("✅ Договор подписан, перейти к оплате", callback_data="enr:pay:start"))
        if (cfg.MENTOR_CONTACT_URL or "").strip():
            sign_kb.row(InlineKeyboardButton("Написать ментору", url=cfg.MENTOR_CONTACT_URL))

        if sign_url:
            bot.send_message(
                c.message.chat.id,
                "Шаг 1: подпиши договор по ссылке.\n"
                "Шаг 2: после подписания нажми «Договор подписан, перейти к оплате».",
                reply_markup=sign_kb if sign_kb.inline_keyboard else None,
            )
        else:
            bot.send_message(
                c.message.chat.id,
                "Ссылка на подписание пока не настроена. Напиши ментору для выдачи ссылки.\n"
                "После подписания нажми «Договор подписан, перейти к оплате».",
                reply_markup=sign_kb if sign_kb.inline_keyboard else None,
            )
        if okidoki_error:
            bot.send_message(
                c.message.chat.id,
                "Автоматическое создание договора в OkiDoki вернуло ошибку. "
                "Ментор проверит и при необходимости создаст договор вручную.",
            )

        repo_states.clear_state(conn, c.from_user.id, tz)
        bot.send_message(
            c.message.chat.id,
            "Договор отправлен. После подписания продолжи оплату кнопкой из сообщения выше.",
            reply_markup=regular_menu_kb(),
        )
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data == "enr:pay:start")
    def cb_enroll_pay_start(c: CallbackQuery):
        if is_admin(c.from_user.id):
            bot.answer_callback_query(c.id, "Это пользовательское меню")
            return
        owner_id = int(c.from_user.id)
        contract = repo_enrollment_contracts.get_by_owner(conn, owner_id)
        if not contract:
            bot.send_message(
                c.message.chat.id,
                "Не найден активный договор. Оформи тариф в «Вступить на обучение» и получи договор заново.",
                reply_markup=regular_menu_kb(),
            )
            bot.answer_callback_query(c.id, "Сначала оформи договор")
            return

        repo_enrollment_contracts.set_status(
            conn,
            tz,
            owner_id,
            status="signed",
            note="signed_confirmed_by_user_in_bot",
        )
        _start_enroll_payment_wizard(owner_id, c.message.chat.id, owner_username=c.from_user.username)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data == "v2:student")
    def cb_v2_student(c: CallbackQuery):
        if is_admin(c.from_user.id):
            bot.answer_callback_query(c.id, "Это пользовательское меню")
            return
        user_id = int(c.from_user.id)
        repo_analytics.log_event(conn, tz, user_id, "funnel.student.entry_click")
        if _has_student_access(user_id):
            repo_analytics.touch_user(conn, tz, user_id, role_type=repo_analytics.ROLE_STUDENT)
            repo_states.clear_state(conn, user_id, tz)
            bot.edit_message_text(
                texts.user_title(),
                c.message.chat.id,
                c.message.message_id,
                reply_markup=user_menu_kb(show_pay=_user_show_pay_button(user_id)),
            )
            bot.answer_callback_query(c.id)
            return

        repo_states.set_state(conn, user_id, STATE_STUDENT_CODE, {}, tz)
        bot.edit_message_text(
            "Введи одноразовый код ученика от ментора.\n"
            "Пример: <code>STU-AB12CD34</code>",
            c.message.chat.id,
            c.message.message_id,
            reply_markup=_v2_back_kb(),
        )
        bot.answer_callback_query(c.id)

    # =========================
    # User cabinet
    # =========================

    @bot.callback_query_handler(func=lambda c: c.data == "u:cancel")
    def cb_cancel(c: CallbackQuery):
        if is_admin(c.from_user.id):
            bot.answer_callback_query(c.id, "Нет")
            return
        if _has_student_access(int(c.from_user.id)):
            send_user_home(c.message.chat.id, c.from_user.id)
        else:
            send_regular_home(c.message.chat.id, c.from_user.id)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data == "u:profile")
    def cb_profile(c: CallbackQuery):
        if is_admin(c.from_user.id):
            bot.answer_callback_query(c.id, "Это меню ученика")
            return
        if not _has_student_access(int(c.from_user.id)):
            _send_student_access_required(c.message.chat.id)
            bot.answer_callback_query(c.id, "Нужен код ученика")
            return

        owner_id = int(c.from_user.id)
        s = repo_students.get_by_owner(conn, owner_id)
        last = _last_request(owner_id, "PROFILE")
        status = (last["status"] if last else None) if not s else "APPROVED"

        msg = ""
        if status == "APPROVED":
            msg = "Анкета подтверждена ментором. Если нужно — можно обновить данные (уйдёт новая заявка на подтверждение)."
        elif status == "PENDING":
            msg = "Анкета отправлена и ждёт подтверждения ментора. Если ошибся — можешь отправить новую версию."
        elif status == "REJECTED":
            msg = "Анкета отклонена ментором. Исправь и отправь заново."
        else:
            msg = "Анкеты ещё нет. Заполни и отправь — она придёт ментору на подтверждение."

        kb = InlineKeyboardMarkup()
        kb.row(InlineKeyboardButton("✏️ Заполнить/изменить", callback_data="u:profile:edit"))
        kb.row(InlineKeyboardButton("🏠 В меню", callback_data="u:cancel"))
        bot.send_message(c.message.chat.id, msg, reply_markup=kb)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data == "u:profile:edit")
    def cb_profile_edit(c: CallbackQuery):
        if is_admin(c.from_user.id):
            bot.answer_callback_query(c.id, "Это меню ученика")
            return
        if not _has_student_access(int(c.from_user.id)):
            _send_student_access_required(c.message.chat.id)
            bot.answer_callback_query(c.id, "Нужен код ученика")
            return
        owner_id = int(c.from_user.id)
        last = _last_request(owner_id, "PROFILE")
        prefill = repo_requests.payload(last) if last else _prefill_profile_from_student(owner_id)
        # normalize username field
        if prefill.get("username") and not str(prefill["username"]).startswith("@"):
            prefill["username"] = "@" + str(prefill["username"])
        _start_profile_wizard(owner_id, c.message.chat.id, prefill=prefill)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data == "u:accounts")
    def cb_accounts(c: CallbackQuery):
        if is_admin(c.from_user.id):
            bot.answer_callback_query(c.id, "Это меню ученика")
            return
        if not _has_student_access(int(c.from_user.id)):
            _send_student_access_required(c.message.chat.id)
            bot.answer_callback_query(c.id, "Нужен код ученика")
            return
        _start_accounts_wizard(int(c.from_user.id), c.message.chat.id)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data == "u:pay")
    def cb_pay(c: CallbackQuery):
        if is_admin(c.from_user.id):
            bot.answer_callback_query(c.id, "Это меню ученика")
            return
        if not _has_student_access(int(c.from_user.id)):
            _send_student_access_required(c.message.chat.id)
            bot.answer_callback_query(c.id, "Нужен код ученика")
            return
        _start_payment_wizard(int(c.from_user.id), c.message.chat.id, owner_username=c.from_user.username)
        bot.answer_callback_query(c.id)

    # =========================
    # Profile form buttons
    # =========================

    def _get_profile_state(user_id: int) -> tuple[str | None, dict, dict]:
        st, data = repo_states.get_state(conn, user_id)
        data = data or {}
        prof = data.get("profile") or {}
        return st, data, prof

    @bot.callback_query_handler(func=lambda c: c.data.startswith("uform:uname:"))
    def uform_uname(c: CallbackQuery):
        if is_admin(c.from_user.id):
            bot.answer_callback_query(c.id, "Нет")
            return
        st, data, prof = _get_profile_state(c.from_user.id)
        if st != STATE_PROFILE or data.get("step") != "username":
            bot.answer_callback_query(c.id)
            return
        val = c.data.split(":", 2)[2]
        if val == "skip":
            prof["username"] = None
        else:
            prof["username"] = val
        data["profile"] = prof
        data["step"] = "direction"
        repo_states.set_state(conn, c.from_user.id, STATE_PROFILE, data, tz)
        bot.send_message(c.message.chat.id, "Направление?", reply_markup=user_direction_kb())
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("uform:dir:"))
    def uform_dir(c: CallbackQuery):
        if is_admin(c.from_user.id):
            bot.answer_callback_query(c.id, "Нет")
            return
        st, data, prof = _get_profile_state(c.from_user.id)
        if st != STATE_PROFILE or data.get("step") != "direction":
            bot.answer_callback_query(c.id)
            return
        val = c.data.split(":", 2)[2]
        if val == "manual":
            bot.send_message(c.message.chat.id, "Напиши направление вручную (например: java):")
            bot.answer_callback_query(c.id)
            return
        prof["direction"] = val
        data["profile"] = prof
        data["step"] = "stage"
        repo_states.set_state(conn, c.from_user.id, STATE_PROFILE, data, tz)
        bot.send_message(c.message.chat.id, "Этап?", reply_markup=user_stage_kb())
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("uform:stage:"))
    def uform_stage(c: CallbackQuery):
        if is_admin(c.from_user.id):
            bot.answer_callback_query(c.id, "Нет")
            return
        st, data, prof = _get_profile_state(c.from_user.id)
        if st != STATE_PROFILE or data.get("step") != "stage":
            bot.answer_callback_query(c.id)
            return
        val = c.data.split(":", 2)[2]
        if val == "manual":
            bot.send_message(c.message.chat.id, "Напиши этап вручную (например: Дипфейк):")
            bot.answer_callback_query(c.id)
            return
        prof["stage"] = val
        data["profile"] = prof
        data["step"] = "tariff"
        repo_states.set_state(conn, c.from_user.id, STATE_PROFILE, data, tz)
        bot.send_message(c.message.chat.id, "Тариф?", reply_markup=user_tariff_kb())
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("uform:tariff:"))
    def uform_tariff(c: CallbackQuery):
        if is_admin(c.from_user.id):
            bot.answer_callback_query(c.id, "Нет")
            return
        st, data, prof = _get_profile_state(c.from_user.id)
        if st != STATE_PROFILE or data.get("step") != "tariff":
            bot.answer_callback_query(c.id)
            return
        tariff = c.data.split(":", 2)[2]
        prof["tariff"] = tariff

        # Важно: если только постоплата — предоплату не спрашиваем.
        if tariff == "post":
            prof["prepay"] = 0
            data["profile"] = prof
            data["step"] = "post_total_percent"
            repo_states.set_state(conn, c.from_user.id, STATE_PROFILE, data, tz)
            bot.send_message(c.message.chat.id, "Процент постоплаты всего:", reply_markup=user_post_total_kb())
        elif tariff == "pre":
            data["profile"] = prof
            data["step"] = "prepay"
            repo_states.set_state(conn, c.from_user.id, STATE_PROFILE, data, tz)
            bot.send_message(c.message.chat.id, "Предоплата (если 0 — выбери 0 или напиши сумму):", reply_markup=user_prepay_kb())
        else:  # pre_post
            data["profile"] = prof
            data["step"] = "prepay"
            repo_states.set_state(conn, c.from_user.id, STATE_PROFILE, data, tz)
            bot.send_message(c.message.chat.id, "Предоплата (если 0 — выбери 0 или напиши сумму):", reply_markup=user_prepay_kb())

        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("uform:prepay:"))
    def uform_prepay(c: CallbackQuery):
        if is_admin(c.from_user.id):
            bot.answer_callback_query(c.id, "Нет")
            return
        st, data, prof = _get_profile_state(c.from_user.id)
        if st != STATE_PROFILE or data.get("step") != "prepay":
            bot.answer_callback_query(c.id)
            return
        val = c.data.split(":", 2)[2]
        if val == "manual":
            bot.send_message(c.message.chat.id, "Напиши сумму предоплаты числом (например 30000):")
            bot.answer_callback_query(c.id)
            return
        prof["prepay"] = _parse_money(val)

        # если только предоплата — постоплату не спрашиваем
        if (prof.get("tariff") or "").strip() == "pre":
            data["profile"] = prof
            data["step"] = "contract"
            repo_states.set_state(conn, c.from_user.id, STATE_PROFILE, data, tz)
            bot.send_message(c.message.chat.id, "Ссылка на договор (обязательно):")
        else:
            data["profile"] = prof
            data["step"] = "post_total_percent"
            repo_states.set_state(conn, c.from_user.id, STATE_PROFILE, data, tz)
            bot.send_message(c.message.chat.id, "Процент постоплаты всего:", reply_markup=user_post_total_kb())
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("uform:post_total:"))
    def uform_post_total(c: CallbackQuery):
        if is_admin(c.from_user.id):
            bot.answer_callback_query(c.id, "Нет")
            return
        st, data, prof = _get_profile_state(c.from_user.id)
        if st != STATE_PROFILE or data.get("step") != "post_total_percent":
            bot.answer_callback_query(c.id)
            return
        val = c.data.split(":", 2)[2]
        if val == "manual":
            bot.send_message(c.message.chat.id, "Напиши процент постоплаты всего числом (например 600):")
            bot.answer_callback_query(c.id)
            return
        try:
            prof["post_total_percent"] = float(val.replace(",", "."))
        except Exception:
            prof["post_total_percent"] = 0.0
        data["profile"] = prof
        data["step"] = "post_monthly_percent"
        repo_states.set_state(conn, c.from_user.id, STATE_PROFILE, data, tz)
        bot.send_message(c.message.chat.id, "Процент в месяц:", reply_markup=user_post_monthly_kb())
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("uform:post_m:"))
    def uform_post_monthly(c: CallbackQuery):
        if is_admin(c.from_user.id):
            bot.answer_callback_query(c.id, "Нет")
            return
        st, data, prof = _get_profile_state(c.from_user.id)
        if st != STATE_PROFILE or data.get("step") != "post_monthly_percent":
            bot.answer_callback_query(c.id)
            return
        val = c.data.split(":", 2)[2]
        if val == "manual":
            bot.send_message(c.message.chat.id, "Напиши процент в месяц (например 50):")
            bot.answer_callback_query(c.id)
            return
        try:
            prof["post_monthly_percent"] = float(val.replace(",", "."))
        except Exception:
            prof["post_monthly_percent"] = 50.0
        data["profile"] = prof
        data["step"] = "contract"
        repo_states.set_state(conn, c.from_user.id, STATE_PROFILE, data, tz)
        bot.send_message(c.message.chat.id, "Ссылка на договор (обязательно):")
        bot.answer_callback_query(c.id)

    # =========================
    # Text handlers for user states
    # =========================

    @bot.message_handler(
        func=lambda m: repo_states.get_state(conn, m.from_user.id)[0] == STATE_STUDENT_CODE,
        content_types=["text"],
    )
    def st_student_code(m: Message):
        if is_admin(m.from_user.id):
            return
        code = (m.text or "").strip().upper()
        if len(code) < 4:
            repo_analytics.log_event(conn, tz, m.from_user.id, "funnel.student.code_invalid", {"reason": "too_short"})
            bot.send_message(m.chat.id, "Код слишком короткий. Проверь и отправь ещё раз.")
            return

        row, err = repo_student_codes.validate_for_use(conn, tz, code)
        if err:
            error_text = {
                "not_found": "Код не найден. Проверь и попробуй снова.",
                "used": "Этот код уже использован.",
                "revoked": "Этот код отозван ментором.",
                "expired": "Срок действия кода истёк.",
            }.get(err, "Код невалиден. Попробуй снова.")
            repo_analytics.log_event(conn, tz, m.from_user.id, "funnel.student.code_invalid", {"reason": err})
            bot.send_message(m.chat.id, error_text, reply_markup=_v2_back_kb())
            return
        if not row:
            repo_analytics.log_event(conn, tz, m.from_user.id, "funnel.student.code_invalid", {"reason": "unknown"})
            bot.send_message(m.chat.id, "Код невалиден. Попробуй снова.", reply_markup=_v2_back_kb())
            return

        ok = repo_student_codes.mark_used(conn, tz, int(row["id"]), int(m.from_user.id))
        if not ok:
            repo_analytics.log_event(conn, tz, m.from_user.id, "funnel.student.code_invalid", {"reason": "race"})
            bot.send_message(m.chat.id, "Не удалось активировать код. Попробуй ещё раз.", reply_markup=_v2_back_kb())
            return

        owner_id = int(m.from_user.id)
        repo_analytics.touch_user(conn, tz, owner_id, role_type=repo_analytics.ROLE_STUDENT)
        repo_analytics.log_event(conn, tz, owner_id, "funnel.student.code_valid")
        last = _last_request(owner_id, "PROFILE")
        prefill = repo_requests.payload(last) if last else _prefill_profile_from_student(owner_id)
        if prefill.get("username") and not str(prefill["username"]).startswith("@"):
            prefill["username"] = "@" + str(prefill["username"])

        bot.send_message(m.chat.id, "Код принят ✅\nЗаполни анкету ученика.")
        _start_profile_wizard(owner_id, m.chat.id, prefill=prefill if prefill else None)

    @bot.message_handler(
        func=lambda m: repo_states.get_state(conn, m.from_user.id)[0] == STATE_AUTOAPPLY,
        content_types=["text"],
    )
    def st_autoapply(m: Message):
        if is_admin(m.from_user.id):
            return
        st, data = repo_states.get_state(conn, m.from_user.id)
        data = data or {}
        if st != STATE_AUTOAPPLY:
            return
        auto = (data.get("auto") or {}).copy()
        step = (data.get("step") or "").strip()
        text = (m.text or "").strip()

        if step == "direction_manual":
            if len(text) < 2:
                bot.send_message(m.chat.id, "Слишком коротко. Напиши направление, например: qa, devops, analyst.")
                return
            auto["direction"] = text.strip().lower()
            saved_login = str(auto.get("login") or "").strip()
            saved_password = str(auto.get("password") or "").strip()
            if saved_login and saved_password:
                repo_states.set_state(conn, m.from_user.id, STATE_AUTOAPPLY, {"step": "login_pick", "auto": auto}, tz)
                bot.send_message(
                    m.chat.id,
                    "Нашёл сохранённые доступы HH. Использовать их или ввести новые?",
                    reply_markup=_auto_login_pick_kb(saved_login),
                )
            else:
                repo_states.set_state(conn, m.from_user.id, STATE_AUTOAPPLY, {"step": "login", "auto": auto}, tz)
                bot.send_message(m.chat.id, "Логин HH (почта/телефон):")
            return

        if step == "login":
            if len(text) < 4:
                bot.send_message(m.chat.id, "Логин слишком короткий. Введи HH логин ещё раз:")
                return
            auto["login"] = text
            repo_states.set_state(conn, m.from_user.id, STATE_AUTOAPPLY, {"step": "password", "auto": auto}, tz)
            bot.send_message(m.chat.id, "Пароль HH:")
            return

        if step == "password":
            if len(text) < 4:
                bot.send_message(m.chat.id, "Пароль слишком короткий. Введи пароль HH:")
                return
            auto["password"] = text
            if bool(auto.get("target_locked")):
                repo_states.set_state(conn, m.from_user.id, STATE_AUTOAPPLY, {"step": "query", "auto": auto}, tz)
                bot.send_message(
                    m.chat.id,
                    (
                        f"Цель откликов взята с сайта: <b>{int(auto.get('target_applies') or 0)}</b>.\n"
                        "Теперь укажи поисковый запрос HH.\n"
                        "Это слово/фраза для поиска вакансий.\n"
                        "Примеры: Java developer, Python backend, Frontend React, QA engineer, DevOps.\n"
                        "Можно отправить текст или выбрать кнопку ниже."
                    ),
                    reply_markup=_auto_query_kb(),
                )
                return
            repo_states.set_state(conn, m.from_user.id, STATE_AUTOAPPLY, {"step": "target", "auto": auto}, tz)
            bot.send_message(m.chat.id, "Цель откликов (числом, например 200):")
            return

        if step == "target":
            target = _parse_money(text)
            if target <= 0:
                bot.send_message(m.chat.id, "Введи число больше 0 (например 200):")
                return
            auto["target_applies"] = min(target, 5000)
            auto["price_total"] = _auto_price_for_user(int(m.from_user.id), auto["target_applies"])
            repo_states.set_state(conn, m.from_user.id, STATE_AUTOAPPLY, {"step": "query", "auto": auto}, tz)
            bot.send_message(
                m.chat.id,
                (
                    "Поисковый запрос HH.\n"
                    "Это слово/фраза для поиска вакансий.\n"
                    "Примеры: Java developer, Python backend, Frontend React, QA engineer, DevOps.\n"
                    "Можно отправить текст или выбрать кнопку ниже:"
                ),
                reply_markup=_auto_query_kb(),
            )
            return

        if step == "query":
            auto["query_text"] = text
            repo_states.set_state(conn, m.from_user.id, STATE_AUTOAPPLY, {"step": "confirm", "auto": auto}, tz)
            summary = (
                "<b>Проверка параметров автооткликов</b>\n"
                f"Направление: <b>{auto.get('direction')}</b>\n"
                f"Логин: <code>{auto.get('login')}</code>\n"
                f"Цель: <b>{int(auto.get('target_applies') or 0)}</b> откликов\n"
                f"Запрос: <code>{auto.get('query_text') or auto.get('direction')}</code>"
            )
            if _auto_requires_site_payment(auto):
                summary += f"\nОплата с сайта: <b>{int(auto.get('price_total') or 0)} ₽</b> (оплата у ментора)."
            bot.send_message(m.chat.id, summary, reply_markup=_auto_confirm_kb())
            return

        if step in {"pay_date", "pay_inn", "pay_photo"}:
            repo_states.clear_state(conn, m.from_user.id, tz)
            bot.send_message(
                m.chat.id,
                "Сценарий оплаты обновлён: оплата автооткликов проводится напрямую у ментора.\n"
                "Нажми «Автоотклики» и снова нажми запуск: бот отправит ментору сумму и параметры.",
                reply_markup=regular_menu_kb(),
            )
            return

        bot.send_message(
            m.chat.id,
            "Сценарий автооткликов не завершён. Нажми «Автоотклики» в меню и начни заново.",
            reply_markup=regular_menu_kb(),
        )

    @bot.message_handler(content_types=["photo", "document"], func=lambda m: repo_states.get_state(conn, m.from_user.id)[0] == STATE_AUTOAPPLY)
    def st_autoapply_payment_photo(m: Message):
        if is_admin(m.from_user.id):
            return
        st, data = repo_states.get_state(conn, m.from_user.id)
        data = data or {}
        if st != STATE_AUTOAPPLY or (data.get("step") or "") != "pay_photo":
            return
        repo_states.clear_state(conn, m.from_user.id, tz)
        bot.send_message(
            m.chat.id,
            "Загрузка чека в боте отключена.\n"
            "Оплата автооткликов проводится напрямую у ментора.",
            reply_markup=regular_menu_kb(),
        )

    @bot.message_handler(func=lambda m: repo_states.get_state(conn, m.from_user.id)[0] == STATE_PROFILE)
    def st_profile(m: Message):
        if is_admin(m.from_user.id):
            return
        st, data = repo_states.get_state(conn, m.from_user.id)
        data = data or {}
        prof = data.get("profile") or {}
        step = data.get("step")
        text = (m.text or "").strip()

        if step == "fio":
            if len(text) < 5:
                bot.send_message(m.chat.id, "Напиши ФИО полностью (минимум 5 символов):")
                return
            prof["fio"] = text
            data["profile"] = prof
            data["step"] = "username"
            repo_states.set_state(conn, m.from_user.id, STATE_PROFILE, data, tz)

            kb = InlineKeyboardMarkup()
            if m.from_user.username:
                kb.row(InlineKeyboardButton(f"Использовать @{m.from_user.username}", callback_data=f"uform:uname:@{m.from_user.username}"))
            kb.row(InlineKeyboardButton("У меня нет username", callback_data="uform:uname:skip"))
            kb.row(InlineKeyboardButton("✖️ Отмена", callback_data="u:cancel"))
            bot.send_message(m.chat.id, "Username (если есть). Выбери кнопку:", reply_markup=kb)
            return

        if step == "username":
            # allow manual entry
            if text.lower() in ("нет", "-", "пропустить"):
                prof["username"] = None
            else:
                prof["username"] = text if text.startswith("@") else ("@" + text)
            data["profile"] = prof
            data["step"] = "direction"
            repo_states.set_state(conn, m.from_user.id, STATE_PROFILE, data, tz)
            bot.send_message(m.chat.id, "Направление?", reply_markup=user_direction_kb())
            return

        if step == "direction":
            prof["direction"] = text
            data["profile"] = prof
            data["step"] = "stage"
            repo_states.set_state(conn, m.from_user.id, STATE_PROFILE, data, tz)
            bot.send_message(m.chat.id, "Этап?", reply_markup=user_stage_kb())
            return

        if step == "stage":
            prof["stage"] = text
            data["profile"] = prof
            data["step"] = "tariff"
            repo_states.set_state(conn, m.from_user.id, STATE_PROFILE, data, tz)
            bot.send_message(m.chat.id, "Тариф?", reply_markup=user_tariff_kb())
            return

        if step == "tariff":
            t = text.lower()
            tariff = None
            if "пост" in t and "пред" not in t:
                tariff = "post"
            elif "пред" in t and "пост" in t:
                tariff = "pre_post"
            elif "пред" in t:
                tariff = "pre"
            elif t in ("post", "pre", "pre_post"):
                tariff = t
            if not tariff:
                bot.send_message(m.chat.id, "Выбери тариф кнопкой ниже:", reply_markup=user_tariff_kb())
                return
            prof["tariff"] = tariff
            if tariff == "post":
                prof["prepay"] = 0
                data["profile"] = prof
                data["step"] = "post_total_percent"
                repo_states.set_state(conn, m.from_user.id, STATE_PROFILE, data, tz)
                bot.send_message(m.chat.id, "Процент постоплаты всего:", reply_markup=user_post_total_kb())
            else:
                data["profile"] = prof
                data["step"] = "prepay"
                repo_states.set_state(conn, m.from_user.id, STATE_PROFILE, data, tz)
                bot.send_message(m.chat.id, "Предоплата (если 0 — выбери 0 или напиши сумму):", reply_markup=user_prepay_kb())
            return

        if step == "prepay":
            prof["prepay"] = _parse_money(text)
            if (prof.get("tariff") or "").strip() == "pre":
                data["profile"] = prof
                data["step"] = "contract"
                repo_states.set_state(conn, m.from_user.id, STATE_PROFILE, data, tz)
                bot.send_message(m.chat.id, "Ссылка на договор (обязательно):")
            else:
                data["profile"] = prof
                data["step"] = "post_total_percent"
                repo_states.set_state(conn, m.from_user.id, STATE_PROFILE, data, tz)
                bot.send_message(m.chat.id, "Процент постоплаты всего:", reply_markup=user_post_total_kb())
            return

        if step == "post_total_percent":
            try:
                prof["post_total_percent"] = float(text.replace(",", "."))
            except Exception:
                prof["post_total_percent"] = 0.0
            data["profile"] = prof
            data["step"] = "post_monthly_percent"
            repo_states.set_state(conn, m.from_user.id, STATE_PROFILE, data, tz)
            bot.send_message(m.chat.id, "Процент в месяц:", reply_markup=user_post_monthly_kb())
            return

        if step == "post_monthly_percent":
            try:
                prof["post_monthly_percent"] = float(text.replace(",", "."))
            except Exception:
                prof["post_monthly_percent"] = 50.0
            data["profile"] = prof
            data["step"] = "contract"
            repo_states.set_state(conn, m.from_user.id, STATE_PROFILE, data, tz)
            bot.send_message(m.chat.id, "Ссылка на договор (обязательно):")
            return

        if step == "contract":
            if not text.startswith("http"):
                bot.send_message(m.chat.id, "Нужна ссылка (начинается с http). Вставь ссылку на договор:")
                return
            prof["contract_url"] = text
            prof["owner_chat_id"] = m.chat.id
            prof["owner_username"] = m.from_user.username
            prof["join_date"] = format_date_ddmmyyyy(now(tz).date())

            # If user didn't set username explicitly, take from telegram.
            if not prof.get("username") and m.from_user.username:
                prof["username"] = "@" + m.from_user.username

            req_id = repo_requests.create(conn, tz, m.from_user.id, "PROFILE", prof, None)
            repo_analytics.log_event(conn, tz, m.from_user.id, "funnel.student.profile_submitted", {"req_id": req_id})

            bot.send_message(m.chat.id, "Анкета отправлена ментору на подтверждение.")
            notify_admins(
                f"<b>[ЗАЯВКА]</b> {texts.request_title('PROFILE')}\nОт: @{m.from_user.username or m.from_user.id}\nID: {req_id}",
                kb=request_admin_kb(req_id),
            )

            send_user_home(m.chat.id, m.from_user.id)
            return

        # unexpected
        bot.send_message(m.chat.id, "Я потерял шаг анкеты. Открой 'Моя анкета' и начни заново.")
        send_user_home(m.chat.id, m.from_user.id)

    @bot.message_handler(func=lambda m: repo_states.get_state(conn, m.from_user.id)[0] == STATE_ACCOUNTS)
    def st_accounts(m: Message):
        if is_admin(m.from_user.id):
            return
        _st, data = repo_states.get_state(conn, m.from_user.id)
        data = data or {}
        step = data.get("step")
        acc = data.get("acc") or {}
        text = (m.text or "").strip()

        if step == "phone":
            acc["hh_phone"] = None if text in {"-", "—"} else text
            data["acc"] = acc
            data["step"] = "email"
            repo_states.set_state(conn, m.from_user.id, STATE_ACCOUNTS, data, tz)
            bot.send_message(m.chat.id, "Почта HH (или '-' если нет):")
            return
        if step == "email":
            acc["hh_email"] = None if text in {"-", "—"} else text
            data["acc"] = acc
            data["step"] = "pass"
            repo_states.set_state(conn, m.from_user.id, STATE_ACCOUNTS, data, tz)
            bot.send_message(m.chat.id, "Пароль HH (или '-' если нет):")
            return
        if step == "pass":
            acc["hh_password"] = None if text in {"-", "—"} else text
            data["acc"] = acc
            data["step"] = "birth"
            repo_states.set_state(conn, m.from_user.id, STATE_ACCOUNTS, data, tz)
            bot.send_message(m.chat.id, "Дата рождения (дд.мм.гггг) или '-' :")
            return

        if step == "birth":
            acc["hh_birth_date"] = None if text in {"-", "—"} else text
            data["acc"] = acc
            data["step"] = "loc"
            repo_states.set_state(conn, m.from_user.id, STATE_ACCOUNTS, data, tz)
            bot.send_message(m.chat.id, "Локация (город/страна) или '-' :")
            return

        if step == "loc":
            acc["hh_location"] = None if text in {"-", "—"} else text
            data["acc"] = acc
            data["step"] = "salary_min"
            repo_states.set_state(conn, m.from_user.id, STATE_ACCOUNTS, data, tz)
            bot.send_message(m.chat.id, "Фин ожидания: минимум (число в ₽) или '-' :")
            return

        if step == "salary_min":
            if text in {"-", "—"}:
                acc["hh_salary_min"] = None
            else:
                n = _parse_money(text)
                if n <= 0:
                    bot.send_message(m.chat.id, "Введи число (например 220000) или '-' :")
                    return
                acc["hh_salary_min"] = n
            data["acc"] = acc
            data["step"] = "salary_comfort"
            repo_states.set_state(conn, m.from_user.id, STATE_ACCOUNTS, data, tz)
            bot.send_message(m.chat.id, "Фин ожидания: комфорт (число в ₽) или '-' :")
            return

        if step == "salary_comfort":
            if text in {"-", "—"}:
                acc["hh_salary_comfort"] = None
            else:
                n = _parse_money(text)
                if n <= 0:
                    bot.send_message(m.chat.id, "Введи число (например 260000) или '-' :")
                    return
                acc["hh_salary_comfort"] = n

            payload = {**acc, "owner_chat_id": m.chat.id, "owner_username": m.from_user.username}
            req_id = repo_requests.create(conn, tz, m.from_user.id, "ACCOUNTS", payload, None)

            bot.send_message(m.chat.id, "Данные HH отправлены ментору на подтверждение.")
            notify_admins(
                f"<b>[ЗАЯВКА]</b> {texts.request_title('ACCOUNTS')}\nОт: @{m.from_user.username or m.from_user.id}\nID: {req_id}",
                kb=request_admin_kb(req_id),
            )
            send_user_home(m.chat.id, m.from_user.id)
            return

        bot.send_message(m.chat.id, "Я потерял шаг. Открой 'Доступы HH' и заполни заново.")
        send_user_home(m.chat.id, m.from_user.id)

    @bot.message_handler(func=lambda m: repo_states.get_state(conn, m.from_user.id)[0] == STATE_ENROLL_PAYMENT)
    def st_enroll_payment(m: Message):
        if is_admin(m.from_user.id):
            return
        repo_states.clear_state(conn, m.from_user.id, tz)
        _start_enroll_payment_wizard(int(m.from_user.id), m.chat.id, owner_username=m.from_user.username)
        return

    @bot.message_handler(content_types=["photo", "document"], func=lambda m: repo_states.get_state(conn, m.from_user.id)[0] == STATE_ENROLL_PAYMENT)
    def st_enroll_payment_photo(m: Message):
        if is_admin(m.from_user.id):
            return
        repo_states.clear_state(conn, m.from_user.id, tz)
        _start_enroll_payment_wizard(int(m.from_user.id), m.chat.id, owner_username=m.from_user.username)
        return

    @bot.message_handler(func=lambda m: repo_states.get_state(conn, m.from_user.id)[0] == STATE_PAYMENT)
    def st_payment(m: Message):
        if is_admin(m.from_user.id):
            return
        repo_states.clear_state(conn, m.from_user.id, tz)
        _start_payment_wizard(int(m.from_user.id), m.chat.id, owner_username=m.from_user.username)
        return

    @bot.message_handler(content_types=["photo", "document"], func=lambda m: repo_states.get_state(conn, m.from_user.id)[0] == STATE_PAYMENT)
    def st_payment_photo(m: Message):
        if is_admin(m.from_user.id):
            return
        repo_states.clear_state(conn, m.from_user.id, tz)
        _start_payment_wizard(int(m.from_user.id), m.chat.id, owner_username=m.from_user.username)
        return
