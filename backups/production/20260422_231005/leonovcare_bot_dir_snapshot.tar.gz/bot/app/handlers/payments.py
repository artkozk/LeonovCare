from __future__ import annotations
import sqlite3
import datetime as dt
from telebot import TeleBot
from telebot.types import CallbackQuery, Message, InlineKeyboardMarkup, InlineKeyboardButton

from app.handlers.common import is_admin
from app.db import repo_states, repo_postpay, repo_payments, repo_students
from app.services.timeutils import now, iso, format_date_ddmmyyyy, parse_date_ddmm_past
from app.services.postpay import post_total, recommended_payment, next_due_after_payment
from app.ui.keyboards import payments_menu_kb, pick_list_kb, open_student_kb
from app.ui.formatters import money

def init(bot: TeleBot, ctx: dict) -> None:
    conn: sqlite3.Connection = ctx["conn"]
    tz = ctx["cfg"].TZ

    def _list_due(from_date: str, to_date: str) -> tuple[str, InlineKeyboardMarkup]:
        rows = repo_postpay.list_due(conn, from_date, to_date)
        if not rows:
            return "Нет ожидаемых платежей в этом диапазоне.", payments_menu_kb()
        lines=[]
        kb=InlineKeyboardMarkup()
        for r in rows[:10]:
            sid=int(r["student_id"])
            offer=r["offer_amount"]
            total = post_total(offer, r["total_percent"])
            paid = repo_payments.sum_payments(conn, sid, "postpay")
            remaining = max(0, (total or 0) - paid) if total is not None else None
            rem_str = money(remaining) if remaining is not None else "—"
            lines.append(f"• <b>{r['fio']}</b> — срок <b>{r['next_due_date']}</b>, осталось {rem_str}")
            kb.row(
                InlineKeyboardButton("👤", callback_data=f"st:open:{sid}"),
                InlineKeyboardButton("💰 Внести", callback_data=f"py:add_for:{sid}"),
            )
        kb.row(InlineKeyboardButton("⬅️ Назад", callback_data="m:payments"))
        return "Ожидаемые платежи:\n" + "\n".join(lines), kb

    @bot.callback_query_handler(func=lambda c: c.data == "py:today")
    def py_today(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        today_str = format_date_ddmmyyyy(now(tz).date())
        msg, kb = _list_due(today_str, today_str)
        bot.edit_message_text(msg, c.message.chat.id, c.message.message_id, reply_markup=kb)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data == "py:week")
    def py_week(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        d = now(tz).date()
        from_str = format_date_ddmmyyyy(d)
        to_str = format_date_ddmmyyyy(d + dt.timedelta(days=7))
        msg, kb = _list_due(from_str, to_str)
        bot.edit_message_text(msg, c.message.chat.id, c.message.message_id, reply_markup=kb)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data == "py:debts")
    def py_debts(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        # list top remaining for all enabled postpay
        rows = conn.execute(
            "SELECT pp.*, s.fio, s.offer_amount FROM student_postpay pp JOIN students s ON s.id=pp.student_id "
            "WHERE s.archived=0 AND pp.enabled=1"
        ).fetchall()
        items=[]
        for r in rows:
            sid=int(r["student_id"])
            total=post_total(r["offer_amount"], r["total_percent"])
            if total is None:
                continue
            paid=repo_payments.sum_payments(conn, sid, "postpay")
            rem=max(0,total-paid)
            items.append((rem, sid, r["fio"]))
        items.sort(reverse=True)
        lines=[]
        kb=InlineKeyboardMarkup()
        for rem, sid, fio in items[:12]:
            lines.append(f"• <b>{fio}</b> — осталось {money(rem)}")
            kb.row(InlineKeyboardButton("Открыть", callback_data=f"st:open:{sid}"),
                   InlineKeyboardButton("Внести", callback_data=f"py:add_for:{sid}"))
        kb.row(InlineKeyboardButton("⬅️ Назад", callback_data="m:payments"))
        bot.edit_message_text("Долги по постоплате:\n" + "\n".join(lines) if lines else "Нет активных долгов.",
                              c.message.chat.id, c.message.message_id, reply_markup=kb)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data == "py:add")
    def py_add(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        repo_states.set_state(conn, c.from_user.id, "PY_FIND_STUDENT", {}, tz)
        bot.send_message(c.message.chat.id, "Введи часть ФИО или @username ученика:")
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("py:add_for:"))
    def py_add_for(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        sid=int(c.data.split(":")[2])
        data={"student_id": sid}
        repo_states.set_state(conn, c.from_user.id, "PY_PICK_TYPE", data, tz)
        _ask_type(c.message.chat.id, sid)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("st:pay:"))
    def st_payments(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        sid=int(c.data.split(":")[2])
        s=repo_students.get_student(conn, sid)
        if not s:
            bot.answer_callback_query(c.id, "Не найдено"); return
        pre=repo_payments.sum_payments(conn, sid, "prepay")
        post=repo_payments.sum_payments(conn, sid, "postpay")
        pp=repo_postpay.get(conn, sid)
        total = post_total(s["offer_amount"], pp["total_percent"]) if pp else None
        msg = f"<b>Платежи — {s['fio']}</b>\nПредоплата: <b>{money(pre)}</b>\nПостоплата: <b>{money(post)}</b>"
        if total is not None:
            msg += f"\nПостоплата всего: <b>{money(total)}</b>\nОсталось: <b>{money(max(0,total-post))}</b>"
        rows=repo_payments.list_payments(conn, sid, limit=10)
        if rows:
            msg += "\n\n<b>Последние платежи</b>"
            for r in rows:
                msg += f"\n• {r['pay_date']} — {r['pay_type']} — {money(r['amount'])}"
        kb=InlineKeyboardMarkup()
        kb.row(InlineKeyboardButton("➕ Внести платёж", callback_data=f"py:add_for:{sid}"))
        kb.row(InlineKeyboardButton("⬅️ Назад", callback_data=f"st:open:{sid}"))
        bot.edit_message_text(msg, c.message.chat.id, c.message.message_id, reply_markup=kb)
        bot.answer_callback_query(c.id)

    def _ask_type(chat_id: int, sid: int):
        kb=InlineKeyboardMarkup()
        kb.row(InlineKeyboardButton("Предоплата", callback_data="py:type:prepay"),
               InlineKeyboardButton("Постоплата", callback_data="py:type:postpay"))
        kb.row(InlineKeyboardButton("Отмена", callback_data=f"st:open:{sid}"))
        bot.send_message(chat_id, "Тип платежа:", reply_markup=kb)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("py:type:"))
    def py_type(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        st, data = repo_states.get_state(conn, c.from_user.id)
        if st != "PY_PICK_TYPE":
            bot.answer_callback_query(c.id); return
        pay_type=c.data.split(":")[2]
        data["pay_type"]=pay_type
        repo_states.set_state(conn, c.from_user.id, "PY_AMOUNT", data, tz)
        sid=int(data["student_id"])
        # suggest amount
        if pay_type=="postpay":
            s=repo_students.get_student(conn, sid)
            pp=repo_postpay.get(conn, sid)
            rec=None
            if s and pp:
                rec=recommended_payment(s["offer_amount"], pp["schedule_type"], pp["per_period_value"])
            if rec:
                kb=InlineKeyboardMarkup()
                kb.row(InlineKeyboardButton(f"Внести {money(rec)}", callback_data=f"py:amt:{rec}"))
                kb.row(InlineKeyboardButton("Ввести вручную", callback_data="py:amt_custom"))
                kb.row(InlineKeyboardButton("Отмена", callback_data=f"st:open:{sid}"))
                bot.send_message(c.message.chat.id, "Сумма:", reply_markup=kb)
            else:
                bot.send_message(c.message.chat.id, "Введи сумму (руб):")
        else:
            bot.send_message(c.message.chat.id, "Введи сумму (руб):")
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("py:amt:") or c.data=="py:amt_custom")
    def py_amt_pick(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        st, data = repo_states.get_state(conn, c.from_user.id)
        if st != "PY_AMOUNT":
            bot.answer_callback_query(c.id); return
        if c.data=="py:amt_custom":
            repo_states.set_state(conn, c.from_user.id, "PY_AMOUNT_MANUAL", data, tz)
            bot.send_message(c.message.chat.id, "Введи сумму (руб):")
            bot.answer_callback_query(c.id); return
        amt=int(c.data.split(":")[2])
        data["amount"]=amt
        _ask_date(c.message.chat.id, c.from_user.id, data)
        bot.answer_callback_query(c.id)

    def _ask_date(chat_id: int, user_id: int, data: dict):
        repo_states.set_state(conn, user_id, "PY_DATE", data, tz)
        today_str = format_date_ddmmyyyy(now(tz).date())
        kb=InlineKeyboardMarkup()
        kb.row(InlineKeyboardButton(f"Сегодня ({today_str})", callback_data="py:date_today"),
               InlineKeyboardButton("Ввести дату", callback_data="py:date_manual"))
        sid=int(data["student_id"])
        kb.row(InlineKeyboardButton("Отмена", callback_data=f"st:open:{sid}"))
        bot.send_message(chat_id, "Дата платежа:", reply_markup=kb)

    @bot.callback_query_handler(func=lambda c: c.data in ("py:date_today","py:date_manual"))
    def py_date_pick(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        st, data = repo_states.get_state(conn, c.from_user.id)
        if st != "PY_DATE":
            bot.answer_callback_query(c.id); return
        if c.data=="py:date_manual":
            repo_states.set_state(conn, c.from_user.id, "PY_DATE_MANUAL", data, tz)
            bot.send_message(c.message.chat.id, "Введи дату: дд.мм (год сам) или дд.мм.гггг")
            bot.answer_callback_query(c.id); return
        data["pay_date"]=format_date_ddmmyyyy(now(tz).date())
        _save_payment(c.message.chat.id, c.from_user.id, data)
        bot.answer_callback_query(c.id)

    @bot.message_handler(func=lambda m: repo_states.get_state(conn, m.from_user.id)[0] in ("PY_FIND_STUDENT","PY_AMOUNT","PY_AMOUNT_MANUAL","PY_DATE_MANUAL"), content_types=["text"])
    def py_text(m: Message):
        if not is_admin(ctx, m.from_user.id):
            return
        st, data = repo_states.get_state(conn, m.from_user.id)
        if st == "PY_FIND_STUDENT":
            rows=repo_students.search_students(conn, m.text, archived=False, limit=8)
            if not rows:
                bot.send_message(m.chat.id, "Не нашёл. Попробуй ещё раз:"); return
            kb=InlineKeyboardMarkup()
            for r in rows:
                kb.row(InlineKeyboardButton(r["fio"][:28], callback_data=f"py:pick_student:{r['id']}"))
            kb.row(InlineKeyboardButton("Отмена", callback_data="m:payments"))
            bot.send_message(m.chat.id, "Выбери ученика:", reply_markup=kb)
            return
        if st == "PY_AMOUNT":
            # manual amount entry (no suggested)
            try:
                amt=int(m.text.strip().replace(" ", ""))
            except Exception:
                bot.send_message(m.chat.id, "Нужно число."); return
            data["amount"]=amt
            _ask_date(m.chat.id, m.from_user.id, data)
            return
        if st == "PY_AMOUNT_MANUAL":
            try:
                amt=int(m.text.strip().replace(" ", ""))
            except Exception:
                bot.send_message(m.chat.id, "Нужно число."); return
            data["amount"]=amt
            _ask_date(m.chat.id, m.from_user.id, data)
            return
        if st == "PY_DATE_MANUAL":
            d=parse_date_ddmm_past(m.text.strip(), tz)
            if not d:
                bot.send_message(m.chat.id, "Формат: дд.мм (год сам) или дд.мм.гггг"); return
            data["pay_date"]=format_date_ddmmyyyy(d)
            _save_payment(m.chat.id, m.from_user.id, data)
            return

    @bot.callback_query_handler(func=lambda c: c.data.startswith("py:pick_student:"))
    def py_pick_student(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        st, data = repo_states.get_state(conn, c.from_user.id)
        if st != "PY_FIND_STUDENT":
            bot.answer_callback_query(c.id); return
        sid=int(c.data.split(":")[2])
        data={"student_id": sid}
        repo_states.set_state(conn, c.from_user.id, "PY_PICK_TYPE", data, tz)
        _ask_type(c.message.chat.id, sid)
        bot.answer_callback_query(c.id)

    def _save_payment(chat_id: int, user_id: int, data: dict):
        sid=int(data["student_id"])
        pay_type=data.get("pay_type","postpay")
        amt=int(data["amount"])
        pay_date=data.get("pay_date") or format_date_ddmmyyyy(now(tz).date())
        repo_payments.add_payment(conn, sid, pay_type, amt, pay_date, tz)
        # update postpay schedule if needed
        if pay_type=="postpay":
            pp=repo_postpay.get(conn, sid)
            if pp and pp["enabled"]:
                new_due = next_due_after_payment(pp["next_due_date"], pay_date, pp["schedule_type"], pp["per_period_value"])
                repo_postpay.upsert(conn, sid, next_due_date=new_due, student_next_notify_date=new_due, enabled=1)
                # auto-disable if fully paid
                s=repo_students.get_student(conn, sid)
                total=post_total(s["offer_amount"], pp["total_percent"]) if s else None
                if total is not None:
                    paid=repo_payments.sum_payments(conn, sid, "postpay")
                    if paid >= total:
                        repo_postpay.disable(conn, sid)
        repo_states.clear_state(conn, user_id, tz)
        # stop any pending payment alerts for student immediately after saving payment
        try:
            s = repo_students.get_student(conn, sid)
            schat = int(s["owner_chat_id"]) if s and s["owner_chat_id"] else None
        except Exception:
            schat = None
        if schat:
            conn.execute(
                "UPDATE alerts SET status='SEEN', updated_at=? WHERE status='PENDING' AND alert_type='PAYMENT' AND related_table='students' AND related_id=? AND chat_id=?",
                (iso(now(tz)), sid, schat),
            )
            conn.commit()
        bot.send_message(chat_id, "✅ Платёж сохранён.", reply_markup=payments_menu_kb())
