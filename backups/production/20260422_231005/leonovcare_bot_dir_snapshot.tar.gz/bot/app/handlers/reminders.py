from __future__ import annotations
import sqlite3
import datetime as dt

from telebot import TeleBot
from telebot.types import CallbackQuery, Message, InlineKeyboardMarkup, InlineKeyboardButton

from app.handlers.common import is_admin
from app.db import repo_states, repo_students, repo_reminders, repo_stage_rules
from app.services.timeutils import now, iso, start_of_day, end_of_day, parse_time_hhmm, parse_date_ddmm_future, tzinfo
from app.ui.keyboards import reminders_menu_kb, pick_list_kb, reminder_card_kb, stage_rule_card_kb, weekday_picker_kb


def _fmt_who(r: sqlite3.Row) -> str:
    if r["student_id"]:
        fio = r.get("fio") if hasattr(r, 'get') else None
        return fio or f"ученик #{r['student_id']}"
    return "персонально"


def _reminder_card_text(r: sqlite3.Row) -> str:
    who = f"Ученик: <b>{r['student_id']}</b>" if r["student_id"] else "Персонально"
    days = r.get("days_of_week") if hasattr(r, 'get') else r["days_of_week"]
    days_str = days or "—"
    return (
        f"<b>Напоминалка #{r['id']}</b>\n"
        f"{who}\n"
        f"Заголовок: <b>{r['title']}</b>\n"
        f"Комментарий: {r['note'] or '—'}\n"
        f"Частота: <b>{r['freq_type']}</b> ({r['freq_value']})\n"
        f"Дни недели: <b>{days_str}</b>\n"
        f"Время: <b>{r['time_of_day']}</b>\n"
        f"Следующее: <b>{r['next_run_at']}</b>\n"
        f"Статус: <b>{'вкл' if r['enabled'] else 'выкл'}</b>"
    )


def _rule_card_text(stage: sqlite3.Row, rule: sqlite3.Row) -> str:
    days_str = rule["days_of_week"] or "—"
    return (
        f"<b>Правило этапа</b>\n"
        f"Этап: <b>{stage['name']}</b>\n\n"
        f"Заголовок: <b>{rule['title']}</b>\n"
        f"Текст: {rule['note']}\n\n"
        f"Частота: <b>{rule['freq_type']}</b> ({rule['freq_value']})\n"
        f"Дни недели: <b>{days_str}</b>\n"
        f"Время: <b>{rule['time_of_day']}</b>\n"
        f"Статус: <b>{'вкл' if rule['enabled'] else 'выкл'}</b>"
    )


def _next_run_once(tz: str, date_str: str, time_str: str) -> str | None:
    d = parse_date_ddmm_future(date_str, tz)
    t = parse_time_hhmm(time_str)
    if not d or not t:
        return None
    dt_obj = dt.datetime.combine(d, t, tzinfo=tzinfo(tz)).replace(microsecond=0)
    return iso(dt_obj)


def init(bot: TeleBot, ctx: dict) -> None:
    conn: sqlite3.Connection = ctx["conn"]
    tz = ctx["cfg"].TZ

    # =====================
    # MAIN
    # =====================

    @bot.callback_query_handler(func=lambda c: c.data == "m:reminders")
    def open_menu(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        bot.edit_message_text("<b>Напоминалки</b>", c.message.chat.id, c.message.message_id, reply_markup=reminders_menu_kb())
        bot.answer_callback_query(c.id)

    # =====================
    # TODAY
    # =====================

    @bot.callback_query_handler(func=lambda c: c.data.startswith("rm:today"))
    def rm_today(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        n = now(tz)
        ds = start_of_day(n.date(), tz)
        de = end_of_day(n.date(), tz)
        rows = repo_reminders.list_due_today(conn, iso(ds), iso(de))
        if not rows:
            bot.edit_message_text("Сегодня нет напоминалок по расписанию.", c.message.chat.id, c.message.message_id,
                                  reply_markup=reminders_menu_kb())
            bot.answer_callback_query(c.id); return

        kb = InlineKeyboardMarkup()
        lines = []
        for r in rows[:10]:
            who = (r["fio"] or "Персонально")
            when = r["next_run_at"].replace("T", " ")
            lines.append(f"• <b>{r['title']}</b> — {who} — {when}")
            kb.row(
                InlineKeyboardButton(f"Открыть #{r['id']}", callback_data=f"rm:open:{r['id']}"),
                InlineKeyboardButton("👤", callback_data=f"st:open:{r['student_id']}" if r["student_id"] else "rm:open:"+str(r['id']))
            )
        kb.row(InlineKeyboardButton("⬅️ Назад", callback_data="m:reminders"))
        bot.edit_message_text("<b>Напоминалки на сегодня</b>\n\n" + "\n".join(lines), c.message.chat.id, c.message.message_id, reply_markup=kb)
        bot.answer_callback_query(c.id)

    # =====================
    # LIST / OPEN
    # =====================

    @bot.callback_query_handler(func=lambda c: c.data.startswith("rm:list"))
    def rm_list(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        parts = c.data.split(":")
        page = int(parts[2]) if len(parts) >= 3 else 0
        page = max(0, page)
        limit = 12
        offset = page * limit
        rows = repo_reminders.list_all(conn, limit=limit, offset=offset)
        total = repo_reminders.count_all(conn)
        if not rows:
            bot.edit_message_text("Пока нет напоминалок.", c.message.chat.id, c.message.message_id,
                                  reply_markup=reminders_menu_kb())
            bot.answer_callback_query(c.id); return

        kb = InlineKeyboardMarkup()
        lines = []
        for r in rows:
            who = "персонально"
            if r["student_id"]:
                who = r["fio"] or (r["username"] or "ученик")
            when = r["next_run_at"].replace("T", " ")
            state = "on" if r["enabled"] else "off"
            lines.append(f"• <b>#{r['id']}</b> {r['title']} — {who} — {when} ({state})")
            kb.row(InlineKeyboardButton(f"Открыть #{r['id']}", callback_data=f"rm:open:{r['id']}"))

        nav = []
        if page > 0:
            nav.append(InlineKeyboardButton("⬅️", callback_data=f"rm:list:{page-1}"))
        if offset + limit < total:
            nav.append(InlineKeyboardButton("➡️", callback_data=f"rm:list:{page+1}"))
        if nav:
            kb.row(*nav)
        kb.row(InlineKeyboardButton("⬅️ Назад", callback_data="m:reminders"))

        bot.edit_message_text("<b>Все напоминалки</b>\n\n" + "\n".join(lines), c.message.chat.id, c.message.message_id, reply_markup=kb)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("rm:open:"))
    def rm_open(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        rid = int(c.data.split(":")[2])
        r = repo_reminders.get(conn, rid)
        if not r:
            bot.answer_callback_query(c.id, "Не найдено"); return
        bot.edit_message_text(_reminder_card_text(r), c.message.chat.id, c.message.message_id,
                              reply_markup=reminder_card_kb(rid, back_cb="rm:list", student_id=r["student_id"]))
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("rm:toggle:"))
    def rm_toggle(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        rid = int(c.data.split(":")[2])
        r = repo_reminders.get(conn, rid)
        if not r:
            bot.answer_callback_query(c.id, "Не найдено"); return
        new = 0 if r["enabled"] else 1
        repo_reminders.update(conn, rid, tz, enabled=new)
        r2 = repo_reminders.get(conn, rid)
        bot.edit_message_text(_reminder_card_text(r2), c.message.chat.id, c.message.message_id,
                              reply_markup=reminder_card_kb(rid, back_cb="rm:list", student_id=r2["student_id"]))
        bot.answer_callback_query(c.id, "Ок")

    @bot.callback_query_handler(func=lambda c: c.data.startswith("rm:del:"))
    def rm_del(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        rid = int(c.data.split(":")[2])
        kb=InlineKeyboardMarkup()
        kb.row(InlineKeyboardButton("Да, удалить", callback_data=f"rm:delok:{rid}"))
        kb.row(InlineKeyboardButton("Отмена", callback_data=f"rm:open:{rid}"))
        bot.edit_message_text(f"Удалить напоминалку #{rid}?", c.message.chat.id, c.message.message_id, reply_markup=kb)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("rm:delok:"))
    def rm_del_ok(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        rid = int(c.data.split(":")[2])
        repo_reminders.delete(conn, rid)
        bot.edit_message_text("Удалено.", c.message.chat.id, c.message.message_id, reply_markup=reminders_menu_kb())
        bot.answer_callback_query(c.id)

    # =====================
    # OPEN FROM STUDENT CARD
    # =====================

    @bot.callback_query_handler(func=lambda c: c.data.startswith("st:rem:"))
    def st_reminders(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        sid = int(c.data.split(":")[2])
        s = repo_students.get_student(conn, sid)
        if not s:
            bot.answer_callback_query(c.id, "Не найдено"); return
        rows = repo_reminders.list_by_student(conn, sid)
        kb=InlineKeyboardMarkup()
        lines=[f"<b>Напоминалки ученика</b>\n{s['fio']}\n"]
        if not rows:
            lines.append("Пока пусто.")
        else:
            for r in rows[:12]:
                when = r["next_run_at"].replace("T", " ")
                lines.append(f"• <b>#{r['id']}</b> {r['title']} — {when} ({'on' if r['enabled'] else 'off'})")
                kb.row(InlineKeyboardButton(f"Открыть #{r['id']}", callback_data=f"rm:open:{r['id']}"))
        kb.row(InlineKeyboardButton("➕ Добавить напоминалку", callback_data=f"rm:add_student:{sid}"))
        kb.row(InlineKeyboardButton("⬅️ Назад", callback_data=f"st:open:{sid}"))
        bot.edit_message_text("\n".join(lines), c.message.chat.id, c.message.message_id, reply_markup=kb)
        bot.answer_callback_query(c.id)

    # =====================
    # ADD REMINDER WIZARD
    # =====================

    @bot.callback_query_handler(func=lambda c: c.data == "rm:add")
    def rm_add(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        items=[("К ученику", "rm:add_kind:student"), ("Персональная", "rm:add_kind:personal")]
        bot.edit_message_text("Какую напоминалку добавить?", c.message.chat.id, c.message.message_id,
                              reply_markup=pick_list_kb(items, "m:reminders"))
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("rm:add_student:"))
    def rm_add_student(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        sid=int(c.data.split(":")[2])
        repo_states.set_state(conn, c.from_user.id, "RM_ADD", {"kind": "student", "student_id": sid}, tz)
        bot.send_message(c.message.chat.id, "Заголовок напоминалки:")
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("rm:add_kind:"))
    def rm_add_kind(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        kind=c.data.split(":")[2]
        if kind=="personal":
            repo_states.set_state(conn, c.from_user.id, "RM_ADD", {"kind": "personal", "student_id": None}, tz)
            bot.send_message(c.message.chat.id, "Заголовок напоминалки:")
            bot.answer_callback_query(c.id); return

        # kind student -> choose student
        repo_states.set_state(conn, c.from_user.id, "RM_PICK_STUDENT", {}, tz)
        bot.send_message(c.message.chat.id, "Введи @username или часть ФИО ученика для поиска:")
        bot.answer_callback_query(c.id)

    def _rm_state_active(m: Message) -> bool:
        if not m.from_user:
            return False
        st, _ = repo_states.get_state(conn, m.from_user.id)
        return st in {"RM_PICK_STUDENT", "RM_ADD", "RM_SET_EVERY_N", "RM_SET_ONCE_DATE", "RM_EDIT_TEXT", "SR_EDIT_TEXT", "RM_WEEKLY_DAYS"}

    @bot.message_handler(func=_rm_state_active)
    def _rm_text_router(m: Message):
        if not m.from_user:
            return
        if not is_admin(ctx, m.from_user.id):
            return

        st, data = repo_states.get_state(conn, m.from_user.id)
        data = data or {}

        # pick student by search
        if st == "RM_PICK_STUDENT":
            q = (m.text or "").strip()
            rows = repo_students.search_students(conn, q, archived=False, limit=10)
            if not rows:
                bot.reply_to(m, "Не нашёл. Введи другую строку:")
                return
            items=[]
            for s in rows:
                items.append((f"{s['fio']} (@{s['username'] or '—'})", f"rm:pick_student:{s['id']}"))
            bot.send_message(m.chat.id, "Выбери ученика:", reply_markup=pick_list_kb(items, "m:reminders"))
            return

        if st == "RM_ADD":
            # step1: title
            if "title" not in data:
                data["title"] = (m.text or "").strip()
                repo_states.set_state(conn, m.from_user.id, "RM_ADD", data, tz)
                bot.reply_to(m, "Комментарий (можно '-'):")
                return

            # step2: note
            if "note" not in data:
                note = (m.text or "").strip()
                data["note"] = None if note in ("-", "—", "") else note
                repo_states.set_state(conn, m.from_user.id, "RM_ADD", data, tz)
                bot.reply_to(m, "Время HH:MM (например 12:00):")
                return

            # step3: time
            if "time_of_day" not in data:
                t = parse_time_hhmm((m.text or "").strip())
                if not t:
                    bot.reply_to(m, "Неверный формат. Пример: 12:00")
                    return
                data["time_of_day"] = f"{t.hour:02d}:{t.minute:02d}"
                repo_states.set_state(conn, m.from_user.id, "RM_ADD", data, tz)
                items=[
                    ("Каждый день", "rm:set_freq:daily"),
                    ("Раз в N дней", "rm:set_freq:every_n_days"),
                    ("Раз в неделю", "rm:set_freq:weekly"),
                    ("Один раз (дата)", "rm:set_freq:once"),
                ]
                bot.send_message(m.chat.id, "Частота:", reply_markup=pick_list_kb(items, "m:reminders"))
                return

        if st == "RM_SET_EVERY_N":
            try:
                n = int((m.text or "").strip())
                n = max(1, n)
            except Exception:
                bot.reply_to(m, "Введи число (например 3).")
                return
            data["freq_type"] = "every_n_days"
            data["freq_value"] = n
            repo_states.set_state(conn, m.from_user.id, "RM_ADD", data, tz)
            bot.reply_to(m, "Ок. Готово. Нажми '✅ Создать' ниже.")
            # show finish buttons
            kb=InlineKeyboardMarkup()
            kb.row(InlineKeyboardButton("✅ Создать", callback_data="rm:create"))
            kb.row(InlineKeyboardButton("Отмена", callback_data="m:reminders"))
            bot.send_message(m.chat.id, "Создать напоминалку?", reply_markup=kb)
            return

        if st == "RM_SET_ONCE_DATE":
            ds=(m.text or "").strip()
            if not parse_date_ddmm_future(ds, tz):
                bot.reply_to(m, "Дата в формате dd.mm (год сам) или dd.mm.yyyy, например 18.02")
                return
            data["once_date"] = ds
            repo_states.set_state(conn, m.from_user.id, "RM_ADD", data, tz)
            kb=InlineKeyboardMarkup()
            kb.row(InlineKeyboardButton("✅ Создать", callback_data="rm:create"))
            kb.row(InlineKeyboardButton("Отмена", callback_data="m:reminders"))
            bot.send_message(m.chat.id, "Создать напоминалку?", reply_markup=kb)
            return

        if st == "RM_EDIT_TEXT":
            rid = int(data["rid"])
            field = data["field"]
            val = (m.text or "").strip()
            if field == "title":
                repo_reminders.update(conn, rid, tz, title=val)
            elif field == "note":
                repo_reminders.update(conn, rid, tz, note=None if val in ("-","—","") else val)
            elif field == "time":
                t=parse_time_hhmm(val)
                if not t:
                    bot.reply_to(m, "Неверный формат. Пример: 12:00")
                    return
                tod=f"{t.hour:02d}:{t.minute:02d}"
                repo_reminders.update(conn, rid, tz, time_of_day=tod)
            elif field == "every_n":
                try:
                    n=int(val); n=max(1,n)
                except Exception:
                    bot.reply_to(m, "Введи число")
                    return
                repo_reminders.update(conn, rid, tz, freq_type="every_n_days", freq_value=n)
            elif field == "once_date":
                if not parse_date_ddmm_future(val, tz):
                    bot.reply_to(m, "Дата в формате dd.mm (год сам) или dd.mm.yyyy")
                    return
                r=repo_reminders.get(conn, rid)
                nxt=_next_run_once(tz, val, r["time_of_day"])
                if not nxt:
                    bot.reply_to(m, "Не получилось распознать дату")
                    return
                repo_reminders.update(conn, rid, tz, freq_type="once", freq_value=1, next_run_at=nxt)

            repo_states.clear_state(conn, m.from_user.id, tz)
            r2=repo_reminders.get(conn, rid)
            bot.send_message(m.chat.id, "Ок.")
            bot.send_message(m.chat.id, _reminder_card_text(r2), reply_markup=reminder_card_kb(rid, back_cb="rm:list", student_id=r2["student_id"]))
            return

        if st == "SR_EDIT_TEXT":
            stage_id=int(data["stage_id"])
            field=data["field"]
            val=(m.text or "").strip()
            rule=repo_stage_rules.ensure_rule(conn, tz, stage_id)
            enabled=int(rule["enabled"] or 0)
            title=str(rule["title"])
            note=str(rule["note"])
            freq_type=str(rule["freq_type"])
            freq_value=int(rule["freq_value"])
            days=rule["days_of_week"]
            time=str(rule["time_of_day"])
            if field=="title":
                title=val
            elif field=="note":
                note=val
            elif field=="time":
                t=parse_time_hhmm(val)
                if not t:
                    bot.reply_to(m, "Неверный формат времени. Пример: 12:00")
                    return
                time=f"{t.hour:02d}:{t.minute:02d}"
            elif field=="every_n":
                try:
                    n=int(val); n=max(1,n)
                except Exception:
                    bot.reply_to(m, "Введи число")
                    return
                freq_type="every_n_days"; freq_value=n

            repo_stage_rules.upsert_rule(conn, tz, stage_id, enabled, title, note, freq_type, freq_value, days, time)
            repo_states.clear_state(conn, m.from_user.id, tz)
            stage = conn.execute("SELECT id,name FROM stages WHERE id=?", (stage_id,)).fetchone()
            rule2 = repo_stage_rules.ensure_rule(conn, tz, stage_id)
            bot.send_message(m.chat.id, "Ок.")
            bot.send_message(m.chat.id, _rule_card_text(stage, rule2), reply_markup=stage_rule_card_kb(stage_id, back_cb="rm:rules"))
            return

    @bot.callback_query_handler(func=lambda c: c.data.startswith("rm:pick_student:"))
    def rm_pick_student(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        sid=int(c.data.split(":")[2])
        repo_states.set_state(conn, c.from_user.id, "RM_ADD", {"kind": "student", "student_id": sid}, tz)
        bot.send_message(c.message.chat.id, "Заголовок напоминалки:")
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("rm:set_freq:"))
    def rm_set_freq(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        ft=c.data.split(":")[2]
        st, data = repo_states.get_state(conn, c.from_user.id)
        if st != "RM_ADD":
            bot.answer_callback_query(c.id); return
        data = data or {}
        if ft=="daily":
            data["freq_type"]="daily"; data["freq_value"]=1; data["days_of_week"]=None
            repo_states.set_state(conn, c.from_user.id, "RM_ADD", data, tz)
            kb=InlineKeyboardMarkup(); kb.row(InlineKeyboardButton("✅ Создать", callback_data="rm:create")); kb.row(InlineKeyboardButton("Отмена", callback_data="m:reminders"))
            bot.send_message(c.message.chat.id, "Создать напоминалку?", reply_markup=kb)
            bot.answer_callback_query(c.id); return
        if ft=="every_n_days":
            repo_states.set_state(conn, c.from_user.id, "RM_SET_EVERY_N", data, tz)
            bot.send_message(c.message.chat.id, "Раз в сколько дней? (число)")
            bot.answer_callback_query(c.id); return
        if ft=="weekly":
            data["freq_type"]="weekly"; data["freq_value"]=1
            repo_states.set_state(conn, c.from_user.id, "RM_WEEKLY_DAYS", data, tz)
            # use temp selected in data
            selected=set()
            bot.send_message(c.message.chat.id, "Выбери дни недели (можно несколько):", reply_markup=weekday_picker_kb(prefix="rmwd", selected=selected, done_cb="rmwd:done", back_cb="m:reminders"))
            bot.answer_callback_query(c.id); return
        if ft=="once":
            data["freq_type"]="once"; data["freq_value"]=1
            repo_states.set_state(conn, c.from_user.id, "RM_SET_ONCE_DATE", data, tz)
            bot.send_message(c.message.chat.id, "Введи дату dd.mm (год сам) или dd.mm.yyyy (например 18.02):")
            bot.answer_callback_query(c.id); return

    @bot.callback_query_handler(func=lambda c: c.data.startswith("rmwd:"))
    def rm_weekday_picker(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        st, data = repo_states.get_state(conn, c.from_user.id)
        if st != "RM_WEEKLY_DAYS":
            bot.answer_callback_query(c.id); return
        data=data or {}
        if c.data == "rmwd:done":
            days = sorted(set(data.get("days", [])))
            data["days_of_week"] = ",".join(str(d) for d in days) if days else None
            repo_states.set_state(conn, c.from_user.id, "RM_ADD", data, tz)
            kb=InlineKeyboardMarkup(); kb.row(InlineKeyboardButton("✅ Создать", callback_data="rm:create")); kb.row(InlineKeyboardButton("Отмена", callback_data="m:reminders"))
            bot.send_message(c.message.chat.id, "Создать напоминалку?", reply_markup=kb)
            bot.answer_callback_query(c.id); return

        # toggle day
        _, day = c.data.split(":")
        try:
            d=int(day)
        except Exception:
            bot.answer_callback_query(c.id); return
        days=set(data.get("days", []))
        if d in days:
            days.remove(d)
        else:
            if 1 <= d <= 7:
                days.add(d)
        data["days"]=sorted(days)
        repo_states.set_state(conn, c.from_user.id, "RM_WEEKLY_DAYS", data, tz)
        bot.edit_message_reply_markup(c.message.chat.id, c.message.message_id, reply_markup=weekday_picker_kb(prefix="rmwd", selected=set(days), done_cb="rmwd:done", back_cb="m:reminders"))
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data == "rm:create")
    def rm_create(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        st, data = repo_states.get_state(conn, c.from_user.id)
        if st != "RM_ADD":
            bot.answer_callback_query(c.id); return
        data=data or {}
        title=data.get("title")
        if not title:
            bot.answer_callback_query(c.id, "Нет заголовка"); return

        student_id=data.get("student_id")
        note=data.get("note")
        time_of_day=data.get("time_of_day", "12:00")
        freq_type=data.get("freq_type", "daily")
        freq_value=int(data.get("freq_value") or 1)
        days_of_week=data.get("days_of_week")

        if freq_type == "once":
            ds=data.get("once_date")
            nxt=_next_run_once(tz, ds, time_of_day) if ds else None
            if not nxt:
                bot.answer_callback_query(c.id, "Нужна дата")
                return
        else:
            nxt = repo_reminders.first_run_from_now(tz, time_of_day)

        rid = repo_reminders.create(conn, tz, int(student_id) if student_id else None, title, note, freq_type, freq_value,
                                   time_of_day, nxt, days_of_week=days_of_week, enabled=1)
        repo_states.clear_state(conn, c.from_user.id, tz)
        bot.edit_message_text(f"✅ Создано. #{rid}", c.message.chat.id, c.message.message_id, reply_markup=reminders_menu_kb())
        bot.answer_callback_query(c.id)

    # =====================
    # EDIT REMINDER
    # =====================

    @bot.callback_query_handler(func=lambda c: c.data.startswith("rm:edit:"))
    def rm_edit(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        _, _, rid, field = c.data.split(":")
        rid=int(rid)
        r=repo_reminders.get(conn, rid)
        if not r:
            bot.answer_callback_query(c.id, "Не найдено"); return
        if field == "freq":
            items=[
                ("Каждый день", f"rm:freqset:{rid}:daily"),
                ("Раз в N дней", f"rm:freqset:{rid}:every_n_days"),
                ("Раз в неделю", f"rm:freqset:{rid}:weekly"),
                ("Один раз (дата)", f"rm:freqset:{rid}:once"),
            ]
            bot.edit_message_text("Частота:", c.message.chat.id, c.message.message_id, reply_markup=pick_list_kb(items, f"rm:open:{rid}"))
            bot.answer_callback_query(c.id); return

        # title/note/time
        repo_states.set_state(conn, c.from_user.id, "RM_EDIT_TEXT", {"rid": rid, "field": field}, tz)
        prompts={
            "title": "Новый заголовок:",
            "note": "Новый комментарий (или '-' чтобы очистить):",
            "time": "Новое время HH:MM:",
        }
        bot.send_message(c.message.chat.id, prompts.get(field, "Введи значение:"))
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("rm:freqset:"))
    def rm_freq_set(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        _, _, rid, ft = c.data.split(":")
        rid=int(rid)
        r=repo_reminders.get(conn, rid)
        if not r:
            bot.answer_callback_query(c.id, "Не найдено"); return

        if ft == "daily":
            repo_reminders.update(conn, rid, tz, freq_type="daily", freq_value=1, days_of_week=None)
            bot.edit_message_text(_reminder_card_text(repo_reminders.get(conn, rid)), c.message.chat.id, c.message.message_id,
                                  reply_markup=reminder_card_kb(rid, back_cb="rm:list", student_id=r["student_id"]))
            bot.answer_callback_query(c.id, "Ок"); return

        if ft == "every_n_days":
            repo_states.set_state(conn, c.from_user.id, "RM_EDIT_TEXT", {"rid": rid, "field": "every_n"}, tz)
            bot.send_message(c.message.chat.id, "Раз в сколько дней? (число)")
            bot.answer_callback_query(c.id); return

        if ft == "weekly":
            # toggle days directly in DB
            cur_days = set()
            if r["days_of_week"]:
                for p in str(r["days_of_week"]).split(","):
                    try:
                        cur_days.add(int(p.strip()))
                    except Exception:
                        pass
            bot.edit_message_text("Выбери дни недели (можно несколько):", c.message.chat.id, c.message.message_id,
                                  reply_markup=weekday_picker_kb(prefix=f"rmwds:{rid}", selected=cur_days, done_cb=f"rmwds_done:{rid}", back_cb=f"rm:open:{rid}"))
            bot.answer_callback_query(c.id); return

        if ft == "once":
            repo_states.set_state(conn, c.from_user.id, "RM_EDIT_TEXT", {"rid": rid, "field": "once_date"}, tz)
            bot.send_message(c.message.chat.id, "Дата dd.mm.yyyy (после сработки напоминалка выключится):")
            bot.answer_callback_query(c.id); return

    @bot.callback_query_handler(func=lambda c: c.data.startswith("rmwds:"))
    def rm_weekly_days_toggle(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        # rmwds:<rid>:<day>
        _, rid, day = c.data.split(":")
        rid=int(rid)
        d=int(day)
        r=repo_reminders.get(conn, rid)
        cur=set()
        if r and r["days_of_week"]:
            for p in str(r["days_of_week"]).split(","):
                try:
                    cur.add(int(p.strip()))
                except Exception:
                    pass
        if d in cur:
            cur.remove(d)
        else:
            if 1 <= d <= 7:
                cur.add(d)
        days_str=",".join(str(x) for x in sorted(cur)) if cur else None
        repo_reminders.update(conn, rid, tz, freq_type="weekly", freq_value=1, days_of_week=days_str)
        bot.edit_message_reply_markup(c.message.chat.id, c.message.message_id,
                                      reply_markup=weekday_picker_kb(prefix=f"rmwds:{rid}", selected=cur, done_cb=f"rmwds_done:{rid}", back_cb=f"rm:open:{rid}"))
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("rmwds_done:"))
    def rm_weekly_days_done(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        rid=int(c.data.split(":")[1])
        r=repo_reminders.get(conn, rid)
        bot.edit_message_text(_reminder_card_text(r), c.message.chat.id, c.message.message_id,
                              reply_markup=reminder_card_kb(rid, back_cb="rm:list", student_id=r["student_id"]))
        bot.answer_callback_query(c.id)

    # =====================
    # STAGE RULES
    # =====================

    @bot.callback_query_handler(func=lambda c: c.data == "rm:rules")
    def rules_menu(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        stages = repo_stage_rules.list_stages(conn)
        items=[(s["name"], f"sr:open:{s['id']}") for s in stages]
        bot.edit_message_text("<b>Правила этапов</b>\nЭтап = группа напоминаний для новых учеников.",
                              c.message.chat.id, c.message.message_id,
                              reply_markup=pick_list_kb(items, "m:reminders"))
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("sr:open:"))
    def sr_open(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        stage_id=int(c.data.split(":")[2])
        stage = conn.execute("SELECT id,name FROM stages WHERE id=?", (stage_id,)).fetchone()
        rule = repo_stage_rules.ensure_rule(conn, tz, stage_id)
        bot.edit_message_text(_rule_card_text(stage, rule), c.message.chat.id, c.message.message_id,
                              reply_markup=stage_rule_card_kb(stage_id, back_cb="rm:rules"))
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("sr:toggle:"))
    def sr_toggle(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        stage_id=int(c.data.split(":")[2])
        rule=repo_stage_rules.ensure_rule(conn, tz, stage_id)
        new = 0 if rule["enabled"] else 1
        repo_stage_rules.upsert_rule(conn, tz, stage_id, new, rule["title"], rule["note"], rule["freq_type"], int(rule["freq_value"]), rule["days_of_week"], rule["time_of_day"])
        stage = conn.execute("SELECT id,name FROM stages WHERE id=?", (stage_id,)).fetchone()
        rule2 = repo_stage_rules.ensure_rule(conn, tz, stage_id)
        bot.edit_message_text(_rule_card_text(stage, rule2), c.message.chat.id, c.message.message_id,
                              reply_markup=stage_rule_card_kb(stage_id, back_cb="rm:rules"))
        bot.answer_callback_query(c.id, "Ок")

    @bot.callback_query_handler(func=lambda c: c.data.startswith("sr:apply:"))
    def sr_apply(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        stage_id=int(c.data.split(":")[2])
        cnt = repo_stage_rules.apply_rule_to_stage(conn, tz, stage_id)
        bot.answer_callback_query(c.id, f"Применил к {cnt}")

    @bot.callback_query_handler(func=lambda c: c.data.startswith("sr:edit:"))
    def sr_edit(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        _, _, stage_id, field = c.data.split(":")
        stage_id=int(stage_id)
        rule=repo_stage_rules.ensure_rule(conn, tz, stage_id)
        if field == "freq":
            items=[
                ("Каждый день", f"sr:freqset:{stage_id}:daily"),
                ("Раз в N дней", f"sr:freqset:{stage_id}:every_n_days"),
                ("Раз в неделю", f"sr:freqset:{stage_id}:weekly"),
            ]
            bot.edit_message_text("Частота правила:", c.message.chat.id, c.message.message_id,
                                  reply_markup=pick_list_kb(items, f"sr:open:{stage_id}"))
            bot.answer_callback_query(c.id); return

        repo_states.set_state(conn, c.from_user.id, "SR_EDIT_TEXT", {"stage_id": stage_id, "field": field}, tz)
        prompts={
            "title": "Новый заголовок:",
            "note": "Новый текст правила:",
            "time": "Новое время HH:MM:",
        }
        bot.send_message(c.message.chat.id, prompts.get(field, "Введи значение:"))
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("sr:freqset:"))
    def sr_freq_set(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        _, _, stage_id, ft = c.data.split(":")
        stage_id=int(stage_id)
        rule=repo_stage_rules.ensure_rule(conn, tz, stage_id)
        enabled=int(rule["enabled"])
        title=str(rule["title"])
        note=str(rule["note"])
        time=str(rule["time_of_day"])

        if ft == "daily":
            repo_stage_rules.upsert_rule(conn, tz, stage_id, enabled, title, note, "daily", 1, None, time)
            bot.answer_callback_query(c.id, "Ок")
            bot.edit_message_text(_rule_card_text(conn.execute("SELECT id,name FROM stages WHERE id=?", (stage_id,)).fetchone(), repo_stage_rules.ensure_rule(conn, tz, stage_id)),
                                  c.message.chat.id, c.message.message_id,
                                  reply_markup=stage_rule_card_kb(stage_id, back_cb="rm:rules"))
            return

        if ft == "every_n_days":
            repo_states.set_state(conn, c.from_user.id, "SR_EDIT_TEXT", {"stage_id": stage_id, "field": "every_n"}, tz)
            bot.send_message(c.message.chat.id, "Раз в сколько дней? (число)")
            bot.answer_callback_query(c.id); return

        if ft == "weekly":
            # day picker toggles days directly in DB
            cur=set()
            if rule["days_of_week"]:
                for p in str(rule["days_of_week"]).split(","):
                    try:
                        cur.add(int(p.strip()))
                    except Exception:
                        pass
            bot.edit_message_text("Выбери дни недели (можно несколько):", c.message.chat.id, c.message.message_id,
                                  reply_markup=weekday_picker_kb(prefix=f"srwds:{stage_id}", selected=cur, done_cb=f"srwds_done:{stage_id}", back_cb=f"sr:open:{stage_id}"))
            bot.answer_callback_query(c.id); return

    @bot.callback_query_handler(func=lambda c: c.data.startswith("srwds:"))
    def sr_weekly_days_toggle(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        _, stage_id, day = c.data.split(":")
        stage_id=int(stage_id)
        d=int(day)
        rule=repo_stage_rules.ensure_rule(conn, tz, stage_id)
        cur=set()
        if rule["days_of_week"]:
            for p in str(rule["days_of_week"]).split(","):
                try:
                    cur.add(int(p.strip()))
                except Exception:
                    pass
        if d in cur:
            cur.remove(d)
        else:
            if 1 <= d <= 7:
                cur.add(d)
        days_str=",".join(str(x) for x in sorted(cur)) if cur else None
        repo_stage_rules.upsert_rule(conn, tz, stage_id, int(rule["enabled"]), str(rule["title"]), str(rule["note"]), "weekly", 1, days_str, str(rule["time_of_day"]))
        bot.edit_message_reply_markup(c.message.chat.id, c.message.message_id,
                                      reply_markup=weekday_picker_kb(prefix=f"srwds:{stage_id}", selected=cur, done_cb=f"srwds_done:{stage_id}", back_cb=f"sr:open:{stage_id}"))
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("srwds_done:"))
    def sr_weekly_days_done(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        stage_id=int(c.data.split(":")[1])
        stage = conn.execute("SELECT id,name FROM stages WHERE id=?", (stage_id,)).fetchone()
        rule = repo_stage_rules.ensure_rule(conn, tz, stage_id)
        bot.edit_message_text(_rule_card_text(stage, rule), c.message.chat.id, c.message.message_id,
                              reply_markup=stage_rule_card_kb(stage_id, back_cb="rm:rules"))
        bot.answer_callback_query(c.id)
