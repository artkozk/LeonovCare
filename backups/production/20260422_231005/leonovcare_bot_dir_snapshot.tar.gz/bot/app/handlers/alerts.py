from __future__ import annotations
import sqlite3
import datetime as dt
from telebot import TeleBot
from telebot.types import CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton

from app.handlers.common import is_admin
from app.db import repo_alerts, repo_states, repo_students, repo_payments, repo_postpay, repo_events, repo_reminders
from app.services.timeutils import now, iso, parse_date_ddmmyyyy, format_date_ddmmyyyy
from app.services.postpay import post_total
from app.ui.formatters import money
from app.ui.keyboards import alert_kb, student_card_kb

def _student_card_text(conn: sqlite3.Connection, sid: int, tz: str) -> str:
    s = repo_students.get_student(conn, sid)
    if not s:
        return "Ученик не найден."
    prepay_paid = repo_payments.sum_payments(conn, sid, "prepay")
    post_paid = repo_payments.sum_payments(conn, sid, "postpay")
    pp = repo_postpay.get(conn, sid)
    total = post_total(s["offer_amount"], pp["total_percent"]) if pp and pp["enabled"] else None
    tariff = repo_students.tariff_label(s["tariff"])
    if s["tariff"] in ("post", "pre_post") and pp and pp["total_percent"] is not None:
        tariff = f"{tariff} ({pp['total_percent']}%)"
    remain = money(max(0,total-post_paid)) if total is not None else "—"
    lines = [
        f"<b>{s['fio']}</b>",
        f"Направление: <b>{s['direction_name'] or '—'}</b>",
        f"Этап: <b>{s['stage_name'] or '—'}</b>",
        f"Тариф: <b>{tariff}</b>",
        f"Предоплата: <b>{money(prepay_paid)}</b>",
        f"Постоплата: <b>{money(post_paid)}</b>",
    ]
    if total is not None:
        lines.append(f"Постоплата всего: <b>{money(total)}</b>")
        lines.append(f"Осталось: <b>{remain}</b>")
        if pp["next_due_date"]:
            lines.append(f"Следующий платёж: <b>{pp['next_due_date']}</b>")
    return "\n".join(lines)

def init(bot: TeleBot, ctx: dict) -> None:
    conn: sqlite3.Connection = ctx["conn"]
    tz = ctx["cfg"].TZ

    def _is_admin(user_id: int) -> bool:
        return is_admin(ctx, user_id)

    def _get_alert_for_action(c: CallbackQuery, aid: int):
        a = repo_alerts.get(conn, aid)
        if not a:
            return None, False
        # Admin can manage everything. Non-admin can manage only alerts in their own chat.
        if _is_admin(c.from_user.id):
            return a, True
        if int(a["chat_id"]) == int(c.message.chat.id):
            return a, False
        return None, False

    @bot.callback_query_handler(func=lambda c: c.data.startswith("a:seen:"))
    def a_seen(c: CallbackQuery):
        aid=int(c.data.split(":")[2])
        a, admin_mode = _get_alert_for_action(c, aid)
        if not a:
            bot.answer_callback_query(c.id, "Нет доступа")
            return

        # Для ученика: "увидел" = отложить следующее напоминание о платеже до завтра,
        # не меняя срок платежа (next_due_date).
        if not admin_mode and a["alert_type"] == "PAYMENT" and a["student_id"] is not None:
            sid = int(a["student_id"])
            tomorrow = now(tz).date() + dt.timedelta(days=1)
            repo_postpay.upsert(conn, sid, student_next_notify_date=format_date_ddmmyyyy(tomorrow))

        repo_alerts.mark_seen(conn, aid, tz)
        # remove keyboard
        try:
            bot.edit_message_reply_markup(c.message.chat.id, c.message.message_id, reply_markup=None)
        except Exception:
            pass
        bot.answer_callback_query(c.id, "Отмечено")

    @bot.callback_query_handler(func=lambda c: c.data.startswith("a:snz:"))
    def a_snooze(c: CallbackQuery):
        _, _, aid, mins = c.data.split(":")
        aid=int(aid); mins=int(mins)
        a, admin_mode = _get_alert_for_action(c, aid)
        if not a:
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        next_retry = now(tz) + dt.timedelta(minutes=mins)
        repo_alerts.snooze(conn, aid, tz, iso(next_retry))
        bot.answer_callback_query(c.id, f"Отложено на {mins} мин")

    @bot.callback_query_handler(func=lambda c: c.data.startswith("a:shift:"))
    def a_shift(c: CallbackQuery):
        _, _, aid, days = c.data.split(":")
        aid = int(aid)
        days = int(days)
        a, admin_mode = _get_alert_for_action(c, aid)
        if not a:
            bot.answer_callback_query(c.id, "Нет доступа")
            return

        # PAYMENT:
        # - admin: переносит срок платежа (next_due_date)
        # - ученик: переносит ТОЛЬКО напоминание (student_next_notify_date)
        if a["alert_type"] == "PAYMENT" and a["student_id"] is not None:
            sid = int(a["student_id"])
            d = now(tz).date() + dt.timedelta(days=days)
            if admin_mode:
                repo_postpay.upsert(conn, sid, next_due_date=format_date_ddmmyyyy(d), enabled=1)
            else:
                repo_postpay.upsert(conn, sid, student_next_notify_date=format_date_ddmmyyyy(d))
            repo_alerts.mark_seen(conn, aid, tz)
            try:
                bot.edit_message_reply_markup(c.message.chat.id, c.message.message_id, reply_markup=None)
            except Exception:
                pass
            bot.answer_callback_query(c.id, "Перенёс")
            return

        # REMINDER: переносим следующий запуск напоминалки
        if a["alert_type"] == "REMINDER" and a["related_table"] == "reminders":
            rid = int(a["related_id"])
            r = repo_reminders.get(conn, rid)
            if r:
                base = dt.datetime.fromisoformat(r["next_run_at"]).astimezone(dt.timezone.utc)
                # сохраняем время из time_of_day
                hh, mm = (r["time_of_day"] or "12:00").split(":")
                new_dt = (now(tz) + dt.timedelta(days=days)).replace(hour=int(hh), minute=int(mm), second=0, microsecond=0)
                repo_reminders.update(conn, rid, tz, next_run_at=iso(new_dt))
            repo_alerts.mark_seen(conn, aid, tz)
            try:
                bot.edit_message_reply_markup(c.message.chat.id, c.message.message_id, reply_markup=None)
            except Exception:
                pass
            bot.answer_callback_query(c.id, "Перенёс")
            return

        # EVENT: просто отложить повтор уведомления (на 1 день/3 дня)
        next_retry = now(tz) + dt.timedelta(days=days)
        repo_alerts.snooze(conn, aid, tz, iso(next_retry))
        bot.answer_callback_query(c.id, "Отложено")

    @bot.callback_query_handler(func=lambda c: c.data.startswith("a:date:"))
    def a_date(c: CallbackQuery):
        aid = int(c.data.split(":")[2])
        a, admin_mode = _get_alert_for_action(c, aid)
        if not a:
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        repo_states.set_state(conn, c.from_user.id, "AL_SET_DATE", {"alert_id": aid}, tz)
        bot.send_message(c.message.chat.id, "Введи дату <b>дд.мм.гггг</b> для переноса:")
        bot.answer_callback_query(c.id)

    @bot.message_handler(func=lambda m: repo_states.get_state(conn, m.from_user.id)[0] == "AL_SET_DATE", content_types=["text"])
    def al_set_date_text(m):
        st, data = repo_states.get_state(conn, m.from_user.id)
        aid = int((data or {}).get("alert_id") or 0)
        d = parse_date_ddmmyyyy((m.text or "").strip())
        if not d:
            bot.reply_to(m, "Формат: дд.мм.гггг"); return
        a = repo_alerts.get(conn, aid)
        if not a:
            repo_states.clear_state(conn, m.from_user.id, tz)
            bot.reply_to(m, "Напоминание не найдено."); return

        # non-admin can set date only for alerts in their own chat
        admin_mode = _is_admin(m.from_user.id)
        if not admin_mode and int(a["chat_id"]) != int(m.chat.id):
            repo_states.clear_state(conn, m.from_user.id, tz)
            bot.reply_to(m, "Нет доступа.");
            return

        if a["alert_type"] == "PAYMENT" and a["student_id"] is not None:
            sid = int(a["student_id"])
            if admin_mode:
                repo_postpay.upsert(conn, sid, next_due_date=format_date_ddmmyyyy(d), enabled=1)
            else:
                repo_postpay.upsert(conn, sid, student_next_notify_date=format_date_ddmmyyyy(d))
            repo_alerts.mark_seen(conn, aid, tz)
            repo_states.clear_state(conn, m.from_user.id, tz)
            bot.reply_to(m, "Перенёс.")
            return
        if a["alert_type"] == "REMINDER" and a["related_table"] == "reminders":
            rid = int(a["related_id"])
            r = repo_reminders.get(conn, rid)
            if r:
                hh, mm = (r["time_of_day"] or "12:00").split(":")
                new_dt = now(tz).replace(year=d.year, month=d.month, day=d.day, hour=int(hh), minute=int(mm), second=0, microsecond=0)
                repo_reminders.update(conn, rid, tz, next_run_at=iso(new_dt))
            repo_alerts.mark_seen(conn, aid, tz)
            repo_states.clear_state(conn, m.from_user.id, tz)
            bot.reply_to(m, "Перенёс напоминалку.")
            return
        # по умолчанию — просто отложить повтор
        repo_alerts.snooze(conn, aid, tz, iso(now(tz).replace(year=d.year, month=d.month, day=d.day)))
        repo_states.clear_state(conn, m.from_user.id, tz)
        bot.reply_to(m, "Ок.")

    @bot.callback_query_handler(func=lambda c: c.data.startswith("a:open_s:"))
    def a_open_student(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        sid=int(c.data.split(":")[2])
        txt=_student_card_text(conn, sid, tz)
        kb=student_card_kb(sid, back_cb="m:main")
        bot.send_message(c.message.chat.id, txt, reply_markup=kb)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("a:open_e:"))
    def a_open_event(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        eid=int(c.data.split(":")[2])
        e=repo_events.get(conn, eid)
        if not e:
            bot.answer_callback_query(c.id, "Не найдено"); return
        who = e["fio"] or "—"
        link = e["link"] or "—"
        msg = f"<b>Событие #{eid}</b>\nТип: <b>{e['event_type']}</b>\nУченик: {who}\nКогда: <b>{e['start_at']}</b>\nДлительность: {e['duration_min']} мин\nСсылка: {link}"
        kb=InlineKeyboardMarkup()
        if e["student_id"]:
            kb.row(InlineKeyboardButton("Открыть ученика", callback_data=f"st:open:{e['student_id']}"))
        bot.send_message(c.message.chat.id, msg, reply_markup=kb)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("a:pay:"))
    def a_pay(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        sid=int(c.data.split(":")[2])
        # set payments flow state so payments.py can continue
        repo_states.set_state(conn, c.from_user.id, "PY_PICK_TYPE", {"student_id": sid}, tz)
        kb=InlineKeyboardMarkup()
        kb.row(InlineKeyboardButton("Предоплата", callback_data="py:type:prepay"),
               InlineKeyboardButton("Постоплата", callback_data="py:type:postpay"))
        kb.row(InlineKeyboardButton("Отмена", callback_data=f"st:open:{sid}"))
        bot.send_message(c.message.chat.id, f"Платёж для ученика #{sid}. Тип:", reply_markup=kb)
        bot.answer_callback_query(c.id)
