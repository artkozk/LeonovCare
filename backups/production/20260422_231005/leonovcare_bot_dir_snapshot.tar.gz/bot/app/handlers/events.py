from __future__ import annotations
import sqlite3
import datetime as dt
from telebot import TeleBot
from telebot.types import CallbackQuery, Message, InlineKeyboardMarkup, InlineKeyboardButton

from app.handlers.common import is_admin
from app.db import repo_states, repo_events, repo_students
from app.services.timeutils import now, iso, start_of_day, end_of_day, add_days, parse_datetime_ddmmyyyy_hhmm, format_dt_ddmmyyyy_hhmm, tzinfo
from app.ui.keyboards import events_menu_kb, pick_list_kb

EVENT_TYPES = [
    ("HR", "HR"),
    ("Тех", "TECH"),
    ("Созвон", "CALL"),
    ("Другое", "OTHER"),
]

EVENT_TYPE_LABEL = {
    "HR": "HR",
    "TECH": "Тех",
    "CALL": "Созвон",
    "OTHER": "Другое",
}

def _etype_label(code: str) -> str:
    return EVENT_TYPE_LABEL.get(code or "", code or "—")


def _day_key(d: dt.date) -> str:
    return d.strftime("%Y%m%d")


def _parse_day_key(s: str) -> dt.date:
    return dt.datetime.strptime(s, "%Y%m%d").date()


def _floor_to_30(m: dt.datetime) -> dt.datetime:
    mm = (m.minute // 30) * 30
    return m.replace(minute=mm, second=0, microsecond=0)


def _slot_starts(day: dt.date, tz: str) -> list[dt.datetime]:
    tz_i = tzinfo(tz)
    cur = dt.datetime.combine(day, dt.time(9, 0)).replace(tzinfo=tz_i)
    end = dt.datetime.combine(day, dt.time(21, 0)).replace(tzinfo=tz_i)
    out: list[dt.datetime] = []
    while cur <= end:
        out.append(cur)
        cur = cur + dt.timedelta(minutes=30)
    return out


def _money(v) -> str:
    try:
        if v is None:
            return "—"
        n = int(v)
        if n <= 0:
            return "—"
        return f"{n:,}".replace(",", " ") + " ₽"
    except Exception:
        return "—"

def init(bot: TeleBot, ctx: dict) -> None:
    conn: sqlite3.Connection = ctx["conn"]
    tz = ctx["cfg"].TZ

    @bot.callback_query_handler(func=lambda c: c.data == "ev:today")
    def ev_today(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        n = now(tz)
        ds = start_of_day(n.date(), tz)
        de = end_of_day(n.date(), tz)
        rows = repo_events.list_upcoming(conn, iso(ds), iso(de))
        if not rows:
            bot.edit_message_text("Сегодня событий нет.", c.message.chat.id, c.message.message_id, reply_markup=events_menu_kb())
            bot.answer_callback_query(c.id); return
        lines=[]
        kb=InlineKeyboardMarkup()
        for e in rows[:10]:
            who = e["fio"] or "—"
            comp = e["company"] if (hasattr(e, "keys") and "company" in e.keys() and e["company"]) else None
            tail = f" — {comp}" if comp else ""
            when = format_dt_ddmmyyyy_hhmm(e["start_at"], tz)
            when_short = (when[:5] + " " + when[-5:]) if len(when) >= 16 else when
            et = _etype_label(e["event_type"])
            lines.append(f"• <b>{et}</b> • {who} — {when}{tail}")
            btn = f"{who} • {when_short}"[:60]
            kb.row(InlineKeyboardButton(btn, callback_data=f"ev:open:{e['id']}"))
        kb.row(InlineKeyboardButton("⬅️ Назад", callback_data="m:events"))
        bot.edit_message_text("События на сегодня:\n" + "\n".join(lines), c.message.chat.id, c.message.message_id, reply_markup=kb)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data == "ev:week")
    def ev_week(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        n = now(tz)
        ds = start_of_day(n.date(), tz)
        de = add_days(ds, 7)
        rows = repo_events.list_upcoming(conn, iso(ds), iso(de))
        if not rows:
            bot.edit_message_text("На неделе событий нет.", c.message.chat.id, c.message.message_id, reply_markup=events_menu_kb())
            bot.answer_callback_query(c.id); return
        lines=[]
        kb=InlineKeyboardMarkup()
        for e in rows[:12]:
            who = e["fio"] or "—"
            comp = e["company"] if (hasattr(e, "keys") and "company" in e.keys() and e["company"]) else None
            tail = f" — {comp}" if comp else ""
            when = format_dt_ddmmyyyy_hhmm(e["start_at"], tz)
            when_short = (when[:5] + " " + when[-5:]) if len(when) >= 16 else when
            et = _etype_label(e["event_type"])
            lines.append(f"• <b>{et}</b> • {who} — {when}{tail}")
            btn = f"{who} • {when_short}"[:60]
            kb.row(InlineKeyboardButton(btn, callback_data=f"ev:open:{e['id']}"))
        kb.row(InlineKeyboardButton("⬅️ Назад", callback_data="m:events"))
        bot.edit_message_text("События на неделе:\n" + "\n".join(lines), c.message.chat.id, c.message.message_id, reply_markup=kb)
        bot.answer_callback_query(c.id)

    def _slots_view(day: dt.date) -> tuple[str, InlineKeyboardMarkup]:
        rows = repo_events.list_for_day(conn, day, tz)

        slots = _slot_starts(day, tz)
        slot_len = dt.timedelta(minutes=30)

        # map slot -> list of event rows to show (start-of-event only)
        display: dict[dt.datetime, list[sqlite3.Row]] = {}
        occupied: set[dt.datetime] = set()

        for e in rows:
            try:
                s = dt.datetime.fromisoformat(e["start_at"])
                dur = int(e["duration_min"] or 0)
                en = s + dt.timedelta(minutes=dur)

                # occupied slots: any 30-min window that intersects event interval
                for sl in slots:
                    if sl < en and (sl + slot_len) > s:
                        occupied.add(sl)

                disp = _floor_to_30(s)
                # clamp display slot to schedule bounds
                if disp < slots[0]:
                    disp = slots[0]
                if disp > slots[-1]:
                    disp = slots[-1]
                display.setdefault(disp, []).append(e)
            except Exception:
                continue

        title = f"<b>Слоты</b> • {day.strftime('%d.%m.%Y')}\n\n"
        if not rows:
            title += "Событий нет. Выбери свободное время."
        else:
            title += "Свободные слоты — кнопки с временем. Занятые — начало события."

        kb = InlineKeyboardMarkup()
        prev_d = day - dt.timedelta(days=1)
        next_d = day + dt.timedelta(days=1)
        kb.row(
            InlineKeyboardButton("⬅️", callback_data=f"slots:day:{_day_key(prev_d)}"),
            InlineKeyboardButton("Сегодня", callback_data=f"slots:day:{_day_key(now(tz).date())}"),
            InlineKeyboardButton("➡️", callback_data=f"slots:day:{_day_key(next_d)}"),
        )

        row_btns: list[InlineKeyboardButton] = []
        for sl in slots:
            if sl in occupied:
                if sl not in display:
                    continue
                # if overlaps exist (legacy), show stacked with short label
                for ev in display.get(sl, [])[:2]:
                    s = dt.datetime.fromisoformat(ev["start_at"])
                    en = s + dt.timedelta(minutes=int(ev["duration_min"] or 0))
                    label = f"{s.strftime('%H:%M')}-{en.strftime('%H:%M')} ({_etype_label(ev['event_type'])})"
                    row_btns.append(InlineKeyboardButton(label[:60], callback_data=f"ev:open:{ev['id']}"))
            else:
                label = sl.strftime("%H:%M")
                row_btns.append(
                    InlineKeyboardButton(
                        label,
                        callback_data=f"slots:free:{_day_key(day)}:{sl.strftime('%H%M')}"
                    )
                )

            if len(row_btns) >= 3:
                kb.row(*row_btns)
                row_btns = []
        if row_btns:
            kb.row(*row_btns)

        kb.row(InlineKeyboardButton("⬅️ Назад", callback_data="m:events"))
        return title, kb

    @bot.callback_query_handler(func=lambda c: c.data == "ev:slots")
    def ev_slots(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        day = now(tz).date()
        text, kb = _slots_view(day)
        bot.edit_message_text(text, c.message.chat.id, c.message.message_id, reply_markup=kb)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("slots:day:"))
    def slots_day(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        key = c.data.split(":", 2)[2]
        day = _parse_day_key(key)
        text, kb = _slots_view(day)
        bot.edit_message_text(text, c.message.chat.id, c.message.message_id, reply_markup=kb)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("slots:free:"))
    def slots_free(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        _, _, day_key, hhmm = c.data.split(":", 3)
        day = _parse_day_key(day_key)
        hh = int(hhmm[:2]); mm = int(hhmm[2:])
        start = dt.datetime.combine(day, dt.time(hh, mm)).replace(tzinfo=tzinfo(tz))
        data = {"preset_start_at": iso(start)}
        repo_states.set_state(conn, c.from_user.id, "EV_PICK_TYPE", data, tz)
        _ask_type(c.message.chat.id, c.from_user.id, data)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data == "ev:list")
    def ev_list(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        rows = repo_events.list_all_upcoming(conn, limit=20)
        if not rows:
            bot.edit_message_text("Предстоящих событий нет.", c.message.chat.id, c.message.message_id, reply_markup=events_menu_kb())
            bot.answer_callback_query(c.id); return
        lines=[]
        kb=InlineKeyboardMarkup()
        for e in rows[:15]:
            who = e["fio"] or "—"
            comp = e["company"] if (hasattr(e, "keys") and "company" in e.keys() and e["company"]) else None
            tail = f" — {comp}" if comp else ""
            when = format_dt_ddmmyyyy_hhmm(e["start_at"], tz)
            when_short = (when[:5] + " " + when[-5:]) if len(when) >= 16 else when
            et = _etype_label(e["event_type"])
            lines.append(f"• <b>{et}</b> • {who} — {when}{tail}")
            btn = f"{who} • {when_short}"[:60]
            kb.row(InlineKeyboardButton(btn, callback_data=f"ev:open:{e['id']}"))
        kb.row(InlineKeyboardButton("⬅️ Назад", callback_data="m:events"))
        bot.edit_message_text("Предстоящие события:\n" + "\n".join(lines), c.message.chat.id, c.message.message_id, reply_markup=kb)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data == "ev:add")
    def ev_add(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        data={}
        repo_states.set_state(conn, c.from_user.id, "EV_PICK_TYPE", data, tz)
        _ask_type(c.message.chat.id, c.from_user.id, data)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("st:ev_add:"))
    def ev_add_from_student(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        sid=int(c.data.split(":")[2])
        data={"student_id": sid}
        repo_states.set_state(conn, c.from_user.id, "EV_PICK_TYPE", data, tz)
        _ask_type(c.message.chat.id, c.from_user.id, data)
        bot.answer_callback_query(c.id)

    def _ask_type(chat_id: int, user_id: int, data: dict):
        items=[(label, f"ev:type:{code}") for label, code in EVENT_TYPES]
        bot.send_message(chat_id, "Формат события:", reply_markup=pick_list_kb(items, "m:events"))

    @bot.callback_query_handler(func=lambda c: c.data.startswith("ev:type:"))
    def ev_type(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        st, data = repo_states.get_state(conn, c.from_user.id)
        if st != "EV_PICK_TYPE":
            bot.answer_callback_query(c.id); return
        data["event_type"]=c.data.split(":")[2]
        # if no student selected, ask optional link to student
        if not data.get("student_id"):
            repo_states.set_state(conn, c.from_user.id, "EV_FIND_STUDENT_OPT", data, tz)
            bot.send_message(c.message.chat.id, "Введи часть ФИО/@username ученика (или '-' чтобы без ученика):")
        else:
            repo_states.set_state(conn, c.from_user.id, "EV_LINK_INPUT", data, tz)
            bot.send_message(c.message.chat.id, "Ссылка на собес/созвон (или '-' если нет):")
        bot.answer_callback_query(c.id)

    @bot.message_handler(func=lambda m: repo_states.get_state(conn, m.from_user.id)[0] in (
        "EV_FIND_STUDENT_OPT","EV_LINK_INPUT","EV_COMPANY_INPUT","EV_DIRECTION_INPUT","EV_ROLE_INPUT","EV_START_INPUT"
    ), content_types=["text"])
    def ev_text(m: Message):
        if not is_admin(ctx, m.from_user.id):
            return
        st, data = repo_states.get_state(conn, m.from_user.id)
        if st == "EV_FIND_STUDENT_OPT":
            txt=m.text.strip()
            if txt in ("-", "—"):
                data["student_id"]=None
                repo_states.set_state(conn, m.from_user.id, "EV_LINK_INPUT", data, tz)
                bot.send_message(m.chat.id, "Ссылка на собес/созвон (или '-' если нет):")
                return
            rows = repo_students.search_students(conn, txt, archived=False, limit=8)
            if not rows:
                bot.send_message(m.chat.id, "Не нашёл. Попробуй ещё раз или '-'"); return
            kb=InlineKeyboardMarkup()
            for r in rows:
                kb.row(InlineKeyboardButton(r["fio"][:28], callback_data=f"ev:pick_student:{r['id']}"))
            kb.row(InlineKeyboardButton("Без ученика", callback_data="ev:pick_student:0"))
            bot.send_message(m.chat.id, "Выбери ученика:", reply_markup=kb)
            return
        if st == "EV_LINK_INPUT":
            link=m.text.strip()
            data["link"]=None if link in ("-","—") else link
            repo_states.set_state(conn, m.from_user.id, "EV_COMPANY_INPUT", data, tz)
            bot.send_message(m.chat.id, "Компания (или '-' если не надо):")
            return

        if st == "EV_COMPANY_INPUT":
            txt=m.text.strip()
            data["company"]=None if txt in ("-","—") else txt
            # direction: try take from student, but allow override
            repo_states.set_state(conn, m.from_user.id, "EV_DIRECTION_INPUT", data, tz)
            bot.send_message(m.chat.id, "Направление/роль (например Java Backend) (или '-' если не надо):")
            return

        if st == "EV_DIRECTION_INPUT":
            txt=m.text.strip()
            data["direction"]=None if txt in ("-","—") else txt
            repo_states.set_state(conn, m.from_user.id, "EV_ROLE_INPUT", data, tz)
            bot.send_message(m.chat.id, "Этап собеса/позиция (например Middle Java, TeamLead) (или '-' если не надо):")
            return

        if st == "EV_ROLE_INPUT":
            txt=m.text.strip()
            data["role"]=None if txt in ("-","—") else txt
            # If user picked a slot, skip manual date entry.
            if data.get("preset_start_at"):
                data["start_at"] = data["preset_start_at"]
                repo_states.set_state(conn, m.from_user.id, "EV_PICK_DURATION", data, tz)
                items=[("30 мин", "ev:dur:30"), ("60 мин", "ev:dur:60"), ("90 мин", "ev:dur:90"), ("120 мин", "ev:dur:120")]
                bot.send_message(m.chat.id, "Длительность:", reply_markup=pick_list_kb(items, "m:events"))
                return

            repo_states.set_state(conn, m.from_user.id, "EV_START_INPUT", data, tz)
            bot.send_message(m.chat.id, "Введи дату и время: <b>дд.мм ЧЧ:ММ</b> (год подставлю сам) или <b>дд.мм.гггг ЧЧ:ММ</b>\nНапример: 14.02 18:30")
            return
        if st == "EV_START_INPUT":
            dt_obj = parse_datetime_ddmmyyyy_hhmm(m.text.strip(), tz)
            if not dt_obj:
                bot.send_message(m.chat.id, "Не понял. Формат: дд.мм.гггг ЧЧ:ММ"); return
            data["start_at"]=iso(dt_obj)
            repo_states.set_state(conn, m.from_user.id, "EV_PICK_DURATION", data, tz)
            items=[("30 мин", "ev:dur:30"), ("60 мин", "ev:dur:60"), ("90 мин", "ev:dur:90"), ("120 мин", "ev:dur:120")]
            bot.send_message(m.chat.id, "Длительность:", reply_markup=pick_list_kb(items, "m:events"))
            return
        if st == "EV_NOTE":  # unused
            return

    @bot.callback_query_handler(func=lambda c: c.data.startswith("ev:pick_student:"))
    def ev_pick_student(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        st, data = repo_states.get_state(conn, c.from_user.id)
        if st != "EV_FIND_STUDENT_OPT":
            bot.answer_callback_query(c.id); return
        sid=int(c.data.split(":")[2])
        data["student_id"]=None if sid==0 else sid
        repo_states.set_state(conn, c.from_user.id, "EV_LINK_INPUT", data, tz)
        bot.send_message(c.message.chat.id, "Ссылка на собес/созвон (или '-' если нет):")
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("ev:dur:"))
    def ev_dur(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        st, data = repo_states.get_state(conn, c.from_user.id)
        if st != "EV_PICK_DURATION":
            bot.answer_callback_query(c.id); return
        data["duration_min"]=int(c.data.split(":")[2])
        repo_states.set_state(conn, c.from_user.id, "EV_PICK_BEFORE", data, tz)
        items=[("За 60 мин", "ev:before:60"), ("За 120 мин", "ev:before:120"), ("За 180 мин", "ev:before:180"), ("Сейчас", "ev:before:0")]
        bot.send_message(c.message.chat.id, "Когда напомнить:", reply_markup=pick_list_kb(items, "m:events"))
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("ev:before:"))
    def ev_before(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        st, data = repo_states.get_state(conn, c.from_user.id)
        if st != "EV_PICK_BEFORE":
            bot.answer_callback_query(c.id); return
        before=int(c.data.split(":")[2])
        data["remind_before_min"]=before

        # overlap protection
        try:
            start_at = dt.datetime.fromisoformat(data["start_at"])
            dur = int(data.get("duration_min", 60))
            end_at = start_at + dt.timedelta(minutes=dur)
            overlaps = repo_events.find_overlaps(conn, start_at, end_at, tz)
        except Exception:
            overlaps = []

        if overlaps and not data.get("allow_overlap"):
            lines = []
            for ov in overlaps[:6]:
                try:
                    os = dt.datetime.fromisoformat(ov["start_at"])
                    oe = os + dt.timedelta(minutes=int(ov["duration_min"] or 0))
                    lines.append(f"• {os.strftime('%d.%m %H:%M')}-{oe.strftime('%H:%M')} ({_etype_label(ov['event_type'])})")
                except Exception:
                    continue
            msg = "⚠️ В это время уже есть событие.\n\n" + "\n".join(lines) + "\n\nВыбери другое время."

            repo_states.set_state(conn, c.from_user.id, "EV_OVERLAP_CONFIRM", {"pending": data}, tz)
            kb = InlineKeyboardMarkup()
            kb.row(InlineKeyboardButton("🕘 Открыть слоты", callback_data=f"slots:day:{_day_key(start_at.date())}"))
            kb.row(
                InlineKeyboardButton("✅ Создать всё равно", callback_data="ev:overlap_force"),
                InlineKeyboardButton("❌ Отмена", callback_data="m:events"),
            )
            bot.edit_message_text(msg, c.message.chat.id, c.message.message_id, reply_markup=kb)
            bot.answer_callback_query(c.id)
            return

        # create event
        next_alert = start_at - dt.timedelta(minutes=before)
        if next_alert < now(tz):
            next_alert = now(tz)
        eid = repo_events.create(conn, tz,
            student_id=data.get("student_id"),
            event_type=data.get("event_type","OTHER"),
            company=data.get("company"),
            role=data.get("role"),
            direction=data.get("direction"),
            link=data.get("link"),
            start_at_iso=data["start_at"],
            duration_min=int(data.get("duration_min",60)),
            remind_before_min=before,
            next_alert_at_iso=iso(next_alert),
        )
        repo_states.clear_state(conn, c.from_user.id, tz)
        bot.send_message(c.message.chat.id, f"✅ Событие создано (id={eid}).", reply_markup=events_menu_kb())
        bot.answer_callback_query(c.id)


    @bot.callback_query_handler(func=lambda c: c.data == "ev:overlap_force")
    def ev_overlap_force(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        st, st_data = repo_states.get_state(conn, c.from_user.id)
        if st != "EV_OVERLAP_CONFIRM" or not isinstance(st_data, dict):
            bot.answer_callback_query(c.id, "Нет данных"); return
        data = st_data.get("pending")
        if not isinstance(data, dict):
            bot.answer_callback_query(c.id, "Нет данных"); return

        data["allow_overlap"] = True
        before = int(data.get("remind_before_min", 0) or 0)
        try:
            start_at = dt.datetime.fromisoformat(data["start_at"])
        except Exception:
            bot.answer_callback_query(c.id, "Ошибка даты"); return
        next_alert = start_at - dt.timedelta(minutes=before)
        if next_alert < now(tz):
            next_alert = now(tz)

        eid = repo_events.create(conn, tz,
            student_id=data.get("student_id"),
            event_type=data.get("event_type","OTHER"),
            company=data.get("company"),
            role=data.get("role"),
            direction=data.get("direction"),
            link=data.get("link"),
            start_at_iso=data["start_at"],
            duration_min=int(data.get("duration_min",60)),
            remind_before_min=before,
            next_alert_at_iso=iso(next_alert),
        )
        repo_states.clear_state(conn, c.from_user.id, tz)
        bot.edit_message_text(f"✅ Событие создано (id={eid}).", c.message.chat.id, c.message.message_id, reply_markup=events_menu_kb())
        bot.answer_callback_query(c.id)



    # -------------------------
    # Просмотр / редактирование / удаление
    # -------------------------

    @bot.callback_query_handler(func=lambda c: c.data.startswith("ev:open:"))
    def ev_open(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        eid = int(c.data.split(":")[2])
        e = repo_events.get(conn, eid)
        if not e:
            bot.answer_callback_query(c.id, "Не найдено"); return

        who = e["fio"] or "—"
        link_val = e["link"]
        link = link_val or "—"
        company = (e["company"] or "—") if (hasattr(e, "keys") and "company" in e.keys()) else "—"
        direction = (e["direction"] or "—") if (hasattr(e, "keys") and "direction" in e.keys()) else "—"
        role = (e["role"] or "—") if (hasattr(e, "keys") and "role" in e.keys()) else "—"
        before = e["remind_before_min"] if e["remind_before_min"] is not None else "—"
        when = format_dt_ddmmyyyy_hhmm(e["start_at"], tz)
        et = _etype_label(e["event_type"])
        msg = (
            f"<b>Событие #{eid}</b>\n"
            f"Тип: <b>{et}</b>\n"
            f"Ученик: {who}\n"
            f"Компания: {company}\n"
            f"Направление: {direction}\n"
            f"Позиция/этап: {role}\n"
            f"Когда: <b>{when}</b>\n"
            f"Длительность: {e['duration_min']} мин\n"
            f"Напомнить за: {before} мин\n"
            f"Ссылка: {link}"
        )

        kb = InlineKeyboardMarkup()
        kb.row(
            InlineKeyboardButton("✏️ Дата/время", callback_data=f"ev:edit:{eid}:when"),
            InlineKeyboardButton("✏️ Ссылка", callback_data=f"ev:edit:{eid}:link"),
        )
        kb.row(
            InlineKeyboardButton("✏️ Длительность", callback_data=f"ev:edit:{eid}:duration"),
            InlineKeyboardButton("✏️ Напоминание", callback_data=f"ev:edit:{eid}:before"),
        )
        kb.row(
            InlineKeyboardButton("✏️ Тип", callback_data=f"ev:edit:{eid}:type"),
            InlineKeyboardButton("✏️ Ученик", callback_data=f"ev:edit:{eid}:student"),
        )
        if link_val and isinstance(link_val, str) and link_val.startswith("http"):
            kb.row(InlineKeyboardButton("🔗 Открыть ссылку", url=link_val))
        kb.row(InlineKeyboardButton("🗑 Удалить", callback_data=f"ev:del:{eid}"))
        if e["student_id"] is not None:
            kb.row(InlineKeyboardButton("Открыть ученика", callback_data=f"st:open:{e['student_id']}"))
        kb.row(InlineKeyboardButton("⬅️ Назад", callback_data="m:events"))

        bot.edit_message_text(msg, c.message.chat.id, c.message.message_id, reply_markup=kb)
        bot.answer_callback_query(c.id)


    @bot.callback_query_handler(func=lambda c: c.data.startswith("ev:del:"))
    def ev_del(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        eid = int(c.data.split(":")[2])
        kb = InlineKeyboardMarkup()
        kb.row(InlineKeyboardButton("Да, удалить", callback_data=f"ev:delok:{eid}"))
        kb.row(InlineKeyboardButton("Отмена", callback_data=f"ev:open:{eid}"))
        bot.edit_message_text(f"Удалить событие #{eid}?", c.message.chat.id, c.message.message_id, reply_markup=kb)
        bot.answer_callback_query(c.id)


    @bot.callback_query_handler(func=lambda c: c.data.startswith("ev:delok:"))
    def ev_del_ok(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        eid = int(c.data.split(":")[2])
        repo_events.delete(conn, eid)
        bot.edit_message_text("Удалено.", c.message.chat.id, c.message.message_id, reply_markup=events_menu_kb())
        bot.answer_callback_query(c.id)


    @bot.callback_query_handler(func=lambda c: c.data.startswith("ev:edit:"))
    def ev_edit(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        _, _, eid_s, field = c.data.split(":")
        eid = int(eid_s)
        e = repo_events.get(conn, eid)
        if not e:
            bot.answer_callback_query(c.id, "Не найдено"); return

        if field == "type":
            items = [
                ("HR", f"ev:set_type:{eid}:HR"),
                ("Тех", f"ev:set_type:{eid}:TECH"),
                ("Созвон", f"ev:set_type:{eid}:CALL"),
                ("Другое", f"ev:set_type:{eid}:OTHER"),
            ]
            bot.edit_message_text(
                "Выбери тип события:",
                c.message.chat.id,
                c.message.message_id,
                reply_markup=pick_list_kb(items, f"ev:open:{eid}"),
            )
            bot.answer_callback_query(c.id)
            return

        if field == "student":
            repo_states.set_state(conn, c.from_user.id, "EV_PICK_STUDENT", {"eid": eid}, tz)
            bot.send_message(c.message.chat.id, "Введи @username или часть ФИО ученика для поиска:")
            bot.answer_callback_query(c.id)
            return

        repo_states.set_state(conn, c.from_user.id, "EV_EDIT_TEXT", {"eid": eid, "field": field}, tz)
        prompts = {
            "when": "Введи дату и время: дд.мм чч:мм (год сам) или дд.мм.гггг чч:мм (например 18.02 14:30)",
            "link": "Введи ссылку (или '-' чтобы очистить):",
            "duration": "Длительность в минутах (число):",
            "before": "Напомнить за сколько минут? (например 10) или 0 чтобы отключить:",
        }
        bot.send_message(c.message.chat.id, prompts.get(field, "Введи значение:"))
        bot.answer_callback_query(c.id)


    @bot.callback_query_handler(func=lambda c: c.data.startswith("ev:set_type:"))
    def ev_set_type(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        _, _, eid_s, t = c.data.split(":", 3)
        eid = int(eid_s)
        repo_events.update(conn, eid, tz, event_type=t)
        bot.answer_callback_query(c.id, "Ок")


    def _ev_state_active(m: Message) -> bool:
        if not m.from_user:
            return False
        st, _ = repo_states.get_state(conn, m.from_user.id)
        return st in {"EV_EDIT_TEXT", "EV_PICK_STUDENT"}


    @bot.message_handler(func=_ev_state_active)
    def ev_text_router(m: Message):
        if not is_admin(ctx, m.from_user.id):
            return
        st, data = repo_states.get_state(conn, m.from_user.id)
        data = data or {}

        if st == "EV_PICK_STUDENT":
            q = (m.text or "").strip()
            rows = repo_students.search_students(conn, q, archived=False, limit=10)
            if not rows:
                bot.reply_to(m, "Не нашёл. Введи другую строку:")
                return
            eid = int(data["eid"])
            items = []
            for s in rows:
                items.append((f"{s['fio']} (@{s['username'] or '—'})", f"ev:set_student:{eid}:{s['id']}"))
            bot.send_message(m.chat.id, "Выбери ученика:", reply_markup=pick_list_kb(items, f"ev:open:{eid}"))
            return

        if st == "EV_EDIT_TEXT":
            eid = int(data["eid"])
            field = data["field"]
            txt = (m.text or "").strip()

            if field == "when":
                start_dt = parse_datetime_ddmmyyyy_hhmm(txt, tz)
                if not start_dt:
                    bot.reply_to(m, "Неверный формат. Пример: 18.02 14:30")
                    return
                start_dt = start_dt.replace(tzinfo=tzinfo(tz), microsecond=0)
                start_iso = iso(start_dt)
                e = repo_events.get(conn, eid)
                dur = int(e["duration_min"] or 0)
                end_dt = start_dt + dt.timedelta(minutes=dur)
                overlaps = repo_events.find_overlaps(conn, start_dt, end_dt, tz, exclude_event_id=eid)
                if overlaps:
                    os = dt.datetime.fromisoformat(overlaps[0]["start_at"])
                    oe = os + dt.timedelta(minutes=int(overlaps[0]["duration_min"] or 0))
                    bot.reply_to(m, f"⚠️ В это время уже есть событие: {os.strftime('%d.%m %H:%M')}-{oe.strftime('%H:%M')}.\nОткрой слоты и выбери другое время.")
                    return
                before = int(e["remind_before_min"] or 0)
                next_alert = start_dt - dt.timedelta(minutes=before)
                repo_events.update(conn, eid, tz, start_at=start_iso, next_alert_at=iso(next_alert))

            elif field == "link":
                repo_events.update(conn, eid, tz, link=None if txt in ("-", "—", "") else txt)

            elif field == "duration":
                try:
                    n = int(txt)
                    n = max(5, n)
                except Exception:
                    bot.reply_to(m, "Введи число")
                    return
                e = repo_events.get(conn, eid)
                start_dt = dt.datetime.fromisoformat(e["start_at"])
                if start_dt.tzinfo is None:
                    start_dt = start_dt.replace(tzinfo=tzinfo(tz))
                end_dt = start_dt + dt.timedelta(minutes=n)
                overlaps = repo_events.find_overlaps(conn, start_dt, end_dt, tz, exclude_event_id=eid)
                if overlaps:
                    os = dt.datetime.fromisoformat(overlaps[0]["start_at"])
                    oe = os + dt.timedelta(minutes=int(overlaps[0]["duration_min"] or 0))
                    bot.reply_to(m, f"⚠️ При такой длительности будет пересечение с событием {os.strftime('%d.%m %H:%M')}-{oe.strftime('%H:%M')}.\nВыбери другую длительность/время.")
                    return
                repo_events.update(conn, eid, tz, duration_min=n)

            elif field == "before":
                try:
                    n = int(txt)
                    n = max(0, n)
                except Exception:
                    bot.reply_to(m, "Введи число")
                    return
                e = repo_events.get(conn, eid)
                start_dt = dt.datetime.fromisoformat(e["start_at"])
                if start_dt.tzinfo is None:
                    start_dt = start_dt.replace(tzinfo=tzinfo(tz))
                next_alert = start_dt - dt.timedelta(minutes=n)
                repo_events.update(conn, eid, tz, remind_before_min=n, next_alert_at=iso(next_alert))

            repo_states.clear_state(conn, m.from_user.id, tz)
            bot.reply_to(m, "Ок. Открой событие снова.")
            return


    @bot.callback_query_handler(func=lambda c: c.data.startswith("ev:set_student:"))
    def ev_set_student(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        _, _, eid_s, sid_s = c.data.split(":")
        eid = int(eid_s)
        sid = int(sid_s)
        repo_events.update(conn, eid, tz, student_id=sid)
        repo_states.clear_state(conn, c.from_user.id, tz)
        bot.answer_callback_query(c.id, "Ок")
