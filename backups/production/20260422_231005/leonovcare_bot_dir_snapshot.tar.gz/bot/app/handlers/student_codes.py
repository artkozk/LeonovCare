from __future__ import annotations

import sqlite3

from telebot import TeleBot
from telebot.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup

from app.db import repo_student_codes
from app.handlers.common import is_admin
from app.services.timeutils import format_dt_ddmmyyyy_hhmm


_LIST_LIMIT = 20


def _menu_text(conn: sqlite3.Connection, tz: str) -> str:
    c = repo_student_codes.counts(conn, tz)
    return (
        "<b>Коды ученика</b>\n"
        "Создавай одноразовые коды, смотри статусы и отзывай коды вручную.\n\n"
        f"Активные: <b>{c['active']}</b>\n"
        f"Использованные: <b>{c['used']}</b>\n"
        f"Истёкшие: <b>{c['expired']}</b>\n"
        f"Отозванные: <b>{c['revoked']}</b>"
    )


def _menu_kb() -> InlineKeyboardMarkup:
    kb = InlineKeyboardMarkup()
    kb.row(
        InlineKeyboardButton("➕ Код на 24ч", callback_data="sc:create:24"),
        InlineKeyboardButton("➕ Код без срока", callback_data="sc:create:none"),
    )
    kb.row(
        InlineKeyboardButton("Активные", callback_data="sc:list:active"),
        InlineKeyboardButton("Использованные", callback_data="sc:list:used"),
    )
    kb.row(
        InlineKeyboardButton("Истёкшие", callback_data="sc:list:expired"),
        InlineKeyboardButton("Отозванные", callback_data="sc:list:revoked"),
    )
    kb.row(InlineKeyboardButton("🏠 Main", callback_data="m:main"))
    return kb


def _status_title(status: str) -> str:
    return {
        "active": "Активные коды",
        "used": "Использованные коды",
        "expired": "Истёкшие коды",
        "revoked": "Отозванные коды",
    }.get(status, "Коды")


def _list_text(rows: list[sqlite3.Row], status: str, tz: str) -> str:
    title = _status_title(status)
    if not rows:
        return f"<b>{title}</b>\n\nСписок пуст."

    lines = [f"<b>{title}</b>\n"]
    for idx, r in enumerate(rows, start=1):
        code = r["code"]
        created = format_dt_ddmmyyyy_hhmm(r["created_at"], tz)
        expires = format_dt_ddmmyyyy_hhmm(r["expires_at"], tz) if r["expires_at"] else "без срока"
        row = f"{idx}. <code>{code}</code>\nсоздан: {created}"
        if status in ("active", "expired"):
            row += f"\nдо: {expires}"
        if status == "used":
            used_by = int(r["used_by_user_id"] or 0)
            used_at = format_dt_ddmmyyyy_hhmm(r["used_at"], tz) if r["used_at"] else "—"
            row += f"\nиспользовал TG: <b>{used_by}</b>\nвремя: {used_at}"
        lines.append(row)
    return "\n\n".join(lines)


def _list_kb(rows: list[sqlite3.Row], status: str) -> InlineKeyboardMarkup:
    kb = InlineKeyboardMarkup()
    if status == "active":
        for r in rows:
            sid = int(r["id"])
            suffix = str(r["code"])[-6:]
            kb.row(
                InlineKeyboardButton(
                    f"🚫 Отозвать ...{suffix}",
                    callback_data=f"sc:revoke:{sid}:{status}",
                )
            )
    kb.row(InlineKeyboardButton("⬅️ К меню кодов", callback_data="sc:menu"))
    return kb


def init(bot: TeleBot, ctx: dict) -> None:
    conn: sqlite3.Connection = ctx["conn"]
    tz = ctx["cfg"].TZ

    def _render_menu(c: CallbackQuery) -> None:
        bot.edit_message_text(
            _menu_text(conn, tz),
            c.message.chat.id,
            c.message.message_id,
            reply_markup=_menu_kb(),
        )

    def _render_list(c: CallbackQuery, status: str) -> None:
        rows = repo_student_codes.list_codes(conn, tz, status, limit=_LIST_LIMIT)
        bot.edit_message_text(
            _list_text(rows, status, tz),
            c.message.chat.id,
            c.message.message_id,
            reply_markup=_list_kb(rows, status),
        )

    @bot.callback_query_handler(func=lambda c: c.data in {"m:student_codes", "sc:menu"})
    def sc_menu(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        _render_menu(c)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("sc:create:"))
    def sc_create(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        mode = c.data.split(":")[2]
        ttl = 24 if mode == "24" else None
        row = repo_student_codes.create(conn, tz, c.from_user.id, ttl_hours=ttl)
        expires = format_dt_ddmmyyyy_hhmm(row["expires_at"], tz) if row["expires_at"] else "без срока"
        text = (
            "<b>Код создан</b>\n\n"
            f"Код: <code>{row['code']}</code>\n"
            f"Срок: <b>{expires}</b>\n\n"
            "Передай код ученику для входа по кнопке «Я ученик»."
        )
        bot.edit_message_text(text, c.message.chat.id, c.message.message_id, reply_markup=_menu_kb())
        bot.answer_callback_query(c.id, "Код создан")

    @bot.callback_query_handler(func=lambda c: c.data.startswith("sc:list:"))
    def sc_list(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        status = c.data.split(":")[2]
        _render_list(c, status)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("sc:revoke:"))
    def sc_revoke(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        parts = c.data.split(":")
        code_id = int(parts[2])
        back_status = parts[3] if len(parts) > 3 else "active"
        ok = repo_student_codes.revoke(conn, tz, code_id)
        _render_list(c, back_status)
        bot.answer_callback_query(c.id, "Код отозван" if ok else "Нечего отзывать")
