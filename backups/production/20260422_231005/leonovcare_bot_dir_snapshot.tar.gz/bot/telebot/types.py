from __future__ import annotations

from dataclasses import dataclass

from aiogram.types import CallbackQuery as CallbackQuery
from aiogram.types import Message as Message


@dataclass(slots=True)
class InlineKeyboardButton:
    text: str
    callback_data: str | None = None
    url: str | None = None


class InlineKeyboardMarkup:
    def __init__(self) -> None:
        self.inline_keyboard: list[list[InlineKeyboardButton]] = []

    def row(self, *buttons: InlineKeyboardButton) -> None:
        self.inline_keyboard.append(list(buttons))

    def add(self, *buttons: InlineKeyboardButton) -> None:
        self.row(*buttons)

