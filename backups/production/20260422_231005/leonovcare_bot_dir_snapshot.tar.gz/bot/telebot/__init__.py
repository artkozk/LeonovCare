from __future__ import annotations

import asyncio
import concurrent.futures
import os
import threading
from dataclasses import dataclass
from typing import Any, Callable

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.exceptions import TelegramBadRequest, TelegramConflictError, TelegramForbiddenError
from aiogram.types import InlineKeyboardButton as AioInlineKeyboardButton
from aiogram.types import InlineKeyboardMarkup as AioInlineKeyboardMarkup
from aiogram.types import Message

from .apihelper import ApiTelegramException
from .types import InlineKeyboardMarkup


@dataclass(slots=True)
class _MessageHandlerSpec:
    handler: Callable[[Any], Any]
    commands: set[str] | None
    func: Callable[[Any], bool] | None
    content_types: set[str]


@dataclass(slots=True)
class _CallbackHandlerSpec:
    handler: Callable[[Any], Any]
    func: Callable[[Any], bool] | None


class TeleBot:
    def __init__(self, token: str, parse_mode: str | None = None, worker_threads: int | None = None) -> None:
        default = DefaultBotProperties(parse_mode=parse_mode) if parse_mode else None
        self._bot = Bot(token=token, default=default)
        self._dp = Dispatcher()
        self._message_handlers: list[_MessageHandlerSpec] = []
        self._callback_handlers: list[_CallbackHandlerSpec] = []
        self._registered = False
        self._handler_executor = concurrent.futures.ThreadPoolExecutor(
            max_workers=max(2, int(worker_threads or (os.cpu_count() or 4) * 4)),
            thread_name_prefix="bot-handler",
        )

        self._loop = asyncio.new_event_loop()
        self._loop_ready = threading.Event()
        self._loop_thread = threading.Thread(target=self._run_loop, name="aiogram-loop", daemon=True)
        self._loop_thread.start()
        self._loop_ready.wait()

    def _run_loop(self) -> None:
        asyncio.set_event_loop(self._loop)
        self._loop_ready.set()
        self._loop.run_forever()

    def _run_coro(self, coro: Any) -> Any:
        fut = asyncio.run_coroutine_threadsafe(coro, self._loop)
        return fut.result()

    def _register_dispatcher_handlers(self) -> None:
        if self._registered:
            return
        self._registered = True

        @self._dp.message()
        async def _on_message(message: Any) -> None:
            await self._dispatch_message(message)

        @self._dp.callback_query()
        async def _on_callback(callback_query: Any) -> None:
            await self._dispatch_callback(callback_query)

    def message_handler(
        self,
        commands: list[str] | tuple[str, ...] | None = None,
        func: Callable[[Any], bool] | None = None,
        content_types: list[str] | tuple[str, ...] | None = None,
    ) -> Callable[[Callable[[Any], Any]], Callable[[Any], Any]]:
        command_set = {str(c).lower() for c in commands} if commands else None
        type_set = {self._normalize_content_type(t) for t in (content_types or ["text"])}

        def decorator(handler: Callable[[Any], Any]) -> Callable[[Any], Any]:
            self._message_handlers.append(
                _MessageHandlerSpec(
                    handler=handler,
                    commands=command_set,
                    func=func,
                    content_types=type_set,
                )
            )
            return handler

        return decorator

    def callback_query_handler(
        self,
        func: Callable[[Any], bool] | None = None,
    ) -> Callable[[Callable[[Any], Any]], Callable[[Any], Any]]:
        def decorator(handler: Callable[[Any], Any]) -> Callable[[Any], Any]:
            self._callback_handlers.append(_CallbackHandlerSpec(handler=handler, func=func))
            return handler

        return decorator

    async def _dispatch_message(self, message: Any) -> None:
        msg_type = self._normalize_content_type(getattr(message, "content_type", "text"))
        for h in self._message_handlers:
            if msg_type not in h.content_types:
                continue
            if h.commands is not None and not self._match_command(message, h.commands):
                continue
            if h.func is not None:
                try:
                    if not await self._run_filter(h.func, message):
                        continue
                except Exception:
                    continue
            await self._invoke_handler(h.handler, message)
            return

    async def _dispatch_callback(self, callback_query: Any) -> None:
        for h in self._callback_handlers:
            if h.func is not None:
                try:
                    if not await self._run_filter(h.func, callback_query):
                        continue
                except Exception:
                    continue
            await self._invoke_handler(h.handler, callback_query)
            return

    async def _run_filter(self, func: Callable[[Any], bool], obj: Any) -> bool:
        if asyncio.iscoroutinefunction(func):
            return bool(await func(obj))
        loop = asyncio.get_running_loop()
        return bool(await loop.run_in_executor(self._handler_executor, lambda: func(obj)))

    async def _invoke_handler(self, handler: Callable[[Any], Any], obj: Any) -> None:
        if asyncio.iscoroutinefunction(handler):
            await handler(obj)
            return
        loop = asyncio.get_running_loop()
        await loop.run_in_executor(self._handler_executor, lambda: handler(obj))

    @staticmethod
    def _match_command(message: Any, commands: set[str]) -> bool:
        text = getattr(message, "text", None) or ""
        if not text.startswith("/"):
            return False
        cmd = text[1:].split()[0].split("@")[0].lower()
        return cmd in commands

    @staticmethod
    def _normalize_content_type(content_type: Any) -> str:
        """Return stable lowercase content type name across aiogram enum/string forms."""
        if content_type is None:
            return "text"
        val = getattr(content_type, "value", None)
        if isinstance(val, str) and val:
            return val.lower()
        if isinstance(content_type, str):
            s = content_type.strip()
            if "." in s:
                s = s.split(".", 1)[1]
            return s.lower() or "text"
        s = str(content_type).strip()
        if "." in s:
            s = s.split(".", 1)[1]
        return s.lower() or "text"

    @staticmethod
    def _convert_markup(markup: Any) -> Any:
        if markup is None:
            return None
        if isinstance(markup, AioInlineKeyboardMarkup):
            return markup
        if isinstance(markup, InlineKeyboardMarkup):
            rows: list[list[AioInlineKeyboardButton]] = []
            for row in markup.inline_keyboard:
                rows.append(
                    [
                        AioInlineKeyboardButton(
                            text=btn.text,
                            callback_data=btn.callback_data,
                            url=btn.url,
                        )
                        for btn in row
                    ]
                )
            return AioInlineKeyboardMarkup(inline_keyboard=rows)
        return markup

    @staticmethod
    def _wrap_telegram_error(exc: Exception) -> ApiTelegramException:
        if isinstance(exc, TelegramBadRequest):
            return ApiTelegramException(str(exc), error_code=400)
        if isinstance(exc, TelegramConflictError):
            return ApiTelegramException(str(exc), error_code=409)
        if isinstance(exc, TelegramForbiddenError):
            return ApiTelegramException(str(exc), error_code=403)
        return ApiTelegramException(str(exc), error_code=None)

    def send_message(self, chat_id: int, text: str, reply_markup: Any = None, **kwargs: Any) -> Message:
        try:
            return self._run_coro(
                self._bot.send_message(
                    chat_id=chat_id,
                    text=text,
                    reply_markup=self._convert_markup(reply_markup),
                    **kwargs,
                )
            )
        except Exception as exc:
            raise self._wrap_telegram_error(exc) from exc

    def send_document(
        self,
        chat_id: int,
        document: Any,
        caption: str | None = None,
        reply_markup: Any = None,
        **kwargs: Any,
    ) -> Message:
        try:
            return self._run_coro(
                self._bot.send_document(
                    chat_id=chat_id,
                    document=document,
                    caption=caption,
                    reply_markup=self._convert_markup(reply_markup),
                    **kwargs,
                )
            )
        except Exception as exc:
            raise self._wrap_telegram_error(exc) from exc

    def send_photo(
        self,
        chat_id: int,
        photo: Any,
        caption: str | None = None,
        reply_markup: Any = None,
        **kwargs: Any,
    ) -> Message:
        try:
            return self._run_coro(
                self._bot.send_photo(
                    chat_id=chat_id,
                    photo=photo,
                    caption=caption,
                    reply_markup=self._convert_markup(reply_markup),
                    **kwargs,
                )
            )
        except Exception as exc:
            raise self._wrap_telegram_error(exc) from exc

    def send_video(
        self,
        chat_id: int,
        video: Any,
        caption: str | None = None,
        reply_markup: Any = None,
        **kwargs: Any,
    ) -> Message:
        try:
            return self._run_coro(
                self._bot.send_video(
                    chat_id=chat_id,
                    video=video,
                    caption=caption,
                    reply_markup=self._convert_markup(reply_markup),
                    **kwargs,
                )
            )
        except Exception as exc:
            raise self._wrap_telegram_error(exc) from exc

    def send_animation(
        self,
        chat_id: int,
        animation: Any,
        caption: str | None = None,
        reply_markup: Any = None,
        **kwargs: Any,
    ) -> Message:
        try:
            return self._run_coro(
                self._bot.send_animation(
                    chat_id=chat_id,
                    animation=animation,
                    caption=caption,
                    reply_markup=self._convert_markup(reply_markup),
                    **kwargs,
                )
            )
        except Exception as exc:
            raise self._wrap_telegram_error(exc) from exc

    def send_audio(
        self,
        chat_id: int,
        audio: Any,
        caption: str | None = None,
        reply_markup: Any = None,
        **kwargs: Any,
    ) -> Message:
        try:
            return self._run_coro(
                self._bot.send_audio(
                    chat_id=chat_id,
                    audio=audio,
                    caption=caption,
                    reply_markup=self._convert_markup(reply_markup),
                    **kwargs,
                )
            )
        except Exception as exc:
            raise self._wrap_telegram_error(exc) from exc

    def send_voice(
        self,
        chat_id: int,
        voice: Any,
        caption: str | None = None,
        reply_markup: Any = None,
        **kwargs: Any,
    ) -> Message:
        try:
            return self._run_coro(
                self._bot.send_voice(
                    chat_id=chat_id,
                    voice=voice,
                    caption=caption,
                    reply_markup=self._convert_markup(reply_markup),
                    **kwargs,
                )
            )
        except Exception as exc:
            raise self._wrap_telegram_error(exc) from exc

    def copy_message(
        self,
        chat_id: int,
        from_chat_id: int,
        message_id: int,
        **kwargs: Any,
    ) -> Any:
        try:
            return self._run_coro(
                self._bot.copy_message(
                    chat_id=chat_id,
                    from_chat_id=from_chat_id,
                    message_id=message_id,
                    **kwargs,
                )
            )
        except Exception as exc:
            raise self._wrap_telegram_error(exc) from exc

    def get_chat_member(self, chat_id: int, user_id: int) -> Any:
        try:
            return self._run_coro(self._bot.get_chat_member(chat_id=chat_id, user_id=user_id))
        except Exception as exc:
            raise self._wrap_telegram_error(exc) from exc

    def reply_to(self, message: Any, text: str, reply_markup: Any = None, **kwargs: Any) -> Message:
        return self.send_message(
            chat_id=int(message.chat.id),
            text=text,
            reply_markup=reply_markup,
            reply_to_message_id=int(message.message_id),
            **kwargs,
        )

    def edit_message_text(
        self,
        text: str,
        chat_id: int,
        message_id: int,
        reply_markup: Any = None,
        **kwargs: Any,
    ) -> Any:
        try:
            return self._run_coro(
                self._bot.edit_message_text(
                    chat_id=chat_id,
                    message_id=message_id,
                    text=text,
                    reply_markup=self._convert_markup(reply_markup),
                    **kwargs,
                )
            )
        except Exception as exc:
            raise self._wrap_telegram_error(exc) from exc

    def edit_message_reply_markup(
        self,
        chat_id: int,
        message_id: int,
        reply_markup: Any = None,
        **kwargs: Any,
    ) -> Any:
        try:
            return self._run_coro(
                self._bot.edit_message_reply_markup(
                    chat_id=chat_id,
                    message_id=message_id,
                    reply_markup=self._convert_markup(reply_markup),
                    **kwargs,
                )
            )
        except Exception as exc:
            raise self._wrap_telegram_error(exc) from exc

    def answer_callback_query(
        self,
        callback_query_id: str,
        text: str | None = None,
        show_alert: bool | None = None,
        **kwargs: Any,
    ) -> bool:
        try:
            return self._run_coro(
                self._bot.answer_callback_query(
                    callback_query_id=callback_query_id,
                    text=text,
                    show_alert=show_alert,
                    **kwargs,
                )
            )
        except Exception as exc:
            raise self._wrap_telegram_error(exc) from exc

    def delete_message(self, chat_id: int, message_id: int) -> bool:
        try:
            return self._run_coro(self._bot.delete_message(chat_id=chat_id, message_id=message_id))
        except Exception as exc:
            raise self._wrap_telegram_error(exc) from exc

    def delete_webhook(self, drop_pending_updates: bool = False) -> bool:
        try:
            return self._run_coro(self._bot.delete_webhook(drop_pending_updates=drop_pending_updates))
        except Exception as exc:
            raise self._wrap_telegram_error(exc) from exc

    def infinity_polling(
        self,
        timeout: int | None = None,
        long_polling_timeout: int | None = None,
        skip_pending: bool = False,
        **kwargs: Any,
    ) -> None:
        del timeout, kwargs
        self._register_dispatcher_handlers()

        async def _poll() -> None:
            if skip_pending:
                await self._bot.delete_webhook(drop_pending_updates=True)
            await self._dp.start_polling(
                self._bot,
                polling_timeout=long_polling_timeout or 20,
            )

        fut: concurrent.futures.Future[Any] = asyncio.run_coroutine_threadsafe(_poll(), self._loop)
        try:
            fut.result()
        except Exception as exc:
            raise self._wrap_telegram_error(exc) from exc

    def close(self) -> None:
        try:
            self._run_coro(self._bot.session.close())
        except Exception:
            pass
        self._handler_executor.shutdown(wait=False, cancel_futures=True)
        try:
            self._loop.call_soon_threadsafe(self._loop.stop)
        except Exception:
            pass
