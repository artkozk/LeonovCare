# Server Deploy (Ubuntu + systemd)

## 1) Install base packages
```bash
sudo apt update
sudo apt install -y python3 python3-venv python3-pip
```

## 2) Create service user and app directories
```bash
sudo useradd -r -s /usr/sbin/nologin mentorbot || true
sudo mkdir -p /opt/mentor-bot/data
sudo chown -R mentorbot:mentorbot /opt/mentor-bot
```

## 3) Copy project
Put project files into `/opt/mentor-bot`.

## 4) Create virtual env and install deps
```bash
cd /opt/mentor-bot
python3 -m venv .venv
. .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
```

## 5) Configure env
```bash
cp deploy/env.example .env
nano .env
```
Required values:
- `BOT_TOKEN`
- `ADMIN_IDS`

Strongly recommended:
- `TZ=Europe/Moscow`
- `MATERIALS_GROUP_CHAT_ID`
- `MATERIALS_GROUP_INVITE_URL`

For autoapply integration:
- `AUTOAPPLY_API_BASE_URL`
- `AUTOAPPLY_INTERNAL_TOKEN`
- `AUTOAPPLY_TIMEOUT_SEC`

For enrollment/contracts:
- `CONTRACT_FILE_PATH` (optional: local file sent by bot)
- `OKIDOKI_SIGN_URL` (static sign link fallback)
- `OKIDOKI_CREATE_CONTRACT_URL` (optional HTTP integration for dynamic sign links)
- `OKIDOKI_API_TOKEN` (optional bearer token for OkiDoki integration endpoint)
- `MENTOR_CONTACT_URL`

For payment receipt checks:
- `PAYMENT_EXPECTED_INN`
- `PAYMENT_MAX_AGE_DAYS`
- `PAYMENT_RECEIVER_NAME`
- `PAYMENT_BANK_NAME`
- `PAYMENT_ACCOUNT_NUMBER`
- `PAYMENT_CORR_ACCOUNT`
- `PAYMENT_BIK`
- `PAYMENT_LINK_URL`

## 6) Install systemd unit
```bash
sudo cp deploy/mentor-bot.service /etc/systemd/system/mentor-bot.service
sudo systemctl daemon-reload
sudo systemctl enable mentor-bot
sudo systemctl start mentor-bot
```

## 7) Verify
```bash
sudo systemctl status mentor-bot --no-pager
journalctl -u mentor-bot -f
```

## 8) Integration checks after deploy

### 8.1 Check autoapply API from server
```bash
curl -X POST "$AUTOAPPLY_API_BASE_URL/api/internal/accounts" \
  -H "Content-Type: application/json" \
  -H "X-Internal-Token: $AUTOAPPLY_INTERNAL_TOKEN" \
  -d '{"login":"healthcheck@example.com","password":"secret","direction":"java","targetApplies":5,"queryText":"Java","active":true}'
```

If this request fails, bot autoapply launches will fail too (bot will still notify admin via request).

### 8.2 Check contract settings
- If using static sign link: ensure `OKIDOKI_SIGN_URL` is valid.
- If using dynamic integration: test `OKIDOKI_CREATE_CONTRACT_URL` manually and verify it returns JSON with `sign_url`.
- If sending local contract file: ensure `CONTRACT_FILE_PATH` exists and service user can read it.

### 8.3 Run smoke-check in production venv
```bash
cd /opt/mentor-bot
. .venv/bin/activate
PYTHONPATH='.' python scripts/smoke_check.py
```

## Update flow
```bash
cd /opt/mentor-bot
git pull
. .venv/bin/activate
pip install -r requirements.txt
sudo systemctl restart mentor-bot
```

If schema changed, it is migrated automatically at startup (`ensure_schema()`).

## Notes
- You can still run manually: `python main.py`.
- For best throughput on Linux, `uvloop` is installed automatically from `requirements.txt`.
- If SQLite lock warnings appear under high load, increase `DB_BUSY_TIMEOUT_SEC` and `BOT_WORKER_THREADS` in `.env`.
