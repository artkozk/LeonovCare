from __future__ import annotations

import os
from pathlib import Path

from scripts.preprod_audit import _load_env_file


def test_load_env_file_handles_spaces_and_pipes(tmp_path: Path, monkeypatch) -> None:
    env_path = tmp_path / ".env"
    env_path.write_text(
        "\n".join(
            [
                "PAYMENT_RECEIVER_NAME=IP Oleg Leonov",
                "CARDLINK_BEARER_TOKEN=32956|TOKEN",
                "EMPTY_VALUE=",
            ]
        ),
        encoding="utf-8",
    )
    monkeypatch.delenv("PAYMENT_RECEIVER_NAME", raising=False)
    monkeypatch.delenv("CARDLINK_BEARER_TOKEN", raising=False)
    monkeypatch.delenv("EMPTY_VALUE", raising=False)

    loaded = _load_env_file(env_path)
    assert loaded == 3
    assert "Oleg Leonov" in (os.getenv("PAYMENT_RECEIVER_NAME") or "")
    assert os.getenv("CARDLINK_BEARER_TOKEN") == "32956|TOKEN"
    assert os.getenv("EMPTY_VALUE") == ""
