from __future__ import annotations

from app.services.owner_hh_parser import _normalize_tg_username


def test_normalize_tg_username_accepts_personal_handle() -> None:
    assert _normalize_tg_username("john_dev_123") == "@john_dev_123"


def test_normalize_tg_username_rejects_joinchat_like_values() -> None:
    assert _normalize_tg_username("joinchat") is None
    assert _normalize_tg_username("https://t.me/joinchat/AAAAAE") is None


def test_normalize_tg_username_rejects_non_person_patterns() -> None:
    assert _normalize_tg_username("@space_daily_news") is None
    assert _normalize_tg_username("@company_official") is None
    assert _normalize_tg_username("@awesomehelperbot") is None
