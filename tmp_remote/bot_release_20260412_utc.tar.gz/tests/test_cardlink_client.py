from __future__ import annotations

import json
import unittest
from unittest.mock import patch

from app.services.cardlink_client import CardlinkClient, CardlinkClientError, normalize_status


class _Resp:
    def __init__(self, status_code: int, body: dict | None = None, text: str = "") -> None:
        self.status_code = status_code
        self._body = body or {}
        self.text = text or json.dumps(self._body, ensure_ascii=False)

    def json(self):
        return self._body


class CardlinkClientTests(unittest.TestCase):
    def test_status_mapping(self) -> None:
        self.assertEqual(normalize_status("SUCCESS"), "SUCCEEDED")
        self.assertEqual(normalize_status("PAID"), "SUCCEEDED")
        self.assertEqual(normalize_status("FAILED"), "CANCELED")
        self.assertEqual(normalize_status("NEW"), "PENDING")
        self.assertEqual(normalize_status(None), "PENDING")

    def test_create_payment_extracts_id_and_url(self) -> None:
        cli = CardlinkClient(
            shop_id="G8vrpjx2LR",
            bearer_token="32956|token",
            return_url="https://re.leonovcare.ru",
            api_base_url="https://cardlink.link/api",
        )
        with patch(
            "app.services.cardlink_client.requests.request",
            return_value=_Resp(
                200,
                {
                    "bill": {"id": "bill_123", "status": "NEW"},
                    "url": "https://pay.cardlink.link/bill_123",
                },
            ),
        ):
            data = cli.create_payment(
                amount_rub=5000,
                description="Test payment",
                metadata={"tg": 1},
            )
        self.assertEqual(data["id"], "bill_123")
        self.assertEqual(data["status"], "NEW")
        self.assertEqual(data["confirmation_url"], "https://pay.cardlink.link/bill_123")
        self.assertTrue(data.get("idempotence_key"))

    def test_create_payment_extracts_nested_payment_url(self) -> None:
        cli = CardlinkClient(
            shop_id="G8vrpjx2LR",
            bearer_token="32956|token",
            return_url="https://re.leonovcare.ru",
            api_base_url="https://cardlink.link/api",
        )
        with patch(
            "app.services.cardlink_client.requests.request",
            return_value=_Resp(
                200,
                {
                    "id": "bill_777",
                    "status": "NEW",
                    "data": {
                        "payment_url": "https://cardlink.link/transfer/bill_777",
                    },
                },
            ),
        ):
            data = cli.create_payment(
                amount_rub=5000,
                description="Test nested payment url",
            )
        self.assertEqual(data["id"], "bill_777")
        self.assertEqual(data["confirmation_url"], "https://cardlink.link/transfer/bill_777")

    def test_create_payment_extracts_payment_link_alias(self) -> None:
        cli = CardlinkClient(
            shop_id="G8vrpjx2LR",
            bearer_token="32956|token",
            return_url="https://re.leonovcare.ru",
            api_base_url="https://cardlink.link/api",
        )
        with patch(
            "app.services.cardlink_client.requests.request",
            return_value=_Resp(
                200,
                {
                    "id": "bill_alias",
                    "status": "NEW",
                    "paymentLink": "https://cardlink.link/pay/bill_alias",
                },
            ),
        ):
            data = cli.create_payment(
                amount_rub=7000,
                description="alias payment link",
            )
        self.assertEqual(data["id"], "bill_alias")
        self.assertEqual(data["confirmation_url"], "https://cardlink.link/pay/bill_alias")

    def test_create_payment_extracts_data_short_url_alias(self) -> None:
        cli = CardlinkClient(
            shop_id="G8vrpjx2LR",
            bearer_token="32956|token",
            return_url="https://re.leonovcare.ru",
            api_base_url="https://cardlink.link/api",
        )
        with patch(
            "app.services.cardlink_client.requests.request",
            return_value=_Resp(
                200,
                {
                    "id": "bill_short",
                    "status": "NEW",
                    "data": {
                        "shortUrl": "https://cardlink.link/s/bill_short",
                    },
                },
            ),
        ):
            data = cli.create_payment(
                amount_rub=9000,
                description="short url alias",
            )
        self.assertEqual(data["id"], "bill_short")
        self.assertEqual(data["confirmation_url"], "https://cardlink.link/s/bill_short")

    def test_get_payment_tries_multiple_endpoints(self) -> None:
        cli = CardlinkClient(
            shop_id="G8vrpjx2LR",
            bearer_token="32956|token",
            api_base_url="https://cardlink.link/api",
        )
        calls = {"n": 0}

        def _req(method, url, headers=None, params=None, json=None, timeout=30):
            del method, headers, json, timeout
            calls["n"] += 1
            if calls["n"] == 1:
                return _Resp(404, {"error": "not found"}, text="not found")
            return _Resp(200, {"id": "bill_9", "status": "SUCCESS", "url": "https://pay/card"})

        with patch("app.services.cardlink_client.requests.request", side_effect=_req):
            data = cli.get_payment("bill_9")
        self.assertEqual(data["id"], "bill_9")
        self.assertEqual(data["status"], "SUCCESS")
        self.assertEqual(calls["n"], 2)

    def test_create_payment_without_id_raises(self) -> None:
        cli = CardlinkClient(
            shop_id="G8vrpjx2LR",
            bearer_token="32956|token",
            api_base_url="https://cardlink.link/api",
        )
        with patch(
            "app.services.cardlink_client.requests.request",
            return_value=_Resp(200, {"status": "NEW"}),
        ):
            with self.assertRaises(CardlinkClientError):
                cli.create_payment(amount_rub=1000, description="x")

    def test_create_payment_normalizes_amount_shape(self) -> None:
        cli = CardlinkClient(
            shop_id="G8vrpjx2LR",
            bearer_token="32956|token",
            api_base_url="https://cardlink.link/api",
        )
        with patch(
            "app.services.cardlink_client.requests.request",
            return_value=_Resp(
                200,
                {
                    "id": "bill_42",
                    "status": "NEW",
                    "amount": "5000",
                    "currency": "RUB",
                    "url": "https://pay.cardlink.link/bill_42",
                },
            ),
        ):
            data = cli.create_payment(amount_rub=5000, description="shape test")
        self.assertIsInstance(data.get("amount"), dict)
        self.assertEqual(data["amount"]["value"], "5000")
        self.assertEqual(data["amount"]["currency"], "RUB")


if __name__ == "__main__":
    unittest.main()
