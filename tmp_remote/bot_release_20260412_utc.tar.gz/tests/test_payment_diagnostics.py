from __future__ import annotations

import unittest

from app.services.cardlink_client import CardlinkClientError
from app.services.payment_diagnostics import (
    build_enrollment_tariff_cases,
    build_service_point_cases,
    extract_rub_amount,
    format_cardlink_diagnostics_report,
    run_cardlink_diagnostics,
)


class _FakeClientOk:
    def __init__(self) -> None:
        self._i = 0

    def create_payment(self, amount_rub: int, description: str, metadata=None):
        self._i += 1
        return {
            "id": f"bill_{self._i}",
            "status": "NEW",
            "confirmation_url": f"https://pay/{self._i}",
            "amount": {"currency": "RUB", "value": str(amount_rub)},
        }

    def get_payment(self, payment_id: str):
        return {"id": payment_id, "status": "SUCCESS"}


class _FakeClientPartiallyBroken(_FakeClientOk):
    def get_payment(self, payment_id: str):
        if payment_id.endswith("2"):
            raise CardlinkClientError("broken check")
        return {"id": payment_id, "status": "SUCCESS"}


class PaymentDiagnosticsTests(unittest.TestCase):
    def test_extract_rub_amount(self) -> None:
        self.assertEqual(extract_rub_amount("60 000 ₽ + 100%"), 60000)
        self.assertEqual(extract_rub_amount("4 990 ₽"), 4990)
        self.assertEqual(extract_rub_amount(""), 0)
        self.assertEqual(extract_rub_amount(None), 0)

    def test_build_cases(self) -> None:
        tracks = {
            "zero-offer": {
                "title": "С нуля до оффера",
                "plans": [
                    {"key": "a100", "title": "Сопровождение", "price": "60 000 ₽ + 100%"},
                    {"key": "diag", "title": "Диагностика", "price": "8 900 ₽"},
                ],
            }
        }
        enroll = build_enrollment_tariff_cases(tracks)
        self.assertEqual(len(enroll), 2)
        self.assertEqual(enroll[0]["point"], "ENROLLMENT_PAYMENT")
        service = build_service_point_cases(500)
        self.assertEqual(len(service), 3)
        self.assertEqual(service[-1]["amount"], 500)

    def test_run_and_format_report(self) -> None:
        tracks = {
            "zero-offer": {
                "title": "С нуля до оффера",
                "plans": [{"key": "diag", "title": "Диагностика", "price": "8 900 ₽"}],
            }
        }
        report = run_cardlink_diagnostics(_FakeClientOk(), tracks, 500, 1)
        self.assertEqual(report["total"], 4)  # 1 тариф + 3 сервисные точки
        self.assertEqual(report["failed"], 0)
        txt = format_cardlink_diagnostics_report(report)
        self.assertIn("Проверка оплаты (Cardlink)", txt)
        self.assertIn("INTERVIEW_HELPER_PAYMENT", txt)

    def test_run_marks_failed_when_status_check_breaks(self) -> None:
        tracks = {
            "zero-offer": {
                "title": "С нуля до оффера",
                "plans": [{"key": "diag", "title": "Диагностика", "price": "8 900 ₽"}],
            }
        }
        report = run_cardlink_diagnostics(_FakeClientPartiallyBroken(), tracks, 500, 1)
        self.assertEqual(report["total"], 4)
        self.assertGreaterEqual(report["failed"], 1)


if __name__ == "__main__":
    unittest.main()
