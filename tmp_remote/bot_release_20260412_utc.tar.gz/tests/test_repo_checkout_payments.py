from __future__ import annotations

import sqlite3

from app.db import repo_checkout_payments
from app.db.schema import ensure_schema


def test_create_checkout_payment_row() -> None:
    conn = sqlite3.connect(":memory:")
    conn.row_factory = sqlite3.Row
    ensure_schema(conn)

    row_id = repo_checkout_payments.create(
        conn=conn,
        tz="Europe/Moscow",
        owner_tg_id=123,
        owner_chat_id=456,
        owner_username="mentor",
        req_type="PAYMENT",
        service_key="AUTOAPPLY_PAYMENT",
        service_title="Автоотклики",
        purpose="Оплата автооткликов",
        amount=4990,
        currency="RUB",
        provider_payment_id="pay_test_1",
        provider="cardlink",
        idempotence_key="idem_1",
        status=repo_checkout_payments.STATUS_PENDING,
        confirmation_url="https://pay.example/1",
        metadata={"owner_id": 123},
        provider_payload={"raw": "ok"},
    )

    assert row_id > 0
    row = repo_checkout_payments.get(conn, row_id)
    assert row is not None
    assert int(row["owner_tg_id"]) == 123
    assert str(row["provider"] or "") == "cardlink"
    assert str(row["provider_payment_id"] or "") == "pay_test_1"
    assert str(row["confirmation_url"] or "") == "https://pay.example/1"
