from __future__ import annotations

import datetime as dt
import unittest
from unittest.mock import patch

from scripts.owner_tg_process_replies import (
    _classify,
    _conversation_state_hint,
    _extract_latest_messages,
    _humanize_reply_text,
    _is_duplicate_inbound,
    _llm_chat_completion,
    _looks_like_lead_message,
    _openai_reply,
    _services_overview,
    _should_answer_replied,
    _typical_reply,
)


class _Msg:
    def __init__(self, out: bool, text: str, when: dt.datetime, mid: int = 0):
        self.out = out
        self.raw_text = text
        self.date = when
        self.id = mid


class _Resp:
    def __init__(self, status_code: int, text: str, data: dict | None = None):
        self.status_code = status_code
        self.text = text
        self._data = data

    def json(self) -> dict:
        if self._data is None:
            raise ValueError("invalid json")
        return self._data


class OwnerRepliesCoreTests(unittest.TestCase):
    def test_extract_latest_messages_inbound_first(self) -> None:
        now = dt.datetime(2026, 4, 8, 20, 0, 0)
        messages = [
            _Msg(False, "inbound-new", now),
            _Msg(True, "outbound-prev", now - dt.timedelta(minutes=1)),
            _Msg(False, "inbound-old", now - dt.timedelta(minutes=2)),
        ]
        inbound, inbound_dt, inbound_id, outbound, outbound_dt, outbound_id = _extract_latest_messages(messages)
        self.assertEqual(inbound, "inbound-new")
        self.assertEqual(outbound, "outbound-prev")
        self.assertEqual(inbound_dt, now)
        self.assertEqual(outbound_dt, now - dt.timedelta(minutes=1))
        self.assertEqual(inbound_id, 0)
        self.assertEqual(outbound_id, 0)

    def test_extract_latest_messages_outbound_first(self) -> None:
        now = dt.datetime(2026, 4, 8, 20, 0, 0)
        messages = [
            _Msg(True, "outbound-new", now),
            _Msg(False, "inbound-prev", now - dt.timedelta(minutes=1)),
        ]
        inbound, _, _, outbound, _, _ = _extract_latest_messages(messages)
        self.assertEqual(inbound, "inbound-prev")
        self.assertEqual(outbound, "outbound-new")

    def test_extract_latest_messages_only_inbound(self) -> None:
        now = dt.datetime(2026, 4, 8, 20, 0, 0)
        messages = [_Msg(False, "only-in", now)]
        inbound, _, _, outbound, _, _ = _extract_latest_messages(messages)
        self.assertEqual(inbound, "only-in")
        self.assertEqual(outbound, "")

    def test_extract_latest_messages_only_outbound(self) -> None:
        now = dt.datetime(2026, 4, 8, 20, 0, 0)
        messages = [_Msg(True, "only-out", now)]
        inbound, _, _, outbound, _, _ = _extract_latest_messages(messages)
        self.assertEqual(inbound, "")
        self.assertEqual(outbound, "only-out")

    def test_extract_latest_messages_skips_empty(self) -> None:
        now = dt.datetime(2026, 4, 8, 20, 0, 0)
        messages = [
            _Msg(False, "   ", now),
            _Msg(True, "", now - dt.timedelta(minutes=1)),
            _Msg(False, "real-inbound", now - dt.timedelta(minutes=2)),
            _Msg(True, "real-outbound", now - dt.timedelta(minutes=3)),
        ]
        inbound, _, _, outbound, _, _ = _extract_latest_messages(messages)
        self.assertEqual(inbound, "real-inbound")
        self.assertEqual(outbound, "real-outbound")

    def test_extract_latest_messages_uses_transcribed_voice(self) -> None:
        now = dt.datetime(2026, 4, 8, 20, 0, 0)
        messages = [
            _Msg(False, "", now, mid=101),
            _Msg(True, "outbound-prev", now - dt.timedelta(minutes=1), mid=102),
        ]
        inbound, _, inbound_id, outbound, _, outbound_id = _extract_latest_messages(messages, transcribed_texts={101: "текст из голосового"})
        self.assertEqual(inbound, "текст из голосового")
        self.assertEqual(outbound, "outbound-prev")
        self.assertEqual(inbound_id, 101)
        self.assertEqual(outbound_id, 102)

    def test_extract_latest_messages_mixed_long(self) -> None:
        now = dt.datetime(2026, 4, 8, 20, 0, 0)
        messages = [
            _Msg(False, "new-inbound", now),
            _Msg(False, "older-inbound", now - dt.timedelta(minutes=1)),
            _Msg(True, "latest-outbound", now - dt.timedelta(minutes=2)),
            _Msg(True, "old-outbound", now - dt.timedelta(minutes=3)),
        ]
        inbound, _, _, outbound, _, _ = _extract_latest_messages(messages)
        self.assertEqual(inbound, "new-inbound")
        self.assertEqual(outbound, "latest-outbound")

    def test_duplicate_by_time(self) -> None:
        now = dt.datetime(2026, 4, 8, 20, 0, 0)
        is_dup, reason = _is_duplicate_inbound(
            prev_inbound_text="abc",
            current_inbound_text="abc",
            has_prev_outbound=True,
            inbound_dt=now - dt.timedelta(minutes=1),
            latest_outbound_dt=now,
        )
        self.assertTrue(is_dup)
        self.assertEqual(reason, "outbound_is_newer")

    def test_duplicate_by_message_id(self) -> None:
        is_dup, reason = _is_duplicate_inbound(
            prev_inbound_text="abc",
            current_inbound_text="abc",
            has_prev_outbound=True,
            inbound_dt=None,
            latest_outbound_dt=None,
            inbound_msg_id=100,
            latest_outbound_msg_id=101,
        )
        self.assertTrue(is_dup)
        self.assertEqual(reason, "outbound_id_is_newer_or_equal")

    def test_same_text_is_not_duplicate_without_time_collision(self) -> None:
        is_dup, reason = _is_duplicate_inbound(
            prev_inbound_text="  Привет  ",
            current_inbound_text="привет",
            has_prev_outbound=True,
            inbound_dt=None,
            latest_outbound_dt=None,
        )
        self.assertFalse(is_dup)
        self.assertEqual(reason, "")

    def test_not_duplicate(self) -> None:
        is_dup, reason = _is_duplicate_inbound(
            prev_inbound_text="привет",
            current_inbound_text="как дела",
            has_prev_outbound=True,
            inbound_dt=None,
            latest_outbound_dt=None,
        )
        self.assertFalse(is_dup)
        self.assertEqual(reason, "")

    def test_classify_detects_aktualen_as_interested(self) -> None:
        self.assertEqual(_classify("актуален"), "interested")
        self.assertEqual(_classify("Тема актуальна"), "interested")

    def test_should_answer_replied_for_greeting_and_actual(self) -> None:
        self.assertTrue(_should_answer_replied("Привет"))
        self.assertTrue(_should_answer_replied("Актуален"))
        self.assertTrue(_should_answer_replied("Буду признателен"))
        self.assertTrue(_should_answer_replied("Я не знаю"))
        self.assertTrue(_should_answer_replied("хз"))
        self.assertFalse(_should_answer_replied("Нет, спасибо"))

    def test_humanize_removes_servile_phrases(self) -> None:
        raw = "Нет, мне не пофиг. Я просто хочу быстро понять, чем именно тебе сейчас помочь с поиском."
        cleaned = _humanize_reply_text(raw, inbound_text="я ищу работу")
        self.assertNotIn("чем именно тебе сейчас помочь", cleaned.lower())
        self.assertNotIn("я просто хочу быстро понять", cleaned.lower())

    def test_typical_reply_for_uncertainty_asks_remaining_questions(self) -> None:
        txt = _typical_reply("не знаю я, что нужно", direction="python")
        self.assertNotIn("@leonov_care_bot", txt.lower())
        self.assertIn("опыта", txt.lower())

    def test_conversation_state_hint_marks_known_fields(self) -> None:
        history = (
            "Ментор: Привет\n"
            "Лид: В программировании 7 лет, стек: Go и Python.\n"
            "Лид: Цель — стабильный проект и 250к net.\n"
            "Лид: Основной затык — автоотказы и архитектура.\n"
        )
        hint = _conversation_state_hint(history)
        self.assertIn("Опыт уже известен", hint)
        self.assertIn("Стек уже известен", hint)
        self.assertIn("Цель уже известна", hint)
        self.assertIn("Стопор уже известен", hint)

    def test_services_overview_unknown_direction_is_not_python_locked(self) -> None:
        text = _services_overview("")
        self.assertIn("разным направлениям", text)
        self.assertNotIn("по направлению python", text.lower())

    def test_looks_like_lead_message_handles_who_are_you(self) -> None:
        self.assertTrue(_looks_like_lead_message("Привет, кто ты?"))
        self.assertTrue(_looks_like_lead_message("Что конкретно предлагаешь?"))
        self.assertTrue(_looks_like_lead_message("Не знаю, а опыт 1 год"))
        self.assertTrue(_looks_like_lead_message("хз"))
        self.assertFalse(_looks_like_lead_message("Скинь мем"))

    @patch("scripts.owner_tg_process_replies._llm_chat_completion")
    def test_strict_mode_llm_failure_goes_to_review(self, llm_mock) -> None:
        llm_mock.return_value = (False, 403, "forbidden", "http_non_2xx")
        result = _openai_reply(
            provider="proxy",
            base_url="https://proxy.example.com",
            proxy_auth="token",
            api_key="",
            model="gpt-5.4-mini",
            script_step_text="Скрипт",
            inbound_text="Сколько стоит?",
            direction="java",
            ai_step=1,
            strict_mode=True,
        )
        self.assertTrue(result["needs_review"])
        self.assertEqual(result["decision_source"], "llm_error")
        self.assertEqual(result["llm_status"], "failed")
        self.assertEqual(result["text"], "")

    @patch("scripts.owner_tg_process_replies._llm_chat_completion")
    def test_non_strict_mode_uses_rule_fallback(self, llm_mock) -> None:
        llm_mock.return_value = (False, 500, "upstream", "http_non_2xx")
        result = _openai_reply(
            provider="proxy",
            base_url="https://proxy.example.com",
            proxy_auth="token",
            api_key="",
            model="gpt-5.4-mini",
            script_step_text="Скрипт",
            inbound_text="Как вы можете помочь?",
            direction="python",
            ai_step=2,
            strict_mode=False,
        )
        self.assertFalse(result["needs_review"])
        self.assertEqual(result["decision_source"], "rule_fallback")
        self.assertTrue(bool(result["text"]))

    @patch("scripts.owner_tg_process_replies._llm_chat_completion")
    def test_ai_step_zero_uses_llm_not_forced_script(self, llm_mock) -> None:
        llm_mock.return_value = (True, 200, "Это ответ от LLM", "")
        result = _openai_reply(
            provider="proxy",
            base_url="https://proxy.example.com",
            proxy_auth="token",
            api_key="",
            model="gpt-5.4-mini",
            script_step_text="Скриптовый шаг",
            inbound_text="Актуально",
            direction="java",
            ai_step=0,
            strict_mode=True,
        )
        self.assertFalse(result["needs_review"])
        self.assertEqual(result["decision_source"], "llm")
        self.assertIn("LLM", result["text"])

    @patch("scripts.owner_tg_process_replies._llm_chat_completion")
    def test_guardrail_violation_blocks_answer(self, llm_mock) -> None:
        llm_mock.return_value = (True, 200, "Мы гарантируем оффер за 1 неделю.", "")
        result = _openai_reply(
            provider="proxy",
            base_url="https://proxy.example.com",
            proxy_auth="token",
            api_key="",
            model="gpt-5.4-mini",
            script_step_text="Скрипт",
            inbound_text="Да, тема актуальна",
            direction="java",
            ai_step=1,
            strict_mode=True,
            guardrails={
                "forbidden_substrings": ["гарантируем оффер"],
                "forbidden_regex": [],
                "max_message_chars": 900,
            },
        )
        self.assertTrue(result["needs_review"])
        self.assertEqual(result["decision_source"], "guardrail_blocked")
        self.assertEqual(result["text"], "")

    @patch("scripts.owner_tg_process_replies._llm_chat_completion")
    def test_without_call_phrase_is_rewritten(self, llm_mock) -> None:
        llm_mock.return_value = (True, 200, "Могу быстро подсказать без созвона.", "")
        result = _openai_reply(
            provider="proxy",
            base_url="https://proxy.example.com",
            proxy_auth="token",
            api_key="",
            model="gpt-5.4-mini",
            script_step_text="Скрипт",
            inbound_text="Буду признателен",
            direction="python",
            ai_step=3,
            strict_mode=True,
        )
        self.assertFalse(result["needs_review"])
        self.assertEqual(result["decision_source"], "llm")
        self.assertNotIn("без созвона", result["text"].lower())

    @patch("scripts.owner_tg_process_replies._llm_chat_completion")
    def test_uncertain_input_asks_missing_questions_first(self, llm_mock) -> None:
        llm_mock.return_value = (True, 200, "Я не знаю, чем тебе помочь.", "")
        result = _openai_reply(
            provider="proxy",
            base_url="https://proxy.example.com",
            proxy_auth="token",
            api_key="",
            model="gpt-5.4-mini",
            script_step_text="Скрипт",
            inbound_text="не знаю я, что нужно",
            direction="python",
            ai_step=4,
            strict_mode=True,
        )
        self.assertFalse(result["needs_review"])
        self.assertNotIn("@leonov_care_bot", result["text"].lower())
        self.assertIn("мини-диагност", result["text"].lower())
        self.assertNotIn("чем тебе помочь", result["text"].lower())

    @patch("scripts.owner_tg_process_replies._llm_chat_completion")
    def test_uncertain_input_invites_call_when_diagnostics_complete(self, llm_mock) -> None:
        llm_mock.return_value = (True, 200, "Любой текст", "")
        history = (
            "Лид: опыт 6 лет, java backend.\n"
            "Лид: цель — продуктовая компания и 300к net.\n"
            "Лид: стопор — мало интервью после откликов.\n"
            "Лид: срок — 2-3 месяца.\n"
        )
        result = _openai_reply(
            provider="proxy",
            base_url="https://proxy.example.com",
            proxy_auth="token",
            api_key="",
            model="gpt-5.4-mini",
            script_step_text="Скрипт",
            inbound_text="не знаю",
            direction="java",
            ai_step=4,
            strict_mode=True,
            chat_history=history,
        )
        self.assertFalse(result["needs_review"])
        self.assertIn("@leonov_care_bot", result["text"].lower())
        self.assertIn("диагност", result["text"].lower())

    @patch("scripts.owner_tg_process_replies.requests.post")
    def test_llm_proxy_fallback_to_openai_success(self, post_mock) -> None:
        post_mock.side_effect = [
            ConnectionError("dns failed"),
            _Resp(
                200,
                '{"choices":[{"message":{"content":"ok"}}]}',
                {"choices": [{"message": {"content": "ok"}}]},
            ),
        ]
        ok, code, payload, err = _llm_chat_completion(
            provider="proxy",
            base_url="https://openai-proxy.example.workers.dev",
            proxy_auth="svc-token",
            api_key="sk-test",
            timeout_sec=30,
            body={"model": "gpt-5.4-mini", "messages": [{"role": "user", "content": "hi"}]},
        )
        self.assertTrue(ok)
        self.assertEqual(code, 200)
        self.assertEqual(payload, "ok")
        self.assertEqual(err, "proxy_fallback_openai")
        self.assertEqual(post_mock.call_count, 2)

    @patch("scripts.owner_tg_process_replies.requests.post")
    def test_llm_proxy_fallback_reports_both_errors(self, post_mock) -> None:
        post_mock.side_effect = [
            ConnectionError("dns failed"),
            _Resp(502, "bad gateway", {"error": {"message": "upstream fail"}}),
        ]
        ok, code, payload, err = _llm_chat_completion(
            provider="proxy",
            base_url="https://openai-proxy.example.workers.dev",
            proxy_auth="svc-token",
            api_key="sk-test",
            timeout_sec=30,
            body={"model": "gpt-5.4-mini", "messages": [{"role": "user", "content": "hi"}]},
        )
        self.assertFalse(ok)
        self.assertEqual(code, 502)
        self.assertIn("bad gateway", payload)
        self.assertIn("proxy_failed:http_error", err)
        self.assertIn("openai_failed:http_non_2xx", err)


if __name__ == "__main__":
    unittest.main()
