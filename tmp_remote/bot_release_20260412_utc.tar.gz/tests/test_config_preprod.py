from __future__ import annotations

from app.config import _resolve_default_parser_root, load_config


def test_default_parser_root_detects_autohh_parser() -> None:
    resolved = _resolve_default_parser_root("")
    assert resolved
    assert "AutoHh" in resolved
    assert "parser_hh" in resolved


def test_cardlink_does_not_fallback_to_legacy_oauth_env(monkeypatch) -> None:
    monkeypatch.setenv("BOT_TOKEN", "1:test")
    monkeypatch.setenv("ADMIN_IDS", "1")
    monkeypatch.delenv("CARDLINK_SHOP_ID", raising=False)
    monkeypatch.delenv("CARDLINK_BEARER_TOKEN", raising=False)
    monkeypatch.delenv("CARDLINK_API_TOKEN", raising=False)
    monkeypatch.delenv("CARDLINK_TOKEN", raising=False)
    monkeypatch.delenv("CARDLINK_MERCHANT_ID", raising=False)
    monkeypatch.delenv("YOOKASSA_SHOP_ID", raising=False)
    monkeypatch.delenv("YOOKASSA_SECRET_KEY", raising=False)
    monkeypatch.setenv("YOOKASSA_OAUTH_CLIENT_ID", "legacy-shop-id")
    monkeypatch.setenv("YOOKASSA_OAUTH_CLIENT_SECRET", "legacy-secret")

    cfg = load_config()
    assert cfg.CARDLINK_SHOP_ID == ""
    assert cfg.CARDLINK_BEARER_TOKEN == ""


def test_cardlink_alias_envs(monkeypatch) -> None:
    monkeypatch.setenv("BOT_TOKEN", "1:test")
    monkeypatch.setenv("ADMIN_IDS", "1")
    monkeypatch.delenv("CARDLINK_SHOP_ID", raising=False)
    monkeypatch.delenv("CARDLINK_BEARER_TOKEN", raising=False)
    monkeypatch.setenv("CARDLINK_MERCHANT_ID", "merchant-42")
    monkeypatch.setenv("CARDLINK_API_TOKEN", "token-42")

    cfg = load_config()
    assert cfg.CARDLINK_SHOP_ID == "merchant-42"
    assert cfg.CARDLINK_BEARER_TOKEN == "token-42"
