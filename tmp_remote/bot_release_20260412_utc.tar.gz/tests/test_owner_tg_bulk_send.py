from scripts.owner_tg_bulk_send import _parse_generic_proxy, _parse_mtproxy, _resolve_proxy


def test_parse_mtproxy_tg_url() -> None:
    raw = "tg://proxy?server=195.133.66.30&port=8443&secret=abc123"
    assert _parse_mtproxy(raw) == ("195.133.66.30", 8443, "abc123")


def test_parse_mtproxy_host_port_secret() -> None:
    raw = "195.133.66.30:8443:abc123"
    assert _parse_mtproxy(raw) == ("195.133.66.30", 8443, "abc123")


def test_parse_mtproxy_bad_value() -> None:
    assert _parse_mtproxy("http://example.com") is None
    assert _parse_mtproxy("tg://proxy?server=&port=8443&secret=s") is None


def test_parse_http_host_port_user_pass() -> None:
    proxy = _parse_generic_proxy("141.11.162.95:47198:PSJ3ETN5:2S3W79O2")
    assert isinstance(proxy, dict)
    assert proxy["proxy_type"] == "http"
    assert proxy["addr"] == "141.11.162.95"
    assert proxy["port"] == 47198
    assert proxy["username"] == "PSJ3ETN5"
    assert proxy["password"] == "2S3W79O2"


def test_resolve_proxy_prefers_mtproxy_when_tg_scheme() -> None:
    res = _resolve_proxy("tg://proxy?server=1.2.3.4&port=443&secret=abc")
    assert res is not None
    assert res[0] == "mtproxy"


def test_resolve_proxy_supports_socks5_url() -> None:
    res = _resolve_proxy("socks5://user:pass@127.0.0.1:1080")
    assert res is not None
    assert res[0] == "socks5"


def test_resolve_proxy_supports_http_url() -> None:
    res = _resolve_proxy("http://user:pass@127.0.0.1:8080")
    assert res is not None
    assert res[0] == "http"
