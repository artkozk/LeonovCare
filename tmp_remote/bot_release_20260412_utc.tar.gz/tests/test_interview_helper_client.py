from __future__ import annotations

from datetime import datetime, timedelta, timezone

from app.services.interview_helper_client import InterviewHelperClient


def test_cached_token_with_naive_expiry_does_not_crash(monkeypatch) -> None:
    client = InterviewHelperClient(
        base_url="http://localhost:8080",
        admin_username="admin",
        admin_password="pass",
    )
    client._cached_token = "cached"
    client._cached_token_expires_at = (
        datetime.now(timezone.utc) + timedelta(minutes=10)
    ).replace(tzinfo=None)  # naive datetime

    # Should return cached token and not attempt re-login.
    monkeypatch.setattr(client, "_login", lambda: (_ for _ in ()).throw(RuntimeError("must not call login")))
    assert client._token() == "cached"


def test_expired_cached_token_requests_new_token(monkeypatch) -> None:
    client = InterviewHelperClient(
        base_url="http://localhost:8080",
        admin_username="admin",
        admin_password="pass",
    )
    client._cached_token = "old"
    client._cached_token_expires_at = (
        datetime.now(timezone.utc) - timedelta(minutes=1)
    ).replace(tzinfo=None)  # naive expired datetime
    monkeypatch.setattr(
        client,
        "_login",
        lambda: ("new-token", datetime.now(timezone.utc) + timedelta(minutes=30)),
    )
    assert client._token() == "new-token"
