# interview-assistant (локальная копия)

Локальная копия сервиса Interview Helper, перенесенная с прод-сервера 2026-03-25.

Источник:
- `/tmp/interview-src` на сервере `85.198.82.221`.

Состав:
- `pom.xml`;
- `src/main/java/...`;
- `src/main/resources/application.yml`.

Важно:
- runtime-база данных (`data/*.db`) в репозиторий не добавляется.
