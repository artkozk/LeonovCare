package org.example.api;

import org.example.dto.ApiException;
import org.example.dto.LicenseStatusResponse;
import org.example.service.LicenseService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping({"/api/v1/license", "/api/v1/licenses"})
public class LicenseController {
    private final LicenseService licenseService;

    public LicenseController(LicenseService licenseService) {
        this.licenseService = licenseService;
    }

    public record LicenseStatusRequest(String key, String licenseKey, String code) {}

    @GetMapping({"/status", "/check", "/validate"})
    public LicenseStatusResponse statusGet(
            @RequestHeader(value = "X-License-Key", required = false) String headerKey,
            @RequestParam(value = "key", required = false) String keyParam,
            @RequestParam(value = "licenseKey", required = false) String licenseKeyParam,
            @RequestParam(value = "code", required = false) String codeParam
    ) {
        String key = resolveKey(headerKey, keyParam, licenseKeyParam, codeParam);
        return licenseService.status(key);
    }

    @PostMapping({"/status", "/check", "/validate"})
    public LicenseStatusResponse statusPost(
            @RequestHeader(value = "X-License-Key", required = false) String headerKey,
            @RequestParam(value = "key", required = false) String keyParam,
            @RequestParam(value = "licenseKey", required = false) String licenseKeyParam,
            @RequestParam(value = "code", required = false) String codeParam,
            @RequestBody(required = false) LicenseStatusRequest body
    ) {
        String bodyKey = body == null ? null : body.key();
        String bodyLicenseKey = body == null ? null : body.licenseKey();
        String bodyCode = body == null ? null : body.code();
        String key = resolveKey(headerKey, keyParam, licenseKeyParam, codeParam, bodyKey, bodyLicenseKey, bodyCode);
        return licenseService.status(key);
    }

    private static String resolveKey(String... candidates) {
        if (candidates == null) {
            throw new ApiException(HttpStatus.FORBIDDEN, "LICENSE_MISSING", "License key is required", Map.of());
        }
        for (String candidate : candidates) {
            if (candidate == null) {
                continue;
            }
            String trimmed = candidate.trim();
            if (!trimmed.isEmpty()) {
                return trimmed;
            }
        }
        throw new ApiException(HttpStatus.FORBIDDEN, "LICENSE_MISSING", "License key is required", Map.of());
    }
}
