package org.example.service;

import org.example.config.LicenseProperties;
import org.example.dto.ApiException;
import org.example.dto.LicenseStatusResponse;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.Instant;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.atomic.AtomicLong;

@Service
public class LicenseService {
    private static final int DEFAULT_MAX_HINTS_PER_DAY = 200;
    private static final int DEFAULT_MAX_SNAPSHOTS_PER_DAY = 200;
    private static final int DEFAULT_MAX_AUDIO_SECONDS_PER_HINT = 180;

    private final LicenseProperties props;
    private final ConcurrentMap<String, DynamicLicense> issued = new ConcurrentHashMap<>();
    private final AtomicLong dynamicId = new AtomicLong(1);

    public LicenseService(LicenseProperties props) {
        this.props = props;
    }

    public record LicenseView(String key, boolean enabled, Instant expiresAt, String plan) {}

    public record DynamicLicense(
            long id,
            String key,
            boolean enabled,
            Instant expiresAt,
            String plan,
            String note,
            Instant createdAt
    ) {}

    public LicenseView requireValid(String licenseKey) {
        if (licenseKey == null || licenseKey.isBlank()) {
            throw new ApiException(HttpStatus.FORBIDDEN, "LICENSE_MISSING",
                    "X-License-Key header is required", Map.of());
        }

        var entry = resolve(licenseKey.trim());
        if (entry == null) {
            throw new ApiException(HttpStatus.FORBIDDEN, "LICENSE_INVALID",
                    "License key not found", Map.of());
        }
        if (!entry.enabled()) {
            throw new ApiException(HttpStatus.FORBIDDEN, "LICENSE_DISABLED",
                    "License is disabled", Map.of());
        }
        if (entry.expiresAt() != null && Instant.now().isAfter(entry.expiresAt())) {
            throw new ApiException(HttpStatus.FORBIDDEN, "LICENSE_EXPIRED",
                    "License is expired", Map.of("expiresAt", entry.expiresAt().toString()));
        }
        return entry;
    }

    public DynamicLicense issue(String plan, Instant expiresAt, String note) {
        String normalizedPlan = (plan == null || plan.isBlank()) ? "PRO" : plan.trim().toUpperCase(Locale.ROOT);
        Instant normalizedExpiresAt = expiresAt != null ? expiresAt : Instant.now().plus(Duration.ofDays(30));
        String key = generateUniqueKey();
        DynamicLicense created = new DynamicLicense(
                dynamicId.getAndIncrement(),
                key,
                true,
                normalizedExpiresAt,
                normalizedPlan,
                note == null ? "" : note.trim(),
                Instant.now()
        );
        issued.put(key, created);
        return created;
    }

    public LicenseStatusResponse status(String licenseKey) {
        LicenseView entry = requireKnown(licenseKey);
        String status = computeStatus(entry);
        return new LicenseStatusResponse(
                status,
                entry.plan(),
                new LicenseStatusResponse.Limits(
                        DEFAULT_MAX_HINTS_PER_DAY,
                        DEFAULT_MAX_SNAPSHOTS_PER_DAY,
                        DEFAULT_MAX_AUDIO_SECONDS_PER_HINT
                ),
                new LicenseStatusResponse.UsageToday(0, 0, 0)
        );
    }

    private LicenseView requireKnown(String licenseKey) {
        if (licenseKey == null || licenseKey.isBlank()) {
            throw new ApiException(HttpStatus.FORBIDDEN, "LICENSE_MISSING",
                    "X-License-Key header is required", Map.of());
        }
        LicenseView entry = resolve(licenseKey.trim());
        if (entry == null) {
            throw new ApiException(HttpStatus.FORBIDDEN, "LICENSE_INVALID",
                    "License key not found", Map.of());
        }
        return entry;
    }

    private String computeStatus(LicenseView entry) {
        if (!entry.enabled()) {
            return "DISABLED";
        }
        if (entry.expiresAt() != null && Instant.now().isAfter(entry.expiresAt())) {
            return "EXPIRED";
        }
        return "ACTIVE";
    }

    private LicenseView resolve(String key) {
        DynamicLicense dynamic = issued.get(key);
        if (dynamic != null) {
            return new LicenseView(dynamic.key(), dynamic.enabled(), dynamic.expiresAt(), dynamic.plan());
        }

        if (props.keys() != null) {
            for (var k : props.keys()) {
                if (key.equals(k.key())) {
                    String plan = (k.plan() == null || k.plan().isBlank()) ? "PRO" : k.plan();
                    return new LicenseView(k.key(), k.enabled(), k.expiresAt(), plan);
                }
            }
        }
        return null;
    }

    private String generateUniqueKey() {
        for (int i = 0; i < 20; i++) {
            String raw = UUID.randomUUID().toString().replace("-", "").toUpperCase(Locale.ROOT);
            String candidate = "IH-" + raw.substring(0, 8) + "-" + raw.substring(8, 12);
            if (resolve(candidate) == null) {
                return candidate;
            }
        }
        throw new ApiException(HttpStatus.INTERNAL_SERVER_ERROR, "LICENSE_GENERATION_FAILED",
                "Could not generate unique license key", Map.of());
    }
}
