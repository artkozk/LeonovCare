package org.example.api;

import org.example.dto.ApiException;
import org.example.service.AdminAuthService;
import org.example.service.LicenseService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.Instant;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/admin")
public class AdminController {
    private final AdminAuthService authService;
    private final LicenseService licenseService;

    public AdminController(AdminAuthService authService, LicenseService licenseService) {
        this.authService = authService;
        this.licenseService = licenseService;
    }

    public record LoginRequest(String username, String password) {}
    public record LoginResponse(String token, String expiresAt) {}

    public record CreateLicenseRequest(String plan, String expiresAt, String note) {}
    public record CreateLicenseResponse(
            long id,
            String key,
            String plan,
            boolean enabled,
            String expiresAt,
            String note
    ) {}

    @PostMapping("/login")
    public LoginResponse login(@RequestBody LoginRequest req) {
        String username = req == null ? "" : req.username();
        String password = req == null ? "" : req.password();
        var auth = authService.login(username, password);
        return new LoginResponse(auth.token(), auth.expiresAt().toString());
    }

    @PostMapping("/licenses")
    public CreateLicenseResponse createLicense(
            @RequestHeader(value = "Authorization", required = false) String authorization,
            @RequestBody CreateLicenseRequest req
    ) {
        authService.requireBearer(authorization);
        Instant expiresAt = parseExpiresAt(req == null ? null : req.expiresAt());
        String plan = req == null ? null : req.plan();
        String note = req == null ? null : req.note();
        var created = licenseService.issue(plan, expiresAt, note);
        return new CreateLicenseResponse(
                created.id(),
                created.key(),
                created.plan(),
                created.enabled(),
                created.expiresAt() == null ? "" : created.expiresAt().toString(),
                created.note()
        );
    }

    private static Instant parseExpiresAt(String raw) {
        if (raw == null || raw.isBlank()) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "BAD_EXPIRES_AT", "expiresAt is required", Map.of());
        }
        try {
            return Instant.parse(raw.trim());
        } catch (Exception e) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "BAD_EXPIRES_AT", "expiresAt must be ISO-8601 UTC", Map.of());
        }
    }
}
