package org.example.service;

import org.example.dto.ApiException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.Instant;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

@Service
public class AdminAuthService {
    private static final Duration TOKEN_TTL = Duration.ofHours(12);

    private final String expectedUsername;
    private final String expectedPassword;
    private final ConcurrentMap<String, Instant> tokens = new ConcurrentHashMap<>();

    public AdminAuthService() {
        this.expectedUsername = readEnvOrDefault("INTERVIEW_API_ADMIN_USERNAME", "admin");
        this.expectedPassword = readEnvOrDefault("INTERVIEW_API_ADMIN_PASSWORD", "change-me-123");
    }

    public record LoginResult(String token, Instant expiresAt) {}

    public LoginResult login(String username, String password) {
        String u = username == null ? "" : username.trim();
        String p = password == null ? "" : password.trim();
        if (!expectedUsername.equals(u) || !expectedPassword.equals(p)) {
            throw new ApiException(HttpStatus.UNAUTHORIZED, "AUTH_FAILED", "Invalid admin credentials", Map.of());
        }

        String token = "ihadm_" + UUID.randomUUID().toString().replace("-", "");
        Instant expiresAt = Instant.now().plus(TOKEN_TTL);
        tokens.put(token, expiresAt);
        return new LoginResult(token, expiresAt);
    }

    public void requireBearer(String authorizationHeader) {
        String token = extractBearerToken(authorizationHeader);
        Instant expiresAt = tokens.get(token);
        if (expiresAt == null) {
            throw new ApiException(HttpStatus.UNAUTHORIZED, "AUTH_REQUIRED", "Admin token is required", Map.of());
        }
        if (Instant.now().isAfter(expiresAt)) {
            tokens.remove(token);
            throw new ApiException(HttpStatus.UNAUTHORIZED, "AUTH_EXPIRED", "Admin token expired", Map.of());
        }
    }

    private static String extractBearerToken(String authorizationHeader) {
        String raw = authorizationHeader == null ? "" : authorizationHeader.trim();
        if (raw.isBlank()) {
            throw new ApiException(HttpStatus.UNAUTHORIZED, "AUTH_REQUIRED", "Authorization header is required", Map.of());
        }
        String lower = raw.toLowerCase(Locale.ROOT);
        if (!lower.startsWith("bearer ")) {
            throw new ApiException(HttpStatus.UNAUTHORIZED, "AUTH_REQUIRED", "Bearer token is required", Map.of());
        }
        String token = raw.substring(7).trim();
        if (token.isBlank()) {
            throw new ApiException(HttpStatus.UNAUTHORIZED, "AUTH_REQUIRED", "Bearer token is empty", Map.of());
        }
        return token;
    }

    private static String readEnvOrDefault(String key, String def) {
        String val = System.getenv(key);
        if (val == null || val.isBlank()) {
            return def;
        }
        return val.trim();
    }
}
