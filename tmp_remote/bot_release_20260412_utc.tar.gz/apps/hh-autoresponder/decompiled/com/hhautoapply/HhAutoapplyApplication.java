/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.springframework.boot.SpringApplication
 *  org.springframework.boot.autoconfigure.SpringBootApplication
 *  org.springframework.boot.context.properties.EnableConfigurationProperties
 *  org.springframework.scheduling.annotation.EnableScheduling
 */
package com.hhautoapply;

import com.hhautoapply.config.HhAccountsProperties;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
@EnableConfigurationProperties(value={HhAccountsProperties.class})
public class HhAutoapplyApplication {
    public static void main(String[] args) {
        SpringApplication.run(HhAutoapplyApplication.class, (String[])args);
    }
}

