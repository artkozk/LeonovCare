/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.springframework.data.jpa.repository.JpaRepository
 */
package com.hhautoapply.repository;

import com.hhautoapply.model.HhAccountEntity;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HhAccountRepository
extends JpaRepository<HhAccountEntity, Long> {
    public Optional<HhAccountEntity> findByLogin(String var1);

    public boolean existsByLogin(String var1);

    public void deleteByLogin(String var1);

    public List<HhAccountEntity> findAllByActiveTrueOrderByIdAsc();
}

