/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 *  org.springframework.boot.context.properties.ConfigurationProperties
 *  org.springframework.stereotype.Component
 */
package com.hhautoapply.config;

import java.util.ArrayList;
import java.util.List;
import lombok.Generated;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix="app")
public class AppProps {
    private List<Account> accounts = new ArrayList<Account>();
    private DailyRun dailyRun = new DailyRun();

    @Generated
    public AppProps() {
    }

    @Generated
    public List<Account> getAccounts() {
        return this.accounts;
    }

    @Generated
    public DailyRun getDailyRun() {
        return this.dailyRun;
    }

    @Generated
    public void setAccounts(List<Account> accounts) {
        this.accounts = accounts;
    }

    @Generated
    public void setDailyRun(DailyRun dailyRun) {
        this.dailyRun = dailyRun;
    }

    @Generated
    public boolean equals(Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof AppProps)) {
            return false;
        }
        AppProps other = (AppProps)o;
        if (!other.canEqual(this)) {
            return false;
        }
        List<Account> this$accounts = this.getAccounts();
        List<Account> other$accounts = other.getAccounts();
        if (this$accounts == null ? other$accounts != null : !((Object)this$accounts).equals(other$accounts)) {
            return false;
        }
        DailyRun this$dailyRun = this.getDailyRun();
        DailyRun other$dailyRun = other.getDailyRun();
        return !(this$dailyRun == null ? other$dailyRun != null : !((Object)this$dailyRun).equals(other$dailyRun));
    }

    @Generated
    protected boolean canEqual(Object other) {
        return other instanceof AppProps;
    }

    @Generated
    public int hashCode() {
        int PRIME = 59;
        int result = 1;
        List<Account> $accounts = this.getAccounts();
        result = result * 59 + ($accounts == null ? 43 : ((Object)$accounts).hashCode());
        DailyRun $dailyRun = this.getDailyRun();
        result = result * 59 + ($dailyRun == null ? 43 : ((Object)$dailyRun).hashCode());
        return result;
    }

    @Generated
    public String toString() {
        return "AppProps(accounts=" + String.valueOf(this.getAccounts()) + ", dailyRun=" + String.valueOf(this.getDailyRun()) + ")";
    }

    public static class DailyRun {
        private Boolean enabled = false;
        private String cron = "0 0 9 * * *";
        private String zone = "Europe/Kaliningrad";

        @Generated
        public DailyRun() {
        }

        @Generated
        public Boolean getEnabled() {
            return this.enabled;
        }

        @Generated
        public String getCron() {
            return this.cron;
        }

        @Generated
        public String getZone() {
            return this.zone;
        }

        @Generated
        public void setEnabled(Boolean enabled) {
            this.enabled = enabled;
        }

        @Generated
        public void setCron(String cron) {
            this.cron = cron;
        }

        @Generated
        public void setZone(String zone) {
            this.zone = zone;
        }

        @Generated
        public boolean equals(Object o) {
            if (o == this) {
                return true;
            }
            if (!(o instanceof DailyRun)) {
                return false;
            }
            DailyRun other = (DailyRun)o;
            if (!other.canEqual(this)) {
                return false;
            }
            Boolean this$enabled = this.getEnabled();
            Boolean other$enabled = other.getEnabled();
            if (this$enabled == null ? other$enabled != null : !((Object)this$enabled).equals(other$enabled)) {
                return false;
            }
            String this$cron = this.getCron();
            String other$cron = other.getCron();
            if (this$cron == null ? other$cron != null : !this$cron.equals(other$cron)) {
                return false;
            }
            String this$zone = this.getZone();
            String other$zone = other.getZone();
            return !(this$zone == null ? other$zone != null : !this$zone.equals(other$zone));
        }

        @Generated
        protected boolean canEqual(Object other) {
            return other instanceof DailyRun;
        }

        @Generated
        public int hashCode() {
            int PRIME = 59;
            int result = 1;
            Boolean $enabled = this.getEnabled();
            result = result * 59 + ($enabled == null ? 43 : ((Object)$enabled).hashCode());
            String $cron = this.getCron();
            result = result * 59 + ($cron == null ? 43 : $cron.hashCode());
            String $zone = this.getZone();
            result = result * 59 + ($zone == null ? 43 : $zone.hashCode());
            return result;
        }

        @Generated
        public String toString() {
            return "AppProps.DailyRun(enabled=" + this.getEnabled() + ", cron=" + this.getCron() + ", zone=" + this.getZone() + ")";
        }
    }

    public static class Account {
        private String name;
        private String login;
        private String password;
        private String coverLetter;
        private String language;

        @Generated
        public Account() {
        }

        @Generated
        public String getName() {
            return this.name;
        }

        @Generated
        public String getLogin() {
            return this.login;
        }

        @Generated
        public String getPassword() {
            return this.password;
        }

        @Generated
        public String getCoverLetter() {
            return this.coverLetter;
        }

        @Generated
        public String getLanguage() {
            return this.language;
        }

        @Generated
        public void setName(String name) {
            this.name = name;
        }

        @Generated
        public void setLogin(String login) {
            this.login = login;
        }

        @Generated
        public void setPassword(String password) {
            this.password = password;
        }

        @Generated
        public void setCoverLetter(String coverLetter) {
            this.coverLetter = coverLetter;
        }

        @Generated
        public void setLanguage(String language) {
            this.language = language;
        }

        @Generated
        public boolean equals(Object o) {
            if (o == this) {
                return true;
            }
            if (!(o instanceof Account)) {
                return false;
            }
            Account other = (Account)o;
            if (!other.canEqual(this)) {
                return false;
            }
            String this$name = this.getName();
            String other$name = other.getName();
            if (this$name == null ? other$name != null : !this$name.equals(other$name)) {
                return false;
            }
            String this$login = this.getLogin();
            String other$login = other.getLogin();
            if (this$login == null ? other$login != null : !this$login.equals(other$login)) {
                return false;
            }
            String this$password = this.getPassword();
            String other$password = other.getPassword();
            if (this$password == null ? other$password != null : !this$password.equals(other$password)) {
                return false;
            }
            String this$coverLetter = this.getCoverLetter();
            String other$coverLetter = other.getCoverLetter();
            if (this$coverLetter == null ? other$coverLetter != null : !this$coverLetter.equals(other$coverLetter)) {
                return false;
            }
            String this$language = this.getLanguage();
            String other$language = other.getLanguage();
            return !(this$language == null ? other$language != null : !this$language.equals(other$language));
        }

        @Generated
        protected boolean canEqual(Object other) {
            return other instanceof Account;
        }

        @Generated
        public int hashCode() {
            int PRIME = 59;
            int result = 1;
            String $name = this.getName();
            result = result * 59 + ($name == null ? 43 : $name.hashCode());
            String $login = this.getLogin();
            result = result * 59 + ($login == null ? 43 : $login.hashCode());
            String $password = this.getPassword();
            result = result * 59 + ($password == null ? 43 : $password.hashCode());
            String $coverLetter = this.getCoverLetter();
            result = result * 59 + ($coverLetter == null ? 43 : $coverLetter.hashCode());
            String $language = this.getLanguage();
            result = result * 59 + ($language == null ? 43 : $language.hashCode());
            return result;
        }

        @Generated
        public String toString() {
            return "AppProps.Account(name=" + this.getName() + ", login=" + this.getLogin() + ", password=" + this.getPassword() + ", coverLetter=" + this.getCoverLetter() + ", language=" + this.getLanguage() + ")";
        }
    }
}

