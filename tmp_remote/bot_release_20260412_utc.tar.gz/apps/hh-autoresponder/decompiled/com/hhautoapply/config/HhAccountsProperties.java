/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 *  org.springframework.boot.context.properties.ConfigurationProperties
 */
package com.hhautoapply.config;

import java.util.ArrayList;
import java.util.List;
import lombok.Generated;
import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix="app")
public class HhAccountsProperties {
    private List<Account> accounts = new ArrayList<Account>();

    @Generated
    public HhAccountsProperties() {
    }

    @Generated
    public List<Account> getAccounts() {
        return this.accounts;
    }

    @Generated
    public void setAccounts(List<Account> accounts) {
        this.accounts = accounts;
    }

    @Generated
    public boolean equals(Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof HhAccountsProperties)) {
            return false;
        }
        HhAccountsProperties other = (HhAccountsProperties)o;
        if (!other.canEqual(this)) {
            return false;
        }
        List<Account> this$accounts = this.getAccounts();
        List<Account> other$accounts = other.getAccounts();
        return !(this$accounts == null ? other$accounts != null : !((Object)this$accounts).equals(other$accounts));
    }

    @Generated
    protected boolean canEqual(Object other) {
        return other instanceof HhAccountsProperties;
    }

    @Generated
    public int hashCode() {
        int PRIME = 59;
        int result = 1;
        List<Account> $accounts = this.getAccounts();
        result = result * 59 + ($accounts == null ? 43 : ((Object)$accounts).hashCode());
        return result;
    }

    @Generated
    public String toString() {
        return "HhAccountsProperties(accounts=" + String.valueOf(this.getAccounts()) + ")";
    }

    public static class Account {
        private String name;
        private String login;
        private String password;
        private String language;
        private String coverLetter;

        @Generated
        public Account() {
        }

        @Generated
        public String getName() {
            return this.name;
        }

        @Generated
        public String getLogin() {
            return this.login;
        }

        @Generated
        public String getPassword() {
            return this.password;
        }

        @Generated
        public String getLanguage() {
            return this.language;
        }

        @Generated
        public String getCoverLetter() {
            return this.coverLetter;
        }

        @Generated
        public void setName(String name) {
            this.name = name;
        }

        @Generated
        public void setLogin(String login) {
            this.login = login;
        }

        @Generated
        public void setPassword(String password) {
            this.password = password;
        }

        @Generated
        public void setLanguage(String language) {
            this.language = language;
        }

        @Generated
        public void setCoverLetter(String coverLetter) {
            this.coverLetter = coverLetter;
        }

        @Generated
        public boolean equals(Object o) {
            if (o == this) {
                return true;
            }
            if (!(o instanceof Account)) {
                return false;
            }
            Account other = (Account)o;
            if (!other.canEqual(this)) {
                return false;
            }
            String this$name = this.getName();
            String other$name = other.getName();
            if (this$name == null ? other$name != null : !this$name.equals(other$name)) {
                return false;
            }
            String this$login = this.getLogin();
            String other$login = other.getLogin();
            if (this$login == null ? other$login != null : !this$login.equals(other$login)) {
                return false;
            }
            String this$password = this.getPassword();
            String other$password = other.getPassword();
            if (this$password == null ? other$password != null : !this$password.equals(other$password)) {
                return false;
            }
            String this$language = this.getLanguage();
            String other$language = other.getLanguage();
            if (this$language == null ? other$language != null : !this$language.equals(other$language)) {
                return false;
            }
            String this$coverLetter = this.getCoverLetter();
            String other$coverLetter = other.getCoverLetter();
            return !(this$coverLetter == null ? other$coverLetter != null : !this$coverLetter.equals(other$coverLetter));
        }

        @Generated
        protected boolean canEqual(Object other) {
            return other instanceof Account;
        }

        @Generated
        public int hashCode() {
            int PRIME = 59;
            int result = 1;
            String $name = this.getName();
            result = result * 59 + ($name == null ? 43 : $name.hashCode());
            String $login = this.getLogin();
            result = result * 59 + ($login == null ? 43 : $login.hashCode());
            String $password = this.getPassword();
            result = result * 59 + ($password == null ? 43 : $password.hashCode());
            String $language = this.getLanguage();
            result = result * 59 + ($language == null ? 43 : $language.hashCode());
            String $coverLetter = this.getCoverLetter();
            result = result * 59 + ($coverLetter == null ? 43 : $coverLetter.hashCode());
            return result;
        }

        @Generated
        public String toString() {
            return "HhAccountsProperties.Account(name=" + this.getName() + ", login=" + this.getLogin() + ", password=" + this.getPassword() + ", language=" + this.getLanguage() + ", coverLetter=" + this.getCoverLetter() + ")";
        }
    }
}

