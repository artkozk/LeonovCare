/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  jakarta.servlet.Filter
 *  lombok.Generated
 *  org.springframework.boot.context.properties.EnableConfigurationProperties
 *  org.springframework.context.annotation.Bean
 *  org.springframework.context.annotation.Configuration
 *  org.springframework.security.config.annotation.web.builders.HttpSecurity
 *  org.springframework.security.config.annotation.web.configurers.AuthorizeHttpRequestsConfigurer$AuthorizedUrl
 *  org.springframework.security.web.SecurityFilterChain
 *  org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter
 */
package com.hhautoapply.config;

import com.hhautoapply.config.InternalApiAuthFilter;
import com.hhautoapply.config.InternalApiProperties;
import jakarta.servlet.Filter;
import lombok.Generated;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configurers.AuthorizeHttpRequestsConfigurer;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@EnableConfigurationProperties(value={InternalApiProperties.class})
public class SecurityConfig {
    private final InternalApiAuthFilter internalApiAuthFilter;

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        return (SecurityFilterChain)http.csrf(csrf -> csrf.disable()).httpBasic(httpBasic -> httpBasic.disable()).formLogin(form -> form.disable()).logout(logout -> logout.disable()).authorizeHttpRequests(auth -> ((AuthorizeHttpRequestsConfigurer.AuthorizedUrl)((AuthorizeHttpRequestsConfigurer.AuthorizedUrl)auth.requestMatchers(new String[]{"/api/internal/**"})).permitAll().anyRequest()).permitAll()).addFilterBefore((Filter)this.internalApiAuthFilter, UsernamePasswordAuthenticationFilter.class).build();
    }

    @Generated
    public SecurityConfig(InternalApiAuthFilter internalApiAuthFilter) {
        this.internalApiAuthFilter = internalApiAuthFilter;
    }
}

