/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  jakarta.servlet.FilterChain
 *  jakarta.servlet.ServletException
 *  jakarta.servlet.ServletRequest
 *  jakarta.servlet.ServletResponse
 *  jakarta.servlet.http.HttpServletRequest
 *  jakarta.servlet.http.HttpServletResponse
 *  lombok.Generated
 *  org.springframework.stereotype.Component
 *  org.springframework.util.AntPathMatcher
 *  org.springframework.web.filter.OncePerRequestFilter
 */
package com.hhautoapply.config;

import com.hhautoapply.config.InternalApiProperties;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import lombok.Generated;
import org.springframework.stereotype.Component;
import org.springframework.util.AntPathMatcher;
import org.springframework.web.filter.OncePerRequestFilter;

@Component
public class InternalApiAuthFilter
extends OncePerRequestFilter {
    private static final String HEADER = "X-Internal-Token";
    private static final AntPathMatcher PATH_MATCHER = new AntPathMatcher();
    private final InternalApiProperties properties;

    protected boolean shouldNotFilter(HttpServletRequest request) {
        return !PATH_MATCHER.match("/api/internal/**", request.getRequestURI());
    }

    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        String clientIp = this.extractClientIp(request);
        String token = request.getHeader(HEADER);
        boolean tokenValid = this.constantTimeEquals(this.properties.getToken(), token);
        if (!tokenValid) {
            response.setStatus(403);
            response.setContentType("application/json;charset=UTF-8");
            response.getWriter().write("{\"ok\":false,\"message\":\"forbidden\"}");
            return;
        }
        filterChain.doFilter((ServletRequest)request, (ServletResponse)response);
    }

    private String extractClientIp(HttpServletRequest request) {
        String forwarded = request.getHeader("X-Forwarded-For");
        if (forwarded != null && !forwarded.isBlank()) {
            return forwarded.split(",")[0].trim();
        }
        return request.getRemoteAddr();
    }

    private boolean constantTimeEquals(String a, String b) {
        if (a == null || b == null) {
            return false;
        }
        return MessageDigest.isEqual(a.getBytes(StandardCharsets.UTF_8), b.getBytes(StandardCharsets.UTF_8));
    }

    @Generated
    public InternalApiAuthFilter(InternalApiProperties properties) {
        this.properties = properties;
    }
}

