/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.swagger.v3.oas.annotations.OpenAPIDefinition
 *  io.swagger.v3.oas.annotations.enums.SecuritySchemeIn
 *  io.swagger.v3.oas.annotations.enums.SecuritySchemeType
 *  io.swagger.v3.oas.annotations.info.Info
 *  io.swagger.v3.oas.annotations.security.SecurityScheme
 *  io.swagger.v3.oas.models.OpenAPI
 *  io.swagger.v3.oas.models.info.Contact
 *  io.swagger.v3.oas.models.info.Info
 *  org.springframework.context.annotation.Bean
 *  org.springframework.context.annotation.Configuration
 */
package com.hhautoapply.config;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.enums.SecuritySchemeIn;
import io.swagger.v3.oas.annotations.enums.SecuritySchemeType;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.security.SecurityScheme;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@OpenAPIDefinition(info=@Info(title="HH Autoapply API", version="1.0", description="API for HH auto-apply flows, internal account management and batch runs."))
@SecurityScheme(name="internalToken", type=SecuritySchemeType.APIKEY, in=SecuritySchemeIn.HEADER, paramName="X-Internal-Token", description="Required for /api/internal/** endpoints.")
public class OpenApiConfig {
    @Bean
    public OpenAPI openAPI() {
        return new OpenAPI().info(new io.swagger.v3.oas.models.info.Info().title("HH Autoapply API").version("1.0").description("API for HH auto-apply flows, internal account management and batch runs.").contact(new Contact().name("HH Autoapply")));
    }
}

