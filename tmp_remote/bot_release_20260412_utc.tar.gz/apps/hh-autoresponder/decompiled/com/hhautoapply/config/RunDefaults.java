/*
 * Decompiled with CFR 0.152.
 */
package com.hhautoapply.config;

public final class RunDefaults {
    public static final int DEFAULT_TARGET_APPLIES = 200;
    public static final boolean DEFAULT_HEADLESS = true;
    public static final int DEFAULT_SLOW_MO_MS = 150;

    private RunDefaults() {
    }
}

