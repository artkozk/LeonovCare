/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.microsoft.playwright.Locator
 *  com.microsoft.playwright.Page
 *  com.microsoft.playwright.Page$NavigateOptions
 *  com.microsoft.playwright.PlaywrightException
 *  com.microsoft.playwright.options.WaitUntilState
 *  lombok.Generated
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 *  org.springframework.stereotype.Component
 */
package com.hhautoapply.service;

import com.hhautoapply.service.CoverLetterHandler;
import com.hhautoapply.service.LlmFlowHandler;
import com.hhautoapply.service.OtherCountryHandler;
import com.hhautoapply.service.PlaywrightSupport;
import com.hhautoapply.service.SubmitButtonFinder;
import com.hhautoapply.service.VacancyDiagnostics;
import com.hhautoapply.service.VacancyPageStateDetector;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.PlaywrightException;
import com.microsoft.playwright.options.WaitUntilState;
import java.net.URI;
import java.util.Map;
import lombok.Generated;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class VacancyApplier {
    @Generated
    private static final Logger log = LoggerFactory.getLogger(VacancyApplier.class);
    private static final int NAV_TIMEOUT_MS = 60000;
    private static final int VISIBLE_MS = 2500;
    private static final int ALREADY_POLL_MS = 120;
    private static final int ALREADY_MAX_MS_AFTER_NAV = 900;
    private static final int ALREADY_MAX_MS_AFTER_CLICK = 650;
    private static final int SUCCESS_WAIT_MS = 11000;
    private static final String RESPOND_BTN_SEL = "button[data-qa*='vacancy-response'], a[data-qa*='vacancy-response'], button[data-qa*='response'], a[data-qa*='response'], button:has-text('\u041e\u0442\u043a\u043b\u0438\u043a\u043d\u0443\u0442\u044c\u0441\u044f'), a:has-text('\u041e\u0442\u043a\u043b\u0438\u043a\u043d\u0443\u0442\u044c\u0441\u044f')";
    private final PlaywrightSupport ui;
    private final VacancyPageStateDetector detector;
    private final VacancyDiagnostics diagnostics;
    private final SubmitButtonFinder submitButtonFinder;
    private final OtherCountryHandler otherCountryHandler;
    private final CoverLetterHandler coverLetterHandler;
    private final LlmFlowHandler llmFlowHandler;
    private static final int FORM_SETTLE_MS = 300;
    private static final int MAX_SAME_BRANCH_STALLS = 2;
    private static final int POST_SUBMIT_ALREADY_GRACE_MS = 1200;

    public Submit apply(Page vacancyPage, Page serpPage, String runId, String href, Long vacancyId, String title, String coverLetter, Map<String, String> candidateContext) {
        ApplyContext ctx = new ApplyContext(vacancyPage, serpPage, runId, href, vacancyId, title, coverLetter, candidateContext);
        try {
            Submit early = this.openVacancyAndCheckInitialState(ctx);
            if (early != null) {
                return this.done(ctx, early);
            }
            Submit startFlow = this.openRespondFlow(ctx);
            if (startFlow != null) {
                return this.done(ctx, startFlow);
            }
            Submit flowResult = this.resolveFlow(ctx);
            return this.done(ctx, flowResult);
        }
        catch (PlaywrightException e) {
            return this.done(ctx, this.failWithException(ctx.vacancyPage, "playwright_exception", null, ctx.startedAt, (Exception)((Object)e), false));
        }
        catch (Exception e) {
            return this.done(ctx, this.failWithException(ctx.vacancyPage, "exception", null, ctx.startedAt, e, false));
        }
    }

    private Submit openVacancyAndCheckInitialState(ApplyContext ctx) {
        try {
            ctx.vacancyPage.navigate(ctx.absUrl, new Page.NavigateOptions().setWaitUntil(WaitUntilState.DOMCONTENTLOADED).setTimeout(60000.0));
            ctx.navMs = ctx.timing.lap();
        }
        catch (Exception e) {
            return this.failWithException(ctx.vacancyPage, "navigate_failed", null, ctx.startedAt, e, false);
        }
        if (this.detector.detectAlreadyAppliedPolled(ctx.vacancyPage, 120, 900) != null) {
            return Submit.alreadyApplied("already_after_nav", ctx.totalMs(), this.diagnostics.diagWithStage(ctx.vacancyPage, "already_after_nav"));
        }
        ctx.preAlreadyMs = ctx.timing.lap();
        return null;
    }

    private Submit openRespondFlow(ApplyContext ctx) {
        Locator respond = this.ui.visible(ctx.vacancyPage.locator(RESPOND_BTN_SEL), 2500);
        ctx.findRespondMs = ctx.timing.lap();
        if (respond == null) {
            if (this.detector.detectAlreadyAppliedPolled(ctx.vacancyPage, 120, 450) != null) {
                return Submit.alreadyApplied("already_no_respond_btn", ctx.totalMs(), this.diagnostics.diagWithStage(ctx.vacancyPage, "already_no_respond_btn"));
            }
            return this.fail(ctx.vacancyPage, "no_respond_btn", null, ctx.startedAt, false);
        }
        boolean responded = this.ui.stableClick(respond, () -> this.detector.firstVisibleModal(ctx.vacancyPage) != null || this.detector.isOtherCountryPopupNow(ctx.vacancyPage) || this.detector.isInResponseFlow(ctx.vacancyPage) || this.detector.hasSuccessNow(ctx.vacancyPage) || this.detector.detectAlreadyAppliedPolled(ctx.vacancyPage, 120, 650) != null, 2600);
        ctx.clickRespondMs = ctx.timing.lap();
        if (!responded) {
            if (this.detector.detectAlreadyAppliedPolled(ctx.vacancyPage, 120, 450) != null) {
                return Submit.alreadyApplied("already_after_failed_click", ctx.totalMs(), this.diagnostics.diagWithStage(ctx.vacancyPage, "already_after_failed_click"));
            }
            return this.fail(ctx.vacancyPage, "respond_click_failed", null, ctx.startedAt, false);
        }
        VacancyPageStateDetector.StopSignal stop = this.detector.detectDailyLimitFast(ctx.vacancyPage);
        if (stop != null) {
            return this.fail(ctx.vacancyPage, "daily_limit_after_respond", null, ctx.startedAt, stop.shouldStopRun());
        }
        return null;
    }

    private Submit resolveFlow(ApplyContext ctx) {
        FlowBranch currentBranch = null;
        FlowBranch lastHandledBranch = null;
        int sameBranchStalls = 0;
        for (int depth = 0; depth < 10; ++depth) {
            if (this.detector.hasSuccessNow(ctx.vacancyPage)) {
                return Submit.applied("success", currentBranch, ctx.totalMs(), this.diagnostics.diag(ctx.vacancyPage));
            }
            if (this.detector.detectAlreadyAppliedPolled(ctx.vacancyPage, 120, 200) != null) {
                return Submit.alreadyApplied("already_mid_flow", ctx.totalMs(), this.diagnostics.diag(ctx.vacancyPage));
            }
            VacancyPageStateDetector.StopSignal stop = this.detector.detectDailyLimitFast(ctx.vacancyPage);
            if (stop != null) {
                return this.fail(ctx.vacancyPage, "daily_limit_mid", currentBranch, ctx.startedAt, stop.shouldStopRun());
            }
            VacancyPageStateDetector.ResponseRequirements req = this.detector.detectRequirements(ctx.vacancyPage);
            ctx.outcomeMs += ctx.timing.lap();
            if (req.otherCountry()) {
                currentBranch = FlowBranch.OTHER_COUNTRY;
                boolean ok = this.otherCountryHandler.confirm(ctx.vacancyPage);
                if (!ok) {
                    return this.fail(ctx.vacancyPage, "other_country_click_failed", currentBranch, ctx.startedAt, false);
                }
                ctx.vacancyPage.waitForTimeout(300.0);
                sameBranchStalls = this.progressStalls(ctx.vacancyPage, currentBranch, lastHandledBranch, sameBranchStalls);
                if (sameBranchStalls >= 2 && this.detector.isOtherCountryPopupNow(ctx.vacancyPage)) {
                    return this.fail(ctx.vacancyPage, "other_country_stalled", currentBranch, ctx.startedAt, false);
                }
                lastHandledBranch = currentBranch;
                continue;
            }
            if (req.questionsPresent()) {
                currentBranch = FlowBranch.LLM;
                boolean llmOk = this.llmFlowHandler.fillQuestions(ctx.vacancyPage, ctx.candidateContext);
                if (!llmOk) {
                    return this.fail(ctx.vacancyPage, "llm_apply_failed", currentBranch, ctx.startedAt, false);
                }
                ctx.vacancyPage.waitForTimeout(300.0);
                sameBranchStalls = this.progressStalls(ctx.vacancyPage, currentBranch, lastHandledBranch, sameBranchStalls);
                if (sameBranchStalls >= 2 && this.detector.detectRequirements(ctx.vacancyPage).questionsPresent() && !this.canSubmitNow(ctx.vacancyPage)) {
                    return this.fail(ctx.vacancyPage, "llm_no_progress", currentBranch, ctx.startedAt, false);
                }
                lastHandledBranch = currentBranch;
                continue;
            }
            if (req.coverRequired()) {
                currentBranch = FlowBranch.COVER_LETTER;
                boolean coverOk = this.coverLetterHandler.fillRequiredCover(ctx.vacancyPage, ctx.coverLetter);
                if (!coverOk) {
                    return this.fail(ctx.vacancyPage, "cover_fill_failed", currentBranch, ctx.startedAt, false);
                }
                ctx.vacancyPage.waitForTimeout(300.0);
                if (this.canSubmitNow(ctx.vacancyPage)) {
                    if (!this.trySubmitReliably(ctx.vacancyPage)) {
                        return this.fail(ctx.vacancyPage, "cover_submit_click_failed", currentBranch, ctx.startedAt, false);
                    }
                    PostSubmitOutcome out = this.waitPostSubmitOutcome(ctx.vacancyPage);
                    if (out == PostSubmitOutcome.SUCCESS) {
                        return Submit.applied("cover_submit_success", currentBranch, ctx.totalMs(), this.diagnostics.diag(ctx.vacancyPage));
                    }
                    if (out == PostSubmitOutcome.ALREADY) {
                        return Submit.applied("cover_submit_success_already_marker", currentBranch, ctx.totalMs(), this.diagnostics.diag(ctx.vacancyPage));
                    }
                    if (out == PostSubmitOutcome.LIMIT) {
                        return this.fail(ctx.vacancyPage, "cover_daily_limit", currentBranch, ctx.startedAt, true);
                    }
                }
                if ((sameBranchStalls = this.progressStalls(ctx.vacancyPage, currentBranch, lastHandledBranch, sameBranchStalls)) >= 2 && this.detector.isCoverRequiredNow(ctx.vacancyPage) && !this.canSubmitNow(ctx.vacancyPage)) {
                    return this.fail(ctx.vacancyPage, "cover_no_progress", currentBranch, ctx.startedAt, false);
                }
                lastHandledBranch = currentBranch;
                continue;
            }
            lastHandledBranch = null;
            sameBranchStalls = 0;
            if (this.canSubmitNow(ctx.vacancyPage)) {
                if (!this.trySubmitReliably(ctx.vacancyPage)) {
                    return this.fail(ctx.vacancyPage, "submit_click_failed", currentBranch, ctx.startedAt, false);
                }
                PostSubmitOutcome out = this.waitPostSubmitOutcome(ctx.vacancyPage);
                if (out == PostSubmitOutcome.SUCCESS) {
                    return Submit.applied("submit_success", currentBranch, ctx.totalMs(), this.diagnostics.diag(ctx.vacancyPage));
                }
                if (out == PostSubmitOutcome.ALREADY) {
                    return Submit.applied("submit_success_already_marker", currentBranch, ctx.totalMs(), this.diagnostics.diag(ctx.vacancyPage));
                }
                if (out == PostSubmitOutcome.LIMIT) {
                    return this.fail(ctx.vacancyPage, "daily_limit_after_submit", currentBranch, ctx.startedAt, true);
                }
                return this.fail(ctx.vacancyPage, "no_success_after_submit", currentBranch, ctx.startedAt, false);
            }
            if (req.none()) {
                return this.fail(ctx.vacancyPage, "submit_not_available", currentBranch, ctx.startedAt, false);
            }
            return this.fail(ctx.vacancyPage, "requirements_detected_but_not_resolved", currentBranch, ctx.startedAt, false);
        }
        return this.fail(ctx.vacancyPage, "depth_limit", currentBranch, ctx.startedAt, false);
    }

    private int progressStalls(Page page, FlowBranch currentBranch, FlowBranch lastHandledBranch, int sameBranchStalls) {
        if (currentBranch != lastHandledBranch) {
            return 1;
        }
        if (this.detector.hasSuccessNow(page) || this.canSubmitNow(page)) {
            return 0;
        }
        return sameBranchStalls + 1;
    }

    private PostSubmitOutcome waitPostSubmitOutcome(Page page) {
        long until = System.currentTimeMillis() + 11000L;
        Long alreadySince = null;
        while (System.currentTimeMillis() < until) {
            try {
                if (this.detector.hasSuccessNow(page)) {
                    return PostSubmitOutcome.SUCCESS;
                }
                if (this.detector.detectDailyLimitFast(page) != null) {
                    return PostSubmitOutcome.LIMIT;
                }
                if (this.detector.detectAlreadyAppliedPolled(page, 120, 200) != null) {
                    if (alreadySince == null) {
                        alreadySince = System.currentTimeMillis();
                    } else if (System.currentTimeMillis() - alreadySince >= 1200L) {
                        return PostSubmitOutcome.ALREADY;
                    }
                } else {
                    alreadySince = null;
                }
                page.waitForTimeout(120.0);
            }
            catch (Exception e) {
                // empty catch block
                break;
            }
        }
        try {
            if (this.detector.hasSuccessNow(page)) {
                return PostSubmitOutcome.SUCCESS;
            }
            if (this.detector.detectDailyLimitFast(page) != null) {
                return PostSubmitOutcome.LIMIT;
            }
            if (this.detector.detectAlreadyAppliedPolled(page, 120, 200) != null) {
                return PostSubmitOutcome.ALREADY;
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return PostSubmitOutcome.NONE;
    }

    private boolean canSubmitNow(Page page) {
        try {
            Locator submit = this.submitButtonFinder.findVisibleSubmit(this.detector.firstVisibleModal(page), page);
            return submit != null && this.ui.isVisible(submit);
        }
        catch (Exception ignore) {
            return false;
        }
    }

    private boolean trySubmitReliably(Page page) {
        try {
            Locator modalBeforeClick = this.detector.firstVisibleModal(page);
            boolean hadModal = modalBeforeClick != null;
            Locator submit = this.submitButtonFinder.findVisibleSubmit(modalBeforeClick, page);
            if (submit == null) {
                return false;
            }
            this.ui.blur(page);
            page.waitForTimeout(120.0);
            if (!submit.isEnabled()) {
                this.ui.waitEnabled(submit, 3500);
            }
            if (!submit.isEnabled()) {
                return false;
            }
            return this.ui.stableClick(submit, () -> this.detector.hasSuccessNow(page) || this.detector.detectDailyLimitFast(page) != null || this.detector.detectAlreadyAppliedPolled(page, 120, 300) != null || hadModal && this.detector.firstVisibleModal(page) == null || !hadModal && !this.isSubmitStillActionable(page), 3200);
        }
        catch (Exception e) {
            log.warn("submit_click_failed", (Throwable)e);
            return false;
        }
    }

    private boolean isSubmitStillActionable(Page page) {
        try {
            Locator modal = this.detector.firstVisibleModal(page);
            Locator submit = this.submitButtonFinder.findVisibleSubmit(modal, page);
            return submit != null && this.ui.isVisible(submit) && submit.isEnabled();
        }
        catch (Exception e) {
            return false;
        }
    }

    private Submit done(ApplyContext ctx, Submit submit) {
        this.logTiming(ctx.runId, ctx.vacancyId, submit.status().name(), submit.stage(), submit.branch() == null ? null : submit.branch().name(), ctx.navMs, ctx.preAlreadyMs, ctx.findRespondMs, ctx.clickRespondMs, ctx.outcomeMs, submit.ms());
        return submit;
    }

    private Submit fail(Page page, String stage, FlowBranch branch, long t0, boolean shouldStopRun) {
        return Submit.failed(stage, branch, shouldStopRun, VacancyApplier.ms(t0), this.diagnostics.diagWithStage(page, stage));
    }

    private Submit failWithException(Page page, String stage, FlowBranch branch, long t0, Exception e, boolean shouldStopRun) {
        String ex = e == null ? "" : e.getClass().getName() + ": " + VacancyApplier.n(e.getMessage());
        String details = this.diagnostics.diagWithStage(page, stage) + " | ex=" + ex;
        return Submit.failed(stage, branch, shouldStopRun, VacancyApplier.ms(t0), details);
    }

    private void logTiming(String runId, Long vacancyId, String status, String stage, String branch, long navMs, long preAlreadyMs, long findRespondMs, long clickRespondMs, long outcomeMs, long totalMs) {
        log.info("[{}][TIMING] vacancyId={} status={} stage={} branch={} navMs={} preAlreadyMs={} findRespondMs={} clickRespondMs={} outcomeMs={} totalMs={}", new Object[]{runId, vacancyId, status, stage, branch, navMs, preAlreadyMs, findRespondMs, clickRespondMs, outcomeMs, totalMs});
    }

    private static long ms(long t0) {
        return Math.max(0L, System.currentTimeMillis() - t0);
    }

    private static String n(String s) {
        return s == null ? "" : s;
    }

    private static String absUrl(Page serpPage, String href) {
        try {
            String base = serpPage.url();
            if (base == null || base.isBlank()) {
                return href;
            }
            return URI.create(base).resolve(href).toString();
        }
        catch (Exception e) {
            return href;
        }
    }

    @Generated
    public VacancyApplier(PlaywrightSupport ui, VacancyPageStateDetector detector, VacancyDiagnostics diagnostics, SubmitButtonFinder submitButtonFinder, OtherCountryHandler otherCountryHandler, CoverLetterHandler coverLetterHandler, LlmFlowHandler llmFlowHandler) {
        this.ui = ui;
        this.detector = detector;
        this.diagnostics = diagnostics;
        this.submitButtonFinder = submitButtonFinder;
        this.otherCountryHandler = otherCountryHandler;
        this.coverLetterHandler = coverLetterHandler;
        this.llmFlowHandler = llmFlowHandler;
    }

    private static final class ApplyContext {
        final Page vacancyPage;
        final String runId;
        final Long vacancyId;
        final String title;
        final String coverLetter;
        final Map<String, String> candidateContext;
        final long startedAt = System.currentTimeMillis();
        final Timing timing = new Timing();
        final String absUrl;
        long navMs;
        long preAlreadyMs;
        long findRespondMs;
        long clickRespondMs;
        long outcomeMs;

        ApplyContext(Page vacancyPage, Page serpPage, String runId, String href, Long vacancyId, String title, String coverLetter, Map<String, String> candidateContext) {
            this.vacancyPage = vacancyPage;
            this.runId = runId;
            this.vacancyId = vacancyId;
            this.title = title;
            this.coverLetter = coverLetter;
            this.candidateContext = candidateContext == null ? Map.of() : candidateContext;
            this.absUrl = VacancyApplier.absUrl(serpPage, href);
        }

        long totalMs() {
            return Math.max(0L, System.currentTimeMillis() - this.startedAt);
        }
    }

    public record Submit(ApplyResultStatus status, boolean shouldStopRun, FlowBranch branch, String stage, String debug, long ms) {
        public static Submit applied(String stage, FlowBranch branch, long ms, String debug) {
            return new Submit(ApplyResultStatus.APPLIED, false, branch, VacancyApplier.n(stage), VacancyApplier.n(debug), ms);
        }

        public static Submit alreadyApplied(String stage, long ms, String debug) {
            return new Submit(ApplyResultStatus.ALREADY_APPLIED, false, null, VacancyApplier.n(stage), VacancyApplier.n(debug), ms);
        }

        public static Submit failed(String stage, FlowBranch branch, boolean shouldStopRun, long ms, String debug) {
            return new Submit(ApplyResultStatus.FAILED, shouldStopRun, branch, VacancyApplier.n(stage), VacancyApplier.n(debug), ms);
        }
    }

    public static enum FlowBranch {
        OTHER_COUNTRY,
        COVER_LETTER,
        LLM;

    }

    private static final class Timing {
        private final long t0;
        private long t;

        private Timing() {
            this.t = this.t0 = System.currentTimeMillis();
        }

        long lap() {
            long now = System.currentTimeMillis();
            long d = now - this.t;
            this.t = now;
            return Math.max(0L, d);
        }
    }

    private static enum PostSubmitOutcome {
        SUCCESS,
        LIMIT,
        ALREADY,
        NONE;

    }

    public static enum ApplyResultStatus {
        APPLIED,
        ALREADY_APPLIED,
        FAILED;

    }
}

