/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.microsoft.playwright.Locator
 *  com.microsoft.playwright.Page
 *  lombok.Generated
 *  org.springframework.stereotype.Component
 */
package com.hhautoapply.service;

import com.hhautoapply.service.PlaywrightSupport;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import lombok.Generated;
import org.springframework.stereotype.Component;

@Component
public class SubmitButtonFinder {
    private static final String SUBMIT_BTN_SEL = "button[data-qa='vacancy-response-submit'], button[data-qa*='vacancy-response-submit'], button[data-qa*='submit'], button[type='submit'], button:has-text('\u041e\u0442\u043f\u0440\u0430\u0432\u0438\u0442\u044c \u043e\u0442\u043a\u043b\u0438\u043a'), a:has-text('\u041e\u0442\u043f\u0440\u0430\u0432\u0438\u0442\u044c \u043e\u0442\u043a\u043b\u0438\u043a'), button:has-text('\u041e\u0442\u043f\u0440\u0430\u0432\u0438\u0442\u044c'), a:has-text('\u041e\u0442\u043f\u0440\u0430\u0432\u0438\u0442\u044c')";
    private final PlaywrightSupport ui;

    public Locator findVisibleSubmit(Locator modal, Page page) {
        try {
            Locator s1;
            if (modal != null && this.ui.isVisible(s1 = modal.locator(SUBMIT_BTN_SEL).first())) {
                return s1;
            }
        }
        catch (Exception s1) {
            // empty catch block
        }
        try {
            Locator s2 = page.locator(SUBMIT_BTN_SEL).first();
            if (this.ui.isVisible(s2)) {
                return s2;
            }
        }
        catch (Exception s2) {
            // empty catch block
        }
        try {
            Locator alt = page.locator("button:has-text('\u041e\u0442\u043f\u0440\u0430\u0432\u0438\u0442\u044c'), button:has-text('\u041e\u0442\u043f\u0440\u0430\u0432\u0438\u0442\u044c \u043e\u0442\u043a\u043b\u0438\u043a')").first();
            if (this.ui.isVisible(alt)) {
                return alt;
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return null;
    }

    @Generated
    public SubmitButtonFinder(PlaywrightSupport ui) {
        this.ui = ui;
    }
}

