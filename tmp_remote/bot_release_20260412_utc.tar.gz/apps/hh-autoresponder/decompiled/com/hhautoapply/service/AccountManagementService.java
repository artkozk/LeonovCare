/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 *  org.springframework.stereotype.Service
 *  org.springframework.transaction.annotation.Transactional
 */
package com.hhautoapply.service;

import com.hhautoapply.model.AccountResponse;
import com.hhautoapply.model.AccountStatsResponse;
import com.hhautoapply.model.CreateAccountRequest;
import com.hhautoapply.model.HhAccountEntity;
import com.hhautoapply.repository.HhAccountRepository;
import java.util.Map;
import lombok.Generated;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AccountManagementService {
    private final HhAccountRepository repository;

    @Transactional
    public AccountResponse create(CreateAccountRequest req) {
        if (req.login() == null || req.login().isBlank()) {
            throw new IllegalArgumentException("login is required");
        }
        if (req.password() == null || req.password().isBlank()) {
            throw new IllegalArgumentException("password is required");
        }
        if (this.repository.existsByLogin(req.login())) {
            throw new IllegalArgumentException("account already exists");
        }
        HhAccountEntity e = new HhAccountEntity();
        e.setLogin(req.login().trim());
        e.setPassword(req.password().trim());
        e.setDirection(req.direction());
        e.setQueryText(req.queryText());
        e.setTargetApplies(req.targetApplies() != null ? req.targetApplies() : 200);
        e.setCoverLetter(req.coverLetter());
        e.setCandidateContext(req.candidateContext() != null ? req.candidateContext() : Map.of());
        e.setActive(req.active() != null ? req.active() : true);
        this.repository.save(e);
        return this.toResponse(e);
    }

    @Transactional
    public void delete(String login) {
        this.repository.deleteByLogin(login);
    }

    @Transactional(readOnly=true)
    public AccountStatsResponse stats(String login) {
        HhAccountEntity e = this.repository.findByLogin(login).orElseThrow(() -> new IllegalArgumentException("account not found"));
        return new AccountStatsResponse(e.getLogin(), e.getDirection(), e.getActive(), e.getLastRunAt(), e.getLastRunStatus(), e.getLastSentCount());
    }

    private AccountResponse toResponse(HhAccountEntity e) {
        return new AccountResponse(e.getId(), e.getLogin(), e.getDirection(), e.getQueryText(), e.getTargetApplies(), e.getActive(), e.getLastRunStatus(), e.getLastSentCount());
    }

    @Generated
    public AccountManagementService(HhAccountRepository repository) {
        this.repository = repository;
    }
}

