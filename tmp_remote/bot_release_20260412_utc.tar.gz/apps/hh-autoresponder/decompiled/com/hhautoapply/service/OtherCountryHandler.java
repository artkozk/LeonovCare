/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.microsoft.playwright.Locator
 *  com.microsoft.playwright.Locator$WaitForOptions
 *  com.microsoft.playwright.Page
 *  com.microsoft.playwright.options.WaitForSelectorState
 *  lombok.Generated
 *  org.springframework.stereotype.Component
 */
package com.hhautoapply.service;

import com.hhautoapply.service.PlaywrightSupport;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.WaitForSelectorState;
import lombok.Generated;
import org.springframework.stereotype.Component;

@Component
public class OtherCountryHandler {
    private static final String OTHER_COUNTRY_PHRASE = "\u0412\u044b \u043e\u0442\u043a\u043b\u0438\u043a\u0430\u0435\u0442\u0435\u0441\u044c \u043d\u0430 \u0432\u0430\u043a\u0430\u043d\u0441\u0438\u044e \u0432 \u0434\u0440\u0443\u0433\u043e\u0439 \u0441\u0442\u0440\u0430\u043d\u0435";
    private static final String OTHER_COUNTRY_BTN_SEL = "button:has-text('\u0412\u0441\u0435 \u0440\u0430\u0432\u043d\u043e \u043e\u0442\u043a\u043b\u0438\u043a\u043d\u0443\u0442\u044c\u0441\u044f'), a:has-text('\u0412\u0441\u0435 \u0440\u0430\u0432\u043d\u043e \u043e\u0442\u043a\u043b\u0438\u043a\u043d\u0443\u0442\u044c\u0441\u044f')";
    private final PlaywrightSupport ui;

    public boolean confirm(Page page) {
        try {
            Locator btn = page.locator(OTHER_COUNTRY_BTN_SEL).first();
            try {
                btn.waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.VISIBLE).setTimeout(2200.0));
            }
            catch (Exception exception) {
                // empty catch block
            }
            if (!this.ui.isVisible(btn)) {
                return false;
            }
            return this.ui.stableClick(btn, () -> !this.ui.isVisible(page.locator("text=\u0412\u044b \u043e\u0442\u043a\u043b\u0438\u043a\u0430\u0435\u0442\u0435\u0441\u044c \u043d\u0430 \u0432\u0430\u043a\u0430\u043d\u0441\u0438\u044e \u0432 \u0434\u0440\u0443\u0433\u043e\u0439 \u0441\u0442\u0440\u0430\u043d\u0435").first()), 3000);
        }
        catch (Exception ignore) {
            return false;
        }
    }

    @Generated
    public OtherCountryHandler(PlaywrightSupport ui) {
        this.ui = ui;
    }
}

