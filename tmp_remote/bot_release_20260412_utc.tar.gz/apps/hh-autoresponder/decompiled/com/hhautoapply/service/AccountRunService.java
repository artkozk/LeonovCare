/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.microsoft.playwright.Browser
 *  com.microsoft.playwright.Browser$NewContextOptions
 *  com.microsoft.playwright.BrowserContext
 *  com.microsoft.playwright.BrowserContext$StorageStateOptions
 *  com.microsoft.playwright.BrowserType$LaunchOptions
 *  com.microsoft.playwright.Page
 *  com.microsoft.playwright.Page$NavigateOptions
 *  com.microsoft.playwright.Playwright
 *  com.microsoft.playwright.Response
 *  com.microsoft.playwright.options.WaitUntilState
 *  lombok.Generated
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 *  org.springframework.stereotype.Service
 *  org.springframework.transaction.annotation.Transactional
 */
package com.hhautoapply.service;

import com.hhautoapply.model.HhAccountEntity;
import com.hhautoapply.repository.HhAccountRepository;
import com.hhautoapply.service.HhApplyService;
import com.hhautoapply.service.HhAuthService;
import com.hhautoapply.service.RunAccountResponse;
import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;
import com.microsoft.playwright.Response;
import com.microsoft.playwright.options.WaitUntilState;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.FileAttribute;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import lombok.Generated;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AccountRunService {
    @Generated
    private static final Logger log = LoggerFactory.getLogger(AccountRunService.class);
    private static final String HH_BASE = "https://hh.ru";
    private final HhAccountRepository repository;
    private final HhAuthService hhAuthService;
    private final HhApplyService hhApplyService;

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Transactional
    public RunAccountResponse run(String login) {
        HhAccountEntity account = this.repository.findByLogin(login).orElseThrow(() -> new IllegalArgumentException("account not found: " + login));
        if (Boolean.FALSE.equals(account.getActive())) {
            return new RunAccountResponse(false, login, "account is inactive", 0, List.of());
        }
        String runId = UUID.randomUUID().toString().substring(0, 8);
        Path storage = this.storagePathFor(account.getLogin());
        Browser browser = null;
        BrowserContext ctx = null;
        try (Playwright pw = Playwright.create();){
            browser = pw.chromium().launch(new BrowserType.LaunchOptions().setHeadless(true).setSlowMo(150.0));
            Browser.NewContextOptions ctxOpts = new Browser.NewContextOptions().setLocale("ru-RU").setIgnoreHTTPSErrors(true).setViewportSize(1280, 720);
            if (Files.exists(storage, new LinkOption[0])) {
                ctxOpts.setStorageStatePath(storage);
                log.info("[{}][AUTH] reuse storageState={} login={}", new Object[]{runId, storage.toAbsolutePath(), AccountRunService.safeShort(login)});
            }
            ctx = browser.newContext(ctxOpts);
            Page page = ctx.newPage();
            SessionProbe preProbe = this.probeSession(page);
            if (!preProbe.loggedIn) {
                HhAuthService.AuthResult auth = this.hhAuthService.loginOnPage(page, account.getLogin(), account.getPassword());
                if (!auth.ok() && !auth.otpRequired()) {
                    this.safeClose(ctx, browser);
                    this.saveRunMeta(account, "AUTH_FAILED", 0);
                    RunAccountResponse runAccountResponse = new RunAccountResponse(false, login, "AUTH_FAILED: " + AccountRunService.safeShort(auth.details()), 0, List.of());
                    return runAccountResponse;
                }
                if (auth.otpRequired()) {
                    this.safeClose(ctx, browser);
                    this.saveRunMeta(account, "OTP_REQUIRED", 0);
                    RunAccountResponse runAccountResponse = new RunAccountResponse(false, login, "OTP_REQUIRED: " + AccountRunService.safeShort(auth.details()), 0, List.of());
                    return runAccountResponse;
                }
                try {
                    this.ensureDir(storage);
                    ctx.storageState(new BrowserContext.StorageStateOptions().setPath(storage));
                }
                catch (Exception e) {
                    log.warn("[{}][AUTH] storage save failed login={} err={}", new Object[]{runId, AccountRunService.safeShort(login), AccountRunService.safeShort(e.toString())});
                }
            }
            SessionProbe finalProbe = this.probeSession(page);
            if (!finalProbe.loggedIn) {
                this.safeClose(ctx, browser);
                this.saveRunMeta(account, "AUTH_FAILED_AFTER_PROBE", 0);
                RunAccountResponse e = new RunAccountResponse(false, login, "AUTH_FAILED_AFTER_PROBE", 0, List.of());
                return e;
            }
            List<HhApplyService.ApplyResult> results = this.hhApplyService.applyFromSerp(page, this.blankToDefault(account.getQueryText(), "java"), account.getTargetApplies() == null || account.getTargetApplies() < 1 ? 200 : account.getTargetApplies(), account.getCoverLetter(), account.getCandidateContext());
            int sent = (int)results.stream().filter(r -> "SENT".equals(r.status()) || "SENT_BY_LLM".equals(r.status()) || "APPLIED".equals(r.status())).count();
            this.safeClose(ctx, browser);
            this.saveRunMeta(account, "OK", sent);
            RunAccountResponse runAccountResponse = new RunAccountResponse(true, login, "OK", sent, results);
            return runAccountResponse;
        }
        catch (Exception e) {
            this.safeClose(ctx, browser);
            this.saveRunMeta(account, "ERR", 0);
            log.error("[{}][RUN_ACCOUNT] login={} err={}", new Object[]{runId, AccountRunService.safeShort(login), e.toString(), e});
            return new RunAccountResponse(false, login, "ERR: " + AccountRunService.safeShort(e.getMessage()), 0, List.of());
        }
    }

    private void saveRunMeta(HhAccountEntity account, String status, int sent) {
        account.setLastRunAt(LocalDateTime.now());
        account.setLastRunStatus(status);
        account.setLastSentCount(sent);
        this.repository.save(account);
    }

    private Path storagePathFor(String login) {
        String safe = (login == null ? "unknown" : login.trim().toLowerCase()).replaceAll("[^a-z0-9._@-]+", "_");
        return Paths.get("profiles", safe, "storageState.json");
    }

    private void ensureDir(Path p) {
        try {
            Files.createDirectories(p.getParent(), new FileAttribute[0]);
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private String blankToDefault(String s, String def) {
        return s == null || s.isBlank() ? def : s.trim();
    }

    private void safeClose(BrowserContext ctx, Browser browser) {
        try {
            if (ctx != null) {
                ctx.close();
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        try {
            if (browser != null) {
                browser.close();
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private static String safeShort(String s) {
        if (s == null) {
            return "";
        }
        return (s = s.trim()).length() <= 180 ? s : s.substring(0, 180) + "...";
    }

    private SessionProbe probeSession(Page page) {
        try {
            int status;
            String url;
            Response resp = page.navigate("https://hh.ru/applicant/resumes", new Page.NavigateOptions().setWaitUntil(WaitUntilState.DOMCONTENTLOADED).setTimeout(45000.0));
            String string = url = page.url() == null ? "" : page.url();
            if (url.contains("/account/login") || url.contains("/login")) {
                return new SessionProbe(false, url, "redirected_to_login");
            }
            int n = status = resp != null ? resp.status() : -1;
            if (status >= 400) {
                return new SessionProbe(false, url, "httpStatus=" + status);
            }
            boolean loginFormVisible = this.isVisible(page, "input[name='username'], input[type='password'], button:has-text('\u0412\u043e\u0439\u0442\u0438')");
            if (loginFormVisible) {
                return new SessionProbe(false, url, "login form visible");
            }
            return new SessionProbe(true, url, "ok");
        }
        catch (Exception e) {
            return new SessionProbe(false, AccountRunService.safeShort(page.url()), "probe exception: " + AccountRunService.safeShort(e.toString()));
        }
    }

    private boolean isVisible(Page page, String selector) {
        try {
            return page.locator(selector).first().isVisible();
        }
        catch (Exception e) {
            return false;
        }
    }

    @Generated
    public AccountRunService(HhAccountRepository repository, HhAuthService hhAuthService, HhApplyService hhApplyService) {
        this.repository = repository;
        this.hhAuthService = hhAuthService;
        this.hhApplyService = hhApplyService;
    }

    private static final class SessionProbe {
        final boolean loggedIn;
        final String url;
        final String details;

        private SessionProbe(boolean loggedIn, String url, String details) {
            this.loggedIn = loggedIn;
            this.url = url;
            this.details = details;
        }
    }
}
