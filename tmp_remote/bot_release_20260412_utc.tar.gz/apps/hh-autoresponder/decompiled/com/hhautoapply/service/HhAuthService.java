/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.microsoft.playwright.Frame
 *  com.microsoft.playwright.Locator
 *  com.microsoft.playwright.Locator$ClickOptions
 *  com.microsoft.playwright.Locator$TypeOptions
 *  com.microsoft.playwright.Locator$WaitForOptions
 *  com.microsoft.playwright.Page
 *  com.microsoft.playwright.Page$NavigateOptions
 *  com.microsoft.playwright.Page$ScreenshotOptions
 *  com.microsoft.playwright.PlaywrightException
 *  com.microsoft.playwright.options.WaitForSelectorState
 *  com.microsoft.playwright.options.WaitUntilState
 *  lombok.Generated
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 *  org.springframework.stereotype.Service
 */
package com.hhautoapply.service;

import com.microsoft.playwright.Frame;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.PlaywrightException;
import com.microsoft.playwright.options.WaitForSelectorState;
import com.microsoft.playwright.options.WaitUntilState;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.OpenOption;
import java.nio.file.Paths;
import lombok.Generated;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class HhAuthService {
    @Generated
    private static final Logger log = LoggerFactory.getLogger(HhAuthService.class);
    private static final String HOME_URL = "https://hh.ru/";
    private static final String LOGIN_URL = "https://hh.ru/account/login?role=applicant&backurl=%2F&hhtmFrom=main";

    public AuthResult loginOnPage(Page page, String login, String password) {
        this.gotoWithRetry(page, LOGIN_URL);
        this.dismissPopups(page);
        this.ensureSeekerMode(page);
        this.waitAny(page, new String[]{"input[inputmode='tel']", "input[type='tel']", "input[data-qa='magritte-phone-input-national-number-input']", "button:has-text('\u0412\u043e\u0439\u0442\u0438 \u0441 \u043f\u0430\u0440\u043e\u043b\u0435\u043c')", "a:has-text('\u0412\u043e\u0439\u0442\u0438 \u0441 \u043f\u0430\u0440\u043e\u043b\u0435\u043c')"}, 12000);
        this.enterLoginAndSwitchToPassword(page, login);
        if (this.isOtpChallenge(page)) {
            return new AuthResult(false, true, this.safeUrl(page), "OTP required");
        }
        this.enterPasswordAndSubmit(page, password);
        boolean ok = this.isLoggedIn(page) && !this.authRequiredNow(page) || this.isLoggedInByProbe(page);
        return new AuthResult(ok, false, this.safeUrl(page), ok ? "ok" : "failed");
    }

    private void ensureSeekerMode(Page page) {
        Locator submit = page.locator("button[data-qa='submit-button']").first();
        Locator cards = page.locator("[data-qa='account-type-cards']").first();
        if (!this.isVisible(submit) || !this.isVisible(cards)) {
            return;
        }
        Locator applicantCard = page.locator("label:has(input[data-qa^='account-type-card-APPLICANT']), input[data-qa^='account-type-card-APPLICANT']").first();
        if (this.isVisible(applicantCard)) {
            this.clickRobust(page, applicantCard, "door:applicant");
            page.waitForTimeout(150.0);
        } else {
            log.info("[AUTH] door detected but APPLICANT card not found");
        }
        this.waitEnabled(submit, page, 8000);
        this.clickRobust(page, submit, "door:submit");
        if (!this.waitAnyOk(page, new String[]{"input[inputmode='tel']", "input[type='tel']", "input[data-qa='magritte-phone-input-national-number-input']", "button:has-text('\u0412\u043e\u0439\u0442\u0438 \u0441 \u043f\u0430\u0440\u043e\u043b\u0435\u043c')", "a:has-text('\u0412\u043e\u0439\u0442\u0438 \u0441 \u043f\u0430\u0440\u043e\u043b\u0435\u043c')", "input[type='password']"}, 15000)) {
            this.dumpDebug(page, "door-submit-but-no-login-form");
            this.fail(page, "door-submit-but-no-login-form");
        }
    }

    private boolean isVisible(Locator l) {
        try {
            return l != null && l.count() > 0 && l.isVisible();
        }
        catch (Exception e) {
            return false;
        }
    }

    private boolean waitAnyOk(Page page, String[] selectors, int timeoutMs) {
        long until = System.currentTimeMillis() + (long)timeoutMs;
        while (System.currentTimeMillis() < until) {
            for (String sel : selectors) {
                try {
                    if (page.locator(sel).count() <= 0) continue;
                    return true;
                }
                catch (Exception exception) {
                    // empty catch block
                }
            }
            Frame f = this.findAuthFrameByContent(page);
            if (f != null) {
                for (String sel : selectors) {
                    try {
                        if (f.locator(sel).count() > 0) {
                            return true;
                        }
                    }
                    catch (Exception exception) {
                        // empty catch block
                    }
                }
            }
            page.waitForTimeout(120.0);
        }
        return false;
    }

    private void enterLoginAndSwitchToPassword(Page page, String rawLogin) {
        Scope scope = this.resolveScope(page);
        if (this.looksLikeEmail(rawLogin)) {
            this.switchCredentialToEmail(page, scope);
            scope = this.resolveScope(page);
            Locator email = this.firstVisible(scope, new String[]{"[data-qa='applicant-login-input-email'] input", "input[type='email']", "input[autocomplete='email']", "input[name='username']"});
            if (email == null) {
                this.dumpDebug(page, "email-field-not-found");
                this.fail(page, "email-field-not-found");
            }
            this.robustInputReact(page, email, rawLogin, "email");
            String actual = this.safeJsValue(email);
            log.info("[AUTH] email jsValue={}", (Object)actual);
            if (actual == null || !actual.contains("@")) {
                this.dumpDebug(page, "email-not-entered");
                this.fail(page, "email-not-entered");
            }
        } else {
            this.switchCredentialToPhone(page, scope);
            scope = this.resolveScope(page);
            Locator tel = this.firstVisible(scope, new String[]{"input[data-qa='magritte-phone-input-national-number-input']", "input[inputmode='tel']", "input[type='tel']", "input[name='login']"});
            if (tel == null) {
                this.fail(page, "phone-field-not-found");
            }
            String digits = this.normalize10Digits(rawLogin);
            this.robustInputReact(page, tel, digits, "phone");
            String actual = this.safeJsValue(tel);
            log.info("[AUTH] phone jsValue={}", (Object)actual);
            if (this.onlyDigits(actual).length() < 10) {
                this.dumpDebug(page, "phone-not-entered");
                this.fail(page, "phone-not-entered");
            }
        }
        page.waitForTimeout(200.0);
        Scope scope2 = this.resolveScope(page);
        Locator btn = this.findExpandByPassword(scope2, page);
        if (btn == null) {
            this.dumpDebug(page, "login-with-password-not-found");
            this.fail(page, "login-with-password-not-found");
        }
        this.waitEnabled(btn, page, 8000);
        this.clickRobust(page, btn, "login-with-password");
        page.waitForTimeout(250.0);
        this.waitAny(page, new String[]{"input[type='password']", "input[name='password']", "input[autocomplete='current-password']"}, 12000);
    }

    private Locator findExpandByPassword(Scope scope, Page page) {
        Locator inScope = scope.locator("button[data-qa='expand-login-by-password']").first();
        if (this.waitVisible(inScope, 6000)) {
            return inScope;
        }
        Locator onPage = page.locator("button[data-qa='expand-login-by-password']").first();
        if (this.waitVisible(onPage, 2000)) {
            return onPage;
        }
        Locator byText = page.locator("button:has-text('\u0412\u043e\u0439\u0442\u0438 \u0441')").first();
        if (this.waitVisible(byText, 1500)) {
            return byText;
        }
        return null;
    }

    private boolean waitVisible(Locator l, int timeoutMs) {
        try {
            l.waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.VISIBLE).setTimeout((double)timeoutMs));
            return true;
        }
        catch (Exception e) {
            return false;
        }
    }

    private void robustInputReact(Page page, Locator input, String value, String tag) {
        String v;
        try {
            input.scrollIntoViewIfNeeded();
        }
        catch (Exception exception) {
            // empty catch block
        }
        try {
            input.click(new Locator.ClickOptions().setTimeout(2000.0));
        }
        catch (Exception exception) {
            // empty catch block
        }
        try {
            input.focus();
        }
        catch (Exception exception) {
            // empty catch block
        }
        try {
            page.keyboard().press("Control+A");
        }
        catch (Exception exception) {
            // empty catch block
        }
        try {
            page.keyboard().press("Backspace");
        }
        catch (Exception exception) {
            // empty catch block
        }
        boolean ok = false;
        try {
            input.type(value, new Locator.TypeOptions().setDelay(35.0));
            page.waitForTimeout(150.0);
            v = this.safeJsValue(input);
            log.info("[AUTH] {} after-type={}", (Object)tag, (Object)v);
            ok = v != null && !v.isBlank();
        }
        catch (Exception e) {
            log.info("[AUTH] {} type failed: {}", (Object)tag, (Object)e.getMessage());
        }
        if (ok) {
            return;
        }
        try {
            this.setReactInputValue(input, value);
            page.waitForTimeout(150.0);
            v = this.safeJsValue(input);
            log.info("[AUTH] {} after-react-set={}", (Object)tag, (Object)v);
        }
        catch (Exception e) {
            log.info("[AUTH] {} react-set failed: {}", (Object)tag, (Object)e.getMessage());
        }
    }

    private String safeJsValue(Locator l) {
        try {
            Object o = l.evaluate("el => el.value");
            return o == null ? "" : o.toString();
        }
        catch (Exception e) {
            return "";
        }
    }

    private boolean looksLikeEmail(String s) {
        if (s == null) {
            return false;
        }
        String x = s.trim();
        return x.contains("@") && x.contains(".");
    }

    private void switchCredentialToEmail(Page page, Scope scope) {
        Locator emailRadio = scope.locator("input[data-qa='credential-type-EMAIL']").first();
        if (emailRadio.count() == 0) {
            return;
        }
        Locator emailLabel = scope.locator("label:has(input[data-qa='credential-type-EMAIL'])").first();
        log.info("[AUTH] switch credential -> EMAIL");
        if (emailLabel.count() > 0) {
            this.clickRobust(page, emailLabel, "cred:email");
        } else {
            this.clickRobust(page, emailRadio, "cred:email-radio");
        }
        page.waitForTimeout(150.0);
    }

    private void switchCredentialToPhone(Page page, Scope scope) {
        Locator phoneRadio = scope.locator("input[data-qa^='credential-type-PHONE']").first();
        if (phoneRadio.count() == 0) {
            return;
        }
        Locator phoneLabel = scope.locator("label:has(input[data-qa^='credential-type-PHONE'])").first();
        log.info("[AUTH] switch credential -> PHONE");
        if (phoneLabel.count() > 0) {
            this.clickRobust(page, phoneLabel, "cred:phone");
        } else {
            this.clickRobust(page, phoneRadio, "cred:phone-radio");
        }
        this.waitChecked(phoneRadio, page, 5000);
        page.waitForTimeout(150.0);
    }

    private void waitChecked(Locator radio, Page page, int timeoutMs) {
        long until = System.currentTimeMillis() + (long)timeoutMs;
        while (System.currentTimeMillis() < until) {
            try {
                if (radio.isChecked()) {
                    return;
                }
            }
            catch (Exception exception) {
                // empty catch block
            }
            page.waitForTimeout(120.0);
        }
        throw new RuntimeException("radio not checked");
    }

    private void setReactInputValue(Locator input, String value) {
        input.evaluate("(el, v) => {el.focus();const lastValue = el.value;const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;setter.call(el, v);const tracker = el._valueTracker;if (tracker) tracker.setValue(lastValue);el.dispatchEvent(new Event('input', { bubbles: true }));el.dispatchEvent(new Event('change', { bubbles: true }));}", (Object)value);
    }

    private void enterPasswordAndSubmit(Page page, String password) {
        Scope scope = this.resolveScope(page);
        Locator pass = this.firstVisible(scope, new String[]{"input[type='password']", "input[name='password']", "input[autocomplete='current-password']"});
        if (pass == null) {
            this.dumpDebug(page, "password-field-not-found");
            this.fail(page, "password-field-not-found");
        }
        pass.click(new Locator.ClickOptions().setTimeout(2000.0));
        pass.fill(password);
        if (!this.clickIfVisible(scope, "button[type='submit']") && !this.clickIfVisible(scope, "button:has-text('\u0412\u043e\u0439\u0442\u0438')")) {
            page.keyboard().press("Enter");
        }
    }

    private Scope resolveScope(Page page) {
        Frame f = this.findAuthFrameByContent(page);
        return new Scope(page, f);
    }

    private Frame findAuthFrameByContent(Page page) {
        Frame best = null;
        int bestScore = 0;
        for (Frame f : page.frames()) {
            try {
                if (f == page.mainFrame()) continue;
                int markers = 0;
                markers += f.locator("input[type='password'], input[name='password'], input[autocomplete='current-password']").count();
                markers += f.locator("input[inputmode='tel'], input[type='tel'], input[data-qa='magritte-phone-input-national-number-input']").count();
                if ((markers += f.locator("button:has-text('\u0412\u043e\u0439\u0442\u0438 \u0441 \u043f\u0430\u0440\u043e\u043b\u0435\u043c'), a:has-text('\u0412\u043e\u0439\u0442\u0438 \u0441 \u043f\u0430\u0440\u043e\u043b\u0435\u043c')").count()) <= 0) continue;
                int score = 100 + markers;
                String u = "";
                try {
                    u = f.url();
                }
                catch (Exception exception) {
                    // empty catch block
                }
                if (u.contains("passport") || u.contains("auth")) {
                    score += 5;
                }
                if (score <= bestScore) continue;
                bestScore = score;
                best = f;
            }
            catch (Exception exception) {}
        }
        return best;
    }

    private Locator firstVisible(Scope scope, String[] selectors) {
        for (String sel : selectors) {
            Locator l = scope.locator(sel).first();
            if (l.count() <= 0) continue;
            try {
                l.waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.VISIBLE).setTimeout(1200.0));
            }
            catch (Exception exception) {
                // empty catch block
            }
            try {
                if (!l.isVisible()) continue;
                return l;
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
        return null;
    }

    private boolean clickIfVisible(Scope scope, String selector) {
        try {
            Locator l = scope.locator(selector).first();
            if (l.count() > 0 && l.isVisible()) {
                l.click(new Locator.ClickOptions().setTimeout(1500.0));
                return true;
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return false;
    }

    private void waitAny(Page page, String[] selectors, int timeoutMs) {
        long until = System.currentTimeMillis() + (long)timeoutMs;
        while (System.currentTimeMillis() < until) {
            for (String sel : selectors) {
                if (page.locator(sel).count() > 0) {
                    return;
                }
                Frame f = this.findAuthFrameByContent(page);
                if (f == null || f.locator(sel).count() <= 0) continue;
                return;
            }
            page.waitForTimeout(120.0);
        }
    }

    private void waitEnabled(Locator l, Page page, int timeoutMs) {
        long until = System.currentTimeMillis() + (long)timeoutMs;
        while (System.currentTimeMillis() < until) {
            try {
                if (l.isVisible() && l.isEnabled()) {
                    return;
                }
            }
            catch (Exception exception) {
                // empty catch block
            }
            page.waitForTimeout(150.0);
        }
        throw new RuntimeException("Button still disabled");
    }

    private void clickRobust(Page page, Locator l, String tag) {
        try {
            l.scrollIntoViewIfNeeded();
        }
        catch (Exception exception) {
            // empty catch block
        }
        try {
            l.click(new Locator.ClickOptions().setTimeout(2000.0));
            page.waitForTimeout(150.0);
            return;
        }
        catch (Exception e1) {
            log.warn("[CLICK:{}] normal failed: {}", (Object)tag, (Object)e1.getMessage());
            try {
                l.click(new Locator.ClickOptions().setTimeout(2000.0).setForce(true));
                page.waitForTimeout(150.0);
                return;
            }
            catch (Exception e2) {
                log.warn("[CLICK:{}] force failed: {}", (Object)tag, (Object)e2.getMessage());
                try {
                    l.evaluate("el => el.click()");
                    page.waitForTimeout(150.0);
                    return;
                }
                catch (Exception e3) {
                    log.warn("[CLICK:{}] js failed: {}", (Object)tag, (Object)e3.getMessage());
                    this.snap(page, "click-failed-" + HhAuthService.safe(tag));
                    throw new RuntimeException("Click failed: " + tag);
                }
            }
        }
    }

    private void dismissPopups(Page page) {
        try {
            page.keyboard().press("Escape");
        }
        catch (Exception exception) {
            // empty catch block
        }
        this.clickIfVisible(new Scope(page, null), "[data-qa='region-clarification-confirm']");
        this.clickIfVisible(new Scope(page, null), "[data-qa='region-clarification-decline']");
        this.clickIfVisible(new Scope(page, null), "[data-qa='cookies-accept']");
        this.clickIfVisible(new Scope(page, null), "button:has-text('\u041f\u043e\u043d\u044f\u0442\u043d\u043e')");
    }

    private void gotoWithRetry(Page page, String url) {
        int attempts = 0;
        while (true) {
            ++attempts;
            try {
                page.navigate(url, new Page.NavigateOptions().setTimeout(20000.0).setWaitUntil(WaitUntilState.DOMCONTENTLOADED));
                return;
            }
            catch (PlaywrightException e) {
                if (attempts >= 3) {
                    this.snap(page, "nav-failed");
                    throw e;
                }
                page.waitForTimeout((double)(800L * (long)attempts));
                continue;
            }
            break;
        }
    }

    private boolean authRequiredNow(Page page) {
        try {
            String u = page.url();
            return u.contains("/login") || u.contains("/account/login") || u.contains("passport");
        }
        catch (Exception e) {
            return false;
        }
    }

    private boolean isOtpChallenge(Page page) {
        Frame f = this.findAuthFrameByContent(page);
        boolean onPage = page.locator("input[name='code'], input[autocomplete='one-time-code'], [data-qa*='otp'] input").count() > 0;
        boolean onFrame = f != null && f.locator("input[name='code'], input[autocomplete='one-time-code'], [data-qa*='otp'] input").count() > 0;
        return onPage || onFrame;
    }

    private boolean isLoggedIn(Page page) {
        for (int i = 0; i < 3; ++i) {
            try {
                return page.locator("[data-qa='mainmenu_applicantProfile'], [data-qa='mainmenu_myResumes']").first().isVisible();
            }
            catch (PlaywrightException e) {
                String msg = String.valueOf(e.getMessage());
                if (msg.contains("Execution context was destroyed") || msg.contains("Target closed") || msg.contains("Navigation")) {
                    try {
                        page.waitForTimeout(150.0);
                    }
                    catch (Exception exception) {}
                    continue;
                }
                throw e;
            }
        }
        return false;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private boolean isLoggedInByProbe(Page page) {
        boolean bl;
        String before = this.safeUrl(page);
        try {
            page.navigate("https://hh.ru/applicant/resumes", new Page.NavigateOptions().setTimeout(15000.0).setWaitUntil(WaitUntilState.DOMCONTENTLOADED));
            page.waitForTimeout(300.0);
            if (this.authRequiredNow(page)) {
                boolean bl2 = false;
                return bl2;
            }
            bl = this.isLoggedIn(page) || page.locator("text=\u041c\u043e\u0438 \u0440\u0435\u0437\u044e\u043c\u0435").count() > 0;
        }
        catch (Exception e) {
            boolean bl3 = false;
            return bl3;
        }
        finally {
            try {
                if (before != null) {
                    page.navigate(before, new Page.NavigateOptions().setTimeout(15000.0).setWaitUntil(WaitUntilState.DOMCONTENTLOADED));
                }
            }
            catch (Exception exception) {}
        }
        return bl;
    }

    private String safeUrl(Page page) {
        try {
            return page == null ? null : page.url();
        }
        catch (Exception e) {
            return null;
        }
    }

    private void snap(Page page, String name) {
        try {
            page.screenshot(new Page.ScreenshotOptions().setPath(Paths.get("debug-" + HhAuthService.safe(name) + ".png", new String[0])));
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private void dumpDebug(Page page, String tag) {
        this.snap(page, tag);
        try {
            Files.writeString(Paths.get("debug-" + HhAuthService.safe(tag) + ".html", new String[0]), (CharSequence)page.content(), StandardCharsets.UTF_8, new OpenOption[0]);
        }
        catch (Exception exception) {
            // empty catch block
        }
        try {
            StringBuilder sb = new StringBuilder();
            for (Frame fr : page.frames()) {
                String u = "";
                try {
                    u = fr.url();
                }
                catch (Exception exception) {
                    // empty catch block
                }
                sb.append(u).append("\n");
            }
            Files.writeString(Paths.get("debug-" + HhAuthService.safe(tag) + "-frames.txt", new String[0]), (CharSequence)sb.toString(), StandardCharsets.UTF_8, new OpenOption[0]);
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private void fail(Page page, String tag) {
        this.dumpDebug(page, tag);
        throw new RuntimeException(tag);
    }

    private static String safe(String s) {
        return s == null ? "null" : s.replaceAll("[^a-zA-Z0-9._-]", "_");
    }

    private String normalize10Digits(String raw) {
        Object digits = this.onlyDigits(raw);
        if (((String)digits).startsWith("8") && ((String)digits).length() == 11) {
            digits = "7" + ((String)digits).substring(1);
        }
        if (((String)digits).startsWith("7") && ((String)digits).length() == 11) {
            digits = ((String)digits).substring(1);
        }
        if (((String)digits).length() > 10) {
            digits = ((String)digits).substring(((String)digits).length() - 10);
        }
        return digits;
    }

    private String onlyDigits(String s) {
        return s == null ? "" : s.replaceAll("\\D+", "");
    }

    public record AuthResult(boolean ok, boolean otpRequired, String url, String details) {
    }

    private record Scope(Page page, Frame frame) {
        Locator locator(String sel) {
            return this.frame != null ? this.frame.locator(sel) : this.page.locator(sel);
        }
    }
}

