/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 *  org.springframework.scheduling.annotation.Scheduled
 *  org.springframework.stereotype.Service
 */
package com.hhautoapply.service;

import com.hhautoapply.api.AuthController;
import com.hhautoapply.config.AppProps;
import com.hhautoapply.model.HhAccountEntity;
import com.hhautoapply.repository.HhAccountRepository;
import com.hhautoapply.service.AccountRunService;
import com.hhautoapply.service.ApplyProfileStore;
import com.hhautoapply.service.RunAccountResponse;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicBoolean;
import lombok.Generated;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

@Service
public class DailyAccountRunScheduler {
    @Generated
    private static final Logger log = LoggerFactory.getLogger(DailyAccountRunScheduler.class);
    private final AppProps appProps;
    private final HhAccountRepository repository;
    private final AccountRunService accountRunService;
    private final ApplyProfileStore applyProfileStore;
    private final AuthController authController;
    private final Executor runsExecutor;
    private final AtomicBoolean running = new AtomicBoolean(false);

    @Scheduled(cron="${app.daily-run.cron:0 0 9 * * *}", zone="${app.daily-run.zone:Europe/Kaliningrad}")
    public void triggerDailyRun() {
        AppProps.DailyRun cfg = this.appProps.getDailyRun();
        if (cfg == null || !Boolean.TRUE.equals(cfg.getEnabled())) {
            return;
        }
        if (!this.running.compareAndSet(false, true)) {
            log.info("[DAILY_RUN] skipped: previous run is still active");
            return;
        }
        this.runsExecutor.execute(() -> {
            try {
                this.runActiveAccounts();
            }
            finally {
                this.running.set(false);
            }
        });
    }

    private void runActiveAccounts() {
        List<HhAccountEntity> dbAccounts = this.repository.findAllByActiveTrueOrderByIdAsc();
        List<String> yamlLogins = this.applyProfileStore.logins();
        int ok = 0;
        int failed = 0;
        int totalSent = 0;
        LinkedHashSet<String> seenLogins = new LinkedHashSet<String>();
        log.info("[DAILY_RUN] started dbAccounts={} yamlAccounts={}", (Object)dbAccounts.size(), (Object)yamlLogins.size());
        for (HhAccountEntity account : dbAccounts) {
            try {
                RunAccountResponse resp = this.accountRunService.run(account.getLogin());
                seenLogins.add(this.normalizeLogin(account.getLogin()));
                if (resp.ok()) {
                    ++ok;
                } else {
                    ++failed;
                }
                totalSent += Math.max(0, resp.sent());
                log.info("[DAILY_RUN][DB] login={} ok={} sent={} details={}", new Object[]{this.safe(account.getLogin()), resp.ok(), resp.sent(), this.safe(resp.details())});
            }
            catch (Exception e) {
                ++failed;
                log.error("[DAILY_RUN][DB] login={} failed err={}", new Object[]{this.safe(account.getLogin()), this.safe(e.toString()), e});
            }
        }
        for (String login : yamlLogins) {
            String normalized = this.normalizeLogin(login);
            if (!normalized.isBlank() && seenLogins.contains(normalized)) {
                log.info("[DAILY_RUN][YAML] login={} skipped=duplicate", (Object)this.safe(login));
                continue;
            }
            try {
                AuthController.ApplyResp resp = this.authController.applyDebug(new AuthController.ApplyReq(login));
                seenLogins.add(normalized);
                if (resp.ok()) {
                    ++ok;
                } else {
                    ++failed;
                }
                totalSent += Math.max(0, resp.sent());
                log.info("[DAILY_RUN][YAML] login={} ok={} sent={} details={}", new Object[]{this.safe(login), resp.ok(), resp.sent(), this.safe(resp.details())});
            }
            catch (Exception e) {
                ++failed;
                log.error("[DAILY_RUN][YAML] login={} failed err={}", new Object[]{this.safe(login), this.safe(e.toString()), e});
            }
        }
        log.info("[DAILY_RUN] finished dbAccounts={} yamlAccounts={} totalRuns={} ok={} failed={} totalSent={}", new Object[]{dbAccounts.size(), yamlLogins.size(), ok + failed, ok, failed, totalSent});
    }

    private String safe(String s) {
        if (s == null) {
            return "";
        }
        return (s = s.trim()).length() <= 200 ? s : s.substring(0, 200) + "...";
    }

    private String normalizeLogin(String login) {
        if (login == null) {
            return "";
        }
        String s = login.trim();
        if (s.contains("@")) {
            return s.toLowerCase(Locale.ROOT);
        }
        Object digits = s.replaceAll("\\D+", "");
        if (((String)digits).length() == 11 && ((String)digits).startsWith("8")) {
            digits = "7" + ((String)digits).substring(1);
        }
        return digits;
    }

    @Generated
    public DailyAccountRunScheduler(AppProps appProps, HhAccountRepository repository, AccountRunService accountRunService, ApplyProfileStore applyProfileStore, AuthController authController, Executor runsExecutor) {
        this.appProps = appProps;
        this.repository = repository;
        this.accountRunService = accountRunService;
        this.applyProfileStore = applyProfileStore;
        this.authController = authController;
        this.runsExecutor = runsExecutor;
    }
}

