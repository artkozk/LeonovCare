/*
 * Decompiled with CFR 0.152.
 */
package com.hhautoapply.service;

import com.hhautoapply.service.HhApplyService;
import java.util.List;

public record RunAccountResponse(boolean ok, String login, String details, int sent, List<HhApplyService.ApplyResult> results) {
}

