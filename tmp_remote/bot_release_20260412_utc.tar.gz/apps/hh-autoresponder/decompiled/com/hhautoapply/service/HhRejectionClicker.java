/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.microsoft.playwright.Frame
 *  com.microsoft.playwright.Locator
 *  com.microsoft.playwright.Locator$ClickOptions
 *  com.microsoft.playwright.Locator$SetCheckedOptions
 *  com.microsoft.playwright.Locator$WaitForOptions
 *  com.microsoft.playwright.Page
 *  com.microsoft.playwright.options.WaitForSelectorState
 *  lombok.Generated
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 *  org.springframework.stereotype.Component
 */
package com.hhautoapply.service;

import com.microsoft.playwright.Frame;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.WaitForSelectorState;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import lombok.Generated;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class HhRejectionClicker {
    @Generated
    private static final Logger log = LoggerFactory.getLogger(HhRejectionClicker.class);
    private static final String CHATIK_ACTIVATOR_SEL = "[data-qa='chatik-activator']";
    private static final String CHATIK_BADGE_SEL = "[data-qa='chatikActivator-badge']";
    private static final String CHATIK_HOST_URL_PART = "chatik.hh.ru";
    private static final String ONLY_UNREAD_CB_SEL = "input[data-qa='chatik-checkbox-only-unread']";
    private static final String CHAT_META_SEL = "[data-qa='chat-cell-meta']";
    private static final String CHAT_TIME_SEL = "[data-qa='chat-cell-creation-time']";
    private static final String REFUSAL_MARK_SEL = "css=div[class*='last-message-color_red']:has-text('\u041e\u0442\u043a\u0430\u0437')";
    private static final String ROW_FROM_MARK_XPATH = "xpath=ancestor::div[.//div[@data-qa='chat-cell-meta'] and .//div[@data-qa='chat-cell-creation-time']][1]";
    private static final String REFUSAL_TEXT_RX = "text=/\u041e\u0442\u043a\u0430\u0437|\u041e\u0442\u043a\u0430\u0437\u0430\u043d\u043e|Rejected|Declined/i";
    private static final String ROW_ROOT_XPATH = "xpath=//div[.//div[@data-qa='chat-cell-meta'] and .//div[@data-qa='chat-cell-creation-time']]";
    private static final int OPEN_RETRIES = 5;
    private static final int CLICK_TIMEOUT_MS = 3500;
    private static final int PICK_CANDIDATES = 60;
    private static final int INNER_STUCK_LIMIT = 10;
    private static final int SCROLL_STEP_PX = 1100;
    private static final int MICRO_SCROLL_PX = 320;
    private static final int MAX_PASSES = 500;
    private static final int NO_PROGRESS_LIMIT = 30;
    private static final int MAX_CLICKS = 2000;
    private static final boolean DBG = true;

    public Result openChatsAndClickUntilNoRefusals(Page page) {
        if (page == null) {
            return Result.fail("page=null");
        }
        try {
            this.dbg("START url=" + HhRejectionClicker.safe(page.url()));
            Frame chatFrame = this.openAndWaitChatikFrame(page);
            if (chatFrame == null) {
                return Result.fail("chatik_frame_not_found");
            }
            this.dbg("chatFrame=" + HhRejectionClicker.safe(chatFrame.url()));
            boolean onlyUnreadLocked = this.ensureOnlyUnreadEnabled(chatFrame);
            HashSet<String> seen = new HashSet<String>();
            int clicked = 0;
            int noProgress = 0;
            Direction dir = Direction.DOWN;
            boolean hitTop = false;
            boolean hitBottom = false;
            for (int pass = 0; pass < 500 && clicked < 2000; ++pass) {
                if (!this.ensureChatikOpen(page, chatFrame)) {
                    this.dbg("ensureChatikOpen=false (panel likely closed or blocked)");
                    if (++noProgress < 30) continue;
                    break;
                }
                if (onlyUnreadLocked) {
                    boolean checked = false;
                    try {
                        Locator cb = chatFrame.locator(ONLY_UNREAD_CB_SEL).first();
                        if (this.isVisible(cb)) {
                            checked = cb.isChecked();
                        }
                    }
                    catch (Exception cb) {
                        // empty catch block
                    }
                    if (!checked) {
                        this.dbg("onlyUnread was reset by UI -> re-enable");
                        onlyUnreadLocked = this.ensureOnlyUnreadEnabled(chatFrame);
                    }
                }
                int beforeClicked = clicked;
                int delta = this.clickRefusalsOnViewport(page, chatFrame, seen, 2000 - clicked, onlyUnreadLocked);
                this.dbg("pass=" + pass + " dir=" + String.valueOf((Object)dir) + " delta=" + delta + " total=" + (clicked += delta));
                if (clicked > beforeClicked) {
                    noProgress = 0;
                    hitTop = false;
                    hitBottom = false;
                } else {
                    ++noProgress;
                }
                if (noProgress >= 30) {
                    this.dbg("STOP noProgress=" + noProgress);
                    break;
                }
                int dy = dir == Direction.DOWN ? 1100 : -1100;
                ScrollResult sr = this.scrollChatList(chatFrame, dy);
                this.dbg("scroll big dir=" + String.valueOf((Object)dir) + " " + String.valueOf(sr));
                if (!sr.moved()) {
                    if (dir == Direction.DOWN) {
                        hitBottom = true;
                    } else {
                        hitTop = true;
                    }
                    if (hitTop && hitBottom && delta == 0) {
                        this.dbg("EXIT: hitTop && hitBottom && delta==0 => no refusals anywhere");
                        break;
                    }
                    dir = dir == Direction.DOWN ? Direction.UP : Direction.DOWN;
                    int mdy = dir == Direction.DOWN ? 320 : -320;
                    ScrollResult micro = this.scrollChatList(chatFrame, mdy);
                    this.dbg("scroll micro switchTo=" + String.valueOf((Object)dir) + " " + String.valueOf(micro));
                }
                page.waitForTimeout(200.0);
            }
            return Result.ok(clicked, "done clicked=" + clicked + " frameUrl=" + HhRejectionClicker.safe(chatFrame.url()));
        }
        catch (Exception e) {
            log.warn("[REFUSAL] exception: {}", (Object)e.toString(), (Object)e);
            return Result.fail("exception: " + HhRejectionClicker.shorty(e.toString()));
        }
    }

    private Frame openAndWaitChatikFrame(Page page) {
        Frame chatFrame = null;
        for (int attempt = 0; attempt < 5; ++attempt) {
            boolean clicked = false;
            Locator badge = page.locator(CHATIK_BADGE_SEL).first();
            if (this.isVisible(badge)) {
                clicked = this.forceClick(badge);
                this.dbg("open attempt=" + attempt + " click badge clicked=" + clicked);
            } else {
                Locator act = page.locator(CHATIK_ACTIVATOR_SEL).first();
                if (this.isVisible(act)) {
                    clicked = this.forceClick(act);
                    this.dbg("open attempt=" + attempt + " click activator clicked=" + clicked);
                } else {
                    this.dbg("open attempt=" + attempt + " no activator/badge visible");
                }
            }
            page.waitForTimeout(250.0);
            chatFrame = this.findChatikFrame(page);
            if (chatFrame == null) {
                this.dbg("open attempt=" + attempt + " frame not found");
                continue;
            }
            if (this.waitChatListVisible(chatFrame, 2500)) {
                this.dbg("open attempt=" + attempt + " chat list visible OK");
                return chatFrame;
            }
            this.dbg("open attempt=" + attempt + " chat list NOT visible; retry");
        }
        return chatFrame;
    }

    private Frame findChatikFrame(Page page) {
        for (Frame f : page.frames()) {
            String u = HhRejectionClicker.safe(f.url());
            if (!u.contains(CHATIK_HOST_URL_PART)) continue;
            return f;
        }
        return null;
    }

    private boolean waitChatListVisible(Frame chatFrame, int timeoutMs) {
        try {
            Locator meta = chatFrame.locator(CHAT_META_SEL).first();
            meta.waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.VISIBLE).setTimeout((double)timeoutMs));
            return true;
        }
        catch (Exception e) {
            return false;
        }
    }

    private boolean ensureChatikOpen(Page page, Frame chatFrame) {
        if (this.isVisible(chatFrame.locator(CHAT_META_SEL).first())) {
            return true;
        }
        Locator act = page.locator(CHATIK_ACTIVATOR_SEL).first();
        Locator badge = page.locator(CHATIK_BADGE_SEL).first();
        boolean clicked = false;
        if (this.isVisible(act)) {
            clicked = this.forceClick(act);
        } else if (this.isVisible(badge)) {
            clicked = this.forceClick(badge);
        }
        this.dbg("ensureOpen clicked=" + clicked);
        page.waitForTimeout(200.0);
        return this.waitChatListVisible(chatFrame, 2500);
    }

    private boolean ensureOnlyUnreadEnabled(Frame chatFrame) {
        try {
            Locator cb = chatFrame.locator(ONLY_UNREAD_CB_SEL).first();
            try {
                cb.waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.VISIBLE).setTimeout(3000.0));
            }
            catch (Exception exception) {
                // empty catch block
            }
            if (!this.isVisible(cb)) {
                this.dbg("onlyUnread: not visible");
                return false;
            }
            for (int i = 0; i < 3; ++i) {
                boolean checked = false;
                try {
                    checked = cb.isChecked();
                }
                catch (Exception exception) {
                    // empty catch block
                }
                this.dbg("onlyUnread: try=" + i + " checked(before)=" + checked);
                if (checked) {
                    return true;
                }
                try {
                    cb.setChecked(true, new Locator.SetCheckedOptions().setTimeout(2500.0).setForce(true));
                }
                catch (Exception e) {
                    this.dbg("onlyUnread: setChecked err=" + HhRejectionClicker.shorty(e.toString()));
                }
                chatFrame.page().waitForTimeout(220.0);
                boolean after = false;
                try {
                    after = cb.isChecked();
                }
                catch (Exception exception) {
                    // empty catch block
                }
                this.dbg("onlyUnread: try=" + i + " checked(after)=" + after);
                if (!after) continue;
                return true;
            }
            return false;
        }
        catch (Exception e) {
            this.dbg("onlyUnread: exception " + HhRejectionClicker.shorty(e.toString()));
            return false;
        }
    }

    private int clickRefusalsOnViewport(Page page, Frame chatFrame, Set<String> seen, int budget, boolean onlyUnreadLocked) {
        int clicked = 0;
        int stuck = 0;
        while (clicked < budget) {
            Locator row = this.pickNextRefusalRow(chatFrame, seen);
            if (row == null) {
                this.dbg("pickNextRefusalRow=null stuck=" + ++stuck);
                if (stuck >= 10) break;
                ScrollResult sc = this.scrollChatList(chatFrame, 320);
                this.dbg("scan micro scroll " + String.valueOf(sc));
                page.waitForTimeout(140.0);
                continue;
            }
            stuck = 0;
            String key = this.rowKey(row);
            if (!key.isBlank()) {
                seen.add(key);
            }
            boolean ok = this.stableClick(row);
            this.dbg("click row ok=" + ok);
            if (onlyUnreadLocked) {
                this.waitRowGone(page, row, 1500);
            } else {
                page.waitForTimeout(150.0);
            }
            ++clicked;
            page.waitForTimeout(80.0);
        }
        return clicked;
    }

    private Locator pickNextRefusalRow(Frame chatFrame, Set<String> seen) {
        int totalRows;
        int totalMarks;
        Locator marks = chatFrame.locator(REFUSAL_MARK_SEL);
        try {
            totalMarks = marks.count();
        }
        catch (Exception e) {
            totalMarks = 0;
        }
        int n = Math.min(totalMarks, 60);
        this.dbg("marks total=" + totalMarks + " scan=" + n);
        for (int i = 0; i < n; ++i) {
            String key;
            Locator row;
            Locator mark = marks.nth(i);
            if (!this.isVisible(mark) || !this.isVisible(row = mark.locator(ROW_FROM_MARK_XPATH).first()) || !this.isVisible(row.locator(CHAT_META_SEL).first()) || !this.isVisible(row.locator(CHAT_TIME_SEL).first()) || !(key = this.rowKey(row)).isBlank() && seen.contains(key)) continue;
            this.dbg("candidateRow[" + i + "] hint=" + HhRejectionClicker.shorty(this.rowTextHint(row)));
            return row;
        }
        Locator rows = chatFrame.locator(ROW_ROOT_XPATH);
        try {
            totalRows = rows.count();
        }
        catch (Exception e) {
            totalRows = 0;
        }
        int rn = Math.min(totalRows, 60);
        this.dbg("fallback rows total=" + totalRows + " scan=" + rn);
        for (int i = 0; i < rn; ++i) {
            String key;
            Locator row = rows.nth(i);
            if (!this.isVisible(row)) continue;
            boolean hasRefusal = false;
            try {
                hasRefusal = row.locator(REFUSAL_TEXT_RX).count() > 0;
            }
            catch (Exception exception) {
                // empty catch block
            }
            if (!hasRefusal || !this.isVisible(row.locator(CHAT_META_SEL).first()) || !this.isVisible(row.locator(CHAT_TIME_SEL).first()) || !(key = this.rowKey(row)).isBlank() && seen.contains(key)) continue;
            this.dbg("fallback candidateRow[" + i + "] hint=" + HhRejectionClicker.shorty(this.rowTextHint(row)));
            return row;
        }
        return null;
    }

    private void waitRowGone(Page page, Locator row, int timeoutMs) {
        if (row == null) {
            return;
        }
        try {
            row.waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.HIDDEN).setTimeout((double)timeoutMs));
        }
        catch (Exception exception) {
            // empty catch block
        }
        page.waitForTimeout(80.0);
    }

    private ScrollResult scrollChatList(Frame chatFrame, int dyPx) {
        try {
            Locator any = chatFrame.locator(CHAT_META_SEL).first();
            if (!this.isVisible(any)) {
                this.dbg("scroll: no visible meta anchor (panel closed?)");
                return new ScrollResult(false, -1, -1, false, -1);
            }
            Object raw = any.evaluate("(el, dy) => {let p = el;for (let k=0; k<18 && p; k++) {  const s = window.getComputedStyle(p);  const oy = s && s.overflowY;  const can = (oy==='auto'||oy==='scroll') && p.scrollHeight>p.clientHeight;  if (can) {    const before = p.scrollTop;    p.scrollTop = before + dy;    const after = p.scrollTop;    return {ok:true, k, before, after};  }  p = p.parentElement;}return {ok:false};}", (Object)dyPx);
            String s = String.valueOf(raw);
            boolean ok = s.contains("ok=true");
            int before = this.extractInt(s, "before=");
            int after = this.extractInt(s, "after=");
            int k = this.extractInt(s, "k=");
            boolean moved = ok && before >= 0 && after >= 0 && before != after;
            return new ScrollResult(ok, before, after, moved, k);
        }
        catch (Exception e) {
            this.dbg("scroll err=" + HhRejectionClicker.shorty(e.toString()));
            return new ScrollResult(false, -1, -1, false, -1);
        }
    }

    private int extractInt(String s, String key) {
        try {
            int j;
            int i = s.indexOf(key);
            if (i < 0) {
                return -1;
            }
            for (j = i += key.length(); j < s.length() && (Character.isDigit(s.charAt(j)) || s.charAt(j) == '-'); ++j) {
            }
            return Integer.parseInt(s.substring(i, j));
        }
        catch (Exception e) {
            return -1;
        }
    }

    private boolean stableClick(Locator l) {
        if (l == null) {
            return false;
        }
        try {
            l.scrollIntoViewIfNeeded();
        }
        catch (Exception exception) {
            // empty catch block
        }
        if (this.clickOnce(l, false)) {
            return true;
        }
        return this.clickOnce(l, true);
    }

    private boolean clickOnce(Locator l, boolean force) {
        try {
            l.click(new Locator.ClickOptions().setTimeout(3500.0).setForce(force));
            return true;
        }
        catch (Exception e) {
            this.dbg("clickOnce force=" + force + " err=" + HhRejectionClicker.shorty(e.toString()));
            return false;
        }
    }

    private boolean forceClick(Locator l) {
        try {
            l.click(new Locator.ClickOptions().setTimeout(3500.0).setForce(true));
            return true;
        }
        catch (Exception e) {
            this.dbg("forceClick err=" + HhRejectionClicker.shorty(e.toString()));
            return false;
        }
    }

    private boolean isVisible(Locator l) {
        try {
            return l != null && l.isVisible();
        }
        catch (Exception e) {
            return false;
        }
    }

    private String rowKey(Locator row) {
        try {
            String t = row.innerText();
            if (t == null) {
                t = "";
            }
            if ((t = t.replaceAll("\\s+", " ").trim()).length() > 260) {
                t = t.substring(0, 260);
            }
            return t.toLowerCase(Locale.ROOT);
        }
        catch (Exception e) {
            return "";
        }
    }

    private String rowTextHint(Locator row) {
        try {
            String t = row.innerText();
            if (t == null) {
                return "";
            }
            return (t = t.replaceAll("\\s+", " ").trim()).length() <= 140 ? t : t.substring(0, 140);
        }
        catch (Exception e) {
            return "";
        }
    }

    private void dbg(String s) {
        log.info("[CHATIK][DBG] {}", (Object)s);
    }

    private static String safe(String s) {
        return s == null ? "" : s;
    }

    private static String shorty(String s) {
        if (s == null) {
            return "";
        }
        return (s = s.trim()).length() <= 500 ? s : s.substring(0, 500) + "...";
    }

    public record Result(boolean ok, int clicked, String details) {
        public static Result ok(int clicked, String details) {
            return new Result(true, clicked, details);
        }

        public static Result fail(String details) {
            return new Result(false, 0, details);
        }
    }

    private static enum Direction {
        DOWN,
        UP;

    }

    private record ScrollResult(boolean ok, int before, int after, boolean moved, int depth) {
        @Override
        public String toString() {
            return "ok=" + this.ok + " moved=" + this.moved + " depth=" + this.depth + " before=" + this.before + " after=" + this.after;
        }
    }
}

