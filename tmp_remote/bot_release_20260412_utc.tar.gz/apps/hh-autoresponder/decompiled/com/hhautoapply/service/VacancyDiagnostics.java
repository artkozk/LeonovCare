/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.microsoft.playwright.Locator
 *  com.microsoft.playwright.Page
 *  lombok.Generated
 *  org.springframework.stereotype.Component
 */
package com.hhautoapply.service;

import com.hhautoapply.service.PlaywrightSupport;
import com.hhautoapply.service.SubmitButtonFinder;
import com.hhautoapply.service.VacancyPageStateDetector;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import lombok.Generated;
import org.springframework.stereotype.Component;

@Component
public class VacancyDiagnostics {
    private static final String Q_SEL = "[data-qa='task-question']";
    private final PlaywrightSupport ui;
    private final VacancyPageStateDetector detector;
    private final SubmitButtonFinder submitButtonFinder;

    public String diag(Page page) {
        try {
            boolean modal = this.detector.firstVisibleModal(page) != null;
            boolean inResp = this.detector.isInResponseFlow(page);
            boolean q = this.detector.detectRequirements(page).questionsPresent();
            boolean success = this.detector.hasSuccessNow(page);
            boolean limit = this.detector.detectDailyLimitFast(page) != null;
            boolean already = this.detector.detectAlreadyAppliedPolled(page, 120, 200) != null;
            Locator submit = this.submitButtonFinder.findVisibleSubmit(this.detector.firstVisibleModal(page), page);
            boolean submitVisible = submit != null;
            boolean submitDisabled = submit == null || !submit.isEnabled();
            return "modal=" + modal + ", inResp=" + inResp + ", q=" + q + ", submitVisible=" + submitVisible + ", submitDisabled=" + submitDisabled + ", success=" + success + ", limit=" + limit + ", already=" + already;
        }
        catch (Exception e) {
            return "diag_failed=" + e.getClass().getSimpleName() + ": " + String.valueOf(e.getMessage());
        }
    }

    public String diagWithStage(Page page, String stage) {
        return "stage=" + stage + " | " + this.diag(page);
    }

    @Generated
    public VacancyDiagnostics(PlaywrightSupport ui, VacancyPageStateDetector detector, SubmitButtonFinder submitButtonFinder) {
        this.ui = ui;
        this.detector = detector;
        this.submitButtonFinder = submitButtonFinder;
    }
}

