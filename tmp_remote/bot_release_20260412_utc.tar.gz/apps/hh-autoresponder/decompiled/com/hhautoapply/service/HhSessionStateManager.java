/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.microsoft.playwright.Browser
 *  com.microsoft.playwright.Browser$NewContextOptions
 *  com.microsoft.playwright.BrowserContext
 *  com.microsoft.playwright.BrowserContext$StorageStateOptions
 *  com.microsoft.playwright.BrowserType$LaunchOptions
 *  com.microsoft.playwright.Page
 *  com.microsoft.playwright.Page$NavigateOptions
 *  com.microsoft.playwright.Playwright
 *  com.microsoft.playwright.Response
 *  com.microsoft.playwright.options.WaitUntilState
 *  lombok.Generated
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 *  org.springframework.stereotype.Component
 */
package com.hhautoapply.service;

import com.hhautoapply.model.ApplyProfile;
import com.hhautoapply.service.ApplyProfileStore;
import com.hhautoapply.service.HhAuthService;
import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;
import com.microsoft.playwright.Response;
import com.microsoft.playwright.options.WaitUntilState;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.attribute.FileAttribute;
import java.security.MessageDigest;
import java.util.HexFormat;
import java.util.Locale;
import lombok.Generated;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class HhSessionStateManager {
    @Generated
    private static final Logger log = LoggerFactory.getLogger(HhSessionStateManager.class);
    private final ApplyProfileStore applyProfileStore;
    private final HhAuthService hhAuthService;
    private static final Path STATE_DIR = Path.of("pw-states", new String[0]);

    public EnsureStateResult ensureStateForAccount(String login) {
        ApplyProfile profile;
        try {
            profile = this.applyProfileStore.profile(login);
        }
        catch (Exception e) {
            return EnsureStateResult.fail("profile lookup failed for login=" + HhSessionStateManager.safeShort(login) + ": " + HhSessionStateManager.shorty(e.toString()));
        }
        try {
            Files.createDirectories(STATE_DIR, new FileAttribute[0]);
            String keyLogin = HhSessionStateManager.normalizeLogin(login);
            Path statePath = this.statePathFor(keyLogin);
            if (!Files.exists(statePath, new LinkOption[0])) {
                return this.createState(keyLogin, profile, statePath, "state_missing");
            }
            boolean ok = this.probeWithState(keyLogin, profile, statePath);
            if (ok) {
                return EnsureStateResult.ok(statePath, "state_ok");
            }
            return this.createState(keyLogin, profile, statePath, "state_expired");
        }
        catch (Exception e) {
            return EnsureStateResult.fail("ensureState err: " + HhSessionStateManager.shorty(e.toString()));
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private EnsureStateResult createState(String login, ApplyProfile profile, Path statePath, String reason) {
        String runId = "state-" + this.shortHash(login) + "-" + reason;
        Browser browser = null;
        BrowserContext ctx = null;
        try (Playwright pw = Playwright.create();){
            browser = pw.chromium().launch(new BrowserType.LaunchOptions().setHeadless(true).setSlowMo(150.0));
            ctx = browser.newContext(new Browser.NewContextOptions().setLocale("ru-RU").setViewportSize(1280, 720));
            Page page = ctx.newPage();
            HhAuthService.AuthResult auth = this.hhAuthService.loginOnPage(page, login, profile.password());
            log.info("[{}][AUTH] ok={} otp={} url={} details={}", new Object[]{runId, auth.ok(), auth.otpRequired(), HhSessionStateManager.safeShort(auth.url()), HhSessionStateManager.safeShort(auth.details())});
            if (auth.otpRequired()) {
                this.safeClose(ctx, browser);
                EnsureStateResult ensureStateResult = EnsureStateResult.fail("OTP_REQUIRED for login=" + HhSessionStateManager.safeShort(login));
                return ensureStateResult;
            }
            SessionProbe probe = this.probeSession(page);
            if (!probe.loggedIn) {
                this.safeClose(ctx, browser);
                EnsureStateResult ensureStateResult = EnsureStateResult.fail("AUTH_FAILED for login=" + HhSessionStateManager.safeShort(login) + ": " + HhSessionStateManager.safeShort(probe.details));
                return ensureStateResult;
            }
            ctx.storageState(new BrowserContext.StorageStateOptions().setPath(statePath));
            this.safeClose(ctx, browser);
            EnsureStateResult ensureStateResult = EnsureStateResult.ok(statePath, "created " + reason);
            return ensureStateResult;
        }
        catch (Exception e) {
            this.safeClose(ctx, browser);
            return EnsureStateResult.fail("createState err: " + HhSessionStateManager.shorty(e.toString()));
        }
    }

    private boolean probeWithState(String login, ApplyProfile profile, Path statePath) {
        boolean bl;
        block8: {
            Browser browser = null;
            BrowserContext ctx = null;
            Playwright pw = Playwright.create();
            try {
                browser = pw.chromium().launch(new BrowserType.LaunchOptions().setHeadless(true).setSlowMo(150.0));
                ctx = browser.newContext(new Browser.NewContextOptions().setLocale("ru-RU").setViewportSize(1280, 720).setStorageStatePath(statePath));
                Page page = ctx.newPage();
                page.navigate("https://hh.ru/applicant/resumes", new Page.NavigateOptions().setWaitUntil(WaitUntilState.DOMCONTENTLOADED).setTimeout(45000.0));
                SessionProbe probe = this.probeSession(page);
                this.safeClose(ctx, browser);
                bl = probe.loggedIn;
                if (pw == null) break block8;
            }
            catch (Throwable throwable) {
                try {
                    if (pw != null) {
                        try {
                            pw.close();
                        }
                        catch (Throwable throwable2) {
                            throwable.addSuppressed(throwable2);
                        }
                    }
                    throw throwable;
                }
                catch (Exception e) {
                    this.safeClose(ctx, browser);
                    return false;
                }
            }
            pw.close();
        }
        return bl;
    }

    private Path statePathFor(String normalizedLogin) {
        return STATE_DIR.resolve("hh_" + this.shortHash(normalizedLogin) + ".json");
    }

    private String shortHash(String s) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] dig = md.digest((s == null ? "" : s.trim().toLowerCase(Locale.ROOT)).getBytes());
            return HexFormat.of().formatHex(dig).substring(0, 16);
        }
        catch (Exception e) {
            return String.valueOf(Math.abs((s == null ? "" : s).hashCode()));
        }
    }

    private SessionProbe probeSession(Page page) {
        try {
            int st;
            String u;
            String origin = this.origin(page.url());
            String resumesUrl = origin + "/applicant/resumes";
            Response resp = page.navigate(resumesUrl, new Page.NavigateOptions().setWaitUntil(WaitUntilState.DOMCONTENTLOADED).setTimeout(45000.0));
            String string = u = page.url() == null ? "" : page.url();
            if (u.contains("/account/login")) {
                return new SessionProbe(false, u, "redirected_to_login");
            }
            int n = st = resp != null ? resp.status() : -1;
            if (st >= 400) {
                return new SessionProbe(false, u, "resumes httpStatus=" + st);
            }
            boolean loginForm = this.isVisible(page, "input[name='username'], input[type='password'], button:has-text('\u0412\u043e\u0439\u0442\u0438')");
            if (loginForm) {
                return new SessionProbe(false, u, "login form visible");
            }
            return new SessionProbe(true, u, "ok");
        }
        catch (Exception e) {
            return new SessionProbe(false, HhSessionStateManager.safeShort(page.url()), "probe exception: " + HhSessionStateManager.safeShort(e.toString()));
        }
    }

    private boolean isVisible(Page page, String selector) {
        try {
            return page.locator(selector).first().isVisible();
        }
        catch (Exception e) {
            return false;
        }
    }

    private String origin(String url) {
        try {
            URI u = URI.create(url);
            return u.getScheme() + "://" + u.getHost();
        }
        catch (Exception e) {
            return "https://hh.ru";
        }
    }

    private void safeClose(BrowserContext ctx, Browser browser) {
        try {
            if (ctx != null) {
                ctx.close();
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        try {
            if (browser != null) {
                browser.close();
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private static String safeShort(String s) {
        if (s == null) {
            return "";
        }
        return (s = s.trim()).length() <= 180 ? s : s.substring(0, 180) + "...";
    }

    private static String shorty(String s) {
        if (s == null) {
            return "";
        }
        return (s = s.trim()).length() <= 500 ? s : s.substring(0, 500) + "...";
    }

    private static String normalizeLogin(String login) {
        if (login == null) {
            return null;
        }
        String s = login.trim();
        if (s.contains("@")) {
            return s.toLowerCase(Locale.ROOT);
        }
        Object digits = s.replaceAll("\\D+", "");
        if (((String)digits).length() == 11 && ((String)digits).startsWith("8")) {
            digits = "7" + ((String)digits).substring(1);
        }
        return digits;
    }

    @Generated
    public HhSessionStateManager(ApplyProfileStore applyProfileStore, HhAuthService hhAuthService) {
        this.applyProfileStore = applyProfileStore;
        this.hhAuthService = hhAuthService;
    }

    public record EnsureStateResult(boolean ok, String details, Path statePath) {
        public static EnsureStateResult ok(Path p, String d) {
            return new EnsureStateResult(true, d, p);
        }

        public static EnsureStateResult fail(String d) {
            return new EnsureStateResult(false, d, null);
        }
    }

    private static final class SessionProbe {
        final boolean loggedIn;
        final String url;
        final String details;

        private SessionProbe(boolean loggedIn, String url, String details) {
            this.loggedIn = loggedIn;
            this.url = url;
            this.details = details;
        }
    }
}

