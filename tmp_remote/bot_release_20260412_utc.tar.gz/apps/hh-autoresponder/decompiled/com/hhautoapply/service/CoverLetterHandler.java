/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.microsoft.playwright.Locator
 *  com.microsoft.playwright.Page
 *  lombok.Generated
 *  org.springframework.stereotype.Component
 */
package com.hhautoapply.service;

import com.hhautoapply.service.PlaywrightSupport;
import com.hhautoapply.service.VacancyPageStateDetector;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import lombok.Generated;
import org.springframework.stereotype.Component;

@Component
public class CoverLetterHandler {
    private static final int COVER_TEXT_MAX = 900;
    private static final String COVER_TEXT_HINT = "\u0421\u043e\u043f\u0440\u043e\u0432\u043e\u0434\u0438\u0442\u0435\u043b\u044c\u043d\u043e\u0435 \u043f\u0438\u0441\u044c\u043c\u043e";
    private static final String COVER_REQUIRED_TEXT = "\u0421\u043e\u043f\u0440\u043e\u0432\u043e\u0434\u0438\u0442\u0435\u043b\u044c\u043d\u043e\u0435 \u043f\u0438\u0441\u044c\u043c\u043e \u043e\u0431\u044f\u0437\u0430\u0442\u0435\u043b\u044c\u043d\u043e\u0435 \u0434\u043b\u044f \u044d\u0442\u043e\u0439 \u0432\u0430\u043a\u0430\u043d\u0441\u0438\u0438";
    private final PlaywrightSupport ui;
    private final VacancyPageStateDetector detector;

    public boolean fillRequiredCover(Page page, String coverLetter) {
        Locator root = this.detector.firstVisibleModal(page);
        if (root == null) {
            return false;
        }
        Locator cover = this.findCoverInputInModal(root);
        if (cover == null) {
            return false;
        }
        boolean filled = this.fillAnyTextInput(cover, coverLetter);
        if (filled) {
            this.ui.blur(page);
        }
        return filled;
    }

    private Locator findCoverInputInModal(Locator modalRoot) {
        Locator ta = this.firstVisible(modalRoot, "textarea[placeholder*='\u0421\u043e\u043f\u0440\u043e\u0432\u043e\u0434\u0438\u0442\u0435\u043b\u044c\u043d\u043e\u0435 \u043f\u0438\u0441\u044c\u043c\u043e']", "textarea[aria-label*='\u0421\u043e\u043f\u0440\u043e\u0432\u043e\u0434\u0438\u0442\u0435\u043b\u044c\u043d\u043e\u0435 \u043f\u0438\u0441\u044c\u043c\u043e']", "xpath=.//*[contains(normalize-space(.), '\u0421\u043e\u043f\u0440\u043e\u0432\u043e\u0434\u0438\u0442\u0435\u043b\u044c\u043d\u043e\u0435 \u043f\u0438\u0441\u044c\u043c\u043e \u043e\u0431\u044f\u0437\u0430\u0442\u0435\u043b\u044c\u043d\u043e\u0435 \u0434\u043b\u044f \u044d\u0442\u043e\u0439 \u0432\u0430\u043a\u0430\u043d\u0441\u0438\u0438')]/preceding::textarea[1]", "xpath=.//*[contains(normalize-space(.), '\u0421\u043e\u043f\u0440\u043e\u0432\u043e\u0434\u0438\u0442\u0435\u043b\u044c\u043d\u043e\u0435 \u043f\u0438\u0441\u044c\u043c\u043e')]/following::textarea[1]", "xpath=.//textarea[not(ancestor::*[@data-qa='task-body'])]");
        if (ta != null) {
            return ta;
        }
        Locator editable = this.firstVisible(modalRoot, "[contenteditable='true'][role='textbox'][aria-label*='\u0421\u043e\u043f\u0440\u043e\u0432\u043e\u0434\u0438\u0442\u0435\u043b\u044c\u043d\u043e\u0435 \u043f\u0438\u0441\u044c\u043c\u043e']", "xpath=.//*[contains(normalize-space(.), '\u0421\u043e\u043f\u0440\u043e\u0432\u043e\u0434\u0438\u0442\u0435\u043b\u044c\u043d\u043e\u0435 \u043f\u0438\u0441\u044c\u043c\u043e')]/following::*[@contenteditable='true'][1]", "xpath=.//*[@contenteditable='true' and not(ancestor::*[@data-qa='task-body'])]");
        if (editable != null) {
            return editable;
        }
        return this.singleVisible(modalRoot, "textarea", "[contenteditable='true'][role='textbox']", "[contenteditable='true']");
    }

    private boolean fillAnyTextInput(Locator input, String value) {
        if (input == null || value == null || value.isBlank()) {
            return false;
        }
        String v = value.length() > 900 ? value.substring(0, 900) : value;
        try {
            String tag = "";
            try {
                tag = String.valueOf(input.evaluate("el => el.tagName || ''"));
            }
            catch (Exception exception) {
                // empty catch block
            }
            if ("TEXTAREA".equalsIgnoreCase(tag) || "INPUT".equalsIgnoreCase(tag)) {
                try {
                    input.fill(v);
                    this.ui.blur(input.page());
                    return true;
                }
                catch (Exception ignore) {
                    try {
                        input.evaluate("(el) => { try { el.value=''; } catch(e){} }");
                    }
                    catch (Exception exception) {
                        // empty catch block
                    }
                    input.type(v);
                    this.ui.blur(input.page());
                    return true;
                }
            }
            String ce = "";
            try {
                ce = CoverLetterHandler.n(input.getAttribute("contenteditable"));
            }
            catch (Exception exception) {
                // empty catch block
            }
            if (!ce.isBlank()) {
                try {
                    input.evaluate("(el) => { el.focus(); el.innerText=''; }");
                }
                catch (Exception exception) {
                    // empty catch block
                }
                input.type(v);
                this.ui.blur(input.page());
                return true;
            }
            input.type(v);
            this.ui.blur(input.page());
            return true;
        }
        catch (Exception e) {
            return false;
        }
    }

    private static String n(String s) {
        return s == null ? "" : s;
    }

    private Locator firstVisible(Locator root, String ... selectors) {
        return this.ui.firstVisible(root, selectors);
    }

    private Locator singleVisible(Locator root, String ... selectors) {
        if (root == null) {
            return null;
        }
        for (String selector : selectors) {
            try {
                Locator all = root.locator(selector);
                int count = Math.min(all.count(), 8);
                Locator only = null;
                for (int i = 0; i < count; ++i) {
                    Locator candidate = all.nth(i);
                    if (!this.ui.isVisible(candidate)) continue;
                    if (only != null) {
                        only = null;
                        break;
                    }
                    only = candidate;
                }
                if (only == null) continue;
                return only;
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
        return null;
    }

    @Generated
    public CoverLetterHandler(PlaywrightSupport ui, VacancyPageStateDetector detector) {
        this.ui = ui;
        this.detector = detector;
    }
}

