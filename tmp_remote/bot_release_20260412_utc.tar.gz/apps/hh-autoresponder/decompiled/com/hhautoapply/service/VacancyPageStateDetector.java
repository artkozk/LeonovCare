/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.microsoft.playwright.Locator
 *  com.microsoft.playwright.Page
 *  lombok.Generated
 *  org.springframework.stereotype.Component
 */
package com.hhautoapply.service;

import com.hhautoapply.service.PlaywrightSupport;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import java.util.Locale;
import lombok.Generated;
import org.springframework.stereotype.Component;

@Component
public class VacancyPageStateDetector {
    private static final String MODAL_SEL = "[data-qa*='modal'], div[role='dialog'], .bloko-modal";
    private static final String Q_SEL = "[data-qa='task-question']";
    private static final String OTHER_COUNTRY_PHRASE = "\u0412\u044b \u043e\u0442\u043a\u043b\u0438\u043a\u0430\u0435\u0442\u0435\u0441\u044c \u043d\u0430 \u0432\u0430\u043a\u0430\u043d\u0441\u0438\u044e \u0432 \u0434\u0440\u0443\u0433\u043e\u0439 \u0441\u0442\u0440\u0430\u043d\u0435";
    private static final String COVER_REQUIRED_TEXT = "\u0421\u043e\u043f\u0440\u043e\u0432\u043e\u0434\u0438\u0442\u0435\u043b\u044c\u043d\u043e\u0435 \u043f\u0438\u0441\u044c\u043c\u043e \u043e\u0431\u044f\u0437\u0430\u0442\u0435\u043b\u044c\u043d\u043e\u0435 \u0434\u043b\u044f \u044d\u0442\u043e\u0439 \u0432\u0430\u043a\u0430\u043d\u0441\u0438\u0438";
    private static final String COVER_REQUIRED_DIV_SEL = "div.magritte-form-helper-text-wrapper___gSEC2_2-0-24:has-text('\u0421\u043e\u043f\u0440\u043e\u0432\u043e\u0434\u0438\u0442\u0435\u043b\u044c\u043d\u043e\u0435 \u043f\u0438\u0441\u044c\u043c\u043e \u043e\u0431\u044f\u0437\u0430\u0442\u0435\u043b\u044c\u043d\u043e\u0435 \u0434\u043b\u044f \u044d\u0442\u043e\u0439 \u0432\u0430\u043a\u0430\u043d\u0441\u0438\u0438'), div:has-text('\u0421\u043e\u043f\u0440\u043e\u0432\u043e\u0434\u0438\u0442\u0435\u043b\u044c\u043d\u043e\u0435 \u043f\u0438\u0441\u044c\u043c\u043e \u043e\u0431\u044f\u0437\u0430\u0442\u0435\u043b\u044c\u043d\u043e\u0435 \u0434\u043b\u044f \u044d\u0442\u043e\u0439 \u0432\u0430\u043a\u0430\u043d\u0441\u0438\u0438')";
    private static final String LIMIT_LINE_1 = "\u0412 \u0442\u0435\u0447\u0435\u043d\u0438\u0435 24 \u0447\u0430\u0441\u043e\u0432 \u043c\u043e\u0436\u043d\u043e \u0441\u043e\u0432\u0435\u0440\u0448\u0438\u0442\u044c \u043d\u0435 \u0431\u043e\u043b\u0435\u0435 200 \u043e\u0442\u043a\u043b\u0438\u043a\u043e\u0432";
    private static final String LIMIT_LINE_2 = "\u0412\u044b \u0438\u0441\u0447\u0435\u0440\u043f\u0430\u043b\u0438 \u043b\u0438\u043c\u0438\u0442 \u043e\u0442\u043a\u043b\u0438\u043a\u043e\u0432";
    private static final String LIMIT_TRY_LATER_1 = "\u043f\u043e\u043f\u0440\u043e\u0431\u0443\u0439\u0442\u0435 \u043e\u0442\u043f\u0440\u0430\u0432\u0438\u0442\u044c \u043e\u0442\u043a\u043b\u0438\u043a \u043f\u043e\u0437\u0434\u043d\u0435\u0435";
    private static final String LIMIT_TRY_LATER_2 = "\u043f\u043e\u043f\u0440\u043e\u0431\u0443\u0439\u0442\u0435 \u043e\u0442\u043f\u0440\u0430\u0432\u0438\u0442\u044c \u043e\u0442\u043a\u043b\u0438\u043a \u043f\u043e\u0437\u0436\u0435";
    private static final String TXT_ALREADY_1 = "\u0412\u044b \u043e\u0442\u043a\u043b\u0438\u043a\u043d\u0443\u043b\u0438\u0441\u044c";
    private static final String TXT_ALREADY_2 = "\u0412\u044b \u0443\u0436\u0435 \u043e\u0442\u043a\u043b\u0438\u043a\u0430\u043b\u0438\u0441\u044c";
    private static final String TXT_ALREADY_3 = "\u041e\u0442\u043a\u043b\u0438\u043a \u0443\u0436\u0435 \u043e\u0442\u043f\u0440\u0430\u0432\u043b\u0435\u043d";
    private static final String TXT_ALREADY_4 = "\u0412\u044b \u0443\u0436\u0435 \u043e\u0442\u043f\u0440\u0430\u0432\u043b\u044f\u043b\u0438 \u043e\u0442\u043a\u043b\u0438\u043a";
    private static final String TXT_INVITED = "\u0412\u0430\u0441 \u043f\u0440\u0438\u0433\u043b\u0430\u0441\u0438\u043b\u0438";
    private static final String TXT_DECLINED = "\u0412\u0430\u043c \u043e\u0442\u043a\u0430\u0437\u0430\u043b\u0438";
    private static final String MAGRITTE_TEXT_SEL = "div[class*='magritte-text']";
    private final PlaywrightSupport ui;

    public boolean isInResponseFlow(Page page) {
        String url = VacancyPageStateDetector.n(page.url());
        return url.contains("/applicant/vacancy_response") || url.contains("/vacancy_response");
    }

    public Locator firstVisibleModal(Page page) {
        try {
            Locator m = page.locator(MODAL_SEL).first();
            return this.ui.isVisible(m) ? m : null;
        }
        catch (Exception ignore) {
            return null;
        }
    }

    public ResponseRequirements detectRequirements(Page page) {
        return new ResponseRequirements(this.isOtherCountryPopupNow(page), this.isCoverRequiredNow(page), this.hasQuestionsNow(page));
    }

    public boolean hasQuestionsNow(Page page) {
        try {
            Object pending = page.evaluate("() => {\n  const visible = (el) => {\n    if (!el) return false;\n    const cs = window.getComputedStyle(el);\n    if (!cs || cs.display === 'none' || cs.visibility === 'hidden' || cs.opacity === '0') return false;\n    const r = el.getBoundingClientRect();\n    return r.width > 0 && r.height > 0;\n  };\n  const enabled = (el) => {\n    if (!el) return false;\n    return !el.disabled && el.getAttribute('aria-disabled') !== 'true';\n  };\n  const textValue = (el) => {\n    if (!el) return '';\n    const raw = ('value' in el ? el.value : (el.innerText || el.textContent || '')) || '';\n    return raw.trim();\n  };\n  const hasPendingText = (scope) => Array.from(scope.querySelectorAll(\n    \"textarea, input[type='text'], input:not([type]), [contenteditable='true'][role='textbox'], [contenteditable='true']\"\n  )).some((el) => visible(el) && enabled(el) && !textValue(el));\n  const hasPendingSelect = (scope) => Array.from(scope.querySelectorAll('select')).some((el) => {\n    if (!visible(el) || !enabled(el)) return false;\n    return !(el.value || '').trim();\n  });\n  const hasPendingChoice = (scope) => {\n    const inputs = Array.from(scope.querySelectorAll(\"input[type='radio'], input[type='checkbox']\"))\n      .filter((el) => enabled(el) && visible(el.closest('label') || el));\n    if (inputs.length > 0) {\n      return !inputs.some((el) => el.checked);\n    }\n    const roles = Array.from(scope.querySelectorAll(\"[role='radio'], [aria-checked], [aria-selected], button[aria-pressed]\"))\n      .filter((el) => visible(el));\n    if (roles.length === 0) return false;\n    return !roles.some((el) =>\n      el.getAttribute('aria-checked') === 'true'\n      || el.getAttribute('aria-selected') === 'true'\n      || el.getAttribute('aria-pressed') === 'true'\n    );\n  };\n  const questions = Array.from(document.querySelectorAll(\"[data-qa='task-question']\"));\n  return questions.some((q) => {\n    if (!visible(q)) return false;\n    const scope = q.closest(\"[data-qa='task-body']\") || q.parentElement || q;\n    if (!scope) return false;\n    return hasPendingText(scope) || hasPendingSelect(scope) || hasPendingChoice(scope);\n  });\n}");
            return Boolean.TRUE.equals(pending);
        }
        catch (Exception ignore) {
            try {
                return this.ui.isVisible(page.locator(Q_SEL).first());
            }
            catch (Exception ignore2) {
                return false;
            }
        }
    }

    public boolean isCoverRequiredNow(Page page) {
        try {
            Locator modal = this.firstVisibleModal(page);
            if (modal != null && this.isCoverRequiredByHelperText(modal)) {
                return true;
            }
            return this.ui.isVisible(page.locator("text=\u0421\u043e\u043f\u0440\u043e\u0432\u043e\u0434\u0438\u0442\u0435\u043b\u044c\u043d\u043e\u0435 \u043f\u0438\u0441\u044c\u043c\u043e \u043e\u0431\u044f\u0437\u0430\u0442\u0435\u043b\u044c\u043d\u043e\u0435 \u0434\u043b\u044f \u044d\u0442\u043e\u0439 \u0432\u0430\u043a\u0430\u043d\u0441\u0438\u0438").first());
        }
        catch (Exception ignore) {
            return false;
        }
    }

    public String detectAlreadyAppliedPolled(Page page, int pollMs, int maxMs) {
        long until = System.currentTimeMillis() + (long)Math.max(0, maxMs);
        while (System.currentTimeMillis() < until) {
            String r = this.detectAlreadyApplied(page);
            if (r != null) {
                return r;
            }
            try {
                page.waitForTimeout((double)pollMs);
            }
            catch (Exception exception) {}
        }
        return this.detectAlreadyApplied(page);
    }

    public String detectAlreadyApplied(Page page) {
        try {
            if (this.ui.isVisible(page.locator("div[class*='magritte-text']:has-text('\u0412\u044b \u043e\u0442\u043a\u043b\u0438\u043a\u043d\u0443\u043b\u0438\u0441\u044c')").first())) {
                return "already";
            }
            if (this.ui.isVisible(page.locator("div[class*='magritte-text']:has-text('\u0412\u0430\u0441 \u043f\u0440\u0438\u0433\u043b\u0430\u0441\u0438\u043b\u0438')").first())) {
                return "invited";
            }
            if (this.ui.isVisible(page.locator("div[class*='magritte-text']:has-text('\u0412\u0430\u043c \u043e\u0442\u043a\u0430\u0437\u0430\u043b\u0438')").first())) {
                return "declined";
            }
            if (this.ui.isVisible(page.locator("text=\u0412\u044b \u043e\u0442\u043a\u043b\u0438\u043a\u043d\u0443\u043b\u0438\u0441\u044c").first())) {
                return "already";
            }
            if (this.ui.isVisible(page.locator("text=\u0412\u044b \u0443\u0436\u0435 \u043e\u0442\u043a\u043b\u0438\u043a\u0430\u043b\u0438\u0441\u044c").first())) {
                return "already";
            }
            if (this.ui.isVisible(page.locator("text=\u041e\u0442\u043a\u043b\u0438\u043a \u0443\u0436\u0435 \u043e\u0442\u043f\u0440\u0430\u0432\u043b\u0435\u043d").first())) {
                return "already";
            }
            if (this.ui.isVisible(page.locator("text=\u0412\u044b \u0443\u0436\u0435 \u043e\u0442\u043f\u0440\u0430\u0432\u043b\u044f\u043b\u0438 \u043e\u0442\u043a\u043b\u0438\u043a").first())) {
                return "already";
            }
            if (this.ui.isVisible(page.locator("text=\u0412\u0430\u0441 \u043f\u0440\u0438\u0433\u043b\u0430\u0441\u0438\u043b\u0438").first())) {
                return "invited";
            }
            if (this.ui.isVisible(page.locator("text=\u0412\u0430\u043c \u043e\u0442\u043a\u0430\u0437\u0430\u043b\u0438").first())) {
                return "declined";
            }
            if (this.ui.isVisible(page.locator("text=\u041e\u0442\u043c\u0435\u043d\u0438\u0442\u044c \u043e\u0442\u043a\u043b\u0438\u043a").first())) {
                return "already";
            }
            Locator toast = this.notification(page);
            if (this.ui.isVisible(toast)) {
                String t = this.ui.safeText(toast, 260).toLowerCase(Locale.ROOT);
                if (t.contains("\u0443\u0436\u0435") && t.contains("\u043e\u0442\u043a\u043b\u0438\u043a")) {
                    return "already";
                }
                if (t.contains("\u043e\u0442\u043a\u043b\u0438\u043a") && (t.contains("\u0443\u0436\u0435") || t.contains("\u0440\u0430\u043d\u0435\u0435")) && (t.contains("\u043e\u0442\u043f\u0440\u0430\u0432") || t.contains("\u0435\u0441\u0442\u044c"))) {
                    return "already";
                }
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return null;
    }

    public StopSignal detectDailyLimitFast(Page page) {
        try {
            boolean limitLine;
            boolean bl = limitLine = this.ui.isVisible(page.locator("text=\u0412 \u0442\u0435\u0447\u0435\u043d\u0438\u0435 24 \u0447\u0430\u0441\u043e\u0432 \u043c\u043e\u0436\u043d\u043e \u0441\u043e\u0432\u0435\u0440\u0448\u0438\u0442\u044c \u043d\u0435 \u0431\u043e\u043b\u0435\u0435 200 \u043e\u0442\u043a\u043b\u0438\u043a\u043e\u0432").first()) || this.ui.isVisible(page.locator("text=\u0412\u044b \u0438\u0441\u0447\u0435\u0440\u043f\u0430\u043b\u0438 \u043b\u0438\u043c\u0438\u0442 \u043e\u0442\u043a\u043b\u0438\u043a\u043e\u0432").first());
            if (limitLine) {
                boolean tryLater;
                boolean bl2 = tryLater = this.ui.isVisible(page.locator("text=\u043f\u043e\u043f\u0440\u043e\u0431\u0443\u0439\u0442\u0435 \u043e\u0442\u043f\u0440\u0430\u0432\u0438\u0442\u044c \u043e\u0442\u043a\u043b\u0438\u043a \u043f\u043e\u0437\u0434\u043d\u0435\u0435").first()) || this.ui.isVisible(page.locator("text=\u043f\u043e\u043f\u0440\u043e\u0431\u0443\u0439\u0442\u0435 \u043e\u0442\u043f\u0440\u0430\u0432\u0438\u0442\u044c \u043e\u0442\u043a\u043b\u0438\u043a \u043f\u043e\u0437\u0436\u0435").first());
                if (tryLater) {
                    return new StopSignal(true);
                }
            }
        }
        catch (Exception limitLine) {
            // empty catch block
        }
        try {
            Locator toast = this.notification(page);
            if (this.ui.isVisible(toast)) {
                String t = this.ui.safeText(toast, 600).toLowerCase(Locale.ROOT);
                boolean hasLimit = t.contains("\u043b\u0438\u043c\u0438\u0442") || t.contains("\u0438\u0441\u0447\u0435\u0440\u043f");
                boolean hasTryLater = t.contains("\u043f\u043e\u0437\u0434\u043d\u0435\u0435") || t.contains("\u043f\u043e\u0437\u0436\u0435") || t.contains("24");
                boolean hasApply = t.contains("\u043e\u0442\u043a\u043b\u0438\u043a");
                boolean has200 = t.contains("200");
                if (hasApply && (hasLimit || hasTryLater) && (has200 || hasTryLater)) {
                    return new StopSignal(true);
                }
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return null;
    }

    public boolean hasSuccessNow(Page page) {
        try {
            if (this.hasGreenSuccessToastNow(page)) {
                return true;
            }
            if (this.ui.isVisible(page.locator("text=\u041e\u0442\u043a\u043b\u0438\u043a \u043e\u0442\u043f\u0440\u0430\u0432\u043b\u0435\u043d").first()) && !this.ui.isVisible(page.locator("text=\u041e\u0442\u043a\u043b\u0438\u043a \u0443\u0436\u0435 \u043e\u0442\u043f\u0440\u0430\u0432\u043b\u0435\u043d").first())) {
                return true;
            }
            return this.ui.isVisible(page.locator("text=\u0421\u043f\u0430\u0441\u0438\u0431\u043e \u0437\u0430 \u043e\u0442\u043a\u043b\u0438\u043a").first());
        }
        catch (Exception ignore) {
            return false;
        }
    }

    public boolean isOtherCountryPopupNow(Page page) {
        try {
            return page.locator("text=\u0412\u044b \u043e\u0442\u043a\u043b\u0438\u043a\u0430\u0435\u0442\u0435\u0441\u044c \u043d\u0430 \u0432\u0430\u043a\u0430\u043d\u0441\u0438\u044e \u0432 \u0434\u0440\u0443\u0433\u043e\u0439 \u0441\u0442\u0440\u0430\u043d\u0435").first().isVisible();
        }
        catch (Exception ignore) {
            return false;
        }
    }

    public boolean isCoverRequiredByHelperText(Locator modalRoot) {
        try {
            Locator d = modalRoot.locator(COVER_REQUIRED_DIV_SEL).first();
            return d != null && d.isVisible();
        }
        catch (Exception d) {
            try {
                return modalRoot.locator("text=\u0421\u043e\u043f\u0440\u043e\u0432\u043e\u0434\u0438\u0442\u0435\u043b\u044c\u043d\u043e\u0435 \u043f\u0438\u0441\u044c\u043c\u043e \u043e\u0431\u044f\u0437\u0430\u0442\u0435\u043b\u044c\u043d\u043e\u0435 \u0434\u043b\u044f \u044d\u0442\u043e\u0439 \u0432\u0430\u043a\u0430\u043d\u0441\u0438\u0438").first().isVisible();
            }
            catch (Exception ignore) {
                return false;
            }
        }
    }

    private Locator notification(Page page) {
        return page.locator("[data-qa*='notification'], .bloko-notification, .notification, [role='alert']").first();
    }

    private boolean hasSuccessToastTextCandidate(Page page) {
        try {
            Locator toasts = page.locator("[data-qa*='notification'], .bloko-notification, .notification, [role='alert']");
            int n = Math.min(toasts.count(), 4);
            for (int i = 0; i < n; ++i) {
                String t;
                Locator el = toasts.nth(i);
                if (!this.ui.isVisible(el) || (t = this.ui.safeText(el, 260).toLowerCase(Locale.ROOT)).isBlank() || t.contains("\u0443\u0436\u0435") || t.contains("\u043e\u0442\u043a\u043b\u0438\u043a\u0430\u043b")) continue;
                if (t.contains("\u0441\u043f\u0430\u0441\u0438\u0431\u043e \u0437\u0430 \u043e\u0442\u043a\u043b\u0438\u043a")) {
                    return true;
                }
                if (!t.contains("\u043e\u0442\u043a\u043b\u0438\u043a") || !t.contains("\u043e\u0442\u043f\u0440\u0430\u0432\u043b\u0435\u043d") && !t.contains("\u043e\u0442\u043f\u0440\u0430\u0432\u0438\u043b\u0438") && !t.contains("\u0443\u0441\u043f\u0435\u0448")) continue;
                return true;
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return false;
    }

    private boolean hasGreenSuccessToastNow(Page page) {
        if (page == null || !this.hasSuccessToastTextCandidate(page)) {
            return false;
        }
        try {
            Object r = page.evaluate("() => {\n  const nodes = Array.from(document.querySelectorAll(\n    '[data-qa*=\"notification\"], .bloko-notification, .notification, [role=\"alert\"]'\n  ));\n  const parseRgb = (c) => {\n    if (!c) return null;\n    let m = c.match(/rgba?\\((\\d+),\\s*(\\d+),\\s*(\\d+)/i);\n    if (m) return { r:+m[1], g:+m[2], b:+m[3] };\n    m = c.match(/#([0-9a-f]{6})/i);\n    if (m) {\n      const x = parseInt(m[1], 16);\n      return { r:(x>>16)&255, g:(x>>8)&255, b:x&255 };\n    }\n    return null;\n  };\n  const greenish = (rgb) => rgb && rgb.g >= 90 && rgb.g > rgb.r + 25 && rgb.g > rgb.b + 25;\n  const isSuccessText = (txt) => {\n    const t = (txt || '').toLowerCase();\n    if (!t) return false;\n    if (t.includes('\u0443\u0436\u0435') || t.includes('\u043e\u0442\u043a\u043b\u0438\u043a\u0430\u043b')) return false;\n    if (t.includes('\u0441\u043f\u0430\u0441\u0438\u0431\u043e \u0437\u0430 \u043e\u0442\u043a\u043b\u0438\u043a')) return true;\n    return t.includes('\u043e\u0442\u043a\u043b\u0438\u043a') && (t.includes('\u043e\u0442\u043f\u0440\u0430\u0432\u043b\u0435\u043d') || t.includes('\u043e\u0442\u043f\u0440\u0430\u0432\u0438\u043b\u0438') || t.includes('\u0443\u0441\u043f\u0435\u0448'));\n  };\n  for (const el of nodes) {\n    const txt = (el.innerText || el.textContent || '');\n    if (!isSuccessText(txt)) continue;\n    const probes = [el, el.firstElementChild].filter(Boolean);\n    for (const p of probes) {\n      const cs = window.getComputedStyle(p);\n      const bg = parseRgb(cs.backgroundColor);\n      const bl = parseRgb(cs.borderLeftColor);\n      if (greenish(bg) || greenish(bl)) return true;\n    }\n  }\n  return false;\n}");
            return Boolean.TRUE.equals(r);
        }
        catch (Exception ignore) {
            return false;
        }
    }

    private static String n(String s) {
        return s == null ? "" : s;
    }

    @Generated
    public VacancyPageStateDetector(PlaywrightSupport ui) {
        this.ui = ui;
    }

    public record ResponseRequirements(boolean otherCountry, boolean coverRequired, boolean questionsPresent) {
        public boolean none() {
            return !this.otherCountry && !this.coverRequired && !this.questionsPresent;
        }
    }

    public record StopSignal(boolean shouldStopRun) {
    }
}

