/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.springframework.core.io.ClassPathResource
 *  org.springframework.stereotype.Component
 *  org.yaml.snakeyaml.Yaml
 */
package com.hhautoapply.service;

import com.hhautoapply.model.ApplyProfile;
import java.io.InputStream;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;
import org.yaml.snakeyaml.Yaml;

@Component
public class ApplyProfileStore {
    private final Map<String, ApplyProfile> profilesByLogin = this.loadFromClasspath("config/profiles.yaml");

    public ApplyProfile profile(String login) {
        String key = ApplyProfileStore.normalizeLogin(login);
        ApplyProfile p = this.profilesByLogin.get(key);
        if (p == null) {
            throw new IllegalArgumentException("profile not found for login=" + login + " (normalized=" + key + "), available=" + String.valueOf(this.profilesByLogin.keySet()));
        }
        if (p.password() == null || p.password().isBlank()) {
            throw new IllegalArgumentException("password empty for login=" + login + " (normalized=" + key + ")");
        }
        return p;
    }

    public List<String> logins() {
        return List.copyOf(this.profilesByLogin.keySet());
    }

    private Map<String, ApplyProfile> loadFromClasspath(String cpPath) {
        LinkedHashMap<String, ApplyProfile> linkedHashMap;
        block11: {
            InputStream in = new ClassPathResource(cpPath).getInputStream();
            try {
                Yaml yaml = new Yaml();
                Map root = (Map)yaml.load(in);
                if (root == null) {
                    throw new IllegalStateException("yaml root is null");
                }
                Map ps = (Map)root.get("profiles");
                if (ps == null) {
                    throw new IllegalStateException("profiles not found in yaml");
                }
                LinkedHashMap<String, ApplyProfile> out = new LinkedHashMap<String, ApplyProfile>();
                for (Map.Entry e : ps.entrySet()) {
                    ApplyProfile profile;
                    String rawLogin = (String)e.getKey();
                    String key = ApplyProfileStore.normalizeLogin(rawLogin);
                    ApplyProfile prev = out.putIfAbsent(key, profile = this.toProfile((Map)e.getValue()));
                    if (prev == null) continue;
                    throw new IllegalStateException("Duplicate profile key after normalization: '" + key + "' (raw key: '" + rawLogin + "')");
                }
                linkedHashMap = out;
                if (in == null) break block11;
            }
            catch (Throwable throwable) {
                try {
                    if (in != null) {
                        try {
                            in.close();
                        }
                        catch (Throwable throwable2) {
                            throwable.addSuppressed(throwable2);
                        }
                    }
                    throw throwable;
                }
                catch (Exception e) {
                    throw new RuntimeException("Failed to load profiles yaml from classpath: " + cpPath, e);
                }
            }
            in.close();
        }
        return linkedHashMap;
    }

    private ApplyProfile toProfile(Map<String, Object> m) {
        return new ApplyProfile(this.str(m.get("password")), this.str(m.get("queryText")), this.toInt(m.get("targetApplies")), this.str(m.get("coverLetter")), this.toStringMap(m.get("candidateContext")));
    }

    private static String normalizeLogin(String login) {
        if (login == null) {
            return null;
        }
        String s = login.trim();
        if (s.contains("@")) {
            return s.toLowerCase(Locale.ROOT);
        }
        Object digits = s.replaceAll("\\D+", "");
        if (((String)digits).length() == 11 && ((String)digits).startsWith("8")) {
            digits = "7" + ((String)digits).substring(1);
        }
        return digits;
    }

    private Integer toInt(Object o) {
        if (o == null) {
            return null;
        }
        if (o instanceof Integer) {
            Integer i = (Integer)o;
            return i;
        }
        if (o instanceof Long) {
            Long l = (Long)o;
            return Math.toIntExact(l);
        }
        if (o instanceof Number) {
            Number n = (Number)o;
            return n.intValue();
        }
        return Integer.parseInt(String.valueOf(o).trim());
    }

    private String str(Object o) {
        return o == null ? null : String.valueOf(o);
    }

    private Map<String, String> toStringMap(Object o) {
        if (o == null) {
            return null;
        }
        if (o instanceof Map) {
            Map mm = (Map)o;
            LinkedHashMap<String, String> out = new LinkedHashMap<String, String>();
            for (Map.Entry e : mm.entrySet()) {
                out.put(String.valueOf(e.getKey()), e.getValue() == null ? null : String.valueOf(e.getValue()));
            }
            return out;
        }
        throw new IllegalArgumentException("candidateContext must be a map, got: " + o.getClass().getName());
    }
}

