/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.fasterxml.jackson.core.type.TypeReference
 *  com.fasterxml.jackson.databind.ObjectMapper
 *  lombok.Generated
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 *  org.springframework.beans.factory.annotation.Value
 *  org.springframework.stereotype.Component
 */
package com.hhautoapply.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hhautoapply.model.ModalSolveRequest;
import com.hhautoapply.model.ModalSolveResponse;
import com.hhautoapply.model.Question;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Authenticator;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.PasswordAuthentication;
import java.net.Proxy;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import lombok.Generated;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class LlmClient {
    @Generated
    private static final Logger log = LoggerFactory.getLogger(LlmClient.class);
    private static final int MAX_RETRY_INITIAL_TOKENS = 2000;
    private static final long MAX_RETRY_ELAPSED_MS = 40000L;
    private final ObjectMapper om;
    private final String baseUrl;
    private final String apiKey;
    private final String model;
    private final int timeoutMs;
    private final Proxy proxy;
    private final String proxyAuthHeader;

    public LlmClient(ObjectMapper om, @Value(value="${app.llm.base-url:https://api.openai.com/v1}") String baseUrl, @Value(value="${app.llm.api-key}") String apiKey, @Value(value="${app.llm.model:gpt-4o}") String model, @Value(value="${app.llm.timeout-ms:30000}") int timeoutMs, @Value(value="${app.llm.proxy.host:}") String proxyHost, @Value(value="${app.llm.proxy.port:0}") int proxyPort, @Value(value="${app.llm.proxy.username:}") String proxyUsername, @Value(value="${app.llm.proxy.password:}") String proxyPassword) {
        this.om = om;
        this.baseUrl = baseUrl;
        this.apiKey = apiKey;
        this.model = model;
        this.timeoutMs = timeoutMs;
        ProxyTransport transport = this.createProxyTransport(proxyHost, proxyPort, proxyUsername, proxyPassword);
        this.proxy = transport.proxy();
        this.proxyAuthHeader = transport.proxyAuthHeader();
    }

    private ProxyTransport createProxyTransport(String proxyHost, int proxyPort, String proxyUsername, String proxyPassword) {
        String host;
        String string = host = proxyHost == null ? "" : proxyHost.trim();
        if (!host.isBlank() && proxyPort > 0) {
            String username;
            this.enableBasicProxyAuthForHttps();
            Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(host, proxyPort));
            String string2 = username = proxyUsername == null ? "" : proxyUsername.trim();
            if (!username.isBlank()) {
                String password = proxyPassword == null ? "" : proxyPassword;
                this.installProxyAuthenticator(host, proxyPort, username, password);
                String basic = Base64.getEncoder().encodeToString((username + ":" + password).getBytes(StandardCharsets.UTF_8));
                log.info("[LLM] Proxy enabled host={} port={} auth={} tunnelingBasicEnabled=true transport=urlconnection", new Object[]{host, proxyPort, true});
                return new ProxyTransport(proxy, "Basic " + basic);
            }
            log.info("[LLM] Proxy enabled host={} port={} auth={} tunnelingBasicEnabled=true transport=urlconnection", new Object[]{host, proxyPort, false});
            return new ProxyTransport(proxy, null);
        }
        return new ProxyTransport(null, null);
    }

    private void installProxyAuthenticator(final String host, final int port, final String username, final String password) {
        Authenticator.setDefault(new Authenticator(this){

            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                if (this.getRequestorType() != Authenticator.RequestorType.PROXY) {
                    return null;
                }
                if (!host.equalsIgnoreCase(this.getRequestingHost()) || port != this.getRequestingPort()) {
                    return null;
                }
                return new PasswordAuthentication(username, password.toCharArray());
            }
        });
    }

    private void enableBasicProxyAuthForHttps() {
        this.clearDisabledScheme("jdk.http.auth.proxying.disabledSchemes", "Basic");
        this.clearDisabledScheme("jdk.http.auth.tunneling.disabledSchemes", "Basic");
    }

    private void clearDisabledScheme(String key, String scheme) {
        String updated;
        String current = System.getProperty(key, "");
        if (current.isBlank()) {
            System.setProperty(key, "");
            return;
        }
        String normalized = current.replace(" ", "");
        if (!normalized.equals(updated = normalized.replace(scheme + ",", "").replace("," + scheme, "").replace(scheme, ""))) {
            System.setProperty(key, updated);
            log.info("[LLM] Updated {} from '{}' to '{}'", new Object[]{key, current, updated});
        }
    }

    public ModalSolveResponse solveModal(ModalSolveRequest req) {
        try {
            long startedAt = System.nanoTime();
            String questionsAsText = this.formatQuestionsForPrompt(req.questions());
            int qCount = req.questions() == null ? 0 : req.questions().size();
            int maxTokens = this.calcMaxTokens(qCount);
            LlmParseOutcome firstAttempt = this.callLlm(req, questionsAsText, maxTokens);
            if (!firstAttempt.retryForLength()) {
                return firstAttempt.response();
            }
            long elapsedMs = (System.nanoTime() - startedAt) / 1000000L;
            if (!this.shouldRetryAfterLength(maxTokens, elapsedMs)) {
                log.warn("[LLM] Skip retry after finish_reason=length model={} tokens={} elapsedMs={} maxRetryInitialTokens={} maxRetryElapsedMs={}", new Object[]{this.model, maxTokens, elapsedMs, 2000, 40000L});
                return firstAttempt.response();
            }
            int retryMaxTokens = this.calcRetryTokens(maxTokens, qCount);
            log.warn("[LLM] Retrying after finish_reason=length model={} tokens={} retryTokens={}", new Object[]{this.model, maxTokens, retryMaxTokens});
            return this.callLlm(req, questionsAsText, retryMaxTokens).response();
        }
        catch (Exception e) {
            log.error("[LLM] solveModal failed", (Throwable)e);
            return new ModalSolveResponse(List.of());
        }
    }

    private LlmParseOutcome callLlm(ModalSolveRequest req, String questionsAsText, int maxCompletionTokens) throws Exception {
        String jsonRequest = this.buildChatRequestJson(req, questionsAsText, maxCompletionTokens);
        RawHttpResponse resp = this.postJson(URI.create(this.baseUrl + "/chat/completions"), jsonRequest);
        if (resp.statusCode() != 200) {
            log.error("[LLM] HTTP {} model={} body={} headers={}", new Object[]{resp.statusCode(), this.model, this.preview(resp.body()), this.preview(String.valueOf(resp.headers()))});
            return LlmParseOutcome.empty();
        }
        return this.parseLlmResponse(resp.body());
    }

    private boolean shouldRetryAfterLength(int initialTokens, long elapsedMs) {
        return initialTokens < 2000 && elapsedMs < 40000L;
    }

    private RawHttpResponse postJson(URI uri, String jsonRequest) throws IOException {
        HttpURLConnection conn = this.openConnection(uri);
        conn.setRequestMethod("POST");
        conn.setConnectTimeout(this.timeoutMs);
        conn.setReadTimeout(this.timeoutMs);
        conn.setDoOutput(true);
        conn.setInstanceFollowRedirects(true);
        conn.setRequestProperty("Authorization", "Bearer " + this.apiKey);
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("Accept", "application/json");
        if (this.proxyAuthHeader != null) {
            conn.setRequestProperty("Proxy-Authorization", this.proxyAuthHeader);
        }
        byte[] payload = jsonRequest.getBytes(StandardCharsets.UTF_8);
        conn.setFixedLengthStreamingMode(payload.length);
        try (OutputStream os = conn.getOutputStream();){
            os.write(payload);
        }
        int status = conn.getResponseCode();
        String body = this.readResponseBody(conn, status);
        Map<String, List<String>> headers = conn.getHeaderFields();
        conn.disconnect();
        return new RawHttpResponse(status, body, headers);
    }

    private HttpURLConnection openConnection(URI uri) throws IOException {
        if (this.proxy != null) {
            return (HttpURLConnection)uri.toURL().openConnection(this.proxy);
        }
        return (HttpURLConnection)uri.toURL().openConnection();
    }

    private String readResponseBody(HttpURLConnection conn, int status) throws IOException {
        InputStream stream;
        InputStream inputStream = stream = status >= 400 ? conn.getErrorStream() : conn.getInputStream();
        if (stream == null) {
            return "";
        }
        try (InputStream in = stream;){
            String string = new String(in.readAllBytes(), StandardCharsets.UTF_8);
            return string;
        }
    }

    private String buildChatRequestJson(ModalSolveRequest req, String questionsAsText, int maxCompletionTokens) throws Exception {
        int qCount = req.questions() == null ? 0 : req.questions().size();
        String persona = "\u0422\u044b \u043a\u0430\u043d\u0434\u0438\u0434\u0430\u0442-\u0440\u0430\u0437\u0440\u0430\u0431\u043e\u0442\u0447\u0438\u043a, \u043e\u0442\u0432\u0435\u0447\u0430\u0435\u0448\u044c \u0440\u0430\u0431\u043e\u0442\u043e\u0434\u0430\u0442\u0435\u043b\u044e.\n\u041f\u0438\u0448\u0438 \u043f\u043e-\u0440\u0443\u0441\u0441\u043a\u0438, \u043a\u0440\u0430\u0442\u043a\u043e \u0438 \u0443\u0432\u0435\u0440\u0435\u043d\u043d\u043e.\n";
        String truthRules = "\u0418\u0441\u0442\u043e\u0447\u043d\u0438\u043a \u043f\u0440\u0430\u0432\u0434\u044b \u2014 \u041f\u0420\u041e\u0424\u0418\u041b\u042c \u041a\u0410\u041d\u0414\u0418\u0414\u0410\u0422\u0410 \u043d\u0438\u0436\u0435.\n\u0415\u0441\u043b\u0438 \u0432 \u043f\u0440\u043e\u0444\u0438\u043b\u0435 \u043d\u0435\u0442 \u043a\u043e\u043d\u043a\u0440\u0435\u0442\u0438\u043a\u0438 \u043e\u0442\u0432\u0435\u0447\u0430\u0439 \u043c\u0430\u043a\u0441\u0438\u043c\u0430\u043b\u044c\u043d\u043e, \u0447\u0442\u043e\u0431\u044b \u043f\u043e\u0437\u0432\u0430\u043b\u0438 \u043d\u0430 \u0441\u043e\u0431\u0435\u0441\u0435\u0434\u043e\u0432\u0430\u043d\u0438\u0435.\n";
        String priorityRules = "\u0412\u0430\u0436\u043d\u044b\u0435 \u043f\u0430\u0440\u0430\u043c\u0435\u0442\u0440\u044b:\n- \u0424\u043e\u0440\u043c\u0430\u0442 \u0440\u0430\u0431\u043e\u0442\u044b (\u043e\u0444\u0438\u0441/\u0433\u0438\u0431\u0440\u0438\u0434/\u0443\u0434\u0430\u043b\u0451\u043d\u043a\u0430)\n- \u0417\u0430\u0440\u043f\u043b\u0430\u0442\u043d\u044b\u0435 \u043e\u0436\u0438\u0434\u0430\u043d\u0438\u044f (\u0432\u0438\u043b\u043a\u0430/\u0444\u0438\u043a\u0441)\n\u041f\u043e \u043d\u0438\u043c \u0432\u0441\u0435\u0433\u0434\u0430 \u043e\u043f\u0438\u0440\u0430\u0439\u0441\u044f \u043d\u0430 \u043f\u0440\u043e\u0444\u0438\u043b\u044c \u043a\u0430\u043d\u0434\u0438\u0434\u0430\u0442\u0430.\n\u0415\u0441\u043b\u0438 \u0432\u043e\u043f\u0440\u043e\u0441 \u043f\u0440\u043e \u043b\u043e\u043a\u0430\u0446\u0438\u044e/\u0440\u0435\u043b\u043e\u043a\u0430\u0446\u0438\u044e/\u0433\u0440\u0430\u0444\u0438\u043a/\u0437\u0430\u043d\u044f\u0442\u043e\u0441\u0442\u044c \u2014 \u0442\u043e\u0436\u0435 \u0431\u0435\u0440\u0438 \u0438\u0437 \u043f\u0440\u043e\u0444\u0438\u043b\u044f.\n";
        String clickRules = "\u0415\u0441\u043b\u0438 \u0432\u043e\u043f\u0440\u043e\u0441 \u0441 \u0432\u0430\u0440\u0438\u0430\u043d\u0442\u0430\u043c\u0438 \u2014 action=\"CLICK\".\nclickText \u0434\u043e\u043b\u0436\u0435\u043d \u0422\u041e\u0427\u041d\u041e \u0441\u043e\u0432\u043f\u0430\u0434\u0430\u0442\u044c \u0441 \u043e\u0434\u043d\u0438\u043c \u0438\u0437 \u0432\u0430\u0440\u0438\u0430\u043d\u0442\u043e\u0432 (\u043a\u043e\u043f\u0438\u0440\u0443\u0439 \u043a\u0430\u043a \u0435\u0441\u0442\u044c).\n\u0415\u0441\u043b\u0438 \u0432\u043e\u043f\u0440\u043e\u0441 \u0442\u0435\u043a\u0441\u0442\u043e\u0432\u044b\u0439 \u2014 action=\"FILL\", fill = \u043e\u0442\u0432\u0435\u0442, clickText = null.\n               \u041d\u0438\u043a\u043e\u0433\u0434\u0430 \u043d\u0435 \u0432\u044b\u0431\u0438\u0440\u0430\u0439 \u0432\u0430\u0440\u0438\u0430\u043d\u0442\u044b \u0442\u0438\u043f\u0430 \u201c\u0421\u0432\u043e\u0439 \u0432\u0430\u0440\u0438\u0430\u043d\u0442\u201d, \u201c\u0414\u0440\u0443\u0433\u043e\u0435\u201d, \u201c\u0418\u043d\u043e\u0435\u201d, \u0435\u0441\u043b\u0438 \u043f\u0440\u0438\u0441\u0443\u0442\u0441\u0442\u0432\u0443\u044e\u0442 \u0434\u0440\u0443\u0433\u0438\u0435 \u0432\u0430\u0440\u0438\u0430\u043d\u0442\u044b.\n                \u0412\u044b\u0431\u0438\u0440\u0430\u0439 \u043e\u0434\u0438\u043d \u0438\u0437 \u043e\u0431\u044b\u0447\u043d\u044b\u0445 \u0432\u0430\u0440\u0438\u0430\u043d\u0442\u043e\u0432.\n";
        String outputRules = "\u0412\u0435\u0440\u043d\u0438 \u0422\u041e\u041b\u042c\u041a\u041e JSON (\u0431\u0435\u0437 \u0442\u0435\u043a\u0441\u0442\u0430 \u0432\u043e\u043a\u0440\u0443\u0433), \u0441\u0442\u0440\u043e\u0433\u043e \u043f\u043e \u0441\u0445\u0435\u043c\u0435.\nanswers \u2014 \u0440\u043e\u0432\u043d\u043e \u0441\u0442\u043e\u043b\u044c\u043a\u043e \u044d\u043b\u0435\u043c\u0435\u043d\u0442\u043e\u0432, \u0441\u043a\u043e\u043b\u044c\u043a\u043e \u0432\u043e\u043f\u0440\u043e\u0441\u043e\u0432, \u0438 \u0432 \u0442\u043e\u043c \u0436\u0435 \u043f\u043e\u0440\u044f\u0434\u043a\u0435.\nreason: \u043a\u043e\u0440\u043e\u0442\u043a\u043e 3\u20137 \u0441\u043b\u043e\u0432, \u043f\u043e-\u0440\u0443\u0441\u0441\u043a\u0438.\n";
        String candidate = this.formatCandidateContext(req.candidateContext());
        String userPayload = "\u041f\u0420\u041e\u0424\u0418\u041b\u042c \u041a\u0410\u041d\u0414\u0418\u0414\u0410\u0422\u0410 (\u0438\u0441\u0442\u043e\u0447\u043d\u0438\u043a \u043f\u0440\u0430\u0432\u0434\u044b):\n" + candidate + "\n\n\u0412\u041e\u041f\u0420\u041e\u0421\u042b:\n" + questionsAsText + "\n\n\u0414\u041e\u041f.\u041f\u041e\u0416\u0415\u041b\u0410\u041d\u0418\u042f:\n" + (req.prompt() == null ? "" : req.prompt());
        LinkedHashMap<String, Object> body = new LinkedHashMap<String, Object>();
        body.put("model", this.model);
        body.put("messages", List.of(Map.of("role", "system", "content", persona + "\n" + truthRules + "\n" + priorityRules + "\n" + clickRules + "\n" + outputRules), Map.of("role", "user", "content", userPayload)));
        body.put("max_completion_tokens", maxCompletionTokens);
        body.put("response_format", this.buildResponseFormat(qCount));
        return this.om.writeValueAsString(body);
    }

    private int calcMaxTokens(int qCount) {
        if (qCount <= 1) {
            return 700;
        }
        if (qCount == 2) {
            return 1000;
        }
        if (qCount <= 4) {
            return 1450;
        }
        if (qCount <= 7) {
            return 1850;
        }
        if (qCount <= 10) {
            return 2400;
        }
        return 2800;
    }

    private int calcRetryTokens(int initialTokens, int qCount) {
        int boosted = Math.max(initialTokens + 650, this.calcMaxTokens(qCount) + 650);
        return Math.min(boosted, 3200);
    }

    private Map<String, Object> buildResponseFormat(final int qCount) {
        if (!this.looksLikeStructuredCapable(this.model) || qCount <= 0) {
            return Map.of("type", "json_object");
        }
        final LinkedHashMap<String, Object> answerItemSchema = new LinkedHashMap<String, Object>();
        answerItemSchema.put("type", "object");
        answerItemSchema.put("additionalProperties", false);
        answerItemSchema.put("properties", Map.of("action", Map.of("type", "string", "enum", List.of("CLICK", "FILL")), "clickText", Map.of("anyOf", List.of(Map.of("type", "string"), Map.of("type", "null"))), "fill", Map.of("anyOf", List.of(Map.of("type", "string"), Map.of("type", "null"))), "reason", Map.of("type", "string")));
        answerItemSchema.put("required", List.of("action", "clickText", "fill", "reason"));
        final LinkedHashMap<String, Object> rootSchema = new LinkedHashMap<String, Object>();
        rootSchema.put("type", "object");
        rootSchema.put("additionalProperties", false);
        rootSchema.put("properties", Map.of("answers", new LinkedHashMap<String, Object>(){
            {
                this.put("type", "array");
                this.put("minItems", qCount);
                this.put("maxItems", qCount);
                this.put("items", answerItemSchema);
            }
        }));
        rootSchema.put("required", List.of("answers"));
        return new LinkedHashMap<String, Object>(){
            {
                this.put("type", "json_schema");
                this.put("strict", true);
                this.put("json_schema", Map.of("name", "modal_answers", "schema", rootSchema));
            }
        };
    }

    private boolean looksLikeStructuredCapable(String model) {
        if (model == null) {
            return false;
        }
        String m = model.toLowerCase();
        return m.startsWith("gpt-4o");
    }

    private String formatCandidateContext(Map<String, String> ctx) {
        if (ctx == null || ctx.isEmpty()) {
            return "{}";
        }
        try {
            return this.om.writerWithDefaultPrettyPrinter().writeValueAsString(ctx);
        }
        catch (Exception e) {
            StringBuilder sb = new StringBuilder("{\n");
            for (Map.Entry<String, String> en : ctx.entrySet()) {
                String k = en.getKey() == null ? "" : en.getKey();
                String v = en.getValue() == null ? "" : en.getValue();
                sb.append("  \"").append(k.replace("\"", "\\\"")).append("\": \"").append(v.replace("\"", "\\\"")).append("\",\n");
            }
            if (sb.length() >= 2) {
                sb.delete(sb.length() - 2, sb.length());
            }
            sb.append("\n}");
            return sb.toString();
        }
    }

    private String formatQuestionsForPrompt(List<Question> questions) {
        if (questions == null || questions.isEmpty()) {
            return "(\u043d\u0435\u0442 \u0432\u043e\u043f\u0440\u043e\u0441\u043e\u0432)";
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < questions.size(); ++i) {
            Question q = questions.get(i);
            sb.append("\u0412\u043e\u043f\u0440\u043e\u0441 \u2116").append(i + 1).append(": ").append(q.questionText()).append("\n");
            if (q.options() != null && !q.options().isEmpty()) {
                sb.append("\u0412\u0430\u0440\u0438\u0430\u043d\u0442\u044b: ").append(String.join((CharSequence)" | ", q.options())).append("\n");
            }
            sb.append("---\n");
        }
        return sb.toString();
    }

    private LlmParseOutcome parseLlmResponse(String responseBody) throws Exception {
        Map map = (Map)this.om.readValue(responseBody, (TypeReference)new TypeReference<Map<String, Object>>(this){});
        List<Map<String, Object>> choices = this.castChoices(map.get("choices"));
        if (choices.isEmpty()) {
            log.warn("[LLM] Empty choices in response: {}", (Object)this.preview(responseBody));
            return LlmParseOutcome.empty();
        }
        Map<String, Object> message = this.castMap(choices.get(0).get("message"));
        String finishReason = this.asText(choices.get(0).get("finish_reason"));
        if (message.isEmpty()) {
            log.warn("[LLM] Missing message payload finishReason={} body={}", (Object)finishReason, (Object)this.preview(responseBody));
            return LlmParseOutcome.empty();
        }
        String refusal = this.asText(message.get("refusal"));
        if (!refusal.isBlank()) {
            log.warn("[LLM] Model refusal finishReason={} refusal={}", (Object)finishReason, (Object)refusal);
            return LlmParseOutcome.empty();
        }
        String content = this.extractMessageContent(message.get("content"));
        if (content.isBlank()) {
            log.warn("[LLM] Empty message content finishReason={} body={}", (Object)finishReason, (Object)this.preview(responseBody));
            return new LlmParseOutcome(new ModalSolveResponse(List.of()), "length".equalsIgnoreCase(finishReason));
        }
        String json = this.extractJsonObject(content);
        if (json.isBlank()) {
            log.warn("[LLM] JSON payload not found in content: {}", (Object)this.preview(content));
            return LlmParseOutcome.empty();
        }
        try {
            return new LlmParseOutcome((ModalSolveResponse)this.om.readValue(json, ModalSolveResponse.class), false);
        }
        catch (Exception e) {
            log.warn("[LLM] Failed to parse content as ModalSolveResponse: {}", (Object)this.preview(json), (Object)e);
            return LlmParseOutcome.empty();
        }
    }

    private List<Map<String, Object>> castChoices(Object raw) {
        List list;
        if (!(raw instanceof List) || (list = (List)raw).isEmpty()) {
            return List.of();
        }
        ArrayList<Map<String, Object>> out = new ArrayList<Map<String, Object>>(list.size());
        for (Object item : list) {
            if (!(item instanceof Map)) continue;
            Map map = (Map)item;
            out.add(map);
        }
        return out;
    }

    private Map<String, Object> castMap(Object raw) {
        if (raw instanceof Map) {
            Map map = (Map)raw;
            return map;
        }
        return Map.of();
    }

    private String extractMessageContent(Object rawContent) {
        List parts;
        if (rawContent instanceof String) {
            String s = (String)rawContent;
            return s;
        }
        if (!(rawContent instanceof List) || (parts = (List)rawContent).isEmpty()) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        for (Object part : parts) {
            Map map;
            String type;
            if (!(part instanceof Map) || !"text".equals(type = Objects.toString((map = (Map)part).get("type"), ""))) continue;
            Object text = map.get("text");
            if (text instanceof String) {
                String s = (String)text;
                sb.append(s);
                continue;
            }
            if (!(text instanceof Map)) continue;
            Map nested = (Map)text;
            sb.append(Objects.toString(nested.get("value"), ""));
        }
        return sb.toString().trim();
    }

    private String extractJsonObject(String content) {
        if (content == null) {
            return "";
        }
        String trimmed = content.trim();
        if (trimmed.startsWith("{") && trimmed.endsWith("}")) {
            return trimmed;
        }
        int start = trimmed.indexOf(123);
        int end = trimmed.lastIndexOf(125);
        if (start >= 0 && end > start) {
            return trimmed.substring(start, end + 1).trim();
        }
        return "";
    }

    private String asText(Object value) {
        return value == null ? "" : String.valueOf(value).trim();
    }

    private String preview(String text) {
        if (text == null) {
            return "";
        }
        String oneLine = text.replaceAll("\\s+", " ").trim();
        if (oneLine.length() <= 500) {
            return oneLine;
        }
        return oneLine.substring(0, 500) + "...";
    }

    private record ProxyTransport(Proxy proxy, String proxyAuthHeader) {
    }

    private record LlmParseOutcome(ModalSolveResponse response, boolean retryForLength) {
        private static LlmParseOutcome empty() {
            return new LlmParseOutcome(new ModalSolveResponse(List.of()), false);
        }
    }

    private record RawHttpResponse(int statusCode, String body, Map<String, List<String>> headers) {
    }
}

