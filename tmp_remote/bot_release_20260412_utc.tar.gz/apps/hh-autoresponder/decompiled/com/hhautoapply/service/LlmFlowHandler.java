/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.microsoft.playwright.Locator
 *  com.microsoft.playwright.Locator$ClickOptions
 *  com.microsoft.playwright.Page
 *  lombok.Generated
 *  org.springframework.stereotype.Component
 */
package com.hhautoapply.service;

import com.hhautoapply.model.Answer;
import com.hhautoapply.model.ModalSolveRequest;
import com.hhautoapply.model.ModalSolveResponse;
import com.hhautoapply.model.Question;
import com.hhautoapply.model.QuestionType;
import com.hhautoapply.service.LlmClient;
import com.hhautoapply.service.PlaywrightSupport;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import lombok.Generated;
import org.springframework.stereotype.Component;

@Component
public class LlmFlowHandler {
    private static final int ACTION_DELAY_MS = 180;
    private static final int LLM_TEXT_MAX = 900;
    private static final int LLM_RETRIES = 2;
    private static final String Q_SEL = "[data-qa='task-question']";
    private static final String A_WRAP_SEL = "[data-qa='textarea-native-wrapper']";
    private final LlmClient llmClient;
    private final PlaywrightSupport ui;

    public boolean fillQuestions(Page page, Map<String, String> candidateContext) {
        List<QBinding> bindings = this.buildQuestionBindings(page);
        if (bindings.isEmpty()) {
            return false;
        }
        List<Question> questions = bindings.stream().map(b -> new Question(b.question(), b.kind() == QKind.TEXTAREA ? QuestionType.TEXTAREA : QuestionType.CHOICE, b.kind() == QKind.CHOICE ? b.options() : List.of())).toList();
        String extraPrompt = "\u0412\u0430\u0436\u043d\u043e: answers \u0441\u0442\u0440\u043e\u0433\u043e \u0432 \u0442\u043e\u043c \u0436\u0435 \u043f\u043e\u0440\u044f\u0434\u043a\u0435, \u0447\u0442\u043e \u0412\u041e\u041f\u0420\u041e\u0421\u042b. \u0415\u0441\u043b\u0438 options \u043f\u0443\u0441\u0442\u043e\u0439 \u2014 \u044d\u0442\u043e \u0442\u0435\u043a\u0441\u0442\u043e\u0432\u044b\u0439 \u0432\u043e\u043f\u0440\u043e\u0441 (FILL). \u0415\u0441\u043b\u0438 options \u043d\u0435 \u043f\u0443\u0441\u0442\u043e\u0439 \u2014 CLICK \u0438 clickText \u0441\u0442\u0440\u043e\u0433\u043e \u0438\u0437 options. \u0422\u0435\u043a\u0441\u0442 \u0434\u043b\u044f FILL \u0434\u0435\u043b\u0430\u0439 \u043a\u043e\u0440\u043e\u0442\u043a\u0438\u043c (\u0434\u043e 800 \u0441\u0438\u043c\u0432\u043e\u043b\u043e\u0432).";
        ModalSolveResponse resp = null;
        for (int attempt = 1; attempt <= 2 && ((resp = this.llmClient.solveModal(new ModalSolveRequest(extraPrompt, questions, candidateContext == null ? Map.of() : candidateContext))) == null || resp.answers() == null || resp.answers().isEmpty()); ++attempt) {
            page.waitForTimeout(220.0);
        }
        if (resp == null || resp.answers() == null || resp.answers().isEmpty()) {
            return false;
        }
        return this.applyLlmAnswersStable(page, bindings, resp.answers());
    }

    private List<QBinding> buildQuestionBindings(Page page) {
        int qn;
        ArrayList<QBinding> out = new ArrayList<QBinding>();
        Locator qs = page.locator(Q_SEL);
        try {
            qn = Math.min(qs.count(), 40);
        }
        catch (Exception e) {
            return out;
        }
        for (int i = 0; i < qn; ++i) {
            String qText;
            Locator qEl = qs.nth(i);
            if (!this.ui.isVisible(qEl) || (qText = this.ui.safeText(qEl, 900).trim()).isBlank()) continue;
            Locator scope = this.findQuestionScope(qEl);
            Locator ta = null;
            try {
                Locator wrap = scope.locator(A_WRAP_SEL).first();
                if (this.ui.isVisible(wrap)) {
                    ta = wrap.locator("textarea").first();
                }
            }
            catch (Exception wrap) {
                // empty catch block
            }
            if (this.ui.isVisible(ta)) {
                out.add(new QBinding(out.size(), qText, QKind.TEXTAREA, scope, ta, List.of()));
                continue;
            }
            Locator ce = this.ui.firstVisible(scope, "[contenteditable='true'][role='textbox']", "[contenteditable='true']");
            if (ce != null) {
                out.add(new QBinding(out.size(), qText, QKind.TEXTAREA, scope, ce, List.of()));
                continue;
            }
            List<String> opts = this.findChoiceOptions(scope);
            if (!opts.isEmpty()) {
                out.add(new QBinding(out.size(), qText, QKind.CHOICE, scope, null, opts));
                continue;
            }
            Locator ta2 = this.ui.firstVisible(scope, "textarea", "input[type='text']");
            if (ta2 == null) continue;
            out.add(new QBinding(out.size(), qText, QKind.TEXTAREA, scope, ta2, List.of()));
        }
        return out;
    }

    private Locator findQuestionScope(Locator qEl) {
        try {
            Locator scope = qEl.locator("xpath=./ancestor::*[@data-qa='task-body']").first();
            if (scope != null && scope.count() > 0) {
                return scope;
            }
        }
        catch (Exception scope) {
            // empty catch block
        }
        try {
            Locator scope2 = qEl.locator("xpath=./ancestor::div[1]").first();
            return scope2 != null ? scope2 : qEl;
        }
        catch (Exception ignore) {
            return qEl;
        }
    }

    private List<String> findChoiceOptions(Locator scope) {
        if (scope == null) {
            return List.of();
        }
        LinkedHashSet<String> out = new LinkedHashSet<String>();
        try {
            Locator cand = scope.locator("label, [role='radio'], button");
            int n = Math.min(cand.count(), 60);
            for (int i = 0; i < n; ++i) {
                String low;
                String t;
                Locator el = cand.nth(i);
                if (!el.isVisible() || (t = this.ui.safeText(el, 90).trim()).isBlank() || t.length() > 80 || (low = t.toLowerCase(Locale.ROOT)).contains("\u043e\u0442\u043a\u043b\u0438\u043a") || low.contains("\u043f\u0435\u0440\u0435\u0439\u0442\u0438 \u043a \u0432\u0430\u043a\u0430\u043d\u0441\u0438\u0438")) continue;
                out.add(t);
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return List.copyOf(out);
    }

    private boolean applyLlmAnswersStable(Page page, List<QBinding> bindings, List<Answer> answers) {
        int n = Math.min(bindings.size(), answers.size());
        boolean anyOk = false;
        for (int i = 0; i < n; ++i) {
            QBinding b = bindings.get(i);
            Answer a = answers.get(i);
            String act = LlmFlowHandler.n(a.action()).toUpperCase(Locale.ROOT);
            boolean ok = "CLICK".equals(act) ? this.clickOptionStable(b, a.clickText()) : ("FILL".equals(act) ? this.fillTextFieldStable(b, a.fill()) : false);
            anyOk |= ok;
            page.waitForTimeout(180.0);
        }
        return anyOk;
    }

    private boolean fillTextFieldStable(QBinding b, String text) {
        if (b == null || text == null) {
            return false;
        }
        String val = LlmFlowHandler.compact(text);
        if (val.isEmpty()) {
            return false;
        }
        if (val.length() > 900) {
            val = val.substring(0, 900);
        }
        try {
            Locator input = b.inputOrEditable();
            if (input == null || !this.ui.isVisible(input)) {
                return false;
            }
            input.scrollIntoViewIfNeeded();
            input.click(new Locator.ClickOptions().setTimeout(1500.0));
            return this.fillAnyTextInput(input, val);
        }
        catch (Exception ignore) {
            return false;
        }
    }

    private boolean fillAnyTextInput(Locator input, String value) {
        if (input == null || value == null || value.isBlank()) {
            return false;
        }
        String v = value;
        if (v.length() > 900) {
            v = v.substring(0, 900);
        }
        try {
            String tag = "";
            try {
                tag = String.valueOf(input.evaluate("el => el.tagName || ''"));
            }
            catch (Exception exception) {
                // empty catch block
            }
            if ("TEXTAREA".equalsIgnoreCase(tag) || "INPUT".equalsIgnoreCase(tag)) {
                try {
                    input.fill(v);
                    this.ui.blur(input.page());
                    return true;
                }
                catch (Exception ignore) {
                    try {
                        input.evaluate("(el) => { try { el.value=''; } catch(e){} }");
                    }
                    catch (Exception exception) {
                        // empty catch block
                    }
                    input.type(v);
                    this.ui.blur(input.page());
                    return true;
                }
            }
            String ce = "";
            try {
                ce = LlmFlowHandler.n(input.getAttribute("contenteditable"));
            }
            catch (Exception exception) {
                // empty catch block
            }
            if (!ce.isBlank()) {
                try {
                    input.evaluate("(el) => { el.focus(); el.innerText=''; }");
                }
                catch (Exception exception) {
                    // empty catch block
                }
                input.type(v);
                this.ui.blur(input.page());
                return true;
            }
            input.type(v);
            this.ui.blur(input.page());
            return true;
        }
        catch (Exception e) {
            return false;
        }
    }

    private boolean clickOptionStable(QBinding b, String clickText) {
        String t = LlmFlowHandler.n(clickText).trim();
        if (b == null || t.isEmpty()) {
            return false;
        }
        String normalized = LlmFlowHandler.normalize(t);
        String chosen = null;
        for (String opt : b.options()) {
            if (!LlmFlowHandler.normalize(opt).equals(normalized)) continue;
            chosen = opt;
            break;
        }
        if (chosen == null) {
            for (String opt : b.options()) {
                String no = LlmFlowHandler.normalize(opt);
                if (!no.contains(normalized) && !normalized.contains(no)) continue;
                chosen = opt;
                break;
            }
        }
        if (chosen == null) {
            chosen = t;
        }
        try {
            String opt;
            Locator scope = b.scope();
            if (scope == null) {
                return false;
            }
            opt = this.ui.firstVisible(scope, "label:has-text('" + LlmFlowHandler.esc(chosen) + "')", "[role='radio']:has-text('" + LlmFlowHandler.esc(chosen) + "')", "button:has-text('" + LlmFlowHandler.esc(chosen) + "')", "a:has-text('" + LlmFlowHandler.esc(chosen) + "')", "span:has-text('" + LlmFlowHandler.esc(chosen) + "')");
            if (opt == null && !this.ui.isVisible((Locator)(opt = scope.locator("text='" + LlmFlowHandler.esc(chosen) + "'").first()))) {
                return false;
            }
            return this.ui.stableClick((Locator)opt, () -> true, 900);
        }
        catch (Exception ignore) {
            return false;
        }
    }

    private static String esc(String s) {
        if (s == null) {
            return "";
        }
        return s.replace("'", "\\'");
    }

    private static String normalize(String s) {
        if (s == null) {
            return "";
        }
        return s.trim().toLowerCase(Locale.ROOT).replaceAll("\\s+", " ");
    }

    private static String compact(String s) {
        if (s == null) {
            return "";
        }
        String x = s.replace("\r\n", "\n").trim();
        x = x.replaceAll("\n{3,}", "\n\n");
        return x;
    }

    private static String n(String s) {
        return s == null ? "" : s;
    }

    @Generated
    public LlmFlowHandler(LlmClient llmClient, PlaywrightSupport ui) {
        this.llmClient = llmClient;
        this.ui = ui;
    }

    private record QBinding(int index, String question, QKind kind, Locator scope, Locator inputOrEditable, List<String> options) {
    }

    private static enum QKind {
        TEXTAREA,
        CHOICE;

    }
}

