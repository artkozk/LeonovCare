/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.microsoft.playwright.Locator
 *  com.microsoft.playwright.Locator$ClickOptions
 *  com.microsoft.playwright.Locator$WaitForOptions
 *  com.microsoft.playwright.Page
 *  com.microsoft.playwright.options.WaitForSelectorState
 *  lombok.Generated
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 *  org.springframework.stereotype.Component
 */
package com.hhautoapply.service;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.WaitForSelectorState;
import lombok.Generated;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class PlaywrightSupport {
    @Generated
    private static final Logger log = LoggerFactory.getLogger(PlaywrightSupport.class);
    private static final int CLICK_TIMEOUT_MS = 4000;

    public Locator visible(Locator loc, int timeoutMs) {
        try {
            Locator f = loc.first();
            f.waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.VISIBLE).setTimeout((double)timeoutMs));
            return f;
        }
        catch (Exception e) {
            return null;
        }
    }

    public Locator firstVisible(Locator root, String ... selectors) {
        if (root == null) {
            return null;
        }
        for (String sel : selectors) {
            try {
                Locator l = root.locator(sel).first();
                if (!this.isVisible(l)) continue;
                return l;
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
        return null;
    }

    public boolean isVisible(Locator l) {
        try {
            return l != null && l.count() > 0 && l.isVisible();
        }
        catch (Exception e) {
            return false;
        }
    }

    public boolean waitSignal(Page page, Condition signal, int waitMs) {
        long until = System.currentTimeMillis() + (long)Math.max(150, waitMs);
        while (System.currentTimeMillis() < until) {
            try {
                if (signal == null || signal.ok()) {
                    return true;
                }
            }
            catch (Exception exception) {
                // empty catch block
            }
            try {
                page.waitForTimeout(80.0);
            }
            catch (Exception exception) {}
        }
        try {
            return signal != null && signal.ok();
        }
        catch (Exception e) {
            return false;
        }
    }

    public boolean stableClick(Locator l, Condition successSignal, int waitMs) {
        if (l == null) {
            return false;
        }
        try {
            l.scrollIntoViewIfNeeded();
        }
        catch (Exception exception) {
            // empty catch block
        }
        if (this.clickOnce(l, false) && this.waitSignal(l.page(), successSignal, waitMs)) {
            return true;
        }
        if (this.clickOnce(l, true)) {
            return this.waitSignal(l.page(), successSignal, waitMs);
        }
        return false;
    }

    public void waitEnabled(Locator l, int timeoutMs) {
        long until = System.currentTimeMillis() + (long)timeoutMs;
        while (System.currentTimeMillis() < until) {
            try {
                if (l.isEnabled()) {
                    return;
                }
            }
            catch (Exception exception) {
                // empty catch block
            }
            try {
                l.page().waitForTimeout(90.0);
            }
            catch (Exception exception) {}
        }
    }

    public void blur(Page page) {
        if (page == null) {
            return;
        }
        try {
            page.evaluate("() => { try { document.activeElement && document.activeElement.blur && document.activeElement.blur(); } catch(e){} }");
        }
        catch (Exception exception) {
            // empty catch block
        }
        try {
            page.keyboard().press("Tab");
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    public String safeText(Locator l, int maxChars) {
        try {
            String s = l.innerText();
            if (s == null) {
                return "";
            }
            return (s = s.trim()).length() <= maxChars ? s : s.substring(0, maxChars);
        }
        catch (Exception e) {
            return "";
        }
    }

    private boolean clickOnce(Locator l, boolean force) {
        try {
            l.click(new Locator.ClickOptions().setTimeout(4000.0).setForce(force));
            return true;
        }
        catch (Exception ignore) {
            return false;
        }
    }

    public static interface Condition {
        public boolean ok();
    }
}

