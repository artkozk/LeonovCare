/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.microsoft.playwright.Locator
 *  com.microsoft.playwright.Locator$ClickOptions
 *  com.microsoft.playwright.Page
 *  com.microsoft.playwright.Page$NavigateOptions
 *  com.microsoft.playwright.Page$WaitForSelectorOptions
 *  com.microsoft.playwright.options.WaitForSelectorState
 *  com.microsoft.playwright.options.WaitUntilState
 *  lombok.Generated
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 *  org.springframework.stereotype.Service
 */
package com.hhautoapply.service;

import com.hhautoapply.service.PlaywrightSupport;
import com.hhautoapply.service.VacancyApplier;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.WaitForSelectorState;
import com.microsoft.playwright.options.WaitUntilState;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.nio.file.attribute.FileAttribute;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Properties;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import lombok.Generated;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class HhApplyService {
    @Generated
    private static final Logger log = LoggerFactory.getLogger(HhApplyService.class);
    private final VacancyApplier vacancyApplier;
    private final PlaywrightSupport ui;
    private static final int NAV_TIMEOUT_MS = 60000;
    private static final int SERP_WAIT_MS = 15000;
    private static final int MAX_PAGER_FAILS_IN_ROW = 4;
    private static final int MAX_EMPTY_SERP_SPINS = 30;
    private static final long MIN_TIER_ELAPSED_MS_BEFORE_SWITCH = 8000L;
    private static final int MIN_GOOD_CARDS_BEFORE_SWITCH = 10;
    private static final int MIN_PAGES_ADVANCED_BEFORE_SWITCH = 1;
    private static final int MAX_SERP_REFRESHES_PER_TIER = 2;
    private static final int CHECKPOINT_EARLY_HIT_INDEX = 3;
    private static final int CHECKPOINT_EARLY_HITS_MAX = 3;
    private static final Path CHECKPOINT_FILE = Paths.get("data", "hh-serp-checkpoints.properties");
    private static final String CARD_SEL = "[data-qa='vacancy-serp__vacancy']";
    private static final String CARD_TITLE_A_SEL = "a[data-qa='serp-item__title']";
    private static final String CARD_TITLE_SEL = "[data-qa='serp-item__title']";
    private static final String NEXT_PAGE_SEL = "a[data-qa='pager-next'], a[rel='next'], a:has-text('\u0414\u0430\u043b\u044c\u0448\u0435'), a:has-text('\u0421\u043b\u0435\u0434\u0443\u044e\u0449\u0430\u044f'), button:has-text('\u0414\u0430\u043b\u044c\u0448\u0435')";
    private static final String[] OVERLAY_CLOSE_SELECTORS = new String[]{"[data-qa='cookies-accept']", "[data-qa='region-clarification-confirm']"};
    private static final Pattern VACANCY_ID_1 = Pattern.compile("/vacancy/(\\d+)");
    private static final Pattern VACANCY_ID_2 = Pattern.compile("vacancyId=(\\d+)");
    private static final String SENT = "SENT";
    private static final String SENT_BY_LLM = "SENT_BY_LLM";
    private static final String APPLIED = "APPLIED";
    private static final String ALREADY_APPLIED = "ALREADY_APPLIED";
    private static final String FAILED = "FAILED";
    private static final String SKIP_NO_HREF = "SKIP_NO_HREF";
    private static final String TIER_EXHAUSTED = "TIER_EXHAUSTED";
    private static final String SERP_ENDED = "SERP_ENDED";
    private static final String TARGET_REACHED = "TARGET_REACHED";
    private static final String REASON_CHECKPOINT_REACHED = "CHECKPOINT_REACHED";
    private final Object checkpointLock = new Object();
    private volatile boolean checkpointsLoaded = false;
    private final Map<String, Long> checkpointTopIdByTierKey = new ConcurrentHashMap<String, Long>();

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private void loadCheckpointsIfNeeded() {
        if (this.checkpointsLoaded) {
            return;
        }
        Object object = this.checkpointLock;
        synchronized (object) {
            if (this.checkpointsLoaded) {
                return;
            }
            if (!Files.exists(CHECKPOINT_FILE, new LinkOption[0])) {
                this.checkpointsLoaded = true;
                return;
            }
            Properties p = new Properties();
            try (InputStream in = Files.newInputStream(CHECKPOINT_FILE, new OpenOption[0]);){
                p.load(in);
                for (String k : p.stringPropertyNames()) {
                    String v = p.getProperty(k);
                    if (v == null || v.isBlank()) continue;
                    try {
                        this.checkpointTopIdByTierKey.put(k, Long.parseLong(v.trim()));
                    }
                    catch (NumberFormatException numberFormatException) {}
                }
                log.info("[CHECKPOINT] loaded {} keys from {}", (Object)this.checkpointTopIdByTierKey.size(), (Object)CHECKPOINT_FILE);
            }
            catch (IOException e) {
                log.warn("[CHECKPOINT] load failed file={} err={}", (Object)CHECKPOINT_FILE, (Object)String.valueOf(e));
            }
            finally {
                this.checkpointsLoaded = true;
            }
        }
    }

    private Long getCheckpointTopId(String tierKey) {
        this.loadCheckpointsIfNeeded();
        return this.checkpointTopIdByTierKey.get(tierKey);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private void saveCheckpointTopId(String tierKey, Long topId) {
        if (tierKey == null || tierKey.isBlank() || topId == null) {
            return;
        }
        this.loadCheckpointsIfNeeded();
        this.checkpointTopIdByTierKey.put(tierKey, topId);
        Object object = this.checkpointLock;
        synchronized (object) {
            try {
                Files.createDirectories(CHECKPOINT_FILE.getParent(), new FileAttribute[0]);
                Properties p = new Properties();
                for (Map.Entry<String, Long> e : this.checkpointTopIdByTierKey.entrySet()) {
                    if (e.getKey() == null || e.getKey().isBlank() || e.getValue() == null) continue;
                    p.setProperty(e.getKey(), String.valueOf(e.getValue()));
                }
                Path tmp = CHECKPOINT_FILE.resolveSibling(String.valueOf(CHECKPOINT_FILE.getFileName()) + ".tmp");
                try (OutputStream out = Files.newOutputStream(tmp, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE);){
                    p.store(out, "hh serp checkpoints: tierKey -> topVacancyId");
                }
                Files.move(tmp, CHECKPOINT_FILE, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            }
            catch (Exception e) {
                log.warn("[CHECKPOINT] save failed file={} err={}", (Object)CHECKPOINT_FILE, (Object)String.valueOf(e));
            }
        }
    }

    private String checkpointTierKey(Page serp, SearchTier tier) {
        URI cur = URI.create(serp.url());
        String host = cur.getHost() == null ? "unknown-host" : cur.getHost();
        String text = this.norm(tier.text());
        String role = this.norm(tier.professionalRole());
        String schedule = this.norm(tier.schedule());
        List<Object> fields = tier.searchFields() == null ? List.of() : tier.searchFields();
        String fieldsKey = fields.stream().filter(Objects::nonNull).map(String::trim).filter(s -> !s.isBlank()).map(String::toLowerCase).reduce((a, b) -> a + "," + b).orElse("");
        return host + "|text=" + text + "|role=" + role + "|schedule=" + schedule + "|fields=" + fieldsKey;
    }

    private String norm(String s) {
        if (s == null) {
            return "";
        }
        return s.trim().toLowerCase(Locale.ROOT);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public List<ApplyResult> applyFromSerp(Page serp, List<SearchTier> tiers, int targetApplies, String coverLetter, Map<String, String> candidateContext) {
        Objects.requireNonNull(serp, "page");
        String runId = UUID.randomUUID().toString().substring(0, 8);
        int target = Math.max(1, targetApplies);
        List<SearchTier> safeTiers = tiers == null || tiers.isEmpty() ? this.defaultTierLadder("java") : tiers;
        log.info("[{}][APPLY] start tiers={} target={}", new Object[]{runId, safeTiers.size(), target});
        ArrayList<ApplyResult> results = new ArrayList<ApplyResult>(256);
        HashSet<Long> seenIds = new HashSet<Long>();
        HashSet<String> seenFallback = new HashSet<String>();
        int sent = 0;
        Page v = serp.context().newPage();
        for (int tierIdx = 0; tierIdx < safeTiers.size() && sent < target; ++tierIdx) {
            SearchTier tier = safeTiers.get(tierIdx);
            String serpUrl = this.buildSerpUrlSameHost(serp, tier);
            String tierKey = this.checkpointTierKey(serp, tier);
            Long stopAtVacancyId = this.getCheckpointTopId(tierKey);
            log.info("[{}][TIER] enter {}/{} text='{}' role={} schedule={} fields={} url={} checkpointTopId={}", new Object[]{runId, tierIdx + 1, safeTiers.size(), String.valueOf(tier.text()), tier.professionalRole(), tier.schedule(), tier.searchFields(), serpUrl, stopAtVacancyId});
            long tierStartedAt = System.currentTimeMillis();
            int tierSent = 0;
            int pagerFailsInRow = 0;
            int emptySpins = 0;
            int goodCards = 0;
            int badNoHref = 0;
            int pagesAdvanced = 0;
            int serpRefreshes = 0;
            Long newTopVacancyId = null;
            int earlyCheckpointHits = 0;
            boolean ignoreCheckpoint = false;
            Long pageTopVacancyId = null;
            boolean tierEndedByCheckpoint = false;
            int checkpointHitIdx = -1;
            if (!this.gotoSerp(serp, runId, serpUrl)) {
                this.add(results, runId, target, new ApplyResult(serpUrl, "", null, TIER_EXHAUSTED, "SERP_NAV_FAILED"));
                this.logTierSwitch(runId, tierIdx, safeTiers.size(), tier, serpUrl, "SERP_NAV_FAILED", tierSent, goodCards, badNoHref, pagesAdvanced, tierStartedAt);
                continue;
            }
            boolean stopTier = false;
            while (sent < target && !stopTier) {
                boolean paged;
                this.dismissOverlays(serp);
                Locator cards = serp.locator(CARD_SEL);
                int n = this.safeCount(cards);
                if (n == 0) {
                    ++emptySpins;
                    serp.mouse().wheel(0.0, 1400.0);
                    serp.waitForTimeout(140.0);
                    if (this.isNearBottom(serp)) {
                        paged = this.goNextSerpPage(serp, runId);
                        if (!paged) {
                            if (++pagerFailsInRow >= 4 || emptySpins >= 30) {
                                if (!this.allowSwitchTier(tierStartedAt, goodCards, pagesAdvanced) && serpRefreshes < 2) {
                                    log.warn("[{}][TIER_GUARD] would-switch-but-guarded reason=EMPTY_OR_PAGER_FAIL refresh={}/{} url={}", new Object[]{runId, ++serpRefreshes, 2, serp.url()});
                                    this.gotoSerp(serp, runId, serpUrl);
                                    pagerFailsInRow = 0;
                                    emptySpins = 0;
                                    continue;
                                }
                                this.add(results, runId, target, new ApplyResult(serp.url(), "", null, TIER_EXHAUSTED, "EMPTY_OR_PAGER_FAIL"));
                                this.logTierSwitch(runId, tierIdx, safeTiers.size(), tier, serp.url(), "EMPTY_OR_PAGER_FAIL", tierSent, goodCards, badNoHref, pagesAdvanced, tierStartedAt);
                                stopTier = true;
                                break;
                            }
                        } else {
                            ++pagesAdvanced;
                            pagerFailsInRow = 0;
                        }
                    }
                    if (emptySpins < 30) continue;
                    if (!this.allowSwitchTier(tierStartedAt, goodCards, pagesAdvanced) && serpRefreshes < 2) {
                        log.warn("[{}][TIER_GUARD] would-switch-but-guarded reason=EMPTY_SPINS refresh={}/{} url={}", new Object[]{runId, ++serpRefreshes, 2, serp.url()});
                        this.gotoSerp(serp, runId, serpUrl);
                        pagerFailsInRow = 0;
                        emptySpins = 0;
                        continue;
                    }
                    this.add(results, runId, target, new ApplyResult(serp.url(), "", null, TIER_EXHAUSTED, "EMPTY_SPINS"));
                    this.logTierSwitch(runId, tierIdx, safeTiers.size(), tier, serp.url(), "EMPTY_SPINS", tierSent, goodCards, badNoHref, pagesAdvanced, tierStartedAt);
                    stopTier = true;
                    break;
                }
                emptySpins = 0;
                pageTopVacancyId = null;
                for (int i = 0; i < n && sent < target; ++i) {
                    Locator card = cards.nth(i);
                    String href = this.extractHref(serp, card);
                    String title = this.extractTitle(card);
                    Long vacancyId = this.extractVacancyId(href);
                    if (i == 0 && vacancyId != null) {
                        pageTopVacancyId = vacancyId;
                    }
                    if (!ignoreCheckpoint && stopAtVacancyId != null && vacancyId != null && vacancyId.equals(stopAtVacancyId)) {
                        boolean topDiffersFromStopAt;
                        boolean earlyIdx = pagesAdvanced == 0 && i <= 3 && tierSent == 0;
                        boolean bl = topDiffersFromStopAt = pageTopVacancyId != null && !pageTopVacancyId.equals(stopAtVacancyId);
                        if (earlyIdx && topDiffersFromStopAt) {
                            log.warn("[{}][TIER_GUARD] early checkpoint hit -> skip card idx={} stopAt={} pageTop={} hits={}/{} url={}", new Object[]{runId, i, stopAtVacancyId, pageTopVacancyId, ++earlyCheckpointHits, 3, serp.url()});
                            if (earlyCheckpointHits < 3) continue;
                            ignoreCheckpoint = true;
                            log.warn("[{}][TIER_GUARD] ignore checkpoint for this tier (pinned/promoted suspected) stopAt={} url={}", new Object[]{runId, stopAtVacancyId, serp.url()});
                            continue;
                        }
                        tierEndedByCheckpoint = true;
                        checkpointHitIdx = i;
                        this.add(results, runId, target, new ApplyResult(serp.url(), "", vacancyId, TIER_EXHAUSTED, "CHECKPOINT_REACHED stopAt=" + stopAtVacancyId));
                        this.logTierSwitch(runId, tierIdx, safeTiers.size(), tier, serp.url(), "CHECKPOINT_REACHED stopAt=" + stopAtVacancyId, tierSent, goodCards, badNoHref, pagesAdvanced, tierStartedAt);
                        stopTier = true;
                        break;
                    }
                    if (!this.dedupe(seenIds, seenFallback, vacancyId, href, i, title)) continue;
                    if (href == null || href.isBlank()) {
                        this.add(results, runId, target, new ApplyResult("", title, vacancyId, SKIP_NO_HREF, ""));
                        if (++badNoHref > 5) continue;
                        this.debugNoHref(runId, tierIdx, i, card);
                        continue;
                    }
                    ++goodCards;
                    VacancyApplier.Submit sub = this.vacancyApplier.apply(v, serp, runId, href, vacancyId, title, coverLetter, candidateContext);
                    if (newTopVacancyId == null && vacancyId != null) {
                        newTopVacancyId = vacancyId;
                    }
                    String applyStatus = this.toApplyStatus(sub);
                    String details = this.toApplyDetails(sub);
                    ApplyResult r = new ApplyResult(href, title, vacancyId, applyStatus, details);
                    this.add(results, runId, target, r);
                    if (this.isRealSent(applyStatus)) {
                        ++sent;
                        ++tierSent;
                    }
                    if (!sub.shouldStopRun()) continue;
                    ArrayList<ApplyResult> arrayList = results;
                    return arrayList;
                }
                if (sent >= target || stopTier) break;
                serp.mouse().wheel(0.0, 1400.0);
                serp.waitForTimeout(120.0);
                if (!this.isNearBottom(serp)) continue;
                paged = this.goNextSerpPage(serp, runId);
                if (!paged) {
                    if (++pagerFailsInRow < 4) continue;
                    if (!this.allowSwitchTier(tierStartedAt, goodCards, pagesAdvanced) && serpRefreshes < 2) {
                        log.warn("[{}][TIER_GUARD] would-switch-but-guarded reason=PAGER_FAILS refresh={}/{} url={}", new Object[]{runId, ++serpRefreshes, 2, serp.url()});
                        this.gotoSerp(serp, runId, serpUrl);
                        pagerFailsInRow = 0;
                        emptySpins = 0;
                        continue;
                    }
                    this.add(results, runId, target, new ApplyResult(serp.url(), "", null, TIER_EXHAUSTED, "PAGER_FAILS"));
                    this.logTierSwitch(runId, tierIdx, safeTiers.size(), tier, serp.url(), "PAGER_FAILS", tierSent, goodCards, badNoHref, pagesAdvanced, tierStartedAt);
                    break;
                }
                ++pagesAdvanced;
                pagerFailsInRow = 0;
            }
            if (newTopVacancyId == null) continue;
            if (tierSent <= 0) {
                log.warn("[{}][CHECKPOINT] skip save (tierSent=0) tierKey={} candidateTop={} stopAt={} endedByCheckpoint={} hitIdx={}", new Object[]{runId, tierKey, newTopVacancyId, stopAtVacancyId, tierEndedByCheckpoint, checkpointHitIdx});
                continue;
            }
            this.saveCheckpointTopId(tierKey, newTopVacancyId);
            log.info("[{}][CHECKPOINT] saved tierKey={} topVacancyId={}", new Object[]{runId, tierKey, newTopVacancyId});
        }
        if (sent >= target) {
            this.add(results, runId, target, new ApplyResult(serp.url(), "", null, TARGET_REACHED, ""));
        } else {
            this.add(results, runId, target, new ApplyResult(serp.url(), "", null, SERP_ENDED, ""));
        }
        log.info("[{}][APPLY] done sent={} results={}", new Object[]{runId, sent, results.size()});
        ArrayList<ApplyResult> arrayList = results;
        return arrayList;
        finally {
            try {
                v.close();
            }
            catch (Exception exception) {}
        }
    }

    public List<ApplyResult> applyFromSerp(Page serp, String queryText, int targetApplies, String coverLetter, Map<String, String> candidateContext) {
        String q = queryText == null || queryText.isBlank() ? "java" : queryText.trim();
        return this.applyFromSerp(serp, this.defaultTierLadder(q), targetApplies, coverLetter, candidateContext);
    }

    private List<SearchTier> defaultTierLadder(String text) {
        return List.of(new SearchTier(text, "96", "remote", List.of("name")), new SearchTier(text, "96", "remote", List.of("name", "company_name")), new SearchTier(text, "96", null, List.of("name", "company_name")), new SearchTier(text, null, null, List.of("name", "company_name", "description")));
    }

    private boolean allowSwitchTier(long tierStartedAt, int goodCards, int pagesAdvanced) {
        long elapsed = System.currentTimeMillis() - tierStartedAt;
        return elapsed >= 8000L || goodCards >= 10 || pagesAdvanced >= 1;
    }

    private boolean isRealSent(String status) {
        if (status == null) {
            return false;
        }
        return SENT.equals(status) || SENT_BY_LLM.equals(status) || APPLIED.equals(status);
    }

    private String toApplyStatus(VacancyApplier.Submit sub) {
        if (sub == null || sub.status() == null) {
            return FAILED;
        }
        return sub.status().name();
    }

    private String toApplyDetails(VacancyApplier.Submit sub) {
        if (sub == null) {
            return "";
        }
        return "ms=" + sub.ms() + " | stage=" + String.valueOf(sub.stage()) + " | branch=" + String.valueOf((Object)sub.branch()) + " | " + String.valueOf(sub.debug());
    }

    private void logTierSwitch(String runId, int fromIdx, int total, SearchTier fromTier, String fromUrl, String reason, int tierSent, int goodCards, int badNoHref, int pagesAdvanced, long tierStartedAt) {
        long elapsed = System.currentTimeMillis() - tierStartedAt;
        int toIdx = Math.min(fromIdx + 2, total);
        log.info("[{}][TIER_SWITCH] from={}/{} -> to={}/{} reason={} elapsedMs={} tierSent={} goodCards={} badNoHref={} pagesAdvanced={} text='{}' role={} schedule={} fields={} url={}", new Object[]{runId, fromIdx + 1, total, toIdx, total, reason, elapsed, tierSent, goodCards, badNoHref, pagesAdvanced, String.valueOf(fromTier.text()), fromTier.professionalRole(), fromTier.schedule(), fromTier.searchFields(), fromUrl});
    }

    private void add(List<ApplyResult> results, String runId, int target, ApplyResult r) {
        results.add(r);
        int trySeq = results.size();
        this.logTry(runId, trySeq, target, r);
    }

    private void logTry(String runId, int trySeq, int target, ApplyResult r) {
        log.info("[{}][TRY] {}/{} status={} vacancyId={} title='{}' url={} details={}", new Object[]{runId, trySeq, target, r.status(), r.vacancyId(), r.title(), r.url(), r.details()});
    }

    private void debugNoHref(String runId, int tierIdx, int i, Locator card) {
        try {
            String html = String.valueOf(card.evaluate("el => el.outerHTML"));
            log.warn("[{}][NO_HREF_DEBUG] tier={} idx={} html={}", new Object[]{runId, tierIdx + 1, i, html});
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private int dismissOverlays(Page page) {
        int closed = 0;
        for (String sel : OVERLAY_CLOSE_SELECTORS) {
            try {
                Locator l = page.locator(sel).first();
                if (!l.isVisible()) continue;
                l.click(new Locator.ClickOptions().setTimeout(900.0));
                ++closed;
                page.waitForTimeout(30.0);
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
        return closed;
    }

    private int safeCount(Locator l) {
        try {
            return l.count();
        }
        catch (Exception e) {
            return 0;
        }
    }

    private boolean gotoSerp(Page page, String runId, String serpUrl) {
        try {
            for (int tries = 1; tries <= 3; ++tries) {
                page.navigate(serpUrl, new Page.NavigateOptions().setWaitUntil(WaitUntilState.DOMCONTENTLOADED).setTimeout(60000.0));
                this.dismissOverlays(page);
                try {
                    page.waitForSelector(CARD_SEL, new Page.WaitForSelectorOptions().setState(WaitForSelectorState.ATTACHED).setTimeout(15000.0));
                }
                catch (Exception exception) {
                    // empty catch block
                }
                int n = this.safeCount(page.locator(CARD_SEL));
                log.info("[{}][SERP] try={} url={} cards={}", new Object[]{runId, tries, page.url(), n});
                if (n > 0 && this.isSerp(page.url())) {
                    return true;
                }
                page.waitForTimeout(200.0);
            }
        }
        catch (Exception e) {
            log.warn("[{}][SERP] nav exception err={}", (Object)runId, (Object)String.valueOf(e));
        }
        log.warn("[{}][SERP] nav fail url={}", (Object)runId, (Object)page.url());
        return false;
    }

    private boolean goNextSerpPage(Page page, String runId) {
        try {
            this.dismissOverlays(page);
            this.neutralizeSerpInterceptors(page);
            Locator next = this.ui.visible(page.locator(NEXT_PAGE_SEL), 900);
            if (next == null) {
                return false;
            }
            String beforeUrl = page.url();
            String nextHref = this.attr(next, "href");
            boolean clicked = false;
            try {
                clicked = this.ui.stableClick(next, () -> !Objects.equals(beforeUrl, page.url()), 1800);
            }
            catch (Exception exception) {
                // empty catch block
            }
            if (!clicked && !this.blank(nextHref)) {
                String absoluteNext = this.absolutize(page.url(), nextHref);
                page.navigate(absoluteNext, new Page.NavigateOptions().setWaitUntil(WaitUntilState.DOMCONTENTLOADED).setTimeout(60000.0));
            } else {
                page.waitForTimeout(220.0);
            }
            try {
                page.waitForSelector(CARD_SEL, new Page.WaitForSelectorOptions().setState(WaitForSelectorState.ATTACHED).setTimeout(15000.0));
            }
            catch (Exception absoluteNext) {
                // empty catch block
            }
            int cards = this.safeCount(page.locator(CARD_SEL));
            boolean ok = this.isSerp(page.url()) && cards > 0;
            log.info("[{}][PAGER] ok={} url={} cards={}", new Object[]{runId, ok, page.url(), cards});
            if (ok) {
                try {
                    page.evaluate("() => window.scrollTo(0, 0)");
                }
                catch (Exception exception) {
                    // empty catch block
                }
            }
            return ok;
        }
        catch (Exception e) {
            log.warn("[{}][PAGER] exception err={}", (Object)runId, (Object)String.valueOf(e));
            return false;
        }
    }

    private void neutralizeSerpInterceptors(Page page) {
        try {
            page.evaluate("() => {\n  const nodes = document.querySelectorAll(\"[data-qa='chatik-root'], .chatik-integration, .chatik-integration-iframe, iframe[src*='chatik.hh.ru']\");\n  nodes.forEach((el) => {\n    try {\n      el.style.setProperty('pointer-events', 'none', 'important');\n      el.style.setProperty('visibility', 'hidden', 'important');\n      el.style.setProperty('opacity', '0', 'important');\n    } catch (e) {}\n  });\n}");
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private boolean isSerp(String url) {
        return url != null && url.contains("/search/vacancy");
    }

    private boolean isNearBottom(Page page) {
        try {
            Boolean b;
            Object v = page.evaluate("() => (window.scrollY + window.innerHeight) >= (document.documentElement.scrollHeight - 260)");
            return v instanceof Boolean && (b = (Boolean)v) != false;
        }
        catch (Exception e) {
            return false;
        }
    }

    private String buildSerpUrlSameHost(Page page, SearchTier tier) {
        URI cur = URI.create(page.url());
        String origin = cur.getScheme() + "://" + cur.getHost();
        String text = tier.text() == null || tier.text().isBlank() ? "java" : tier.text().trim();
        String encText = URLEncoder.encode(text, StandardCharsets.UTF_8);
        StringBuilder sb = new StringBuilder(origin).append("/search/vacancy").append("?text=").append(encText);
        sb.append("&order_by=relevance");
        if (tier.schedule() != null && !tier.schedule().isBlank()) {
            sb.append("&schedule=").append(URLEncoder.encode(tier.schedule(), StandardCharsets.UTF_8));
        }
        if (tier.professionalRole() != null && !tier.professionalRole().isBlank()) {
            sb.append("&professional_role=").append(URLEncoder.encode(tier.professionalRole(), StandardCharsets.UTF_8));
        }
        List<Object> fields = tier.searchFields() == null ? List.of() : tier.searchFields();
        for (String string : fields) {
            if (string == null || string.isBlank()) continue;
            sb.append("&search_field=").append(URLEncoder.encode(string, StandardCharsets.UTF_8));
        }
        sb.append("&enable_snippets=false");
        return sb.toString();
    }

    private Long extractVacancyId(String url) {
        if (url == null) {
            return null;
        }
        Matcher m1 = VACANCY_ID_1.matcher(url);
        if (m1.find()) {
            return Long.parseLong(m1.group(1));
        }
        Matcher m2 = VACANCY_ID_2.matcher(url);
        if (m2.find()) {
            return Long.parseLong(m2.group(1));
        }
        return null;
    }

    private boolean dedupe(Set<Long> seenIds, Set<String> seenFallback, Long vacancyId, String href, int idx, String title) {
        if (vacancyId != null) {
            return seenIds.add(vacancyId);
        }
        Object key = href != null && !href.isBlank() ? href : "idx:" + idx + "|t:" + title;
        return seenFallback.add((String)key);
    }

    private String extractHref(Page serp, Locator card) {
        String href = this.attr(card.locator(CARD_TITLE_A_SEL).first(), "href");
        if (this.blank(href)) {
            href = this.attr(card.locator(CARD_TITLE_A_SEL).first(), "data-href");
        }
        if (this.blank(href)) {
            href = this.attr(card.locator("a").first(), "href");
        }
        if (this.blank(href)) {
            href = this.attr(card.locator("a").first(), "data-href");
        }
        if (this.blank(href)) {
            return null;
        }
        if (href.startsWith("/")) {
            URI cur = URI.create(serp.url());
            String origin = cur.getScheme() + "://" + cur.getHost();
            return origin + href;
        }
        return href;
    }

    private String extractTitle(Locator card) {
        String t = this.text(card.locator(CARD_TITLE_SEL).first());
        if (t.isBlank()) {
            t = this.text(card.locator(CARD_TITLE_A_SEL).first());
        }
        if (t.isBlank()) {
            t = this.text(card.locator("a").first());
        }
        return t;
    }

    private String attr(Locator l, String name) {
        try {
            return l.getAttribute(name);
        }
        catch (Exception e) {
            return null;
        }
    }

    private String text(Locator l) {
        try {
            String s = l.innerText();
            return s == null ? "" : s.replace("\u00a0", " ").trim();
        }
        catch (Exception e) {
            return "";
        }
    }

    private boolean blank(String s) {
        return s == null || s.isBlank();
    }

    private String absolutize(String currentUrl, String href) {
        try {
            if (href == null || href.isBlank()) {
                return href;
            }
            return URI.create(currentUrl).resolve(href).toString();
        }
        catch (Exception e) {
            return href;
        }
    }

    @Generated
    public HhApplyService(VacancyApplier vacancyApplier, PlaywrightSupport ui) {
        this.vacancyApplier = vacancyApplier;
        this.ui = ui;
    }

    public record SearchTier(String text, String professionalRole, String schedule, List<String> searchFields) {
    }

    public record ApplyResult(String url, String title, Long vacancyId, String status, String details) {
    }
}

