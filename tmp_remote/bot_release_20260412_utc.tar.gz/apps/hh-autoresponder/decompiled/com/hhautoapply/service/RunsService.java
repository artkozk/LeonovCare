/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.microsoft.playwright.Browser
 *  com.microsoft.playwright.Browser$NewContextOptions
 *  com.microsoft.playwright.BrowserContext
 *  com.microsoft.playwright.BrowserType$LaunchOptions
 *  com.microsoft.playwright.Page
 *  com.microsoft.playwright.Playwright
 *  lombok.Generated
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 *  org.springframework.stereotype.Service
 */
package com.hhautoapply.service;

import com.hhautoapply.config.HhAccountsProperties;
import com.hhautoapply.model.RunState;
import com.hhautoapply.service.HhApplyService;
import com.hhautoapply.service.HhAuthService;
import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;
import java.time.Instant;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executor;
import lombok.Generated;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class RunsService {
    @Generated
    private static final Logger log = LoggerFactory.getLogger(RunsService.class);
    private final HhAccountsProperties props;
    private final HhAuthService authService;
    private final HhApplyService applyService;
    private final Executor runsExecutor;
    private final Map<String, RunState> runs = new ConcurrentHashMap<String, RunState>();

    public RunState startAll(String queryText, Integer perAccountLimit) {
        String runId = UUID.randomUUID().toString().substring(0, 8);
        RunState st = new RunState();
        st.setRunId(runId);
        st.setStartedAt(Instant.now());
        st.setStatus("RUNNING");
        st.setQueryText(queryText == null || queryText.isBlank() ? "java" : queryText.trim());
        st.setPerAccountLimit(perAccountLimit);
        for (HhAccountsProperties.Account a : this.props.getAccounts()) {
            RunState.AccountRun ar = new RunState.AccountRun();
            ar.setName(a.getName());
            ar.setLogin(a.getLogin());
            ar.setLanguage(a.getLanguage());
            st.getAccounts().add(ar);
        }
        this.runs.put(runId, st);
        this.runsExecutor.execute(() -> this.doRun(st));
        return st;
    }

    public RunState get(String runId) {
        return this.runs.get(runId);
    }

    public List<RunState> list() {
        return this.runs.values().stream().sorted(Comparator.comparing(RunState::getStartedAt).reversed()).toList();
    }

    private void doRun(RunState st) {
        for (int idx = 0; idx < this.props.getAccounts().size(); ++idx) {
            HhAccountsProperties.Account acc = this.props.getAccounts().get(idx);
            RunState.AccountRun ar = st.getAccounts().get(idx);
            int limit = st.getPerAccountLimit() != null ? Math.min(st.getPerAccountLimit(), 200) : 200;
            String q = st.getQueryText();
            try (Playwright pw = Playwright.create();){
                Browser browser = pw.chromium().launch(new BrowserType.LaunchOptions().setHeadless(true).setSlowMo(150.0));
                BrowserContext ctx = browser.newContext(new Browser.NewContextOptions().setLocale("ru-RU").setViewportSize(1280, 720));
                Page page = ctx.newPage();
                page.onRequestFailed(r -> log.debug("[PW][{}] reqFailed {} {}", new Object[]{st.getRunId(), r.method(), r.url()}));
                page.onResponse(r -> {
                    if (r.status() >= 400) {
                        log.debug("[PW][{}] resp {} {}", new Object[]{st.getRunId(), r.status(), r.url()});
                    }
                });
                HhAuthService.AuthResult auth = this.authService.loginOnPage(page, acc.getLogin(), acc.getPassword());
                ar.setLastUrl(page.url());
                if (!auth.ok() || auth.otpRequired()) {
                    ar.setLastError("AUTH_FAILED: " + auth.details());
                    this.safeClose(ctx, browser);
                    continue;
                }
                ar.setLastUrl(page.url());
                this.safeClose(ctx, browser);
                continue;
            }
            catch (Exception e) {
                ar.setLastError(e.toString());
                log.warn("[{}] account '{}' failed: {}", new Object[]{st.getRunId(), acc.getName(), e.toString()});
            }
        }
        st.setFinishedAt(Instant.now());
        st.setStatus("FINISHED");
    }

    private void safeClose(BrowserContext ctx, Browser browser) {
        try {
            if (ctx != null) {
                ctx.close();
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        try {
            if (browser != null) {
                browser.close();
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    @Generated
    public RunsService(HhAccountsProperties props, HhAuthService authService, HhApplyService applyService, Executor runsExecutor) {
        this.props = props;
        this.authService = authService;
        this.applyService = applyService;
        this.runsExecutor = runsExecutor;
    }
}

