/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.swagger.v3.oas.annotations.Operation
 *  io.swagger.v3.oas.annotations.security.SecurityRequirement
 *  io.swagger.v3.oas.annotations.tags.Tag
 *  lombok.Generated
 *  org.springframework.web.bind.annotation.DeleteMapping
 *  org.springframework.web.bind.annotation.GetMapping
 *  org.springframework.web.bind.annotation.PathVariable
 *  org.springframework.web.bind.annotation.PostMapping
 *  org.springframework.web.bind.annotation.RequestBody
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.RestController
 */
package com.hhautoapply.api;

import com.hhautoapply.api.RunAccountRequest;
import com.hhautoapply.model.AccountResponse;
import com.hhautoapply.model.AccountStatsResponse;
import com.hhautoapply.model.CreateAccountRequest;
import com.hhautoapply.service.AccountManagementService;
import com.hhautoapply.service.AccountRunService;
import com.hhautoapply.service.RunAccountResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.Generated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value={"/api/internal/accounts"})
@Tag(name="Internal Accounts", description="Internal API for creating, deleting, inspecting and running DB-backed accounts.")
@SecurityRequirement(name="internalToken")
public class InternalAccountController {
    private final AccountManagementService service;
    private final AccountRunService accountRunService;

    @PostMapping
    @Operation(summary="Create a new DB-backed account")
    public AccountResponse create(@RequestBody CreateAccountRequest req) {
        return this.service.create(req);
    }

    @DeleteMapping(value={"/{login}"})
    @Operation(summary="Delete an account by login")
    public void delete(@PathVariable String login) {
        this.service.delete(login);
    }

    @GetMapping(value={"/{login}/stats"})
    @Operation(summary="Get account statistics by login")
    public AccountStatsResponse stats(@PathVariable String login) {
        return this.service.stats(login);
    }

    @PostMapping(value={"/run"})
    @Operation(summary="Run one DB-backed account immediately")
    public RunAccountResponse run(@RequestBody RunAccountRequest req) {
        return this.accountRunService.run(req.login());
    }

    @Generated
    public InternalAccountController(AccountManagementService service, AccountRunService accountRunService) {
        this.service = service;
        this.accountRunService = accountRunService;
    }
}

