/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.swagger.v3.oas.annotations.Operation
 *  io.swagger.v3.oas.annotations.tags.Tag
 *  lombok.Generated
 *  org.springframework.web.bind.annotation.GetMapping
 *  org.springframework.web.bind.annotation.PathVariable
 *  org.springframework.web.bind.annotation.PostMapping
 *  org.springframework.web.bind.annotation.RequestBody
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.RestController
 */
package com.hhautoapply.api;

import com.hhautoapply.model.RunState;
import com.hhautoapply.service.RunsService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.util.List;
import lombok.Generated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value={"/api/runs"})
@Tag(name="Runs", description="Endpoints for starting and inspecting legacy YAML-based batch runs.")
public class RunsController {
    private final RunsService runsService;

    @PostMapping(value={"/start"})
    @Operation(summary="Start a legacy batch run for configured YAML accounts")
    public StartResp start(@RequestBody(required=false) StartReq req) {
        String q = req != null ? req.queryText() : null;
        Integer lim = req != null ? req.perAccountLimit() : null;
        RunState st = this.runsService.startAll(q, lim);
        return new StartResp(st.getRunId(), st.getStatus());
    }

    @GetMapping(value={"/{runId}"})
    @Operation(summary="Get one run status by runId")
    public RunState status(@PathVariable String runId) {
        return this.runsService.get(runId);
    }

    @GetMapping
    @Operation(summary="List all recorded runs")
    public List<RunState> list() {
        return this.runsService.list();
    }

    @Generated
    public RunsController(RunsService runsService) {
        this.runsService = runsService;
    }

    public record StartReq(String queryText, Integer perAccountLimit) {
    }

    public record StartResp(String runId, String status) {
    }
}

