/*
 * Decompiled with CFR 0.152.
 */
package com.hhautoapply.api;

record RunAccountRequest(String login) {
}

