/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.microsoft.playwright.Browser
 *  com.microsoft.playwright.Browser$NewContextOptions
 *  com.microsoft.playwright.BrowserContext
 *  com.microsoft.playwright.BrowserType$LaunchOptions
 *  com.microsoft.playwright.Page
 *  com.microsoft.playwright.Page$NavigateOptions
 *  com.microsoft.playwright.Playwright
 *  com.microsoft.playwright.options.WaitUntilState
 *  io.swagger.v3.oas.annotations.Operation
 *  io.swagger.v3.oas.annotations.tags.Tag
 *  lombok.Generated
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 *  org.springframework.web.bind.annotation.PostMapping
 *  org.springframework.web.bind.annotation.RequestBody
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.RestController
 */
package com.hhautoapply.api;

import com.hhautoapply.service.HhRejectionClicker;
import com.hhautoapply.service.HhSessionStateManager;
import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;
import com.microsoft.playwright.options.WaitUntilState;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.Generated;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value={"/api/chatik"})
@Tag(name="Chatik", description="Automation endpoints for chat and refusal handling.")
public class ChatikController {
    @Generated
    private static final Logger log = LoggerFactory.getLogger(ChatikController.class);
    private final HhSessionStateManager sessionStateManager;
    private final HhRejectionClicker rejectionClicker;

    @PostMapping(value={"/click-refusals"})
    @Operation(summary="Open chats and click refusals until there are no more")
    public ClickResp clickRefusals(@RequestBody ClickReq req) {
        ClickResp clickResp;
        block10: {
            if (req.login() == null || req.login().isBlank()) {
                return new ClickResp(false, "login required", 0);
            }
            HhSessionStateManager.EnsureStateResult st = this.sessionStateManager.ensureStateForAccount(req.login());
            if (!st.ok()) {
                return new ClickResp(false, st.details(), 0);
            }
            Browser browser = null;
            BrowserContext ctx = null;
            Playwright pw = Playwright.create();
            try {
                browser = pw.chromium().launch(new BrowserType.LaunchOptions().setHeadless(true).setSlowMo(150.0));
                ctx = browser.newContext(new Browser.NewContextOptions().setLocale("ru-RU").setViewportSize(1280, 720).setStorageStatePath(st.statePath()));
                Page page = ctx.newPage();
                page.navigate("https://hh.ru/applicant/resumes", new Page.NavigateOptions().setWaitUntil(WaitUntilState.DOMCONTENTLOADED).setTimeout(45000.0));
                HhRejectionClicker.Result r = this.rejectionClicker.openChatsAndClickUntilNoRefusals(page);
                this.safeClose(ctx, browser);
                clickResp = new ClickResp(r.ok(), r.details(), r.clicked());
                if (pw == null) break block10;
            }
            catch (Throwable throwable) {
                try {
                    if (pw != null) {
                        try {
                            pw.close();
                        }
                        catch (Throwable throwable2) {
                            throwable.addSuppressed(throwable2);
                        }
                    }
                    throw throwable;
                }
                catch (Exception e) {
                    this.safeClose(ctx, browser);
                    return new ClickResp(false, "ERR: " + ChatikController.safeShort(e.toString()), 0);
                }
            }
            pw.close();
        }
        return clickResp;
    }

    private void safeClose(BrowserContext ctx, Browser browser) {
        try {
            if (ctx != null) {
                ctx.close();
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        try {
            if (browser != null) {
                browser.close();
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private static String safeShort(String s) {
        if (s == null) {
            return "";
        }
        return (s = s.trim()).length() <= 220 ? s : s.substring(0, 220) + "...";
    }

    @Generated
    public ChatikController(HhSessionStateManager sessionStateManager, HhRejectionClicker rejectionClicker) {
        this.sessionStateManager = sessionStateManager;
        this.rejectionClicker = rejectionClicker;
    }

    public record ClickReq(String login) {
    }

    public record ClickResp(boolean ok, String details, int clicked) {
    }
}

