/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.microsoft.playwright.Browser
 *  com.microsoft.playwright.Browser$NewContextOptions
 *  com.microsoft.playwright.BrowserContext
 *  com.microsoft.playwright.BrowserContext$StorageStateOptions
 *  com.microsoft.playwright.BrowserType$LaunchOptions
 *  com.microsoft.playwright.Page
 *  com.microsoft.playwright.Page$NavigateOptions
 *  com.microsoft.playwright.Playwright
 *  com.microsoft.playwright.Response
 *  com.microsoft.playwright.options.WaitUntilState
 *  io.swagger.v3.oas.annotations.Operation
 *  io.swagger.v3.oas.annotations.tags.Tag
 *  lombok.Generated
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 *  org.springframework.web.bind.annotation.PostMapping
 *  org.springframework.web.bind.annotation.RequestBody
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.RestController
 */
package com.hhautoapply.api;

import com.hhautoapply.model.ApplyProfile;
import com.hhautoapply.service.ApplyProfileStore;
import com.hhautoapply.service.HhApplyService;
import com.hhautoapply.service.HhAuthService;
import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;
import com.microsoft.playwright.Response;
import com.microsoft.playwright.options.WaitUntilState;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.FileAttribute;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import lombok.Generated;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value={"/api/auth"})
@Tag(name="Auth Apply", description="Endpoints for single and batch apply runs based on profiles.yaml accounts.")
public class AuthController {
    @Generated
    private static final Logger log = LoggerFactory.getLogger(AuthController.class);
    private static final String HH_BASE = "https://hh.ru";
    private final HhAuthService hhAuthService;
    private final HhApplyService hhApplyService;
    private final ApplyProfileStore applyProfileStore;

    private ApplyResp safeRunApplyForLogin(String login) {
        try {
            return this.runApplyForLogin(login);
        }
        catch (Exception e) {
            log.error("[apply-login] login={} ERR {}", new Object[]{AuthController.safeShort(login), e.toString(), e});
            return new ApplyResp(false, false, login, null, "ERR: " + AuthController.safeShort(e.getMessage()), 0, List.of());
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private ApplyResp runApplyForLogin(String login) {
        if (login == null) return new ApplyResp(false, false, null, null, "login is required", 0, List.of());
        if (login.isBlank()) {
            return new ApplyResp(false, false, null, null, "login is required", 0, List.of());
        }
        ApplyProfile p = this.applyProfileStore.profile(login);
        if (p == null) {
            return new ApplyResp(false, false, login, null, "PROFILE_NOT_FOUND login=" + AuthController.safeShort(login), 0, List.of());
        }
        String password = p.password();
        if (password == null) return new ApplyResp(false, false, login, null, "PROFILE_PASSWORD_EMPTY login=" + AuthController.safeShort(login), 0, List.of());
        if (password.isBlank()) {
            return new ApplyResp(false, false, login, null, "PROFILE_PASSWORD_EMPTY login=" + AuthController.safeShort(login), 0, List.of());
        }
        String queryText = p.queryText() == null || p.queryText().isBlank() ? "java" : p.queryText().trim();
        int targetApplies = p.targetApplies() == null || p.targetApplies() < 1 ? 200 : p.targetApplies();
        String runId = UUID.randomUUID().toString().substring(0, 8);
        Browser browser = null;
        BrowserContext ctx = null;
        Path storage = this.storagePathFor(login);
        try (Playwright pw = Playwright.create();){
            String diag;
            browser = pw.chromium().launch(new BrowserType.LaunchOptions().setHeadless(true).setSlowMo(150.0));
            Browser.NewContextOptions ctxOpts = new Browser.NewContextOptions().setLocale("ru-RU").setIgnoreHTTPSErrors(true).setViewportSize(1280, 720);
            if (Files.exists(storage, new LinkOption[0])) {
                ctxOpts.setStorageStatePath(storage);
                log.info("[{}][AUTH] reuse storageState={} login={}", new Object[]{runId, storage.toAbsolutePath(), AuthController.safeShort(login)});
            } else {
                log.info("[{}][AUTH] no storageState yet login={}", (Object)runId, (Object)AuthController.safeShort(login));
            }
            ctx = browser.newContext(ctxOpts);
            Page page = ctx.newPage();
            this.attachCleanNetworkLogging(page, runId);
            SessionProbe preProbe = this.probeSession(page);
            if (!preProbe.loggedIn) {
                HhAuthService.AuthResult auth = this.hhAuthService.loginOnPage(page, login, password);
                log.info("[{}][AUTH] login={} ok={} otp={} url={} details={}", new Object[]{runId, AuthController.safeShort(login), auth.ok(), auth.otpRequired(), AuthController.safeShort(auth.url()), AuthController.safeShort(auth.details())});
                if (!auth.ok() && !auth.otpRequired()) {
                    SessionProbe probe = this.probeSession(page);
                    log.info("[{}][AUTH_PROBE] login={} loggedIn={} url={} details={}", new Object[]{runId, AuthController.safeShort(login), probe.loggedIn, AuthController.safeShort(probe.url), AuthController.safeShort(probe.details)});
                    if (!probe.loggedIn) {
                        String diag2 = this.authDiagnostics(page);
                        this.safeClose(ctx, browser);
                        ApplyResp applyResp = new ApplyResp(false, false, login, AuthController.safeShort(page.url()), "AUTH_FAILED: " + AuthController.safeShort(auth.details()) + " | " + AuthController.safeShort(probe.details) + " | " + AuthController.safeShort(diag2), 0, List.of());
                        return applyResp;
                    }
                    log.warn("[{}][AUTH] service ok=false, but probe loggedIn=true. Continue. login={}", (Object)runId, (Object)AuthController.safeShort(login));
                }
                if (auth.otpRequired()) {
                    diag = this.authDiagnostics(page);
                    this.safeClose(ctx, browser);
                    ApplyResp diag2 = new ApplyResp(false, true, login, AuthController.safeShort(page.url()), "OTP_REQUIRED: " + AuthController.safeShort(auth.details()) + " | " + AuthController.safeShort(diag), 0, List.of());
                    return diag2;
                }
                try {
                    this.ensureDir(storage);
                    ctx.storageState(new BrowserContext.StorageStateOptions().setPath(storage));
                    log.info("[{}][AUTH] saved storageState={} login={}", new Object[]{runId, storage.toAbsolutePath(), AuthController.safeShort(login)});
                }
                catch (Exception e) {
                    log.warn("[{}][AUTH] failed to save storageState login={} err={}", new Object[]{runId, AuthController.safeShort(login), AuthController.safeShort(e.toString())});
                }
            }
            SessionProbe finalProbe = this.probeSession(page);
            if (!finalProbe.loggedIn) {
                diag = this.authDiagnostics(page);
                this.safeClose(ctx, browser);
                ApplyResp diag2 = new ApplyResp(false, false, login, AuthController.safeShort(page.url()), "AUTH_FAILED_AFTER_PROBE: " + AuthController.safeShort(finalProbe.details) + " | " + AuthController.safeShort(diag), 0, List.of());
                return diag2;
            }
            List<HhApplyService.ApplyResult> results = this.hhApplyService.applyFromSerp(page, queryText, targetApplies, p.coverLetter(), p.candidateContext());
            int sent = (int)results.stream().filter(r -> "SENT".equals(r.status()) || "SENT_BY_LLM".equals(r.status()) || "APPLIED".equals(r.status())).count();
            this.safeClose(ctx, browser);
            ApplyResp applyResp = new ApplyResp(true, false, login, AuthController.safeShort(page.url()), "OK", sent, results);
            return applyResp;
        }
        catch (Exception e) {
            this.safeClose(ctx, browser);
            log.error("[{}][apply-login] login={} ERR {}", new Object[]{runId, AuthController.safeShort(login), e.toString(), e});
            return new ApplyResp(false, false, login, null, "ERR: " + AuthController.safeShort(e.getMessage()), 0, List.of());
        }
    }

    @PostMapping(value={"/apply-batch"})
    @Operation(summary="Run apply flow for multiple profile logins")
    public ApplyBatchResp applyBatch(@RequestBody ApplyBatchReq req) {
        List<ApplyResp> results;
        List logins;
        List<Object> list = logins = req == null || req.logins() == null ? List.of() : req.logins();
        if (logins.isEmpty()) {
            return new ApplyBatchResp(false, 0, 0, List.of());
        }
        try (ExecutorService executor = Executors.newVirtualThreadPerTaskExecutor();){
            List<CompletableFuture> futures = logins.stream().map(login -> CompletableFuture.supplyAsync(() -> this.safeRunApplyForLogin((String)login), executor)).toList();
            results = futures.stream().map(CompletableFuture::join).toList();
        }
        int successAccounts = (int)results.stream().filter(ApplyResp::ok).count();
        return new ApplyBatchResp(successAccounts > 0, logins.size(), successAccounts, results);
    }

    @PostMapping(value={"/apply-debug"})
    @Operation(summary="Run apply flow for one profile login")
    public ApplyResp applyDebug(@RequestBody ApplyReq req) {
        String login = req == null ? null : req.login();
        return this.safeRunApplyForLogin(login);
    }

    private Path storagePathFor(String login) {
        String safe = (login == null ? "unknown" : login.trim().toLowerCase()).replaceAll("[^a-z0-9._@-]+", "_");
        return Paths.get("profiles", safe, "storageState.json");
    }

    private void ensureDir(Path p) {
        try {
            Files.createDirectories(p.getParent(), new FileAttribute[0]);
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private SessionProbe probeSession(Page page) {
        try {
            int st;
            String u;
            String resumesUrl = "https://hh.ru/applicant/resumes";
            Response resp = page.navigate(resumesUrl, new Page.NavigateOptions().setWaitUntil(WaitUntilState.DOMCONTENTLOADED).setTimeout(45000.0));
            String string = u = page.url() == null ? "" : page.url();
            if (u.contains("/account/login") || u.contains("/login")) {
                return new SessionProbe(false, u, "redirected_to_login");
            }
            int n = st = resp != null ? resp.status() : -1;
            if (st >= 400) {
                return new SessionProbe(false, u, "resumes httpStatus=" + st);
            }
            boolean loginForm = this.isVisible(page, "input[name='username'], input[type='password'], button:has-text('\u0412\u043e\u0439\u0442\u0438')");
            if (loginForm) {
                return new SessionProbe(false, u, "login form visible on resumes");
            }
            return new SessionProbe(true, u, "ok");
        }
        catch (Exception e) {
            return new SessionProbe(false, AuthController.safeShort(page.url()), "probe exception: " + AuthController.safeShort(e.toString()));
        }
    }

    private String authDiagnostics(Page page) {
        StringBuilder sb = new StringBuilder();
        try {
            sb.append("url=").append(AuthController.safeShort(page.url())).append("; ");
        }
        catch (Exception exception) {
            // empty catch block
        }
        try {
            sb.append("title=").append(AuthController.safeShort(page.title())).append("; ");
        }
        catch (Exception exception) {
            // empty catch block
        }
        sb.append("loginForm=").append(this.isVisible(page, "input[name='username'], input[type='password'], button:has-text('\u0412\u043e\u0439\u0442\u0438')")).append("; ");
        sb.append("otpInput=").append(this.isVisible(page, "input[name*='otp'], input[inputmode='numeric'], text=\u041a\u043e\u0434 \u0438\u0437")).append("; ");
        sb.append("captcha=").append(this.isVisible(page, "iframe[src*='captcha'], text=\u042f \u043d\u0435 \u0440\u043e\u0431\u043e\u0442, text=\u041f\u043e\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435, \u0447\u0442\u043e \u0432\u044b \u043d\u0435 \u0440\u043e\u0431\u043e\u0442")).append("; ");
        sb.append("emailNotConfirmed=").append(this.isVisible(page, "text=\u043d\u0435 \u043f\u043e\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043d")).append("; ");
        try {
            Object txt = page.evaluate("() => (document.body && (document.body.innerText||'').slice(0, 240)) || ''");
            sb.append("bodyHint=").append(AuthController.safeShort(String.valueOf(txt)));
        }
        catch (Exception exception) {
            // empty catch block
        }
        return sb.toString();
    }

    private boolean isVisible(Page page, String selector) {
        try {
            return page.locator(selector).first().isVisible();
        }
        catch (Exception e) {
            return false;
        }
    }

    private void attachCleanNetworkLogging(Page page, String runId) {
        page.onRequestFailed(r -> {
            boolean aborted;
            String url = r.url();
            if (url.contains("websocket.") || url.contains("/proxy-webapp/")) {
                return;
            }
            String method = r.method();
            String err = "";
            try {
                err = String.valueOf(r.failure());
            }
            catch (Exception exception) {
                // empty catch block
            }
            boolean bl = aborted = err != null && err.contains("net::ERR_ABORTED");
            if (aborted || this.isNoisyUrl(url)) {
                log.debug("[{}][PW] reqFailed {} {} err={}", new Object[]{runId, method, AuthController.safeShort(url), AuthController.safeShort(err)});
            } else {
                log.warn("[{}][PW] reqFailed {} {} err={}", new Object[]{runId, method, AuthController.safeShort(url), AuthController.safeShort(err)});
            }
        });
        page.onResponse(resp -> {
            int st = resp.status();
            if (st < 400) {
                return;
            }
            String url = resp.url();
            if (this.isNoisyUrl(url)) {
                log.debug("[{}][PW] resp {} {}", new Object[]{runId, st, AuthController.safeShort(url)});
                return;
            }
            log.warn("[{}][PW] resp {} {}", new Object[]{runId, st, AuthController.safeShort(url)});
        });
        page.onPageError(err -> log.warn("[{}][PW] pageError url={} err={}", new Object[]{runId, AuthController.safeShort(page.url()), AuthController.safeShort(String.valueOf(err))}));
        page.onConsoleMessage(msg -> log.debug("[{}][PW] console {}: {}", new Object[]{runId, msg.type(), AuthController.safeShort(msg.text())}));
    }

    private boolean isNoisyUrl(String url) {
        if (url == null) {
            return true;
        }
        String u = url.toLowerCase();
        if (u.startsWith("chrome-extension://")) {
            return true;
        }
        if (u.contains("127.0.0.1:") || u.contains("localhost:")) {
            return true;
        }
        if (u.contains("mc.yandex.ru") || u.contains("metrika")) {
            return true;
        }
        return u.contains("adfox") || u.contains("doubleclick") || u.contains("googlesyndication");
    }

    private void safeClose(BrowserContext ctx, Browser browser) {
        try {
            if (ctx != null) {
                ctx.close();
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        try {
            if (browser != null) {
                browser.close();
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private static String safeShort(String s) {
        if (s == null) {
            return "";
        }
        return (s = s.trim()).length() <= 180 ? s : s.substring(0, 180) + "...";
    }

    @Generated
    public AuthController(HhAuthService hhAuthService, HhApplyService hhApplyService, ApplyProfileStore applyProfileStore) {
        this.hhAuthService = hhAuthService;
        this.hhApplyService = hhApplyService;
        this.applyProfileStore = applyProfileStore;
    }

    public record ApplyResp(boolean ok, boolean otpRequired, String login, String url, String details, int sent, List<HhApplyService.ApplyResult> results) {
    }

    private static final class SessionProbe {
        final boolean loggedIn;
        final String url;
        final String details;

        private SessionProbe(boolean loggedIn, String url, String details) {
            this.loggedIn = loggedIn;
            this.url = url;
            this.details = details;
        }
    }

    public record ApplyBatchReq(List<String> logins) {
    }

    public record ApplyBatchResp(boolean ok, int totalAccounts, int successAccounts, List<ApplyResp> accounts) {
    }

    public record ApplyReq(String login) {
    }
}

