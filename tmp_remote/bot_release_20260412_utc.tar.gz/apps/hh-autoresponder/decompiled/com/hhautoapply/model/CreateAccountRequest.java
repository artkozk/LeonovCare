/*
 * Decompiled with CFR 0.152.
 */
package com.hhautoapply.model;

import java.util.Map;

public record CreateAccountRequest(String login, String password, String direction, String queryText, Integer targetApplies, String coverLetter, Map<String, String> candidateContext, Boolean active) {
}

