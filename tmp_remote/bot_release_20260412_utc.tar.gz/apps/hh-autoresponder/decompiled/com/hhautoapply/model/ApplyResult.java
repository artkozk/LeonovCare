/*
 * Decompiled with CFR 0.152.
 */
package com.hhautoapply.model;

public enum ApplyResult {
    APPLIED,
    SKIPPED,
    ERROR;

}

