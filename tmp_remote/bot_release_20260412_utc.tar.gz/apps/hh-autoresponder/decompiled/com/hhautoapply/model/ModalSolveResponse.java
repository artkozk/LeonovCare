/*
 * Decompiled with CFR 0.152.
 */
package com.hhautoapply.model;

import com.hhautoapply.model.Answer;
import java.util.List;

public record ModalSolveResponse(List<Answer> answers) {
}

