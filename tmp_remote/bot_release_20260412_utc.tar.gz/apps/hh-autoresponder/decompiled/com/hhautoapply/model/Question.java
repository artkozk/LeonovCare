/*
 * Decompiled with CFR 0.152.
 */
package com.hhautoapply.model;

import com.hhautoapply.model.QuestionType;
import java.util.List;

public record Question(String questionText, QuestionType type, List<String> options) {
}

