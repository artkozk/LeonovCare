/*
 * Decompiled with CFR 0.152.
 */
package com.hhautoapply.model;

public enum FlowBranch {
    OTHER_COUNTRY,
    COVER_LETTER_REQUIRED,
    LLM_REQUIRED;

}

