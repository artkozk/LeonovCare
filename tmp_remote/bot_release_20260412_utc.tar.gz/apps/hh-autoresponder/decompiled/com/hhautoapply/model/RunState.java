/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 */
package com.hhautoapply.model;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import lombok.Generated;

public class RunState {
    private String runId;
    private Instant startedAt;
    private Instant finishedAt;
    private String status;
    private String queryText;
    private Integer perAccountLimit;
    private List<AccountRun> accounts = new ArrayList<AccountRun>();

    @Generated
    public RunState() {
    }

    @Generated
    public String getRunId() {
        return this.runId;
    }

    @Generated
    public Instant getStartedAt() {
        return this.startedAt;
    }

    @Generated
    public Instant getFinishedAt() {
        return this.finishedAt;
    }

    @Generated
    public String getStatus() {
        return this.status;
    }

    @Generated
    public String getQueryText() {
        return this.queryText;
    }

    @Generated
    public Integer getPerAccountLimit() {
        return this.perAccountLimit;
    }

    @Generated
    public List<AccountRun> getAccounts() {
        return this.accounts;
    }

    @Generated
    public void setRunId(String runId) {
        this.runId = runId;
    }

    @Generated
    public void setStartedAt(Instant startedAt) {
        this.startedAt = startedAt;
    }

    @Generated
    public void setFinishedAt(Instant finishedAt) {
        this.finishedAt = finishedAt;
    }

    @Generated
    public void setStatus(String status) {
        this.status = status;
    }

    @Generated
    public void setQueryText(String queryText) {
        this.queryText = queryText;
    }

    @Generated
    public void setPerAccountLimit(Integer perAccountLimit) {
        this.perAccountLimit = perAccountLimit;
    }

    @Generated
    public void setAccounts(List<AccountRun> accounts) {
        this.accounts = accounts;
    }

    @Generated
    public boolean equals(Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof RunState)) {
            return false;
        }
        RunState other = (RunState)o;
        if (!other.canEqual(this)) {
            return false;
        }
        Integer this$perAccountLimit = this.getPerAccountLimit();
        Integer other$perAccountLimit = other.getPerAccountLimit();
        if (this$perAccountLimit == null ? other$perAccountLimit != null : !((Object)this$perAccountLimit).equals(other$perAccountLimit)) {
            return false;
        }
        String this$runId = this.getRunId();
        String other$runId = other.getRunId();
        if (this$runId == null ? other$runId != null : !this$runId.equals(other$runId)) {
            return false;
        }
        Instant this$startedAt = this.getStartedAt();
        Instant other$startedAt = other.getStartedAt();
        if (this$startedAt == null ? other$startedAt != null : !((Object)this$startedAt).equals(other$startedAt)) {
            return false;
        }
        Instant this$finishedAt = this.getFinishedAt();
        Instant other$finishedAt = other.getFinishedAt();
        if (this$finishedAt == null ? other$finishedAt != null : !((Object)this$finishedAt).equals(other$finishedAt)) {
            return false;
        }
        String this$status = this.getStatus();
        String other$status = other.getStatus();
        if (this$status == null ? other$status != null : !this$status.equals(other$status)) {
            return false;
        }
        String this$queryText = this.getQueryText();
        String other$queryText = other.getQueryText();
        if (this$queryText == null ? other$queryText != null : !this$queryText.equals(other$queryText)) {
            return false;
        }
        List<AccountRun> this$accounts = this.getAccounts();
        List<AccountRun> other$accounts = other.getAccounts();
        return !(this$accounts == null ? other$accounts != null : !((Object)this$accounts).equals(other$accounts));
    }

    @Generated
    protected boolean canEqual(Object other) {
        return other instanceof RunState;
    }

    @Generated
    public int hashCode() {
        int PRIME = 59;
        int result = 1;
        Integer $perAccountLimit = this.getPerAccountLimit();
        result = result * 59 + ($perAccountLimit == null ? 43 : ((Object)$perAccountLimit).hashCode());
        String $runId = this.getRunId();
        result = result * 59 + ($runId == null ? 43 : $runId.hashCode());
        Instant $startedAt = this.getStartedAt();
        result = result * 59 + ($startedAt == null ? 43 : ((Object)$startedAt).hashCode());
        Instant $finishedAt = this.getFinishedAt();
        result = result * 59 + ($finishedAt == null ? 43 : ((Object)$finishedAt).hashCode());
        String $status = this.getStatus();
        result = result * 59 + ($status == null ? 43 : $status.hashCode());
        String $queryText = this.getQueryText();
        result = result * 59 + ($queryText == null ? 43 : $queryText.hashCode());
        List<AccountRun> $accounts = this.getAccounts();
        result = result * 59 + ($accounts == null ? 43 : ((Object)$accounts).hashCode());
        return result;
    }

    @Generated
    public String toString() {
        return "RunState(runId=" + this.getRunId() + ", startedAt=" + String.valueOf(this.getStartedAt()) + ", finishedAt=" + String.valueOf(this.getFinishedAt()) + ", status=" + this.getStatus() + ", queryText=" + this.getQueryText() + ", perAccountLimit=" + this.getPerAccountLimit() + ", accounts=" + String.valueOf(this.getAccounts()) + ")";
    }

    public static class AccountRun {
        private String name;
        private String login;
        private String language;
        private int sent;
        private int totalResults;
        private String lastUrl;
        private String lastError;

        @Generated
        public AccountRun() {
        }

        @Generated
        public String getName() {
            return this.name;
        }

        @Generated
        public String getLogin() {
            return this.login;
        }

        @Generated
        public String getLanguage() {
            return this.language;
        }

        @Generated
        public int getSent() {
            return this.sent;
        }

        @Generated
        public int getTotalResults() {
            return this.totalResults;
        }

        @Generated
        public String getLastUrl() {
            return this.lastUrl;
        }

        @Generated
        public String getLastError() {
            return this.lastError;
        }

        @Generated
        public void setName(String name) {
            this.name = name;
        }

        @Generated
        public void setLogin(String login) {
            this.login = login;
        }

        @Generated
        public void setLanguage(String language) {
            this.language = language;
        }

        @Generated
        public void setSent(int sent) {
            this.sent = sent;
        }

        @Generated
        public void setTotalResults(int totalResults) {
            this.totalResults = totalResults;
        }

        @Generated
        public void setLastUrl(String lastUrl) {
            this.lastUrl = lastUrl;
        }

        @Generated
        public void setLastError(String lastError) {
            this.lastError = lastError;
        }

        @Generated
        public boolean equals(Object o) {
            if (o == this) {
                return true;
            }
            if (!(o instanceof AccountRun)) {
                return false;
            }
            AccountRun other = (AccountRun)o;
            if (!other.canEqual(this)) {
                return false;
            }
            if (this.getSent() != other.getSent()) {
                return false;
            }
            if (this.getTotalResults() != other.getTotalResults()) {
                return false;
            }
            String this$name = this.getName();
            String other$name = other.getName();
            if (this$name == null ? other$name != null : !this$name.equals(other$name)) {
                return false;
            }
            String this$login = this.getLogin();
            String other$login = other.getLogin();
            if (this$login == null ? other$login != null : !this$login.equals(other$login)) {
                return false;
            }
            String this$language = this.getLanguage();
            String other$language = other.getLanguage();
            if (this$language == null ? other$language != null : !this$language.equals(other$language)) {
                return false;
            }
            String this$lastUrl = this.getLastUrl();
            String other$lastUrl = other.getLastUrl();
            if (this$lastUrl == null ? other$lastUrl != null : !this$lastUrl.equals(other$lastUrl)) {
                return false;
            }
            String this$lastError = this.getLastError();
            String other$lastError = other.getLastError();
            return !(this$lastError == null ? other$lastError != null : !this$lastError.equals(other$lastError));
        }

        @Generated
        protected boolean canEqual(Object other) {
            return other instanceof AccountRun;
        }

        @Generated
        public int hashCode() {
            int PRIME = 59;
            int result = 1;
            result = result * 59 + this.getSent();
            result = result * 59 + this.getTotalResults();
            String $name = this.getName();
            result = result * 59 + ($name == null ? 43 : $name.hashCode());
            String $login = this.getLogin();
            result = result * 59 + ($login == null ? 43 : $login.hashCode());
            String $language = this.getLanguage();
            result = result * 59 + ($language == null ? 43 : $language.hashCode());
            String $lastUrl = this.getLastUrl();
            result = result * 59 + ($lastUrl == null ? 43 : $lastUrl.hashCode());
            String $lastError = this.getLastError();
            result = result * 59 + ($lastError == null ? 43 : $lastError.hashCode());
            return result;
        }

        @Generated
        public String toString() {
            return "RunState.AccountRun(name=" + this.getName() + ", login=" + this.getLogin() + ", language=" + this.getLanguage() + ", sent=" + this.getSent() + ", totalResults=" + this.getTotalResults() + ", lastUrl=" + this.getLastUrl() + ", lastError=" + this.getLastError() + ")";
        }
    }
}

