/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.fasterxml.jackson.core.type.TypeReference
 *  com.fasterxml.jackson.databind.ObjectMapper
 *  jakarta.persistence.AttributeConverter
 *  jakarta.persistence.Converter
 */
package com.hhautoapply.model;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;
import java.util.HashMap;
import java.util.Map;

@Converter
public class MapJsonConverter
implements AttributeConverter<Map<String, String>, String> {
    private static final ObjectMapper MAPPER = new ObjectMapper();

    public String convertToDatabaseColumn(Map<String, String> attribute) {
        try {
            return attribute == null ? "{}" : MAPPER.writeValueAsString(attribute);
        }
        catch (Exception e) {
            throw new IllegalStateException("Cannot serialize candidateContext", e);
        }
    }

    public Map<String, String> convertToEntityAttribute(String dbData) {
        try {
            return dbData == null || dbData.isBlank() ? new HashMap<String, String>() : (Map)MAPPER.readValue(dbData, (TypeReference)new TypeReference<Map<String, String>>(this){});
        }
        catch (Exception e) {
            throw new IllegalStateException("Cannot deserialize candidateContext", e);
        }
    }
}

