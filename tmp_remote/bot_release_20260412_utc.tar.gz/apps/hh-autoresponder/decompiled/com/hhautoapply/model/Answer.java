/*
 * Decompiled with CFR 0.152.
 */
package com.hhautoapply.model;

public record Answer(String action, String clickText, String fill, String reason) {
}

