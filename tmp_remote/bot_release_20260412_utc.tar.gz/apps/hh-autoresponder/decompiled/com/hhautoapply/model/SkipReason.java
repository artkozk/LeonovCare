/*
 * Decompiled with CFR 0.152.
 */
package com.hhautoapply.model;

public enum SkipReason {
    NO_APPLY_BUTTON,
    AUTH_REQUIRED,
    ALREADY_APPLIED_UI,
    SUBMIT_FAILED,
    NO_UI_PROOF,
    ALREADY_PROCESSED,
    ERROR_ON_PAGE;

}

