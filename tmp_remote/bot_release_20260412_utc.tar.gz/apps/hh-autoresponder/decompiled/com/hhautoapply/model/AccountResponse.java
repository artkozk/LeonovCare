/*
 * Decompiled with CFR 0.152.
 */
package com.hhautoapply.model;

public record AccountResponse(Long id, String login, String direction, String queryText, Integer targetApplies, Boolean active, String lastRunStatus, Integer lastSentCount) {
}

