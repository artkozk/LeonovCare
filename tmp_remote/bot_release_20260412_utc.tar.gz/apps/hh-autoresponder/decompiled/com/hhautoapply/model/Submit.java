/*
 * Decompiled with CFR 0.152.
 */
package com.hhautoapply.model;

import com.hhautoapply.model.ApplyResultStatus;

public record Submit(ApplyResultStatus status, String flowStage, String failureCode, String details, long ms) {
    public boolean ok() {
        return this.status == ApplyResultStatus.APPLIED;
    }

    public boolean alreadyApplied() {
        return this.status == ApplyResultStatus.ALREADY_APPLIED;
    }

    public boolean failed() {
        return this.status == ApplyResultStatus.FAILED;
    }
}

