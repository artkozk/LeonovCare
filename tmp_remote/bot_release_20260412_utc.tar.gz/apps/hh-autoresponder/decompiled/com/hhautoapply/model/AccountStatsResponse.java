/*
 * Decompiled with CFR 0.152.
 */
package com.hhautoapply.model;

import java.time.LocalDateTime;

public record AccountStatsResponse(String login, String direction, Boolean active, LocalDateTime lastRunAt, String lastRunStatus, Integer lastSentCount) {
}

