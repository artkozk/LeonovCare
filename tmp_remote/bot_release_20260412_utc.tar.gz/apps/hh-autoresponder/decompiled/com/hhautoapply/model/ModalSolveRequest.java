/*
 * Decompiled with CFR 0.152.
 */
package com.hhautoapply.model;

import com.hhautoapply.model.Question;
import java.util.List;
import java.util.Map;

public record ModalSolveRequest(String prompt, List<Question> questions, Map<String, String> candidateContext) {
}

