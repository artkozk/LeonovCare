/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  jakarta.persistence.Column
 *  jakarta.persistence.Convert
 *  jakarta.persistence.Entity
 *  jakarta.persistence.GeneratedValue
 *  jakarta.persistence.GenerationType
 *  jakarta.persistence.Id
 *  jakarta.persistence.Lob
 *  jakarta.persistence.Table
 *  lombok.Generated
 *  org.hibernate.annotations.CreationTimestamp
 *  org.hibernate.annotations.UpdateTimestamp
 */
package com.hhautoapply.model;

import com.hhautoapply.model.MapJsonConverter;
import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import jakarta.persistence.Table;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import lombok.Generated;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

@Entity
@Table(name="hh_account")
public class HhAccountEntity {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long id;
    @Column(name="login", nullable=false, unique=true, length=120)
    private String login;
    @Column(name="password", nullable=false, length=255)
    private String password;
    @Column(name="direction", length=64)
    private String direction;
    @Column(name="query_text", length=255)
    private String queryText;
    @Column(name="target_applies")
    private Integer targetApplies = 200;
    @Lob
    @Column(name="cover_letter")
    private String coverLetter;
    @Convert(converter=MapJsonConverter.class)
    @Column(name="candidate_context_json", columnDefinition="TEXT")
    private Map<String, String> candidateContext = new HashMap<String, String>();
    @Column(name="active", nullable=false)
    private Boolean active = true;
    @Column(name="last_run_at")
    private LocalDateTime lastRunAt;
    @Column(name="last_run_status", length=64)
    private String lastRunStatus;
    @Column(name="last_sent_count")
    private Integer lastSentCount = 0;
    @CreationTimestamp
    @Column(name="created_at", nullable=false, updatable=false)
    private LocalDateTime createdAt;
    @UpdateTimestamp
    @Column(name="updated_at", nullable=false)
    private LocalDateTime updatedAt;

    @Generated
    public Long getId() {
        return this.id;
    }

    @Generated
    public String getLogin() {
        return this.login;
    }

    @Generated
    public String getPassword() {
        return this.password;
    }

    @Generated
    public String getDirection() {
        return this.direction;
    }

    @Generated
    public String getQueryText() {
        return this.queryText;
    }

    @Generated
    public Integer getTargetApplies() {
        return this.targetApplies;
    }

    @Generated
    public String getCoverLetter() {
        return this.coverLetter;
    }

    @Generated
    public Map<String, String> getCandidateContext() {
        return this.candidateContext;
    }

    @Generated
    public Boolean getActive() {
        return this.active;
    }

    @Generated
    public LocalDateTime getLastRunAt() {
        return this.lastRunAt;
    }

    @Generated
    public String getLastRunStatus() {
        return this.lastRunStatus;
    }

    @Generated
    public Integer getLastSentCount() {
        return this.lastSentCount;
    }

    @Generated
    public LocalDateTime getCreatedAt() {
        return this.createdAt;
    }

    @Generated
    public LocalDateTime getUpdatedAt() {
        return this.updatedAt;
    }

    @Generated
    public void setId(Long id) {
        this.id = id;
    }

    @Generated
    public void setLogin(String login) {
        this.login = login;
    }

    @Generated
    public void setPassword(String password) {
        this.password = password;
    }

    @Generated
    public void setDirection(String direction) {
        this.direction = direction;
    }

    @Generated
    public void setQueryText(String queryText) {
        this.queryText = queryText;
    }

    @Generated
    public void setTargetApplies(Integer targetApplies) {
        this.targetApplies = targetApplies;
    }

    @Generated
    public void setCoverLetter(String coverLetter) {
        this.coverLetter = coverLetter;
    }

    @Generated
    public void setCandidateContext(Map<String, String> candidateContext) {
        this.candidateContext = candidateContext;
    }

    @Generated
    public void setActive(Boolean active) {
        this.active = active;
    }

    @Generated
    public void setLastRunAt(LocalDateTime lastRunAt) {
        this.lastRunAt = lastRunAt;
    }

    @Generated
    public void setLastRunStatus(String lastRunStatus) {
        this.lastRunStatus = lastRunStatus;
    }

    @Generated
    public void setLastSentCount(Integer lastSentCount) {
        this.lastSentCount = lastSentCount;
    }

    @Generated
    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    @Generated
    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }
}

