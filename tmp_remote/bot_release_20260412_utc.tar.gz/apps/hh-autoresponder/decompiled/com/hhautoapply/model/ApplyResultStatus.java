/*
 * Decompiled with CFR 0.152.
 */
package com.hhautoapply.model;

public enum ApplyResultStatus {
    APPLIED,
    ALREADY_APPLIED,
    FAILED;

}

