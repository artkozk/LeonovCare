package com.hhautoapply.api;

import com.hhautoapply.model.AccountResponse;
import com.hhautoapply.model.AccountStatsResponse;
import com.hhautoapply.model.CreateAccountRequest;
import com.hhautoapply.service.AccountManagementService;
import com.hhautoapply.service.AccountRunService;
import com.hhautoapply.service.RunAccountResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.http.HttpStatus;

import java.util.List;
import java.util.Set;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

@RestController
@RequestMapping("/api/internal/accounts")
@Tag(name = "Internal Accounts", description = "Internal API for creating, deleting, inspecting and running DB-backed accounts.")
@SecurityRequirement(name = "internalToken")
public class InternalAccountController {
    private static final Logger log = LoggerFactory.getLogger(InternalAccountController.class);
    private static final Set<String> RUNNING_LOGINS = ConcurrentHashMap.newKeySet();
    private static final ExecutorService RUN_EXECUTOR = new ThreadPoolExecutor(
            1,
            1,
            0L,
            TimeUnit.MILLISECONDS,
            new ArrayBlockingQueue<>(200),
            r -> {
                Thread t = new Thread(r, "acc-run-dispatcher");
                t.setDaemon(true);
                return t;
            },
            new ThreadPoolExecutor.AbortPolicy()
    );

    private final AccountManagementService service;
    private final AccountRunService accountRunService;

    public InternalAccountController(AccountManagementService service, AccountRunService accountRunService) {
        this.service = service;
        this.accountRunService = accountRunService;
    }

    @PostMapping
    @Operation(summary = "Create a new DB-backed account")
    public AccountResponse create(@RequestBody CreateAccountRequest req) {
        return service.create(req);
    }

    @DeleteMapping("/{login}")
    @Operation(summary = "Delete an account by login")
    public void delete(@PathVariable("login") String login) {
        service.delete(login);
    }

    @GetMapping("/{login}/stats")
    @Operation(summary = "Get account statistics by login")
    public AccountStatsResponse stats(@PathVariable("login") String login) {
        return service.stats(login);
    }

    @PostMapping("/run")
    @Operation(summary = "Run one DB-backed account immediately")
    public RunAccountResponse run(@RequestBody RunAccountRequest req) {
        String login = req == null ? "" : req.login();
        return enqueueRun(login);
    }

    @PostMapping("/{login}/run")
    @Operation(summary = "Run one DB-backed account immediately by login path")
    public RunAccountResponse runByPath(@PathVariable("login") String login) {
        return enqueueRun(login);
    }

    private RunAccountResponse enqueueRun(String rawLogin) {
        String login = normalize(rawLogin);
        if (login.isEmpty()) {
            return new RunAccountResponse(false, "", "LOGIN_REQUIRED", 0, List.of());
        }
        ensureAccountExists(login);
        if (!RUNNING_LOGINS.add(login)) {
            return new RunAccountResponse(true, login, "ALREADY_RUNNING", 0, List.of());
        }
        try {
            RUN_EXECUTOR.execute(() -> {
                try {
                    accountRunService.run(login);
                } catch (Exception e) {
                    log.error("[ASYNC_RUN] login={} err={}", safe(login), safe(e.toString()), e);
                } finally {
                    RUNNING_LOGINS.remove(login);
                }
            });
            return new RunAccountResponse(true, login, "STARTED", 0, List.of());
        } catch (RejectedExecutionException e) {
            RUNNING_LOGINS.remove(login);
            log.warn("[ASYNC_RUN] queue rejected login={} err={}", safe(login), safe(e.toString()));
            return new RunAccountResponse(false, login, "RUN_QUEUE_BUSY", 0, List.of());
        }
    }

    private String normalize(String raw) {
        return raw == null ? "" : raw.trim();
    }

    private void ensureAccountExists(String login) {
        try {
            service.stats(login);
        } catch (IllegalArgumentException ex) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "account not found: " + safe(login));
        }
    }

    private String safe(String s) {
        if (s == null) {
            return "";
        }
        String v = s.trim();
        return v.length() <= 220 ? v : v.substring(0, 220) + "...";
    }
}
