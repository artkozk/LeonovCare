package com.hhautoapply.service;

import com.hhautoapply.model.HhAccountEntity;
import com.hhautoapply.repository.HhAccountRepository;
import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;
import com.microsoft.playwright.Response;
import com.microsoft.playwright.options.WaitUntilState;
import lombok.Generated;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.FileAttribute;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Service
public class AccountRunService {
    @Generated
    private static final Logger log = LoggerFactory.getLogger(AccountRunService.class);
    private static final String HH_BASE = "https://hh.ru";

    private final HhAccountRepository repository;
    private final HhAuthService hhAuthService;
    private final HhApplyService hhApplyService;

    @Transactional
    public RunAccountResponse run(String login) {
        HhAccountEntity account = repository.findByLogin(login)
                .orElseThrow(() -> new IllegalArgumentException("account not found: " + login));

        if (Boolean.FALSE.equals(account.getActive())) {
            return new RunAccountResponse(false, login, "account is inactive", 0, List.of());
        }

        String runId = UUID.randomUUID().toString().substring(0, 8);
        Path storage = storagePathFor(account.getLogin());

        Browser browser = null;
        BrowserContext ctx = null;

        try (Playwright pw = Playwright.create()) {
            browser = pw.chromium().launch(new BrowserType.LaunchOptions().setHeadless(true).setSlowMo(150));
            Browser.NewContextOptions ctxOpts = new Browser.NewContextOptions()
                    .setLocale("ru-RU")
                    .setIgnoreHTTPSErrors(true)
                    .setViewportSize(1280, 720);

            if (Files.exists(storage, new LinkOption[0])) {
                ctxOpts.setStorageStatePath(storage);
                log.info("[{}][AUTH] reuse storageState={} login={}", runId, storage.toAbsolutePath(), safeShort(login));
            }

            ctx = browser.newContext(ctxOpts);
            Page page = ctx.newPage();

            SessionProbe preProbe = probeSession(page);
            if (!preProbe.loggedIn) {
                HhAuthService.AuthResult auth = hhAuthService.loginOnPage(page, account.getLogin(), account.getPassword());

                if (!auth.ok() && !auth.otpRequired()) {
                    SessionProbe authProbe = probeSession(page);
                    if (!authProbe.loggedIn) {
                        safeClose(ctx, browser);
                        saveRunMeta(account, "AUTH_FAILED", 0);
                        return new RunAccountResponse(false, login, "AUTH_FAILED: " + safeShort(auth.details()) + " | " + safeShort(authProbe.details), 0, List.of());
                    }
                    log.warn("[{}][AUTH] service ok=false, but probe loggedIn=true. Continue. login={}", runId, safeShort(login));
                }

                if (auth.otpRequired()) {
                    safeClose(ctx, browser);
                    saveRunMeta(account, "OTP_REQUIRED", 0);
                    return new RunAccountResponse(false, login, "OTP_REQUIRED: " + safeShort(auth.details()), 0, List.of());
                }

                try {
                    ensureDir(storage);
                    ctx.storageState(new BrowserContext.StorageStateOptions().setPath(storage));
                } catch (Exception e) {
                    log.warn("[{}][AUTH] storage save failed login={} err={}", runId, safeShort(login), safeShort(e.toString()));
                }
            }

            SessionProbe finalProbe = probeSession(page);
            if (!finalProbe.loggedIn) {
                safeClose(ctx, browser);
                saveRunMeta(account, "AUTH_FAILED_AFTER_PROBE", 0);
                return new RunAccountResponse(false, login, "AUTH_FAILED_AFTER_PROBE", 0, List.of());
            }

            List<HhApplyService.ApplyResult> results = hhApplyService.applyFromSerp(
                    page,
                    blankToDefault(account.getQueryText(), "java"),
                    (account.getTargetApplies() == null || account.getTargetApplies() < 1) ? 200 : account.getTargetApplies(),
                    account.getCoverLetter(),
                    account.getCandidateContext()
            );

            int sent = (int) results.stream().filter(r -> "SENT".equals(r.status()) || "SENT_BY_LLM".equals(r.status()) || "APPLIED".equals(r.status())).count();
            safeClose(ctx, browser);
            saveRunMeta(account, "OK", sent);
            return new RunAccountResponse(true, login, "OK", sent, results);

        } catch (Exception e) {
            safeClose(ctx, browser);
            saveRunMeta(account, "ERR", 0);
            log.error("[{}][RUN_ACCOUNT] login={} err={}", runId, safeShort(login), e.toString(), e);
            return new RunAccountResponse(false, login, "ERR: " + safeShort(e.getMessage()), 0, List.of());
        }
    }

    private void saveRunMeta(HhAccountEntity account, String status, int sent) {
        account.setLastRunAt(LocalDateTime.now());
        account.setLastRunStatus(status);
        account.setLastSentCount(sent);
        repository.save(account);
    }

    private Path storagePathFor(String login) {
        String safe = (login == null ? "unknown" : login.trim().toLowerCase()).replaceAll("[^a-z0-9._@-]+", "_");
        return Paths.get("profiles", safe, "storageState.json");
    }

    private void ensureDir(Path p) {
        try { Files.createDirectories(p.getParent(), new FileAttribute[0]); } catch (Exception ignored) {}
    }

    private String blankToDefault(String s, String def) { return (s == null || s.isBlank()) ? def : s.trim(); }

    private void safeClose(BrowserContext ctx, Browser browser) {
        try { if (ctx != null) ctx.close(); } catch (Exception ignored) {}
        try { if (browser != null) browser.close(); } catch (Exception ignored) {}
    }

    private static String safeShort(String s) {
        if (s == null) return "";
        s = s.trim();
        return s.length() <= 180 ? s : s.substring(0, 180) + "...";
    }

    private SessionProbe probeSession(Page page) {
        try {
            Response resp = page.navigate(HH_BASE + "/applicant/resumes", new Page.NavigateOptions().setWaitUntil(WaitUntilState.DOMCONTENTLOADED).setTimeout(45000));
            String url = page.url() == null ? "" : page.url();
            if (url.contains("/account/login") || url.contains("/login")) return new SessionProbe(false, url, "redirected_to_login");
            int status = resp != null ? resp.status() : -1;
            if (status >= 400) return new SessionProbe(false, url, "httpStatus=" + status);
            boolean loginFormVisible = isVisible(page, "input[name='username'], input[type='password'], button:has-text('?????')");
            if (loginFormVisible) return new SessionProbe(false, url, "login form visible");
            return new SessionProbe(true, url, "ok");
        } catch (Exception e) {
            return new SessionProbe(false, safeShort(page.url()), "probe exception: " + safeShort(e.toString()));
        }
    }

    private boolean isVisible(Page page, String selector) {
        try { return page.locator(selector).first().isVisible(); } catch (Exception e) { return false; }
    }

    @Generated
    public AccountRunService(HhAccountRepository repository, HhAuthService hhAuthService, HhApplyService hhApplyService) {
        this.repository = repository;
        this.hhAuthService = hhAuthService;
        this.hhApplyService = hhApplyService;
    }

    private static final class SessionProbe {
        final boolean loggedIn;
        final String url;
        final String details;
        private SessionProbe(boolean loggedIn, String url, String details) {
            this.loggedIn = loggedIn; this.url = url; this.details = details;
        }
    }
}
