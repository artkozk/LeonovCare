package com.hhautoapply.service;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.concurrent.locks.ReentrantLock;

@Aspect
@Component
public class RunSerializationAspect {
    private static final Logger log = LoggerFactory.getLogger(RunSerializationAspect.class);
    private static final ReentrantLock LOCK = new ReentrantLock(true);

    @Around("execution(* com.hhautoapply.service.AccountRunService.run(..))")
    public Object aroundRun(ProceedingJoinPoint pjp) throws Throwable {
        String login = "";
        Object[] args = pjp.getArgs();
        if (args != null && args.length > 0 && args[0] != null) {
            login = String.valueOf(args[0]).trim();
        }

        long waitStartedAt = System.currentTimeMillis();
        LOCK.lock();
        long waitedMs = System.currentTimeMillis() - waitStartedAt;

        try {
            if (waitedMs > 1500) {
                log.info("[RUN_LOCK] login={} waitedMs={}", safe(login), waitedMs);
            }
            return pjp.proceed();
        } finally {
            LOCK.unlock();
        }
    }

    private String safe(String s) {
        if (s == null) {
            return "";
        }
        String v = s.trim();
        return v.length() <= 180 ? v : v.substring(0, 180) + "...";
    }
}
