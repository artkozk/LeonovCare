# hh-autoresponder (локальная копия)

Локальная копия сервиса автооткликов, восстановленная с прод-сервера 2026-03-25.

Источник:
- базовые Java-классы: `/tmp/hh_base`;
- активные hotfix-исходники: `/opt/hh-autoresponder/runtime/patch/src`;
- Maven-конфиг: `/opt/hh-autoresponder/runtime/pom.xml`.

Состав:
- `pom.xml`, `pom.runtime.xml`;
- `src/main/java/com/hhautoapply/...` (рабочая версия для доработок);
- `decompiled/com/hhautoapply/...` (референс на случай сверки);
- `RECOVERED_SUMMARY.txt`, `DECOMP_SUMMARY.txt`.

Важно:
- проект восстановлен из runtime/decompiled исходников и может отличаться от исходного приватного репозитория.

Последние правки (2026-03-26):
- `InternalAccountController` переведен на асинхронный запуск `run` с дедупликацией по логину и поддержкой обоих путей:
  - `POST /api/internal/accounts/run`
  - `POST /api/internal/accounts/{login}/run`
- добавлен `RunSerializationAspect` для последовательного выполнения `AccountRunService.run(..)` (защита от параллельных запусков и OOM).
