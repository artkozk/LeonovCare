# Server Deploy (Ubuntu + systemd)

## 1) Install base packages
```bash
sudo apt update
sudo apt install -y python3 python3-venv python3-pip
```

## 2) Create service user and app directories
```bash
sudo useradd -r -s /usr/sbin/nologin mentorbot || true
sudo mkdir -p /opt/mentor-bot/data
sudo chown -R mentorbot:mentorbot /opt/mentor-bot
```

## 3) Copy project
Put project files into `/opt/mentor-bot`.

## 4) Create virtual env and install deps
```bash
cd /opt/mentor-bot
python3 -m venv .venv
. .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
```

## 5) Configure env
```bash
cp deploy/env.example .env
nano .env
```
Required values:
- `BOT_TOKEN`
- `ADMIN_IDS`

Strongly recommended:
- `TZ=Europe/Moscow`
- `MATERIALS_GROUP_CHAT_ID`
- `MATERIALS_GROUP_INVITE_URL`

For autoapply integration:
- `AUTOAPPLY_API_BASE_URL`
- `AUTOAPPLY_INTERNAL_TOKEN`
- `AUTOAPPLY_TIMEOUT_SEC`

For enrollment/contracts:
- `CONTRACT_FILE_PATH` (optional: local file sent by bot)
- `OKIDOKI_SIGN_URL` (static sign link fallback)
- `OKIDOKI_CREATE_CONTRACT_URL` (optional HTTP integration for dynamic sign links)
- `OKIDOKI_API_TOKEN` (optional bearer token for OkiDoki integration endpoint)
- `MENTOR_CONTACT_URL`

For AI outreach replies (LLM):
- `OWNER_OPENAI_MODEL` (default `gpt-5.4-mini`)
- `OWNER_AI_PROVIDER` (`proxy` recommended, or `openai`)
- `OWNER_AI_BASE_URL` (required for `proxy`, e.g. Cloudflare Worker URL)
- `OWNER_AI_PROXY_AUTH` (optional bearer token for proxy)
- `OWNER_AI_HTTP_PROXY` (optional transport proxy for OpenAI/AI-proxy, format `http://user:pass@host:port`)
- `OWNER_AI_REQUEST_TIMEOUT_SEC`
- `OWNER_AI_STRICT_MODE` (`true` -> no fallback replies when LLM fails)
- `OWNER_OPENAI_API_KEY` (required only for `OWNER_AI_PROVIDER=openai`)

For payment receipt checks:
- `PAYMENT_EXPECTED_INN`
- `PAYMENT_MAX_AGE_DAYS`
- `PAYMENT_RECEIVER_NAME`
- `PAYMENT_BANK_NAME`
- `PAYMENT_ACCOUNT_NUMBER`
- `PAYMENT_CORR_ACCOUNT`
- `PAYMENT_BIK`
- `PAYMENT_LINK_URL`

For Cardlink checkout:
- `CARDLINK_SHOP_ID`
- `CARDLINK_BEARER_TOKEN`
- `CARDLINK_RETURN_URL`
- `CARDLINK_TIMEOUT_SEC`
- `CARDLINK_API_BASE_URL`

For Interview Helper licensing:
- `INTERVIEW_API_BASE_URL`
- `INTERVIEW_API_ADMIN_USERNAME`
- `INTERVIEW_API_ADMIN_PASSWORD`
- `INTERVIEW_API_PLAN`
- `INTERVIEW_API_TIMEOUT_SEC`
- `INTERVIEW_HELPER_PRICE_RUB`
- `INTERVIEW_HELPER_DURATION_DAYS`
- `INTERVIEW_HELPER_DOWNLOAD_URL`
- `INTERVIEW_HELPER_STUDENT_FREE` (`false` = ключ только через оплату)

## 6) Install systemd unit
```bash
sudo cp deploy/mentor-bot.service /etc/systemd/system/mentor-bot.service
sudo systemctl daemon-reload
sudo systemctl enable mentor-bot
sudo systemctl start mentor-bot
```

## 7) Verify
```bash
sudo systemctl status mentor-bot --no-pager
journalctl -u mentor-bot -f
```

## 8) Integration checks after deploy

### 8.1 Check autoapply API from server
```bash
curl -X POST "$AUTOAPPLY_API_BASE_URL/api/internal/accounts" \
  -H "Content-Type: application/json" \
  -H "X-Internal-Token: $AUTOAPPLY_INTERNAL_TOKEN" \
  -d '{"login":"healthcheck@example.com","password":"secret","direction":"java","targetApplies":5,"queryText":"Java","active":true}'
```

If this request fails, bot autoapply launches will fail too (bot will still notify admin via request).

### 8.2 Check contract settings
- If using static sign link: ensure `OKIDOKI_SIGN_URL` is valid.
- If using dynamic integration: test `OKIDOKI_CREATE_CONTRACT_URL` manually and verify it returns JSON with `sign_url`.
- If sending local contract file: ensure `CONTRACT_FILE_PATH` exists and service user can read it.

### 8.3 Run smoke-check in production venv
```bash
cd /opt/mentor-bot
. .venv/bin/activate
PYTHONPATH='.' python scripts/smoke_check.py
```

### 8.4 Check AI connectivity from server
For `OWNER_AI_PROVIDER=proxy`:
```bash
curl -X POST "$OWNER_AI_BASE_URL/v1/chat/completions" \
  -H "Authorization: Bearer $OWNER_AI_PROXY_AUTH" \
  -H "Content-Type: application/json" \
  -d '{"model":"gpt-5.4-mini","messages":[{"role":"user","content":"ping"}],"max_completion_tokens":12}'
```

For `OWNER_AI_PROVIDER=openai` with transport proxy:
```bash
curl -x "$OWNER_AI_HTTP_PROXY" -X POST "https://api.openai.com/v1/chat/completions" \
  -H "Authorization: Bearer $OWNER_OPENAI_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"model":"gpt-5.4-mini","messages":[{"role":"user","content":"ping"}],"max_completion_tokens":12}'
```

Expected: HTTP 200 and non-empty `choices[0].message.content`.

### 8.5 Run pre-prod audit (one command)
```bash
cd /opt/mentor-bot
. .venv/bin/activate
PYTHONPATH='.' python scripts/preprod_audit.py --json-out /tmp/preprod_audit.json
```

The report contains:
- bot tests/smoke/compile status;
- parser root detection;
- health checks for Autoapply and Interview Helper;
- AI runtime readiness + live check `svc:ai:chat`;
- env readiness for Cardlink/AI/Interview.

Important:
- for legacy environments Cardlink variables can be sourced from old names:
  - `YOOKASSA_SHOP_ID` or `YOOKASSA_OAUTH_CLIENT_ID` -> `CARDLINK_SHOP_ID`;
  - `YOOKASSA_SECRET_KEY` or `YOOKASSA_OAUTH_CLIENT_SECRET` -> `CARDLINK_BEARER_TOKEN`.

## Update flow
```bash
cd /opt/mentor-bot
git pull
. .venv/bin/activate
pip install -r requirements.txt
sudo systemctl restart mentor-bot
```

If schema changed, it is migrated automatically at startup (`ensure_schema()`).

## Notes
- You can still run manually: `python main.py`.
- For best throughput on Linux, `uvloop` is installed automatically from `requirements.txt`.
- If SQLite lock warnings appear under high load, increase `DB_BUSY_TIMEOUT_SEC` and `BOT_WORKER_THREADS` in `.env`.
