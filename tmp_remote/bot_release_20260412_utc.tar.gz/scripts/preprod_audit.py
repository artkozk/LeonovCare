from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from urllib.parse import urljoin

import requests


@dataclass
class CheckResult:
    name: str
    status: str  # PASS | WARN | FAIL
    details: str


def _run_cmd(name: str, cmd: list[str], cwd: Path, timeout_sec: int) -> CheckResult:
    try:
        proc = subprocess.run(
            cmd,
            cwd=str(cwd),
            check=False,
            capture_output=True,
            text=True,
            timeout=timeout_sec,
        )
    except Exception as exc:
        return CheckResult(name=name, status="FAIL", details=f"ошибка запуска: {exc}")
    if proc.returncode == 0:
        tail = (proc.stdout or "").strip() or "ok"
        return CheckResult(name=name, status="PASS", details=tail[-800:])
    out = "\n".join(x for x in [(proc.stdout or "").strip(), (proc.stderr or "").strip()] if x).strip()
    return CheckResult(name=name, status="FAIL", details=out[-1200:] or f"код выхода {proc.returncode}")


def _http_get(name: str, url: str, timeout_sec: int = 10) -> CheckResult:
    try:
        resp = requests.get(url, timeout=timeout_sec)
    except Exception as exc:
        return CheckResult(name=name, status="FAIL", details=f"{url} -> {type(exc).__name__}: {exc}")
    body = (resp.text or "").strip()
    if resp.status_code >= 400:
        return CheckResult(name=name, status="FAIL", details=f"{url} -> HTTP {resp.status_code}: {body[:300]}")
    return CheckResult(name=name, status="PASS", details=f"{url} -> HTTP {resp.status_code}: {body[:300]}")


def _http_post_json(
    name: str,
    url: str,
    payload: dict[str, Any],
    timeout_sec: int = 10,
    headers: dict[str, str] | None = None,
    proxies: dict[str, str] | None = None,
) -> CheckResult:
    try:
        resp = requests.post(
            url,
            json=payload,
            timeout=timeout_sec,
            headers=headers,
            proxies=proxies,
        )
    except Exception as exc:
        return CheckResult(name=name, status="FAIL", details=f"{url} -> {type(exc).__name__}: {exc}")
    body = (resp.text or "").strip()
    if resp.status_code >= 400:
        return CheckResult(name=name, status="FAIL", details=f"{url} -> HTTP {resp.status_code}: {body[:300]}")
    return CheckResult(name=name, status="PASS", details=f"{url} -> HTTP {resp.status_code}: {body[:300]}")


def _env_state(name: str) -> str:
    val = str(os.getenv(name, "") or "").strip()
    return "SET" if val else "EMPTY"


def _load_env_file(path: Path) -> int:
    if not path.exists() or not path.is_file():
        return 0
    loaded = 0
    for raw in path.read_text(encoding="utf-8", errors="ignore").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            continue
        key, value = line.split("=", 1)
        k = key.strip()
        if not k:
            continue
        v = value.strip()
        if len(v) >= 2 and ((v[0] == "'" and v[-1] == "'") or (v[0] == '"' and v[-1] == '"')):
            v = v[1:-1]
        if os.getenv(k) is None:
            os.environ[k] = v
            loaded += 1
    return loaded


def _check_env_group(group_name: str, keys: list[str], hard_required: bool = False) -> CheckResult:
    missing = [k for k in keys if _env_state(k) == "EMPTY"]
    if not missing:
        return CheckResult(group_name, "PASS", "все переменные заполнены")
    details = f"не заполнены: {', '.join(missing)}"
    return CheckResult(group_name, "FAIL" if hard_required else "WARN", details)


def _resolve_parser_root(bot_root: Path) -> str:
    explicit = str(os.getenv("OWNER_PARSER_ROOT", "") or "").strip()
    if explicit:
        return explicit
    candidates = [
        bot_root.parent / "AutoHh" / "parser_hh",
        bot_root.parent.parent / "AutoHh" / "parser_hh",
        bot_root.parent.parent / "parser_hh-main",
        bot_root.parent / "parser_hh-main",
        bot_root / "parser_hh-main",
    ]
    for c in candidates:
        try:
            if c.is_dir() and (c / "application").is_dir():
                return str(c.resolve())
        except Exception:
            continue
    return ""


def _service_base(name: str) -> str:
    raw = str(os.getenv(name, "") or "").strip().rstrip("/")
    return raw


def _proxy_cfg_from_env(*names: str) -> dict[str, str] | None:
    for n in names:
        v = str(os.getenv(n, "") or "").strip()
        if v:
            return {"http": v, "https": v}
    return None


def main() -> int:
    parser = argparse.ArgumentParser(description="Pre-prod аудит бота и смежных сервисов")
    parser.add_argument("--env-file", type=str, default="")
    parser.add_argument("--skip-tests", action="store_true")
    parser.add_argument("--skip-smoke", action="store_true")
    parser.add_argument("--skip-compile", action="store_true")
    parser.add_argument("--timeout-sec", type=int, default=180)
    parser.add_argument("--json-out", type=str, default="")
    args = parser.parse_args()

    bot_root = Path(__file__).resolve().parent.parent
    results: list[CheckResult] = []
    env_file = str(args.env_file or "").strip()
    if env_file:
        loaded = _load_env_file(Path(env_file).expanduser().resolve())
        results.append(CheckResult("env:file", "PASS", f"загружено переменных: {loaded}"))

    results.append(CheckResult("python", "PASS", sys.version.replace("\n", " ")))
    results.append(
        _check_env_group(
            "env:core",
            ["BOT_TOKEN", "ADMIN_IDS", "DB_PATH"],
            hard_required=True,
        )
    )
    results.append(
        _check_env_group(
            "env:autoapply",
            ["AUTOAPPLY_API_BASE_URL", "AUTOAPPLY_INTERNAL_TOKEN"],
            hard_required=False,
        )
    )
    results.append(
        _check_env_group(
            "env:interview",
            ["INTERVIEW_API_BASE_URL", "INTERVIEW_API_ADMIN_USERNAME", "INTERVIEW_API_ADMIN_PASSWORD"],
            hard_required=False,
        )
    )
    results.append(
        _check_env_group(
            "env:cardlink",
            ["CARDLINK_SHOP_ID", "CARDLINK_BEARER_TOKEN", "CARDLINK_RETURN_URL"],
            hard_required=False,
        )
    )
    results.append(_check_env_group("env:ai", ["OWNER_AI_PROVIDER", "OWNER_OPENAI_MODEL"], hard_required=False))
    ai_provider = str(os.getenv("OWNER_AI_PROVIDER", "") or "").strip().lower()
    ai_base_url = str(os.getenv("OWNER_AI_BASE_URL", "") or "").strip().rstrip("/")
    ai_key = str(os.getenv("OWNER_OPENAI_API_KEY", "") or "").strip()
    ai_http_proxy = str(os.getenv("OWNER_AI_HTTP_PROXY", "") or "").strip()
    if ai_provider == "proxy":
        if not ai_base_url:
            results.append(
                CheckResult(
                    "env:ai_runtime",
                    "FAIL",
                    "OWNER_AI_PROVIDER=proxy, но OWNER_AI_BASE_URL пуст (AI-ответы будут в needs_review)",
                )
            )
        else:
            results.append(CheckResult("env:ai_runtime", "PASS", "proxy base url задан"))
    elif ai_provider == "openai":
        if not ai_key:
            results.append(
                CheckResult(
                    "env:ai_runtime",
                    "WARN",
                    "OWNER_AI_PROVIDER=openai, но OWNER_OPENAI_API_KEY пуст",
                )
            )
        else:
            details = "openai key задан"
            if ai_http_proxy:
                details += " + OWNER_AI_HTTP_PROXY задан"
            results.append(CheckResult("env:ai_runtime", "PASS", details))
    else:
        results.append(
            CheckResult(
                "env:ai_runtime",
                "WARN",
                f"неизвестный OWNER_AI_PROVIDER={ai_provider or 'EMPTY'}",
            )
        )

    parser_root = _resolve_parser_root(bot_root)
    if parser_root:
        results.append(CheckResult("parser_root", "PASS", parser_root))
    else:
        results.append(
            CheckResult(
                "parser_root",
                "WARN",
                "не найден parser_hh автоматически (задай OWNER_PARSER_ROOT)",
            )
        )

    if not args.skip_tests:
        results.append(
            _run_cmd(
                "tests",
                [sys.executable, "-m", "pytest", "-q", "tests"],
                cwd=bot_root,
                timeout_sec=max(args.timeout_sec, 120),
            )
        )
    if not args.skip_smoke:
        results.append(
            _run_cmd(
                "smoke",
                [sys.executable, "scripts/smoke_check.py"],
                cwd=bot_root,
                timeout_sec=max(args.timeout_sec, 60),
            )
        )
    if not args.skip_compile:
        results.append(
            _run_cmd(
                "compile",
                [sys.executable, "-m", "compileall", "app", "scripts"],
                cwd=bot_root,
                timeout_sec=max(args.timeout_sec, 120),
            )
        )

    autoapply_base = _service_base("AUTOAPPLY_API_BASE_URL")
    if autoapply_base:
        results.append(
            _http_get(
                "svc:autoapply:health",
                urljoin(autoapply_base + "/", "actuator/health"),
            )
        )
    else:
        results.append(CheckResult("svc:autoapply:health", "WARN", "AUTOAPPLY_API_BASE_URL не задан"))

    interview_base = _service_base("INTERVIEW_API_BASE_URL")
    if interview_base:
        results.append(_http_get("svc:interview:health", urljoin(interview_base + "/", "health")))
        iu = str(os.getenv("INTERVIEW_API_ADMIN_USERNAME", "") or "").strip()
        ip = str(os.getenv("INTERVIEW_API_ADMIN_PASSWORD", "") or "").strip()
        if iu and ip:
            results.append(
                _http_post_json(
                    "svc:interview:admin_login",
                    urljoin(interview_base + "/", "api/v1/admin/login"),
                    {"username": iu, "password": ip},
                )
            )
        else:
            results.append(
                CheckResult(
                    "svc:interview:admin_login",
                    "WARN",
                    "пропущено: нет INTERVIEW_API_ADMIN_USERNAME/INTERVIEW_API_ADMIN_PASSWORD",
                )
            )
    else:
        results.append(CheckResult("svc:interview:health", "WARN", "INTERVIEW_API_BASE_URL не задан"))

    ai_headers = {"Content-Type": "application/json"}
    ai_payload = {
        "model": str(os.getenv("OWNER_OPENAI_MODEL", "") or "").strip() or "gpt-5.4-mini",
        "messages": [{"role": "user", "content": "ping"}],
        "temperature": 0.0,
        "max_completion_tokens": 12,
    }
    ai_proxies = _proxy_cfg_from_env("OWNER_AI_HTTP_PROXY", "HTTPS_PROXY")
    if ai_provider == "proxy":
        token = str(os.getenv("OWNER_AI_PROXY_AUTH", "") or "").strip()
        if token:
            ai_headers["Authorization"] = f"Bearer {token}"
        if ai_base_url:
            results.append(
                _http_post_json(
                    "svc:ai:chat",
                    urljoin(ai_base_url + "/", "v1/chat/completions"),
                    ai_payload,
                    timeout_sec=15,
                    headers=ai_headers,
                    proxies=ai_proxies,
                )
            )
        else:
            results.append(CheckResult("svc:ai:chat", "FAIL", "proxy mode без OWNER_AI_BASE_URL"))
    elif ai_provider == "openai":
        if ai_key:
            ai_headers["Authorization"] = f"Bearer {ai_key}"
            results.append(
                _http_post_json(
                    "svc:ai:chat",
                    "https://api.openai.com/v1/chat/completions",
                    ai_payload,
                    timeout_sec=15,
                    headers=ai_headers,
                    proxies=ai_proxies,
                )
            )
        else:
            results.append(CheckResult("svc:ai:chat", "WARN", "openai mode без OWNER_OPENAI_API_KEY"))

    status_order = {"PASS": 0, "WARN": 1, "FAIL": 2}
    overall = "PASS"
    for r in results:
        if status_order.get(r.status, 2) > status_order.get(overall, 0):
            overall = r.status

    report = {
        "overall": overall,
        "checks": [{"name": r.name, "status": r.status, "details": r.details} for r in results],
    }

    print(f"PREPROD STATUS: {overall}")
    for r in results:
        print(f"[{r.status}] {r.name}: {r.details}")

    if args.json_out:
        out = Path(args.json_out).expanduser().resolve()
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"json report: {out}")

    return 1 if overall == "FAIL" else 0


if __name__ == "__main__":
    raise SystemExit(main())
