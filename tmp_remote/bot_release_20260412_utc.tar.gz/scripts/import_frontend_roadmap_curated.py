#!/usr/bin/env python3
from __future__ import annotations

"""
Импорт Frontend roadmap в формате как у golang:
- блоки и шаги в БД;
- каждый шаг открывает конкретное сообщение в группе.

Источник (topic 264):
- https://t.me/c/3730365848/264/265
"""

import argparse
import os
import sqlite3
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def _default_db_path() -> str:
    env_db = (os.getenv("DB_PATH") or "").strip()
    if env_db:
        return env_db
    prod_db = Path("/opt/mentor-bot/data/mentor_bot.db")
    if prod_db.exists():
        return str(prod_db)
    return "mentor_bot.db"


CHAT_ID = 3730365848
TOPIC_ID = 264

BLOCK_TITLES: dict[int, str] = {
    1: "Блок 1. HTML + CSS",
    2: "Блок 2. JavaScript",
    3: "Блок 3. Инструменты + React",
    4: "Блок 4. Качество и портфолио",
    5: "Блок 5. Итоговый проект / capstone",
}


def _msg_url(message_id: int) -> str:
    return f"https://t.me/c/{CHAT_ID}/{TOPIC_ID}/{int(message_id)}"


STEPS: list[dict[str, object]] = [
    # Блок 1
    {"block": 1, "position": 1, "title": "Шаг 1. HTML: структура страницы и семантика", "message_id": 265},
    {"block": 1, "position": 2, "title": "Шаг 2. CSS: селекторы, box model, flex, grid и адаптив", "message_id": 266},
    # Блок 2
    {"block": 2, "position": 1, "title": "Шаг 1. JavaScript: база языка и DOM", "message_id": 267},
    {"block": 2, "position": 2, "title": "Шаг 2. Современный JavaScript: асинхронность, fetch, модули", "message_id": 268},
    # Блок 3
    {"block": 3, "position": 1, "title": "Шаг 1. Инструменты: Git, npm, Vite, TypeScript", "message_id": 269},
    {"block": 3, "position": 2, "title": "Шаг 2. React: компоненты, состояние, props, формы", "message_id": 270},
    # Блок 4
    {"block": 4, "position": 1, "title": "Шаг 1. Качество интерфейса: доступность, производительность, структура", "message_id": 271},
    {"block": 4, "position": 2, "title": "Шаг 2. Подготовка к финальному проекту и портфолио", "message_id": 272},
    # Блок 5
    {"block": 5, "position": 1, "title": "Итоговый проект / capstone", "message_id": 273},
]


def main() -> int:
    parser = argparse.ArgumentParser(description="Import frontend roadmap (topic style)")
    parser.add_argument("--direction", default="frontend", help="java|golang|frontend|python")
    parser.add_argument("--db-path", default=_default_db_path(), help="SQLite DB path")
    parser.add_argument("--tz", default=os.getenv("TZ", "Europe/Moscow"), help="Timezone for updated_at")
    parser.add_argument("--topic-id", type=int, default=TOPIC_ID, help="Forum topic id to map direction")
    parser.add_argument("--purge-direction", action="store_true", default=True, help="Replace all existing steps for direction")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    from app.db import repo_materials
    from app.db.schema import ensure_schema
    from app.services.timeutils import iso, now

    conn = sqlite3.connect(args.db_path)
    conn.row_factory = sqlite3.Row
    ensure_schema(conn)
    tz = str(args.tz or "Europe/Moscow")
    direction = repo_materials.normalize_direction(args.direction)
    if not direction:
        print("invalid --direction, use: java|golang|frontend|python", file=sys.stderr)
        return 2

    if args.dry_run:
        for s in STEPS:
            print(
                f"[DRY] {direction} | block {s['block']} | pos {s['position']} | "
                f"{s['title']} -> {_msg_url(int(s['message_id']))}"
            )
        print(f"DRY RUN complete: steps={len(STEPS)}")
        print(f"DB path: {args.db_path}")
        return 0

    if args.purge_direction:
        ts = iso(now(tz))
        conn.execute("DELETE FROM user_material_progress WHERE step_id IN (SELECT id FROM material_steps WHERE direction=?)", (direction,))
        conn.execute("DELETE FROM material_steps WHERE direction=?", (direction,))
        conn.commit()
        print(f"Purged existing steps for direction={direction}")

    inserted = 0
    for s in STEPS:
        block = int(s["block"])
        pos = int(s["position"])
        title = str(s["title"]).strip()
        message_url = _msg_url(int(s["message_id"]))
        block_title = BLOCK_TITLES.get(block, f"Блок {block}")
        repo_materials.upsert_auto_step(
            conn=conn,
            tz=tz,
            direction=direction,
            block_number=block,
            block_title=block_title,
            position=pos,
            title=title,
            message_url=message_url,
        )
        inserted += 1

    if int(args.topic_id or 0) > 0:
        repo_materials.set_topic_mapping(conn, direction, int(args.topic_id), tz)

    print(f"Imported/updated roadmap: direction={direction}, steps={inserted}")
    print(f"DB path: {args.db_path}")
    print(f"Topic mapping set: {direction} -> {int(args.topic_id or 0)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
