from __future__ import annotations

import argparse
import asyncio
import json
import os
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from app.services.tg_proxy import (
    build_client_kwargs,
    parse_generic_proxy,
    parse_mtproxy,
    resolve_proxy,
)


def _session_locked(exc: Exception) -> bool:
    return "database is locked" in str(exc or "").lower()


def _cleanup_session_locks(session_file: str) -> None:
    base = Path(str(session_file)).expanduser().resolve()
    for suffix in ("-journal", "-wal", "-shm"):
        p = Path(str(base) + suffix)
        try:
            if p.exists():
                p.unlink()
        except Exception:
            pass


def _load_contacts(path: Path) -> list[str]:
    raw = json.loads(path.read_text(encoding="utf-8"))
    usernames: list[str] = []
    if isinstance(raw, list):
        for item in raw:
            if isinstance(item, str):
                val = item.strip()
            elif isinstance(item, dict):
                val = str(item.get("telegram") or "").strip()
            else:
                val = ""
            if not val:
                continue
            if not val.startswith("@"):
                val = "@" + val
            usernames.append(val)
    # unique keep order
    out: list[str] = []
    seen: set[str] = set()
    for uname in usernames:
        key = uname.lower()
        if key in seen:
            continue
        seen.add(key)
        out.append(uname)
    return out


_SECONDS_RE = re.compile(r"(\d+)\s*(?:sec|secs|second|seconds|сек|секунд|секунды)", re.IGNORECASE)


def _extract_wait_seconds(exc: Exception) -> int:
    sec = int(getattr(exc, "seconds", 0) or 0)
    if sec > 0:
        return sec
    txt = str(exc or "")
    m = _SECONDS_RE.search(txt)
    if m:
        try:
            return int(m.group(1))
        except Exception:
            return 0
    return 0


def _is_too_many_requests(exc: Exception) -> bool:
    txt = str(exc or "").lower()
    return any(
        marker in txt
        for marker in (
            "too many requests",
            "peerflood",
            "flood",
            "rate limit",
            "retry after",
        )
    )


def _parse_mtproxy(raw_value: str) -> tuple[str, int, str] | None:
    return parse_mtproxy(raw_value)


def _parse_generic_proxy(raw_value: str) -> dict | None:
    proxy = parse_generic_proxy(raw_value)
    return proxy if isinstance(proxy, dict) else None


def _resolve_proxy(raw_value: str) -> tuple[str, object, str] | None:
    return resolve_proxy(raw_value)


async def _run(args: argparse.Namespace) -> int:
    try:
        from telethon import TelegramClient, errors as tg_errors
    except Exception as exc:
        payload = {
            "status": "failed",
            "error": f"telethon import error: {exc}",
            "total": 0,
            "attempted": 0,
            "success": 0,
            "failed": 0,
            "details": [],
        }
        Path(args.report_file).write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        return 1

    contacts_file = Path(args.contacts_file).expanduser().resolve()
    report_file = Path(args.report_file).expanduser().resolve()
    report_file.parent.mkdir(parents=True, exist_ok=True)
    message_text = Path(args.message_file).expanduser().resolve().read_text(encoding="utf-8").strip()
    delay_sec = max(float(args.delay_sec or 0.0), 0.0)
    flood_max_wait = max(int(args.flood_max_wait or 0), 0)
    limit = max(int(args.limit or 0), 0)
    usernames = _load_contacts(contacts_file)
    if limit > 0:
        usernames = usernames[:limit]

    payload: dict = {
        "status": "done",
        "error": "",
        "total": len(usernames),
        "attempted": 0,
        "success": 0,
        "failed": 0,
        "details": [],
        "account_limited": False,
        "account_limit_reason": "",
        "stopped_early": False,
    }
    proxy_raw = (
        str(getattr(args, "proxy", "") or "").strip()
        or str(os.getenv("OWNER_TG_PROXY") or "").strip()
        or str(os.getenv("OWNER_TG_MTPROXY") or "").strip()
    )
    proxy_resolved = _resolve_proxy(proxy_raw)
    payload["proxy_used"] = bool(proxy_resolved)
    payload["proxy"] = str(proxy_resolved[2]) if proxy_resolved else ""
    payload["proxy_type"] = str(proxy_resolved[0]) if proxy_resolved else ""

    session_file = str(Path(args.session_file).expanduser().resolve())
    client = None
    last_exc: Exception | None = None
    client_kwargs, proxy_resolved = build_client_kwargs(proxy_raw)
    for attempt in range(2):
        try:
            client = TelegramClient(
                session_file,
                int(args.api_id),
                str(args.api_hash),
                **client_kwargs,
            )
            await client.connect()
            break
        except Exception as exc:
            last_exc = exc
            if client is not None:
                try:
                    await client.disconnect()
                except Exception:
                    pass
            if attempt == 0 and _session_locked(exc):
                _cleanup_session_locks(session_file)
                await asyncio.sleep(0.3)
                continue
            client = None
            break
    if client is None:
        err = str(last_exc or "failed to initialize Telegram client")
        payload["status"] = "failed"
        payload["error"] = f"Telegram connect failed: {err}"
        payload["failed"] = int(payload.get("total") or 0)
        payload["details"] = [
            {"telegram": uname, "status": "failed", "error": payload["error"]}
            for uname in usernames
        ]
        report_file.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        return 5
    try:
        if not await client.is_user_authorized():
            payload["status"] = "failed"
            payload["error"] = "Telegram user session is not authorized."
            report_file.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
            return 2

        if not message_text:
            payload["status"] = "failed"
            payload["error"] = "Message text is empty."
            report_file.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
            return 3

        account_limited_reason = ""
        for uname in usernames:
            payload["attempted"] += 1
            if account_limited_reason:
                payload["failed"] += 1
                payload["details"].append(
                    {"telegram": uname, "status": "blocked", "error": account_limited_reason}
                )
                payload["stopped_early"] = True
                continue
            try:
                sent = False
                send_error = ""
                send_status = "failed"
                for _attempt in range(2):
                    try:
                        entity = await client.get_entity(uname)
                        await client.send_message(entity, message_text)
                        sent = True
                        send_status = "sent"
                        send_error = ""
                        break
                    except tg_errors.FloodWaitError as exc:
                        wait_sec = max(_extract_wait_seconds(exc), 1)
                        if wait_sec <= flood_max_wait and _attempt == 0:
                            await asyncio.sleep(wait_sec + 1)
                            continue
                        send_status = "blocked"
                        send_error = f"FloodWait {wait_sec}s: {exc}"
                        account_limited_reason = send_error
                        break
                    except tg_errors.PeerFloodError as exc:
                        send_status = "blocked"
                        send_error = f"PeerFlood: {exc}"
                        account_limited_reason = send_error
                        break
                    except tg_errors.RPCError as exc:
                        if _is_too_many_requests(exc):
                            send_status = "blocked"
                            send_error = str(exc)
                            account_limited_reason = send_error
                        else:
                            send_status = "failed"
                            send_error = str(exc)
                        break
                if not sent:
                    payload["failed"] += 1
                    payload["details"].append(
                        {"telegram": uname, "status": send_status, "error": send_error}
                    )
                    continue
                payload["success"] += 1
                payload["details"].append({"telegram": uname, "status": "sent", "error": ""})
            except Exception as exc:
                if _is_too_many_requests(exc):
                    account_limited_reason = str(exc)
                    payload["details"].append(
                        {"telegram": uname, "status": "blocked", "error": str(exc)}
                    )
                else:
                    payload["details"].append({"telegram": uname, "status": "failed", "error": str(exc)})
                payload["failed"] += 1
            if delay_sec > 0:
                await asyncio.sleep(delay_sec)

        if account_limited_reason:
            payload["account_limited"] = True
            payload["account_limit_reason"] = account_limited_reason
            if not payload.get("error"):
                payload["error"] = account_limited_reason

        report_file.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        return 0 if int(payload["failed"] or 0) == 0 else 4
    except Exception as exc:
        payload["status"] = "failed"
        payload["error"] = str(exc)
        if not isinstance(payload.get("details"), list):
            payload["details"] = []
        if int(payload.get("attempted") or 0) <= 0 and int(payload.get("total") or 0) > 0:
            payload["failed"] = int(payload.get("total") or 0)
            if not payload["details"]:
                payload["details"] = [
                    {"telegram": uname, "status": "failed", "error": payload["error"]}
                    for uname in usernames
                ]
        report_file.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        return 5
    finally:
        await client.disconnect()


def main() -> int:
    p = argparse.ArgumentParser(description="Bulk sender via owner Telegram user session")
    p.add_argument("--api-id", type=int, required=True)
    p.add_argument("--api-hash", type=str, required=True)
    p.add_argument("--session-file", type=str, required=True)
    p.add_argument("--contacts-file", type=str, required=True)
    p.add_argument("--message-file", type=str, required=True)
    p.add_argument("--report-file", type=str, required=True)
    p.add_argument("--limit", type=int, default=0)
    p.add_argument("--delay-sec", type=float, default=2.0)
    p.add_argument("--flood-max-wait", type=int, default=90)
    p.add_argument("--proxy", type=str, default=str(os.getenv("OWNER_TG_PROXY", "") or ""))
    args = p.parse_args()
    return asyncio.run(_run(args))


if __name__ == "__main__":
    raise SystemExit(main())
