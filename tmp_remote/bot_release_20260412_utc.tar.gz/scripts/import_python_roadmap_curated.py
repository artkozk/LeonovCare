#!/usr/bin/env python3
from __future__ import annotations

"""
Импорт Python roadmap в формате как у golang:
- в БД храним блоки и шаги;
- message_url каждого шага ведёт на КОНКРЕТНОЕ сообщение в Telegram-группе.

Источник (topic 235):
- https://t.me/c/3730365848/235/236
"""

import argparse
import os
import sqlite3
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def _default_db_path() -> str:
    env_db = (os.getenv("DB_PATH") or "").strip()
    if env_db:
        return env_db
    prod_db = Path("/opt/mentor-bot/data/mentor_bot.db")
    if prod_db.exists():
        return str(prod_db)
    return "mentor_bot.db"


CHAT_ID = 3730365848
TOPIC_ID = 235

BLOCK_TITLES: dict[int, str] = {
    1: "Блок 1. Старт, установка и первый код",
    2: "Блок 2. Условия, циклы, строки, коллекции и функции",
    3: "Блок 3. Модули, исключения, файлы и стандартная библиотека",
    4: "Блок 4. ООП и устройство объектов в Python",
    5: "Блок 5. Инструменты Python-разработчика: venv, pip, pytest, typing",
    6: "Блок 6. Регулярные выражения, CLI, логирование, SQLite, asyncio",
    7: "Блок 7. Финальный pet project",
}


def _msg_url(message_id: int) -> str:
    # Формат с topic-id, чтобы всегда открывался нужный тред.
    return f"https://t.me/c/{CHAT_ID}/{TOPIC_ID}/{int(message_id)}"


# Сообщения с шагами из твоего топика (по порядку).
# Блоковые "заголовки" тоже есть в топике, но в roadmap храним именно шаги.
# IDs:
# 236=заголовок блока 1, 237..239=шаги блока 1, ...
STEPS: list[dict[str, object]] = [
    # block 1
    {"block": 1, "position": 1, "title": "Шаг 1. Что такое Python и зачем он нужен", "message_id": 237},
    {"block": 1, "position": 2, "title": "Шаг 2. Установка Python и первая программа", "message_id": 238},
    {"block": 1, "position": 3, "title": "Шаг 3. Ввод, вывод, переменные и базовые типы", "message_id": 239},
    # block 2
    {"block": 2, "position": 4, "title": "Шаг 1. Условный оператор и булева логика", "message_id": 241},
    {"block": 2, "position": 5, "title": "Шаг 2. Циклы for и while", "message_id": 242},
    {"block": 2, "position": 6, "title": "Шаг 3. Строки, списки, словари, множества", "message_id": 243},
    {"block": 2, "position": 7, "title": "Шаг 4. Функции и декомпозиция", "message_id": 244},
    # block 3
    {"block": 3, "position": 8, "title": "Шаг 1. Исключения и чтение ошибок", "message_id": 246},
    {"block": 3, "position": 9, "title": "Шаг 2. Модули и импорт", "message_id": 247},
    {"block": 3, "position": 10, "title": "Шаг 3. Файлы, чтение и запись данных", "message_id": 248},
    # block 4
    {"block": 4, "position": 11, "title": "Шаг 1. Первый вход в ООП простым языком", "message_id": 250},
    {"block": 4, "position": 12, "title": "Шаг 2. ООП через системное объяснение", "message_id": 251},
    # block 5
    {"block": 5, "position": 13, "title": "Шаг 1. Виртуальные окружения и зависимости", "message_id": 253},
    {"block": 5, "position": 14, "title": "Шаг 2. Unit-тесты на pytest", "message_id": 254},
    {"block": 5, "position": 15, "title": "Шаг 3. Type hints и mypy", "message_id": 255},
    # block 6
    {"block": 6, "position": 16, "title": "Шаг 1. Регулярные выражения", "message_id": 257},
    {"block": 6, "position": 17, "title": "Шаг 2. CLI через argparse", "message_id": 258},
    {"block": 6, "position": 18, "title": "Шаг 3. Логирование", "message_id": 259},
    {"block": 6, "position": 19, "title": "Шаг 4. SQLite и хранение данных", "message_id": 260},
    {"block": 6, "position": 20, "title": "Шаг 5. Основы asyncio", "message_id": 261},
    # block 7
    {"block": 7, "position": 21, "title": "Шаг 1. Сборка итогового CLI-проекта", "message_id": 263},
]


def main() -> int:
    parser = argparse.ArgumentParser(description="Import python roadmap (topic style)")
    parser.add_argument("--direction", default="python", help="java|golang|frontend|python")
    parser.add_argument("--db-path", default=_default_db_path(), help="SQLite DB path")
    parser.add_argument("--tz", default=os.getenv("TZ", "Europe/Moscow"), help="Timezone for updated_at")
    parser.add_argument("--topic-id", type=int, default=TOPIC_ID, help="Forum topic id to map direction")
    parser.add_argument("--purge-direction", action="store_true", default=True, help="Replace all existing steps for direction")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    from app.db import repo_materials
    from app.db.schema import ensure_schema
    from app.services.timeutils import iso, now

    conn = sqlite3.connect(args.db_path)
    conn.row_factory = sqlite3.Row
    ensure_schema(conn)
    tz = str(args.tz or "Europe/Moscow")
    direction = repo_materials.normalize_direction(args.direction)
    if not direction:
        print("invalid --direction, use: java|golang|frontend|python", file=sys.stderr)
        return 2

    if args.dry_run:
        for s in STEPS:
            print(
                f"[DRY] {direction} | block {s['block']} | pos {s['position']} | "
                f"{s['title']} -> {_msg_url(int(s['message_id']))}"
            )
        print(f"DRY RUN complete: steps={len(STEPS)}")
        print(f"DB path: {args.db_path}")
        return 0

    if args.purge_direction:
        ts = iso(now(tz))
        conn.execute("DELETE FROM user_material_progress WHERE step_id IN (SELECT id FROM material_steps WHERE direction=?)", (direction,))
        conn.execute("DELETE FROM material_steps WHERE direction=?", (direction,))
        conn.commit()
        print(f"Purged existing steps for direction={direction}")

    inserted = 0
    for s in STEPS:
        block = int(s["block"])
        pos = int(s["position"])
        title = str(s["title"]).strip()
        message_url = _msg_url(int(s["message_id"]))
        block_title = BLOCK_TITLES.get(block, f"Блок {block}")
        repo_materials.upsert_auto_step(
            conn=conn,
            tz=tz,
            direction=direction,
            block_number=block,
            block_title=block_title,
            position=pos,
            title=title,
            message_url=message_url,
        )
        inserted += 1

    if int(args.topic_id or 0) > 0:
        repo_materials.set_topic_mapping(conn, direction, int(args.topic_id), tz)

    print(f"Imported/updated roadmap: direction={direction}, steps={inserted}")
    print(f"DB path: {args.db_path}")
    print(f"Topic mapping set: {direction} -> {int(args.topic_id or 0)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
