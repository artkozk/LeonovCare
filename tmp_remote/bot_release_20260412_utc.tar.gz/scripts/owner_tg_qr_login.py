from __future__ import annotations

import argparse
import asyncio
import json
import os
import time
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from app.services.tg_proxy import build_client_kwargs


def _write_status(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def _session_locked(exc: Exception) -> bool:
    return "database is locked" in str(exc or "").lower()


def _cleanup_session_locks(session_file: str) -> None:
    base = Path(str(session_file)).expanduser().resolve()
    for suffix in ("-journal", "-wal", "-shm"):
        p = Path(str(base) + suffix)
        try:
            if p.exists():
                p.unlink()
        except Exception:
            pass


def _load_cloud_password(args: argparse.Namespace) -> str:
    raw = str(getattr(args, "cloud_password", "") or "").strip()
    if raw:
        return raw
    p_raw = str(getattr(args, "cloud_password_file", "") or "").strip()
    if not p_raw:
        return ""
    p = Path(p_raw).expanduser().resolve()
    if not p.exists() or not p.is_file():
        return ""
    try:
        value = p.read_text(encoding="utf-8").strip()
    except Exception:
        value = ""
    try:
        p.unlink()
    except Exception:
        pass
    return value


async def _run(args: argparse.Namespace) -> int:
    try:
        from telethon import TelegramClient
        from telethon.errors import SessionPasswordNeededError
    except Exception as exc:
        _write_status(Path(args.status_file), {"status": "error", "error": f"telethon import error: {exc}"})
        return 1

    qrcode_mod = None
    try:
        import qrcode as qrcode_mod  # type: ignore
    except Exception:
        qrcode_mod = None

    session_file = str(Path(args.session_file).expanduser().resolve())
    status_file = Path(args.status_file).expanduser().resolve()
    qr_file = Path(args.qr_file).expanduser().resolve()
    cloud_password = _load_cloud_password(args)
    qr_file.parent.mkdir(parents=True, exist_ok=True)
    proxy_raw = (
        str(getattr(args, "proxy", "") or "").strip()
        or str(os.getenv("OWNER_TG_PROXY") or "").strip()
        or str(os.getenv("OWNER_TG_MTPROXY") or "").strip()
    )
    client_kwargs, proxy_resolved = build_client_kwargs(proxy_raw)

    client = None
    last_exc: Exception | None = None
    for attempt in range(2):
        try:
            client = TelegramClient(session_file, int(args.api_id), str(args.api_hash), **client_kwargs)
            await client.connect()
            break
        except Exception as exc:
            last_exc = exc
            if client is not None:
                try:
                    await client.disconnect()
                except Exception:
                    pass
            if attempt == 0 and _session_locked(exc):
                _cleanup_session_locks(session_file)
                await asyncio.sleep(0.3)
                continue
            payload = {"status": "error", "error": str(exc)}
            if proxy_resolved:
                payload["proxy"] = str(proxy_resolved[2])
                payload["proxy_type"] = str(proxy_resolved[0])
            _write_status(status_file, payload)
            return 1
    if client is None:
        payload = {"status": "error", "error": str(last_exc or "failed to initialize Telegram client")}
        if proxy_resolved:
            payload["proxy"] = str(proxy_resolved[2])
            payload["proxy_type"] = str(proxy_resolved[0])
        _write_status(status_file, payload)
        return 1
    try:
        if await client.is_user_authorized():
            _write_status(
                status_file,
                {
                    "status": "authorized",
                    "updated_at_unix": int(time.time()),
                    "session_file": session_file,
                },
            )
            return 0

        qr = await client.qr_login()
        qr_url = str(qr.url or "").strip()
        if not qr_url:
            _write_status(status_file, {"status": "error", "error": "Empty QR URL"})
            return 2

        expires_at = int(time.time()) + int(max(30, args.timeout))
        if qrcode_mod is not None:
            img = qrcode_mod.make(qr_url)
            img.save(qr_file)
        else:
            qr_file.write_text(qr_url, encoding="utf-8")

        _write_status(
            status_file,
            {
                "status": "pending",
                "qr_url": qr_url,
                "qr_file": str(qr_file),
                "expires_at_unix": expires_at,
                "updated_at_unix": int(time.time()),
            },
        )

        try:
            await qr.wait(timeout=int(max(30, args.timeout)))
        except SessionPasswordNeededError:
            if not cloud_password:
                _write_status(
                    status_file,
                    {
                        "status": "error",
                        "error": "Cloud password required (2FA enabled).",
                        "updated_at_unix": int(time.time()),
                    },
                )
                return 4
            try:
                await client.sign_in(password=cloud_password)
            except Exception as exc:
                _write_status(
                    status_file,
                    {
                        "status": "error",
                        "error": f"Cloud password sign-in failed: {exc}",
                        "updated_at_unix": int(time.time()),
                    },
                )
                return 5
        except Exception as exc:
            _write_status(
                status_file,
                {
                    "status": "error",
                    "error": str(exc),
                    "updated_at_unix": int(time.time()),
                },
            )
            return 3

        _write_status(
            status_file,
            {
                "status": "authorized",
                "updated_at_unix": int(time.time()),
                "session_file": session_file,
            },
        )
        return 0
    finally:
        await client.disconnect()


def main() -> int:
    p = argparse.ArgumentParser(description="Owner TG QR login helper")
    p.add_argument("--api-id", type=int, required=True)
    p.add_argument("--api-hash", type=str, required=True)
    p.add_argument("--session-file", type=str, required=True)
    p.add_argument("--status-file", type=str, required=True)
    p.add_argument("--qr-file", type=str, required=True)
    p.add_argument("--timeout", type=int, default=180)
    p.add_argument("--cloud-password", type=str, default="")
    p.add_argument("--cloud-password-file", type=str, default="")
    p.add_argument("--proxy", type=str, default=str(os.getenv("OWNER_TG_PROXY", "") or ""))
    args = p.parse_args()
    return asyncio.run(_run(args))


if __name__ == "__main__":
    raise SystemExit(main())
