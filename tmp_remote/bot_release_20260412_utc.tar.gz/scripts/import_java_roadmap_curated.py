#!/usr/bin/env python3
from __future__ import annotations

"""
Импорт Java roadmap в формате как у golang:
- блоки и шаги в БД;
- каждый шаг открывает конкретное сообщение в группе.

Источник (topic 143):
- https://t.me/c/3730365848/143/145
"""

import argparse
import os
import sqlite3
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def _default_db_path() -> str:
    env_db = (os.getenv("DB_PATH") or "").strip()
    if env_db:
        return env_db
    prod_db = Path("/opt/mentor-bot/data/mentor_bot.db")
    if prod_db.exists():
        return str(prod_db)
    return "mentor_bot.db"


CHAT_ID = 3730365848
TOPIC_ID = 143

BLOCK_TITLES: dict[int, str] = {
    1: "Подготовка среды",
    2: "Блок 1. Вход в Java",
    3: "Блок 2. Core Java без дыр",
    4: "Блок 3. Рабочая разработка на Java",
    5: "Блок 4. Многопоточность и SQL",
    6: "Блок 5. Первый backend на Java",
    7: "Блок 6. Пет-проект",
}


def _msg_url(message_id: int) -> str:
    return f"https://t.me/c/{CHAT_ID}/{TOPIC_ID}/{int(message_id)}"


# Маппинг по сообщениям из треда.
STEPS: list[dict[str, object]] = [
    # Подготовка
    {"block": 1, "position": 1, "title": "Шаг 1. Установка лицензионной IDE от JetBrains", "message_id": 145},
    # Блок 1
    {"block": 2, "position": 1, "title": "Шаг 1. Что такое Java, JDK и первая программа", "message_id": 147},
    {"block": 2, "position": 2, "title": "Шаг 2. Все основы Java", "message_id": 148},
    {"block": 2, "position": 3, "title": "Шаг 3. Практика по базе Java", "message_id": 149},
    {"block": 2, "position": 4, "title": "Шаг 4. Дополнительное закрепление базы", "message_id": 150},
    {"block": 2, "position": 5, "title": "Шаг 5. Практика и самопроверка по первому блоку", "message_id": 151},
    # Блок 2
    {"block": 3, "position": 6, "title": "Шаг 6. Классы, объекты, наследование и интерфейсы", "message_id": 153},
    {"block": 3, "position": 7, "title": "Шаг 7. Исключения", "message_id": 154},
    {"block": 3, "position": 8, "title": "Шаг 8. Коллекции", "message_id": 155},
    {"block": 3, "position": 9, "title": "Шаг 9. Generics и Stream API", "message_id": 156},
    {"block": 3, "position": 10, "title": "Шаг 10. Практика и самопроверка по второму блоку", "message_id": 157},
    # Блок 3
    {"block": 4, "position": 11, "title": "Шаг 11. IntelliJ IDEA, debugger и чтение stack trace", "message_id": 159},
    {"block": 4, "position": 12, "title": "Шаг 12. JUnit 5", "message_id": 160},
    {"block": 4, "position": 13, "title": "Шаг 13. Maven", "message_id": 161},
    {"block": 4, "position": 14, "title": "Шаг 14. Практика и самопроверка по третьему блоку", "message_id": 162},
    # Блок 4
    {"block": 5, "position": 15, "title": "Шаг 15. Многопоточность", "message_id": 164},
    {"block": 5, "position": 16, "title": "Шаг 16. SQL с нуля", "message_id": 165},
    {"block": 5, "position": 17, "title": "Шаг 17. PostgreSQL и JDBC", "message_id": 166},
    {"block": 5, "position": 18, "title": "Шаг 18. Практика и самопроверка по четвертому блоку", "message_id": 167},
    # Блок 5
    {"block": 6, "position": 19, "title": "Шаг 19. Spring Boot с нуля", "message_id": 169},
    {"block": 6, "position": 21, "title": "Шаг 21. Практика по backend-блоку", "message_id": 170},
    # Блок 6
    {"block": 7, "position": 22, "title": "Шаг 22. Первый pet project", "message_id": 172},
]


def main() -> int:
    parser = argparse.ArgumentParser(description="Import java roadmap (topic style)")
    parser.add_argument("--direction", default="java", help="java|golang|frontend|python")
    parser.add_argument("--db-path", default=_default_db_path(), help="SQLite DB path")
    parser.add_argument("--tz", default=os.getenv("TZ", "Europe/Moscow"), help="Timezone for updated_at")
    parser.add_argument("--topic-id", type=int, default=TOPIC_ID, help="Forum topic id to map direction")
    parser.add_argument("--purge-direction", action="store_true", default=True, help="Replace all existing steps for direction")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    from app.db import repo_materials
    from app.db.schema import ensure_schema
    from app.services.timeutils import iso, now

    conn = sqlite3.connect(args.db_path)
    conn.row_factory = sqlite3.Row
    ensure_schema(conn)
    tz = str(args.tz or "Europe/Moscow")
    direction = repo_materials.normalize_direction(args.direction)
    if not direction:
        print("invalid --direction, use: java|golang|frontend|python", file=sys.stderr)
        return 2

    if args.dry_run:
        for s in STEPS:
            print(
                f"[DRY] {direction} | block {s['block']} | pos {s['position']} | "
                f"{s['title']} -> {_msg_url(int(s['message_id']))}"
            )
        print(f"DRY RUN complete: steps={len(STEPS)}")
        print(f"DB path: {args.db_path}")
        return 0

    if args.purge_direction:
        ts = iso(now(tz))
        conn.execute("DELETE FROM user_material_progress WHERE step_id IN (SELECT id FROM material_steps WHERE direction=?)", (direction,))
        conn.execute("DELETE FROM material_steps WHERE direction=?", (direction,))
        conn.commit()
        print(f"Purged existing steps for direction={direction}")

    inserted = 0
    for s in STEPS:
        block = int(s["block"])
        pos = int(s["position"])
        title = str(s["title"]).strip()
        message_url = _msg_url(int(s["message_id"]))
        block_title = BLOCK_TITLES.get(block, f"Блок {block}")
        repo_materials.upsert_auto_step(
            conn=conn,
            tz=tz,
            direction=direction,
            block_number=block,
            block_title=block_title,
            position=pos,
            title=title,
            message_url=message_url,
        )
        inserted += 1

    if int(args.topic_id or 0) > 0:
        repo_materials.set_topic_mapping(conn, direction, int(args.topic_id), tz)

    print(f"Imported/updated roadmap: direction={direction}, steps={inserted}")
    print(f"DB path: {args.db_path}")
    print(f"Topic mapping set: {direction} -> {int(args.topic_id or 0)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
