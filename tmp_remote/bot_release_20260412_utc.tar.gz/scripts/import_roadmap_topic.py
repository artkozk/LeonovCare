#!/usr/bin/env python3
"""
Одноразовый полный импорт roadmap из форум-топика супергруппы.

Почему не кнопка в боте: Bot API не отдаёт историю чата. Скрипт ходит в Telegram
от имени твоего аккаунта (MTProto) и читает все сообщения в топике.

  pip install telethon
  python scripts/import_roadmap_topic.py \\
    --api-id YOUR_API_ID --api-hash YOUR_HASH \\
    --chat-id -100xxxxxxxxxx --topic-id THREAD_ID \\
    --direction golang

API id/hash: https://my.telegram.org → API development tools
THREAD_ID: тот же, что topic_id в админке бота (id топика в группе).
"""
from __future__ import annotations

import argparse
import asyncio
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

_ROADMAP_RE_FULL = re.compile(
    r"[Бб]лок\s*(\d+)\s*[.,;:\-—|/\s]+[Шш]аг\s*(\d+)\s*[.,;:\-—|/\s]+(.+)",
    re.DOTALL,
)
_ROADMAP_RE_NOTEXT = re.compile(r"[Бб]лок\s*(\d+)\s*[.,;:\-—|/\s]+[Шш]аг\s*(\d+)\s*$")
_ROADMAP_RE_SHORT = re.compile(r"(\d+)[./](\d+)\.?\s+(.+)", re.DOTALL)
_ROADMAP_RE_SHORT_NOTEXT = re.compile(r"(\d+)[./](\d+)\s*$")


def parse_roadmap_message(text: str) -> tuple[int, int, str] | None:
    if not text or not text.strip():
        return None
    lines = text.strip().split("\n")
    first = lines[0].strip()
    m = _ROADMAP_RE_FULL.match(first)
    if m:
        return int(m.group(1)), int(m.group(2)), m.group(3).strip()
    m = _ROADMAP_RE_NOTEXT.match(first)
    if m and len(lines) > 1:
        t = lines[1].strip()
        if t:
            return int(m.group(1)), int(m.group(2)), t
    m = _ROADMAP_RE_SHORT.match(first)
    if m:
        return int(m.group(1)), int(m.group(2)), m.group(3).strip()
    m = _ROADMAP_RE_SHORT_NOTEXT.match(first)
    if m and len(lines) > 1:
        t = lines[1].strip()
        if t:
            return int(m.group(1)), int(m.group(2)), t
    return None


async def run() -> None:
    parser = argparse.ArgumentParser(description="Full roadmap import from forum topic (Telethon)")
    parser.add_argument("--api-id", type=int, required=True)
    parser.add_argument("--api-hash", required=True)
    parser.add_argument("--chat-id", type=int, required=True, help="Supergroup id, e.g. -100...")
    parser.add_argument("--topic-id", type=int, required=True, help="Forum thread / topic id")
    parser.add_argument("--direction", required=True, help="java|golang|frontend|python")
    parser.add_argument("--session", default="roadmap_import", help="Session file name (without .session)")
    args = parser.parse_args()

    try:
        from telethon import TelegramClient
    except ImportError:
        print("Установи: pip install telethon", file=sys.stderr)
        sys.exit(1)

    from app.config import load_config
    from app.db import connect
    from app.db import repo_materials
    from app.db.schema import ensure_schema

    cfg = load_config()
    conn = connect(cfg)
    ensure_schema(conn)
    tz = cfg.TZ
    d = repo_materials.normalize_direction(args.direction)
    if not d:
        print("direction должен быть: java, golang, frontend, python", file=sys.stderr)
        sys.exit(1)

    client = TelegramClient(args.session, args.api_id, args.api_hash)
    await client.start()
    n = 0
    skipped = 0
    # Старые сообщения первыми (от низа топика к верху в хронологии)
    async for msg in client.iter_messages(args.chat_id, reply_to=args.topic_id, reverse=True):
        if not msg or getattr(msg, "action", None):
            continue
        text = (getattr(msg, "message", None) or "").strip()
        if not text:
            skipped += 1
            continue
        parsed = parse_roadmap_message(text)
        if not parsed:
            skipped += 1
            continue
        block_n, step_n, title = parsed
        block_title = f"Блок {block_n}"
        url = repo_materials.build_message_url(args.chat_id, msg.id)
        existing = repo_materials.find_step_by_url(conn, url)
        if existing:
            repo_materials.update_step_full(
                conn,
                tz,
                int(existing["id"]),
                title=title,
                block_number=block_n,
                block_title=block_title,
                position=step_n,
            )
        else:
            repo_materials.upsert_auto_step(
                conn, tz, d, block_n, block_title, step_n, title, url
            )
        n += 1

    repo_materials.set_topic_mapping(conn, d, args.topic_id, tz)
    await client.disconnect()
    print(f"Готово: импортировано шагов с разметкой «Блок/Шаг»: {n}")
    print(f"Пропущено сообщений без подходящего текста: {skipped}")
    print(f"Топик привязан к направлению {d} (thread_id={args.topic_id}).")


if __name__ == "__main__":
    asyncio.run(run())
