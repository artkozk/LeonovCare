from __future__ import annotations

import argparse
import html
import json
import os
import re
import sys
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from owner_tg_process_replies import _openai_reply


def _load_json(path: Path, default: Any) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def _norm(text: str) -> str:
    return re.sub(r"\s+", " ", str(text or "").strip().lower())


def _load_guardrails(path: str) -> dict[str, Any]:
    p = Path(str(path or "").strip())
    if not p.exists() or not p.is_file():
        return {}
    raw = _load_json(p, {})
    return raw if isinstance(raw, dict) else {}


def _load_scenarios(path: str) -> list[dict[str, Any]]:
    p = Path(str(path or "").strip())
    if not p.exists() or not p.is_file():
        return []
    raw = _load_json(p, [])
    if not isinstance(raw, list):
        return []
    out: list[dict[str, Any]] = []
    for item in raw:
        if not isinstance(item, dict):
            continue
        name = str(item.get("name") or "").strip()
        inbound = str(item.get("inbound_text") or "").strip()
        if not name or not inbound:
            continue
        out.append(item)
    return out


def _check_scenario(result_text: str, scenario: dict[str, Any], llm_resp: dict[str, Any]) -> tuple[bool, list[str]]:
    errors: list[str] = []
    text_norm = _norm(result_text)

    exp_any = scenario.get("expect_any")
    if isinstance(exp_any, list) and exp_any:
        if not any(_norm(str(x)) in text_norm for x in exp_any if str(x).strip()):
            errors.append("expect_any_not_met")

    forbid = scenario.get("forbid")
    if isinstance(forbid, list) and forbid:
        for token in forbid:
            tok = _norm(str(token))
            if tok and tok in text_norm:
                errors.append(f"forbidden_found:{tok}")

    exp_review = scenario.get("expect_needs_review")
    if isinstance(exp_review, bool):
        got_review = bool(llm_resp.get("needs_review"))
        if got_review != exp_review:
            errors.append(f"needs_review_mismatch:{got_review}!={exp_review}")

    min_len = scenario.get("min_len")
    if isinstance(min_len, int) and min_len > 0:
        if len(result_text.strip()) < min_len:
            errors.append(f"too_short:{len(result_text.strip())}<{min_len}")

    return len(errors) == 0, errors


def _render_txt(report: dict[str, Any]) -> str:
    lines = [
        "AI тест-отчет",
        f"Провайдер: {report.get('provider')}",
        f"Модель: {report.get('model')}",
        f"Сценариев: {report.get('total')} | Пройдено: {report.get('passed')} | Провалено: {report.get('failed')}",
        f"LLM ok/failed: {report.get('llm_ok')}/{report.get('llm_failed')}",
        "",
    ]
    for i, d in enumerate(report.get("details") or [], start=1):
        status = "OK" if d.get("passed") else "FAIL"
        lines.append(f"{i}. {d.get('name')} [{status}]")
        lines.append(f"   inbound: {d.get('inbound_text')}")
        lines.append(f"   reply: {d.get('reply_text')}")
        if d.get("errors"):
            lines.append(f"   errors: {', '.join(d.get('errors') or [])}")
        if d.get("llm_error"):
            lines.append(f"   llm_error: {d.get('llm_error')}")
        lines.append("")
    return "\n".join(lines).strip() + "\n"


def _render_html(report: dict[str, Any]) -> str:
    rows: list[str] = []
    for d in report.get("details") or []:
        status = "OK" if d.get("passed") else "FAIL"
        rows.append(
            "<tr>"
            f"<td>{html.escape(str(d.get('name') or ''))}</td>"
            f"<td>{html.escape(status)}</td>"
            f"<td>{html.escape(str(d.get('inbound_text') or ''))}</td>"
            f"<td>{html.escape(str(d.get('reply_text') or ''))}</td>"
            f"<td>{html.escape(', '.join(d.get('errors') or []))}</td>"
            f"<td>{html.escape(str(d.get('llm_error') or ''))}</td>"
            "</tr>"
        )
    return (
        "<!doctype html><html><head><meta charset='utf-8'>"
        "<title>AI test report</title>"
        "<style>body{font-family:Arial,sans-serif;padding:16px}table{border-collapse:collapse;width:100%}"
        "th,td{border:1px solid #ccc;padding:8px;vertical-align:top}th{background:#f4f4f4}</style>"
        "</head><body>"
        f"<h2>AI тест-отчет</h2>"
        f"<p>Провайдер: <b>{html.escape(str(report.get('provider') or ''))}</b><br>"
        f"Модель: <b>{html.escape(str(report.get('model') or ''))}</b><br>"
        f"Сценариев: <b>{report.get('total')}</b> | Пройдено: <b>{report.get('passed')}</b> | Провалено: <b>{report.get('failed')}</b><br>"
        f"LLM ok/failed: <b>{report.get('llm_ok')}/{report.get('llm_failed')}</b></p>"
        "<table><thead><tr><th>Сценарий</th><th>Статус</th><th>Входящее</th><th>Ответ</th><th>Ошибки</th><th>LLM ошибка</th></tr></thead>"
        f"<tbody>{''.join(rows)}</tbody></table>"
        "</body></html>"
    )


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--provider", type=str, default="proxy")
    p.add_argument("--base-url", type=str, default="")
    p.add_argument("--http-proxy", type=str, default="")
    p.add_argument("--model", type=str, default="gpt-5.4-mini")
    p.add_argument("--timeout-sec", type=int, default=30)
    p.add_argument("--strict-mode", type=int, default=1)
    p.add_argument("--scenarios-file", type=str, required=True)
    p.add_argument("--guardrails-file", type=str, default="")
    p.add_argument("--report-json", type=str, required=True)
    p.add_argument("--report-txt", type=str, required=True)
    p.add_argument("--report-html", type=str, required=True)
    args = p.parse_args()

    scenarios = _load_scenarios(args.scenarios_file)
    if not scenarios:
        Path(args.report_json).write_text(
            json.dumps({"status": "failed", "error": "no_scenarios"}, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        return 2

    api_key = str(os.getenv("OWNER_OPENAI_API_KEY", "") or "").strip()
    proxy_auth = str(os.getenv("OWNER_AI_PROXY_AUTH", "") or "").strip()
    http_proxy = str(args.http_proxy or os.getenv("OWNER_AI_HTTP_PROXY", "") or "").strip()
    guardrails = _load_guardrails(args.guardrails_file)

    report: dict[str, Any] = {
        "status": "done",
        "provider": str(args.provider or "").strip().lower() or "proxy",
        "model": str(args.model or "").strip() or "gpt-5.4-mini",
        "total": 0,
        "passed": 0,
        "failed": 0,
        "llm_ok": 0,
        "llm_failed": 0,
        "details": [],
    }

    for scenario in scenarios:
        name = str(scenario.get("name") or "").strip() or "scenario"
        inbound = str(scenario.get("inbound_text") or "").strip()
        direction = str(scenario.get("direction") or "python").strip().lower()
        ai_step = int(scenario.get("ai_step") or 1)
        script_step_text = str(scenario.get("script_step_text") or "").strip()
        previous_outbound = str(scenario.get("previous_outbound_text") or "").strip()
        chat_history = str(scenario.get("chat_history") or "").strip()
        force_booking = bool(scenario.get("force_booking_cta"))
        report["total"] = int(report["total"]) + 1

        llm_resp = _openai_reply(
            provider=args.provider,
            base_url=args.base_url,
            proxy_auth=proxy_auth,
            api_key=api_key,
            http_proxy=http_proxy,
            model=args.model,
            script_step_text=script_step_text,
            inbound_text=inbound,
            direction=direction,
            ai_step=ai_step,
            previous_outbound_text=previous_outbound,
            chat_history=chat_history,
            force_booking_cta=force_booking,
            examples=[],
            guardrails=guardrails,
            strict_mode=bool(int(args.strict_mode or 0)),
            timeout_sec=max(5, int(args.timeout_sec or 30)),
        )
        llm_status = str(llm_resp.get("llm_status") or "").strip().lower()
        if llm_status == "ok":
            report["llm_ok"] = int(report["llm_ok"]) + 1
        elif llm_status:
            report["llm_failed"] = int(report["llm_failed"]) + 1

        reply_text = str(llm_resp.get("text") or "").strip()
        ok, errors = _check_scenario(reply_text, scenario, llm_resp)
        if ok:
            report["passed"] = int(report["passed"]) + 1
        else:
            report["failed"] = int(report["failed"]) + 1
        report["details"].append(
            {
                "name": name,
                "direction": direction,
                "inbound_text": inbound,
                "reply_text": reply_text,
                "passed": ok,
                "errors": errors,
                "needs_review": bool(llm_resp.get("needs_review")),
                "decision_source": str(llm_resp.get("decision_source") or ""),
                "llm_status": llm_status,
                "llm_code": int(llm_resp.get("llm_code") or 0),
                "llm_error": str(llm_resp.get("llm_error") or ""),
            }
        )

    Path(args.report_json).write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    Path(args.report_txt).write_text(_render_txt(report), encoding="utf-8")
    Path(args.report_html).write_text(_render_html(report), encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
