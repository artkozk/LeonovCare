from __future__ import annotations

import argparse
import asyncio
import datetime as dt
import json
import os
import random
import sys
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from app.services.tg_proxy import build_client_kwargs


REACTIONS = ["🏆", "🔥", "💯", "👍", "🤝"]
MIN_REACTION_AGE_SEC = 10 * 60


def _message_age_sec(message: Any) -> float | None:
    ts = getattr(message, "date", None)
    if ts is None:
        return None
    if not isinstance(ts, dt.datetime):
        return None
    if ts.tzinfo is None:
        ts = ts.replace(tzinfo=dt.timezone.utc)
    now_utc = dt.datetime.now(dt.timezone.utc)
    return max((now_utc - ts.astimezone(dt.timezone.utc)).total_seconds(), 0.0)


def _session_locked(exc: Exception) -> bool:
    return "database is locked" in str(exc or "").lower()


def _cleanup_session_locks(session_file: str) -> None:
    base = Path(str(session_file)).expanduser().resolve()
    for suffix in ("-journal", "-wal", "-shm"):
        p = Path(str(base) + suffix)
        try:
            if p.exists():
                p.unlink()
        except Exception:
            pass


async def _run(args: argparse.Namespace) -> int:
    try:
        from telethon import TelegramClient, functions, types
    except Exception as exc:
        Path(args.report_file).write_text(
            json.dumps({"status": "failed", "error": f"telethon import error: {exc}"}, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        return 1

    report: dict[str, Any] = {
        "status": "done",
        "channel": args.channel,
        "processed_messages": 0,
        "ok": 0,
        "failed": 0,
        "details": [],
    }
    proxy_raw = (
        str(getattr(args, "proxy", "") or "").strip()
        or str(os.getenv("OWNER_TG_PROXY") or "").strip()
        or str(os.getenv("OWNER_TG_MTPROXY") or "").strip()
    )
    client_kwargs, proxy_resolved = build_client_kwargs(proxy_raw)
    report["proxy_used"] = bool(proxy_resolved)
    report["proxy"] = str(proxy_resolved[2]) if proxy_resolved else ""
    report["proxy_type"] = str(proxy_resolved[0]) if proxy_resolved else ""

    session_file = str(Path(args.session_file).expanduser().resolve())
    client = None
    last_exc: Exception | None = None
    for attempt in range(2):
        try:
            client = TelegramClient(session_file, int(args.api_id), str(args.api_hash), **client_kwargs)
            await client.connect()
            break
        except Exception as exc:
            last_exc = exc
            if client is not None:
                try:
                    await client.disconnect()
                except Exception:
                    pass
            if attempt == 0 and _session_locked(exc):
                _cleanup_session_locks(session_file)
                await asyncio.sleep(0.3)
                continue
            raise
    if client is None:
        raise RuntimeError(str(last_exc or "failed to initialize Telegram client"))
    try:
        if not await client.is_user_authorized():
            report["status"] = "failed"
            report["error"] = "Session not authorized"
            Path(args.report_file).write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
            return 2

        channel = str(args.channel or "").strip()
        if not channel:
            report["status"] = "failed"
            report["error"] = "empty channel"
            Path(args.report_file).write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
            return 3
        if channel.startswith("https://t.me/"):
            channel = channel.replace("https://t.me/", "", 1)
        channel = channel.replace("t.me/", "").lstrip("@")
        peer = await client.get_entity(channel)

        limit = max(1, min(int(args.limit or 0), 100))
        messages = await client.get_messages(peer, limit=limit)
        for msg in messages:
            if not getattr(msg, "id", None):
                continue
            if not (getattr(msg, "message", None) or getattr(msg, "media", None)):
                continue
            age_sec = _message_age_sec(msg)
            if age_sec is not None and age_sec < MIN_REACTION_AGE_SEC:
                continue
            report["processed_messages"] += 1
            selected = random.sample(REACTIONS, k=min(3, len(REACTIONS)))
            # Одна заявка SendReaction со списком emoji — иначе каждый следующий вызов
            # перезаписывает предыдущую реакцию пользователя на сообщении.
            item = {
                "message_id": int(msg.id),
                "reaction": ",".join(selected),
                "status": "ok",
                "error": "",
            }
            try:
                await client(
                    functions.messages.SendReactionRequest(
                        peer=peer,
                        msg_id=int(msg.id),
                        big=False,
                        add_to_recent=True,
                        reaction=[types.ReactionEmoji(emoticon=emo) for emo in selected],
                    )
                )
                report["ok"] += 1
            except Exception as exc:
                item["status"] = "failed"
                item["error"] = str(exc)
                report["failed"] += 1
            report["details"].append(item)

        Path(args.report_file).write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        return 0
    finally:
        await client.disconnect()


def main() -> int:
    p = argparse.ArgumentParser(description="Put reactions on channel posts")
    p.add_argument("--api-id", type=int, required=True)
    p.add_argument("--api-hash", type=str, required=True)
    p.add_argument("--session-file", type=str, required=True)
    p.add_argument("--channel", type=str, required=True)
    p.add_argument("--limit", type=int, default=10)
    p.add_argument("--report-file", type=str, required=True)
    p.add_argument("--proxy", type=str, default=str(os.getenv("OWNER_TG_PROXY", "") or ""))
    args = p.parse_args()
    return asyncio.run(_run(args))


if __name__ == "__main__":
    raise SystemExit(main())
