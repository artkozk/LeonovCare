from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

import requests

logger = logging.getLogger(__name__)


@dataclass(slots=True)
class InterviewHelperClientError(RuntimeError):
    message: str
    status_code: int | None = None
    body: str = ""

    def __str__(self) -> str:
        code = f" (HTTP {self.status_code})" if self.status_code is not None else ""
        tail = f": {self.body}" if self.body else ""
        return f"{self.message}{code}{tail}"


class InterviewHelperClient:
    def __init__(
        self,
        base_url: str,
        admin_username: str,
        admin_password: str,
        timeout_sec: int = 20,
    ) -> None:
        self.base_url = (base_url or "").strip().rstrip("/")
        self.admin_username = (admin_username or "").strip()
        self.admin_password = (admin_password or "").strip()
        self.timeout_sec = max(int(timeout_sec or 20), 5)
        self._cached_token: str = ""
        self._cached_token_expires_at: datetime | None = None

    @property
    def enabled(self) -> bool:
        return bool(self.base_url and self.admin_username and self.admin_password)

    def _request(
        self,
        method: str,
        path: str,
        payload: dict[str, Any] | None = None,
        token: str | None = None,
    ) -> dict[str, Any]:
        if not self.base_url:
            raise InterviewHelperClientError("Не настроен base_url Interview Helper")
        url = f"{self.base_url}{path}"
        headers = {"Content-Type": "application/json"}
        if token:
            headers["Authorization"] = f"Bearer {token}"
        req_body = json.dumps(payload or {}, ensure_ascii=False)
        logger.info("[INTERVIEW][HTTP_REQ] method=%s url=%s body=%s", method.upper(), url, req_body)
        try:
            resp = requests.request(
                method=method.upper(),
                url=url,
                headers=headers,
                json=payload,
                timeout=self.timeout_sec,
            )
        except requests.RequestException as exc:
            logger.exception(
                "[INTERVIEW][HTTP_ERR] method=%s url=%s body=%s err=%s",
                method.upper(),
                url,
                req_body,
                type(exc).__name__,
            )
            raise InterviewHelperClientError("Не удалось связаться с Interview Helper API") from exc

        body = (resp.text or "").strip()
        logger.info(
            "[INTERVIEW][HTTP_RESP] method=%s url=%s status=%s body=%s",
            method.upper(),
            url,
            resp.status_code,
            body,
        )
        if resp.status_code >= 400:
            if path == "/api/v1/admin/login" and resp.status_code == 404:
                raise InterviewHelperClientError(
                    "Interview Helper API не содержит endpoint /api/v1/admin/login (несовместимая версия сервиса)",
                    status_code=resp.status_code,
                    body=body[:500],
                )
            raise InterviewHelperClientError(
                "Interview Helper API вернул ошибку",
                status_code=resp.status_code,
                body=body[:500],
            )
        if not body:
            return {}
        try:
            data = resp.json()
        except Exception as exc:
            raise InterviewHelperClientError(
                "Interview Helper API вернул не-JSON ответ",
                status_code=resp.status_code,
                body=body[:500],
            ) from exc
        if isinstance(data, dict):
            return data
        return {"data": data}

    def _login(self) -> tuple[str, datetime | None]:
        if not self.enabled:
            raise InterviewHelperClientError("Интеграция Interview Helper не настроена")
        data = self._request(
            "POST",
            "/api/v1/admin/login",
            payload={
                "username": self.admin_username,
                "password": self.admin_password,
            },
        )
        token = str(data.get("token") or "").strip()
        if not token:
            raise InterviewHelperClientError("Interview Helper не вернул токен администратора")
        expires_raw = str(data.get("expiresAt") or "").strip()
        expires_at: datetime | None = None
        if expires_raw:
            try:
                expires_at = datetime.fromisoformat(expires_raw.replace("Z", "+00:00"))
            except Exception:
                expires_at = None
        return token, expires_at

    def _token(self) -> str:
        if self._cached_token:
            exp = self._cached_token_expires_at
            if exp is not None and exp.tzinfo is None:
                exp = exp.replace(tzinfo=timezone.utc)
            if exp is None or exp > datetime.now(timezone.utc):
                return self._cached_token
        token, expires_at = self._login()
        self._cached_token = token
        self._cached_token_expires_at = expires_at
        return token

    def create_license(self, plan: str, expires_at: str, note: str | None = None) -> dict[str, Any]:
        token = self._token()
        payload = {
            "plan": (plan or "PRO").strip() or "PRO",
            "expiresAt": (expires_at or "").strip(),
            "note": (note or "").strip(),
        }
        return self._request(
            "POST",
            "/api/v1/admin/licenses",
            payload=payload,
            token=token,
        )

    def check_license_status(self, license_key: str) -> dict[str, Any]:
        key = (license_key or "").strip()
        if not key:
            raise InterviewHelperClientError("Не передан лицензионный ключ")
        url = f"{self.base_url}/api/v1/license/status"
        logger.info("[INTERVIEW][HTTP_REQ] method=GET url=%s body={\"X-License-Key\":\"%s\"}", url, key)
        try:
            resp = requests.get(
                url,
                headers={"X-License-Key": key},
                timeout=self.timeout_sec,
            )
        except requests.RequestException as exc:
            logger.exception(
                "[INTERVIEW][HTTP_ERR] method=GET url=%s body={\"X-License-Key\":\"%s\"} err=%s",
                url,
                key,
                type(exc).__name__,
            )
            raise InterviewHelperClientError("Не удалось проверить статус лицензии") from exc
        body = (resp.text or "").strip()
        logger.info(
            "[INTERVIEW][HTTP_RESP] method=GET url=%s status=%s body=%s",
            url,
            resp.status_code,
            body,
        )
        if resp.status_code >= 400:
            raise InterviewHelperClientError(
                "Interview Helper API вернул ошибку при проверке лицензии",
                status_code=resp.status_code,
                body=body[:500],
            )
        if not body:
            return {}
        try:
            data = resp.json()
        except Exception as exc:
            raise InterviewHelperClientError(
                "Interview Helper API вернул не-JSON статус лицензии",
                status_code=resp.status_code,
                body=body[:500],
            ) from exc
        if isinstance(data, dict):
            return data
        return {"data": data}
