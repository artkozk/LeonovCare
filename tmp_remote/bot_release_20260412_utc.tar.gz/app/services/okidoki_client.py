from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from io import BytesIO
import re
from typing import Any
from urllib.parse import urlparse

import requests


@dataclass(slots=True)
class OkiDokiClientError(RuntimeError):
    message: str
    status_code: int | None = None
    body: str = ""

    def __str__(self) -> str:
        code = f" (HTTP {self.status_code})" if self.status_code is not None else ""
        tail = f": {self.body}" if self.body else ""
        return f"{self.message}{code}{tail}"


class OkiDokiClient:
    def __init__(self, create_contract_url: str, api_token: str, timeout_sec: int = 30) -> None:
        self.create_contract_url = (create_contract_url or "").strip()
        self.api_token = (api_token or "").strip()
        self.timeout_sec = max(int(timeout_sec or 30), 5)

    @property
    def _default_create_url(self) -> str:
        return "https://api.doki.online/external/contract"

    def _resolve_create_url(self) -> str:
        raw = str(self.create_contract_url or "").strip()
        if not raw:
            return self._default_create_url

        low = raw.lower()
        if "/swagger-ui/" in low:
            raw = raw[: low.index("/swagger-ui/")]
            low = raw.lower()
        if low.endswith("/docs"):
            raw = raw[: -len("/docs")]
            low = raw.lower()
        if low.endswith("/docs/"):
            raw = raw[: -len("/docs/")]

        parsed = urlparse(raw)
        if not parsed.scheme or not parsed.netloc:
            return self._default_create_url
        path = str(parsed.path or "").strip()
        if not path or path == "/":
            return f"{parsed.scheme}://{parsed.netloc}/external/contract"
        return raw

    @staticmethod
    def _looks_like_official_external_contract(url: str) -> bool:
        try:
            parsed = urlparse(str(url or "").strip())
        except Exception:
            return False
        host = str(parsed.netloc or "").lower()
        path = str(parsed.path or "").lower()
        return "doki.online" in host and path.rstrip("/") == "/external/contract"

    @staticmethod
    def _parse_tariff_from_payload(payload: dict[str, Any]) -> dict[str, Any]:
        tariff_price = str(payload.get("tariff_price") or "").strip()
        if "/" in tariff_price:
            # Для мульти-офферов ("60k +100% / 30k +150%") берем первый вариант.
            tariff_price = str(tariff_price.split("/", 1)[0]).strip()
        tariff_key = str(payload.get("tariff_key") or "").strip().lower()
        level = str(payload.get("level") or payload.get("level_key") or "").strip().lower()
        out: dict[str, Any] = {
            "tariff_type": "",
            "prepay": 0,
            "post_total_percent": 0.0,
            "post_monthly_percent": 0.0,
            "stage": "С нуля" if level == "zero" else ("Дообучение" if level else ""),
        }

        def _money(s: str) -> int:
            digits = "".join(ch for ch in (s or "") if ch.isdigit())
            try:
                return int(digits) if digits else 0
            except Exception:
                return 0

        percents: list[float] = []
        for m in re.finditer(r"(\d{1,3}(?:[.,]\d+)?)\s*%", tariff_price):
            try:
                percents.append(float(str(m.group(1)).replace(",", ".")))
            except Exception:
                continue
        out["post_total_percent"] = float(percents[0]) if percents else 0.0
        out["post_monthly_percent"] = float(percents[1]) if len(percents) > 1 else (50.0 if percents else 0.0)

        prepay = 0
        if "+" in tariff_price:
            prepay = _money(tariff_price.split("+", 1)[0])
        elif "₽" in tariff_price or "руб" in tariff_price.lower():
            prepay = _money(tariff_price)
        elif _money(tariff_price) > 0 and not percents:
            # На части шаблонов цена приходит просто числом без "₽"/"руб".
            prepay = _money(tariff_price)
        out["prepay"] = int(prepay or 0)

        if out["prepay"] > 0 and out["post_total_percent"] > 0:
            out["tariff_type"] = "pre_post"
        elif out["post_total_percent"] > 0:
            out["tariff_type"] = "post"
        elif out["prepay"] > 0:
            out["tariff_type"] = "pre"
        elif tariff_key in {"a100"}:
            out["tariff_type"] = "pre_post"
            out["prepay"] = 60000
            if out["post_total_percent"] <= 0:
                out["post_total_percent"] = 100.0
            if out["post_monthly_percent"] <= 0:
                out["post_monthly_percent"] = 50.0
        return out

    @staticmethod
    def _fallback_contract_body(payload: dict[str, Any]) -> str:
        track_title = str(payload.get("track_title") or payload.get("track_key") or "обучение").strip()
        tariff_title = str(payload.get("tariff_title") or payload.get("tariff_key") or "тариф").strip()
        tariff_price = str(payload.get("tariff_price") or "по согласованию").strip()
        direction = str(payload.get("direction") or payload.get("specialization") or track_title or "").strip()
        tariff_meta = OkiDokiClient._parse_tariff_from_payload(payload)
        user_id = str(payload.get("user_id") or "").strip()
        username = str(payload.get("username") or "").strip().lstrip("@")
        user_ref = f"@{username}" if username else (f"tg:{user_id}" if user_id else "не указан")
        today = date.today().strftime("%d.%m.%Y")
        tariff_type = str(tariff_meta.get("tariff_type") or "").strip()
        prepay = int(tariff_meta.get("prepay") or 0)
        post_total = float(tariff_meta.get("post_total_percent") or 0.0)
        post_monthly = float(tariff_meta.get("post_monthly_percent") or 0.0)
        stage = str(tariff_meta.get("stage") or "").strip()
        return (
            "Договор на оказание услуг менторского сопровождения.\n"
            f"Направление: {direction}.\n"
            f"Этап: {stage or 'Дообучение'}.\n"
            f"Тариф: {tariff_title}.\n"
            f"Стоимость: {tariff_price}.\n"
            f"Тариф_тип: {tariff_type or 'pre_post'}.\n"
            f"Предоплата_руб: {prepay}.\n"
            f"Постоплата_всего_%: {post_total}.\n"
            f"Постоплата_в_месяц_%: {post_monthly}.\n"
            f"Клиент (Telegram): {user_ref}.\n"
            f"Дата формирования: {today}."
        )

    def _auth_headers(self) -> dict[str, str]:
        headers = {"Accept": "application/json"}
        if self.api_token:
            headers["Authorization"] = f"Bearer {self.api_token}"
            headers["X-API-KEY"] = self.api_token
        return headers

    def list_templates(self) -> list[dict[str, str]]:
        if not self.api_token:
            raise OkiDokiClientError("Не задан OKIDOKI_API_TOKEN для получения шаблонов")
        try:
            resp = requests.get(
                "https://api.doki.online/external/templates",
                params={"api_key": self.api_token},
                headers=self._auth_headers(),
                timeout=self.timeout_sec,
            )
        except requests.RequestException as exc:
            raise OkiDokiClientError("Не удалось получить список шаблонов OkiDoki") from exc
        body = (resp.text or "").strip()
        if resp.status_code >= 400:
            raise OkiDokiClientError(
                "OkiDoki не вернул список шаблонов",
                status_code=resp.status_code,
                body=body[:500],
            )
        try:
            data = resp.json()
        except Exception as exc:
            raise OkiDokiClientError("Список шаблонов OkiDoki вернул не-JSON") from exc
        raw_items = data.get("templates") if isinstance(data, dict) else []
        out: list[dict[str, str]] = []
        for item in raw_items or []:
            if not isinstance(item, dict):
                continue
            template_id = str(item.get("template_id") or item.get("id") or "").strip()
            template_name = str(
                item.get("template_name") or item.get("name") or item.get("template_full_name") or ""
            ).strip()
            if not template_id:
                continue
            out.append({"template_id": template_id, "template_name": template_name})
        return out

    def get_template_entities(self, template_id: str) -> list[dict[str, Any]]:
        tid = str(template_id or "").strip()
        if not tid:
            return []
        if not self.api_token:
            raise OkiDokiClientError("Не задан OKIDOKI_API_TOKEN для чтения полей шаблона")
        try:
            resp = requests.get(
                "https://api.doki.online/external/get-template-entities",
                params={"api_key": self.api_token, "template_id": tid},
                headers=self._auth_headers(),
                timeout=self.timeout_sec,
            )
        except requests.RequestException as exc:
            raise OkiDokiClientError("Не удалось получить поля шаблона OkiDoki") from exc
        body = (resp.text or "").strip()
        if resp.status_code >= 400:
            raise OkiDokiClientError(
                "OkiDoki не вернул поля шаблона",
                status_code=resp.status_code,
                body=body[:500],
            )
        try:
            data = resp.json()
        except Exception as exc:
            raise OkiDokiClientError("Поля шаблона OkiDoki вернули не-JSON") from exc
        entities = data.get("entities") if isinstance(data, dict) else []
        return [e for e in (entities or []) if isinstance(e, dict)]

    @staticmethod
    def _pick_template_id(templates: list[dict[str, str]], tariff_type: str) -> str:
        by_num: dict[int, str] = {}
        for t in templates:
            name = str(t.get("template_name") or "").strip()
            tid = str(t.get("template_id") or "").strip()
            if not tid:
                continue
            m = re.search(r"шаблон\s+обучение\s+(\d+)", name, flags=re.IGNORECASE)
            if m:
                try:
                    by_num[int(m.group(1))] = tid
                except Exception:
                    pass
        preferred: list[int]
        if tariff_type == "post":
            preferred = [3, 5]
        elif tariff_type == "pre":
            preferred = [2, 1, 4, 7]
        else:
            preferred = [1, 4, 7, 2]
        for num in preferred:
            tid = by_num.get(num)
            if tid:
                return tid
        for t in templates:
            tid = str(t.get("template_id") or "").strip()
            if tid:
                return tid
        return ""

    def prepare_enroll_contract_payload(self, payload: dict[str, Any]) -> dict[str, Any]:
        """
        Формирует payload строго под официальный шаблон OkiDoki.
        Здесь НЕ используется fallback-body: только template_id + entities.
        """
        src = dict(payload or {})
        tariff_meta = self._parse_tariff_from_payload(src)
        tariff_type = str(tariff_meta.get("tariff_type") or "").strip().lower() or "pre_post"
        templates = self.list_templates()
        template_id = self._pick_template_id(templates, tariff_type)
        if not template_id:
            raise OkiDokiClientError("В OkiDoki не найден ни один шаблон договора")
        entities_meta = self.get_template_entities(template_id)

        direction = str(src.get("direction") or src.get("track_title") or src.get("track_key") or "Обучение").strip()
        username = str(src.get("username") or "").strip().lstrip("@")
        user_id = str(src.get("user_id") or src.get("chat_id") or "").strip()
        tg_ref = f"@{username}" if username else (f"tg:{user_id}" if user_id else "")
        prepay = int(tariff_meta.get("prepay") or 0)
        post_total = float(tariff_meta.get("post_total_percent") or 0.0)
        post_monthly = float(tariff_meta.get("post_monthly_percent") or 0.0)
        post_months = 0
        if post_total > 0 and post_monthly > 0:
            try:
                post_months = max(1, int(round(post_total / post_monthly)))
            except Exception:
                post_months = 0

        value_by_keyword: dict[str, str] = {
            "область": direction,
            "телеграм клиента": tg_ref,
            "предоплата": str(prepay),
            "дата предоплаты": date.today().strftime("%d.%m.%Y"),
            "количество месяцев постоплаты": str(post_months),
        }

        entities: list[dict[str, Any]] = []
        for e in entities_meta:
            keyword = str(e.get("keyword") or e.get("name") or "").strip()
            key_norm = keyword.lower()
            if not key_norm:
                continue
            value = value_by_keyword.get(key_norm)
            if value is None:
                continue
            item: dict[str, Any] = {"keyword": keyword, "value": value}
            eid = str(e.get("id") or "").strip()
            if eid:
                item["id"] = eid
            entities.append(item)

        if not entities:
            raise OkiDokiClientError("У выбранного шаблона OkiDoki не удалось определить поля для заполнения")

        out = dict(src)
        out["template_id"] = template_id
        out["entities"] = entities
        out.pop("body", None)
        if not str(out.get("external_id") or "").strip():
            uid = str(out.get("user_id") or out.get("chat_id") or "unknown").strip()
            tariff_key = str(out.get("tariff_key") or "plan").strip()
            out["external_id"] = f"tg_{uid}_{tariff_key}"
        return out

    def _download_contract_pdf(self, contract_id: str) -> bytes | None:
        if not self.api_token:
            return None
        cid = str(contract_id or "").strip()
        if not cid:
            return None
        url = f"https://api.doki.online/external/contracts/{cid}/download"
        headers = {"X-API-KEY": self.api_token, "Accept": "application/pdf"}
        try:
            resp = requests.get(url, headers=headers, timeout=self.timeout_sec)
        except requests.RequestException:
            return None
        if resp.status_code >= 400:
            return None
        data = resp.content or b""
        if len(data) < 20:
            return None
        return data

    @staticmethod
    def _extract_profile_hints_from_pdf(pdf_bytes: bytes) -> dict[str, Any]:
        if not pdf_bytes:
            return {}
        try:
            from pypdf import PdfReader  # type: ignore
        except Exception:
            return {}

        try:
            reader = PdfReader(BytesIO(pdf_bytes))
            text = "\n".join((page.extract_text() or "") for page in reader.pages[:6])
        except Exception:
            return {}

        raw_text = str(text or "")
        if not raw_text.strip():
            return {}
        normalized = " ".join(raw_text.replace("\xa0", " ").split())
        lowered = normalized.lower()
        out: dict[str, Any] = {}

        m_direction = re.search(
            r"(?:в|по)\s+области\s+(.{2,90}?)(?:\s*\(далее|\s*[.;,])",
            normalized,
            flags=re.IGNORECASE,
        )
        if m_direction:
            direction = str(m_direction.group(1) or "").strip(" \t\n\r-–—")
            direction = direction.replace("  ", " ")
            if direction and "{" not in direction and "}" not in direction:
                out["direction"] = direction

        # Частый формат в "юридическом" шаблоне: «ЗАКАЗЧИК - Гражданин ФИО ...»
        m_fio = re.search(
            r"гражданин\s+([А-ЯЁA-Z][А-ЯЁA-Zа-яёa-z-]+(?:\s+[А-ЯЁA-Z][А-ЯЁA-Zа-яёa-z-]+){1,3})",
            normalized,
            flags=re.IGNORECASE,
        )
        if m_fio:
            fio = str(m_fio.group(1) or "").strip(" \t\n\r,.;:()")
            if fio and "{" not in fio and "}" not in fio:
                out["fio"] = fio

        # Стадию извлекаем только по явным сигналам, чтобы не ловить ложные
        # срабатывания на общие слова в теле договора (например, "собеседования"
        # часто встречается в описании услуг).
        m_stage_hint = re.search(
            r"(?:этап|уровень|стадия)[^:\n\r]{0,40}[:\-]?\s*([^\n\r.;,]{2,80})",
            normalized,
            flags=re.IGNORECASE,
        )
        stage_hint = str(m_stage_hint.group(1) or "").strip().lower() if m_stage_hint else ""
        if stage_hint:
            if "с нуля" in stage_hint or "zero" in stage_hint:
                out["stage"] = "С нуля"
            elif "дообуч" in stage_hint or "not_zero" in stage_hint:
                out["stage"] = "Дообучение"
            elif "собесед" in stage_hint or "interview" in stage_hint:
                out["stage"] = "Собеседования"
        elif "с нуля" in lowered:
            out["stage"] = "С нуля"
        elif "дообуч" in lowered:
            out["stage"] = "Дообучение"

        m_dir_label = re.search(r"направление\s*:\s*([^\n\r]+)", raw_text, flags=re.IGNORECASE)
        if m_dir_label:
            direction = str(m_dir_label.group(1) or "").strip(" \t\n\r.;,")
            if direction and "{" not in direction and "}" not in direction:
                out["direction"] = direction

        m_stage_label = re.search(r"этап\s*:\s*([^\n\r]+)", raw_text, flags=re.IGNORECASE)
        if m_stage_label:
            stage = str(m_stage_label.group(1) or "").strip().lower()
            if "с нуля" in stage:
                out["stage"] = "С нуля"
            elif "дообуч" in stage:
                out["stage"] = "Дообучение"
            elif "собесед" in stage:
                out["stage"] = "Собеседования"

        m_tariff_type = re.search(r"тариф_тип\s*:\s*([^\n\r]+)", raw_text, flags=re.IGNORECASE)
        if m_tariff_type:
            t = str(m_tariff_type.group(1) or "").strip().lower()
            if t in {"pre", "post", "pre_post"}:
                out["tariff"] = t

        def _to_int_money(raw: str | None) -> int | None:
            digits = "".join(ch for ch in str(raw or "") if ch.isdigit())
            if not digits:
                return None
            try:
                val = int(digits)
            except Exception:
                return None
            return val if val > 0 else None

        def _to_float_percent(raw: str | None) -> float | None:
            txt = str(raw or "").replace(",", ".").strip()
            if not txt:
                return None
            try:
                val = float(txt)
            except Exception:
                return None
            return val if val > 0 else None

        prepay = None
        m_prepay = re.search(
            r"предоплат[аы][^\d]{0,80}(\d[\d\s]{2,})\s*(?:₽|руб|рубл)",
            lowered,
            flags=re.IGNORECASE,
        )
        if m_prepay:
            prepay = _to_int_money(m_prepay.group(1))

        post_total_percent = None
        m_post_total = re.search(
            r"постоплат[аы][^%]{0,140}(\d{1,3}(?:[.,]\d+)?)\s*%",
            lowered,
            flags=re.IGNORECASE,
        )
        if m_post_total:
            post_total_percent = _to_float_percent(m_post_total.group(1))
        if post_total_percent is None:
            m_offer_percent = re.search(
                r"(\d{1,3}(?:[.,]\d+)?)\s*%[^.]{0,80}(?:оффер|доход|зарплат|вознагражден)",
                lowered,
                flags=re.IGNORECASE,
            )
            if m_offer_percent:
                post_total_percent = _to_float_percent(m_offer_percent.group(1))
        if post_total_percent is None:
            # В ряде шаблонов процент указан без символа "%":
            # "Пост-оплата 100 от активного дохода ...".
            m_post_plain = re.search(
                r"пост-?оплат[аы][^\d]{0,50}(\d{1,3}(?:[.,]\d+)?)\b",
                lowered,
                flags=re.IGNORECASE,
            )
            if m_post_plain:
                post_total_percent = _to_float_percent(m_post_plain.group(1))

        post_monthly_percent = None
        m_monthly = re.search(
            r"(\d{1,3}(?:[.,]\d+)?)\s*%[^.]{0,80}(?:в\s*месяц|ежемесяч)",
            lowered,
            flags=re.IGNORECASE,
        )
        if m_monthly:
            post_monthly_percent = _to_float_percent(m_monthly.group(1))
        if post_monthly_percent is None and post_total_percent:
            m_months = re.search(
                r"за\s*(\d{1,2})\s*месяц",
                lowered,
                flags=re.IGNORECASE,
            )
            if m_months:
                try:
                    months = max(1, int(m_months.group(1)))
                    post_monthly_percent = float(post_total_percent) / float(months)
                except Exception:
                    pass

        m_prepay_label = re.search(r"предоплата_руб\s*:\s*([^\n\r]+)", raw_text, flags=re.IGNORECASE)
        if m_prepay_label:
            v = _to_int_money(m_prepay_label.group(1))
            if v:
                prepay = v

        m_total_label = re.search(r"постоплата_всего_%\s*:\s*([^\n\r]+)", raw_text, flags=re.IGNORECASE)
        if m_total_label:
            v = _to_float_percent(m_total_label.group(1))
            if v:
                post_total_percent = v

        m_monthly_label = re.search(r"постоплата_в_месяц_%\s*:\s*([^\n\r]+)", raw_text, flags=re.IGNORECASE)
        if m_monthly_label:
            v = _to_float_percent(m_monthly_label.group(1))
            if v:
                post_monthly_percent = v

        if prepay:
            out["prepay"] = int(prepay)
        if post_total_percent:
            out["post_total_percent"] = float(post_total_percent)
        if post_monthly_percent:
            out["post_monthly_percent"] = float(post_monthly_percent)

        if prepay and post_total_percent:
            out["tariff"] = "pre_post"
        elif post_total_percent:
            out["tariff"] = "post"
        elif prepay:
            out["tariff"] = "pre"
        return out

    @property
    def enabled(self) -> bool:
        return bool(self.create_contract_url or self.api_token)

    def create_contract(self, payload: dict[str, Any]) -> dict[str, Any]:
        if not self.enabled:
            raise OkiDokiClientError("Интеграция OkiDoki не настроена")
        url = self._resolve_create_url()
        headers = {"Content-Type": "application/json", "Accept": "application/json"}
        body_payload = dict(payload or {})
        if self.api_token and not str(body_payload.get("api_key") or "").strip():
            body_payload["api_key"] = self.api_token
        if self._looks_like_official_external_contract(url):
            has_template = bool(str(body_payload.get("template_id") or "").strip())
            has_body = bool(str(body_payload.get("body") or "").strip())
            if not has_template and not has_body:
                raise OkiDokiClientError(
                    "Для official OkiDoki /external/contract обязателен template_id (или body)"
                )
        if self.api_token:
            headers["Authorization"] = f"Bearer {self.api_token}"
            headers["X-API-KEY"] = self.api_token
        try:
            resp = requests.post(
                url,
                json=body_payload,
                headers=headers,
                timeout=self.timeout_sec,
            )
        except requests.RequestException as exc:
            raise OkiDokiClientError("Не удалось связаться с OkiDoki-интеграцией") from exc

        body = (resp.text or "").strip()
        if resp.status_code >= 400:
            raise OkiDokiClientError(
                "OkiDoki-интеграция вернула ошибку",
                status_code=resp.status_code,
                body=body[:500],
            )
        if not body:
            return {}
        try:
            data = resp.json()
        except Exception as exc:
            raise OkiDokiClientError("OkiDoki-интеграция вернула не-JSON ответ", status_code=resp.status_code, body=body[:500]) from exc
        if isinstance(data, dict):
            contract = data.get("contract")
            if isinstance(contract, dict):
                contract_link = str(contract.get("link") or contract.get("url") or "").strip()
                if contract_link and not str(data.get("link") or "").strip():
                    data["link"] = contract_link
            if str(data.get("link") or "").strip() and not str(data.get("sign_url") or "").strip():
                data["sign_url"] = str(data.get("link") or "").strip()
            return data
        return {"data": data}

    @staticmethod
    def extract_contract_id(contract_url_or_id: str | None) -> str:
        raw = str(contract_url_or_id or "").strip()
        if not raw:
            return ""
        if re.fullmatch(r"[A-Za-z0-9_-]{8,64}", raw):
            return raw
        try:
            path = urlparse(raw).path or ""
        except Exception:
            path = raw
        m = re.search(r"/contracts?/([A-Za-z0-9_-]{8,64})", path)
        if m:
            return str(m.group(1)).strip()
        return ""

    def fetch_contract_payload(self, contract_url_or_id: str) -> dict[str, Any]:
        """
        Пытается получить карточку договора по contract_id напрямую из публичного API OkiDoki.
        Используется как fallback для автозаполнения анкеты, когда локальный кэш договора пуст.
        """
        contract_id = self.extract_contract_id(contract_url_or_id)
        if not contract_id:
            raise OkiDokiClientError("Не удалось определить contract_id из ссылки OkiDoki")

        headers = {"Accept": "application/json"}
        if self.api_token:
            headers["Authorization"] = f"Bearer {self.api_token}"
            headers["X-API-KEY"] = self.api_token

        endpoints_with_params: list[tuple[str, dict[str, Any]]] = []
        if self.api_token:
            endpoints_with_params.append(
                (
                    "https://api.doki.online/external/contract",
                    {"api_key": self.api_token, "contract_id": contract_id},
                )
            )

        endpoints_with_params.extend(
            [
                (f"https://api.doki.online/contracts/{contract_id}", {}),
                (f"https://api.doki.online/v1/contracts/{contract_id}", {}),
                (f"https://api.doki.online/public/contracts/{contract_id}", {}),
            ]
        )

        last_error: OkiDokiClientError | None = None
        for url, params in endpoints_with_params:
            try:
                resp = requests.get(url, params=params or None, headers=headers, timeout=self.timeout_sec)
            except requests.RequestException as exc:
                last_error = OkiDokiClientError("Не удалось связаться с API OkiDoki для чтения договора", body=str(exc)[:300])
                continue

            body = (resp.text or "").strip()
            if resp.status_code == 404:
                continue
            if resp.status_code >= 400:
                last_error = OkiDokiClientError(
                    "API OkiDoki не дал доступ к данным договора",
                    status_code=resp.status_code,
                    body=body[:500],
                )
                continue
            if not body:
                return {}
            try:
                data = resp.json()
            except Exception:
                last_error = OkiDokiClientError(
                    "API OkiDoki вернул не-JSON при чтении договора",
                    status_code=resp.status_code,
                    body=body[:500],
                )
                continue
            if isinstance(data, dict):
                root = data.get("contract") if isinstance(data.get("contract"), dict) else data
                source_url = str(root.get("link") or root.get("url") or contract_url_or_id or "").strip()
                source_contract_id = self.extract_contract_id(source_url) or contract_id
                if source_contract_id:
                    pdf_bytes = self._download_contract_pdf(source_contract_id)
                    hints = self._extract_profile_hints_from_pdf(pdf_bytes or b"")
                    if hints:
                        for k, v in hints.items():
                            if root.get(k) in (None, "", 0):
                                root[k] = v
                            if data.get(k) in (None, "", 0):
                                data[k] = v
                return data
            return {"data": data}

        if last_error:
            raise last_error
        raise OkiDokiClientError("Договор OkiDoki не найден", status_code=404)
