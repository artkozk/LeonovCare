from __future__ import annotations

import sqlite3

from app.db import repo_settings

CORE_AUTOAPPLY_DIRECTIONS: tuple[str, ...] = ("java", "frontend", "golang", "python")

DEFAULT_QUERY_BY_DIRECTION: dict[str, str] = {
    "java": "Java",
    "frontend": "React",
    "golang": "Golang",
    "python": "Python",
}

_SETTINGS_PREFIX = "autoapply.query.core."


def normalize_direction(direction: str | None) -> str:
    return str(direction or "").strip().lower()


def is_core_direction(direction: str | None) -> bool:
    return normalize_direction(direction) in CORE_AUTOAPPLY_DIRECTIONS


def setting_key(direction: str | None) -> str | None:
    d = normalize_direction(direction)
    if d not in CORE_AUTOAPPLY_DIRECTIONS:
        return None
    return f"{_SETTINGS_PREFIX}{d}"


def get_core_query(conn: sqlite3.Connection, direction: str | None) -> str | None:
    d = normalize_direction(direction)
    if d not in CORE_AUTOAPPLY_DIRECTIONS:
        return None
    key = setting_key(d)
    if not key:
        return None
    raw = str(repo_settings.get(conn, key, "") or "").strip()
    if raw:
        return raw
    return DEFAULT_QUERY_BY_DIRECTION.get(d)


def set_core_query(conn: sqlite3.Connection, direction: str | None, query: str) -> bool:
    d = normalize_direction(direction)
    if d not in CORE_AUTOAPPLY_DIRECTIONS:
        return False
    q = str(query or "").strip()
    if not q:
        return False
    key = setting_key(d)
    if not key:
        return False
    repo_settings.set(conn, key, q)
    return True


def reset_core_queries(conn: sqlite3.Connection) -> None:
    for d in CORE_AUTOAPPLY_DIRECTIONS:
        key = setting_key(d)
        if not key:
            continue
        repo_settings.set(conn, key, DEFAULT_QUERY_BY_DIRECTION[d])


def list_core_queries(conn: sqlite3.Connection) -> dict[str, str]:
    out: dict[str, str] = {}
    for d in CORE_AUTOAPPLY_DIRECTIONS:
        q = get_core_query(conn, d) or DEFAULT_QUERY_BY_DIRECTION[d]
        out[d] = q
    return out
