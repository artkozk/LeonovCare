from __future__ import annotations

from typing import Any
from urllib.parse import parse_qs, urlparse


def parse_mtproxy(raw_value: str) -> tuple[str, int, str] | None:
    raw = str(raw_value or "").strip()
    if not raw:
        return None
    if raw.startswith("tg://proxy"):
        parsed = urlparse(raw)
        q = parse_qs(parsed.query)
        host = str((q.get("server") or [""])[0] or "").strip()
        port_raw = str((q.get("port") or [""])[0] or "").strip()
        secret = str((q.get("secret") or [""])[0] or "").strip()
        try:
            port = int(port_raw)
        except Exception:
            port = 0
        if host and port > 0 and secret:
            return host, port, secret
        return None
    parts = raw.split(":")
    # plain MTProxy: host:port:secret
    if len(parts) == 3:
        host = str(parts[0] or "").strip()
        try:
            port = int(str(parts[1] or "").strip())
        except Exception:
            port = 0
        secret = str(parts[2] or "").strip()
        if host and port > 0 and secret:
            return host, port, secret
    return None


def parse_generic_proxy(raw_value: str) -> dict[str, Any] | None:
    raw = str(raw_value or "").strip()
    if not raw:
        return None
    proxy_type = "http"
    host = ""
    port = 0
    username = ""
    password = ""

    if raw.startswith("socks5://"):
        proxy_type = "socks5"
        parsed = urlparse(raw)
        host = str(parsed.hostname or "").strip()
        try:
            port = int(parsed.port or 0)
        except Exception:
            port = 0
        username = str(parsed.username or "").strip()
        password = str(parsed.password or "").strip()
    elif raw.startswith("http://") or raw.startswith("https://"):
        proxy_type = "http"
        parsed = urlparse(raw)
        host = str(parsed.hostname or "").strip()
        try:
            port = int(parsed.port or 0)
        except Exception:
            port = 0
        username = str(parsed.username or "").strip()
        password = str(parsed.password or "").strip()
    else:
        parts = raw.split(":")
        if len(parts) >= 2:
            host = str(parts[0] or "").strip()
            try:
                port = int(str(parts[1] or "").strip())
            except Exception:
                port = 0
            if len(parts) >= 4:
                username = str(parts[2] or "").strip()
                password = str(":".join(parts[3:]) or "").strip()

    if not host or port <= 0:
        return None
    return {
        "proxy_type": proxy_type,
        "addr": host,
        "port": port,
        "username": username or None,
        "password": password or None,
        "rdns": True,
    }


def resolve_proxy(raw_value: str) -> tuple[str, object, str] | None:
    raw = str(raw_value or "").strip()
    if not raw:
        return None
    mt = parse_mtproxy(raw)
    if mt:
        return ("mtproxy", mt, f"{mt[0]}:{mt[1]}:{mt[2]}")
    proxy = parse_generic_proxy(raw)
    if proxy:
        usr = str(proxy.get("username") or "")
        pwd = str(proxy.get("password") or "")
        auth = f"{usr}:{pwd}@" if usr or pwd else ""
        return (
            str(proxy.get("proxy_type") or "http"),
            proxy,
            f"{auth}{proxy.get('addr')}:{proxy.get('port')}",
        )
    return None


def build_client_kwargs(proxy_raw: str) -> tuple[dict[str, Any], tuple[str, object, str] | None]:
    client_kwargs: dict[str, Any] = {
        "request_retries": 1,
        "connection_retries": 1,
        "retry_delay": 1,
        "timeout": 15,
        "auto_reconnect": False,
    }
    proxy_resolved = resolve_proxy(proxy_raw)
    if proxy_resolved:
        proxy_type, proxy_obj, _ = proxy_resolved
        if proxy_type == "mtproxy":
            from telethon import connection

            client_kwargs["connection"] = connection.ConnectionTcpMTProxyRandomizedIntermediate
            client_kwargs["proxy"] = proxy_obj
        else:
            client_kwargs["proxy"] = proxy_obj
    return client_kwargs, proxy_resolved
