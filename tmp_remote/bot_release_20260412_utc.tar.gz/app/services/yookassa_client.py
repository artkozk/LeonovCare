from __future__ import annotations

import base64
import uuid
from dataclasses import dataclass
from decimal import Decimal, ROUND_HALF_UP
from typing import Any

import requests


def _amount_to_decimal_str(amount_rub: int) -> str:
    value = Decimal(max(int(amount_rub or 0), 0)).quantize(Decimal("1"), rounding=ROUND_HALF_UP)
    return f"{value:.2f}"


def normalize_status(raw: str | None) -> str:
    val = (raw or "").strip().lower()
    if val == "succeeded":
        return "SUCCEEDED"
    if val == "waiting_for_capture":
        return "WAITING_FOR_CAPTURE"
    if val == "canceled":
        return "CANCELED"
    return "PENDING"


@dataclass(slots=True)
class YooKassaClientError(RuntimeError):
    message: str
    status_code: int | None = None
    body: str = ""

    def __str__(self) -> str:
        code = f" (HTTP {self.status_code})" if self.status_code is not None else ""
        tail = f": {self.body}" if self.body else ""
        return f"{self.message}{code}{tail}"


class YooKassaClient:
    def __init__(
        self,
        shop_id: str,
        secret_key: str,
        return_url: str,
        timeout_sec: int = 30,
        api_base_url: str = "https://api.yookassa.ru/v3",
        oauth_token: str = "",
        oauth_client_id: str = "",
        oauth_client_secret: str = "",
        oauth_authorization_code: str = "",
        oauth_token_url: str = "https://yookassa.ru/oauth/v2/token",
    ) -> None:
        self.shop_id = (shop_id or "").strip()
        self.secret_key = (secret_key or "").strip()
        self.return_url = (return_url or "").strip()
        self.timeout_sec = max(int(timeout_sec or 30), 5)
        self.api_base_url = (api_base_url or "").strip().rstrip("/")
        self.oauth_token = (oauth_token or "").strip()
        self.oauth_client_id = (oauth_client_id or "").strip()
        self.oauth_client_secret = (oauth_client_secret or "").strip()
        self.oauth_authorization_code = (oauth_authorization_code or "").strip()
        self.oauth_token_url = (oauth_token_url or "").strip() or "https://yookassa.ru/oauth/v2/token"
        self._oauth_access_token = self.oauth_token
        self._compound_secret_full = ""
        self._compound_secret_right = ""
        self._normalize_compound_secret()

    def _normalize_compound_secret(self) -> None:
        """
        Backward compatibility for credentials that are sometimes shared as
        "<left>|<right>" instead of classic shop+secret.

        Cases handled:
        - shop_id is empty, secret_key="12345|abcdef" -> shop_id=12345, secret_key=abcdef
        - shop_id is set, secret_key="12345|abcdef"   -> keep shop_id, secret_key=abcdef
        - no explicit OAuth token                      -> try right part as OAuth token fallback
        """
        raw = (self.secret_key or "").strip()
        if "|" not in raw:
            return
        left, right = raw.split("|", 1)
        left = left.strip()
        right = right.strip()
        self._compound_secret_full = raw
        self._compound_secret_right = right
        if right:
            self.secret_key = right
            if not self._oauth_access_token:
                self._oauth_access_token = right
        if not self.shop_id and left:
            self.shop_id = left

    @property
    def enabled(self) -> bool:
        if not self.return_url:
            return False
        if self.shop_id and self.secret_key:
            return True
        if self._oauth_access_token:
            return True
        return bool(
            self.oauth_client_id
            and self.oauth_client_secret
        )

    def _ensure_oauth_token(self) -> str:
        token = (self._oauth_access_token or "").strip()
        if token:
            return token
        if not (
            self.oauth_client_id
            and self.oauth_client_secret
            and self.oauth_authorization_code
        ):
            raise YooKassaClientError(
                "OAuth-токен не настроен (нужен YOOKASSA_OAUTH_TOKEN или связка "
                "YOOKASSA_OAUTH_CLIENT_ID/YOOKASSA_OAUTH_CLIENT_SECRET/YOOKASSA_OAUTH_AUTH_CODE)"
            )

        pair = f"{self.oauth_client_id}:{self.oauth_client_secret}".encode("utf-8")
        basic = base64.b64encode(pair).decode("ascii")
        headers = {
            "Authorization": f"Basic {basic}",
            "Content-Type": "application/x-www-form-urlencoded",
        }
        data = {
            "grant_type": "authorization_code",
            "code": self.oauth_authorization_code,
        }
        try:
            resp = requests.post(
                self.oauth_token_url,
                headers=headers,
                data=data,
                timeout=self.timeout_sec,
            )
        except requests.RequestException as exc:
            raise YooKassaClientError("Не удалось получить OAuth-токен YooKassa") from exc

        body = (resp.text or "").strip()
        if resp.status_code >= 400:
            raise YooKassaClientError(
                "YooKassa OAuth вернула ошибку",
                status_code=resp.status_code,
                body=body[:500],
            )
        try:
            payload = resp.json() if body else {}
        except Exception as exc:
            raise YooKassaClientError(
                "YooKassa OAuth вернула не-JSON ответ",
                status_code=resp.status_code,
                body=body[:500],
            ) from exc

        token = str((payload or {}).get("access_token") or "").strip()
        if not token:
            raise YooKassaClientError(
                "YooKassa OAuth не вернула access_token",
                status_code=resp.status_code,
                body=body[:500],
            )
        self._oauth_access_token = token
        return token

    def _auth_variants(self) -> list[tuple[tuple[str, str] | None, str | None]]:
        variants: list[tuple[tuple[str, str] | None, str | None]] = []
        seen: set[tuple[str, str]] = set()

        def _add(auth: tuple[str, str] | None, bearer: str | None) -> None:
            key = ("basic", f"{auth[0]}:{auth[1]}") if auth else ("bearer", str(bearer or ""))
            if key in seen:
                return
            seen.add(key)
            variants.append((auth, bearer))

        if self.shop_id and self.secret_key:
            _add((self.shop_id, self.secret_key), None)
        if self.shop_id and self._compound_secret_full:
            _add((self.shop_id, self._compound_secret_full), None)
        if self._oauth_access_token:
            _add(None, self._oauth_access_token)
        if self.oauth_client_id and self.oauth_client_secret and self.oauth_authorization_code:
            token = self._ensure_oauth_token()
            _add(None, token)
        if self.oauth_client_id and self.oauth_client_secret:
            # Compatibility: some setups keep merchant pair in OAuth fields.
            _add((self.oauth_client_id, self.oauth_client_secret), None)
        if self._compound_secret_right:
            _add(None, self._compound_secret_right)
        if self._compound_secret_full:
            _add(None, self._compound_secret_full)
        return variants

    def _request(
        self,
        method: str,
        path: str,
        payload: dict[str, Any] | None = None,
        idempotence_key: str | None = None,
    ) -> dict[str, Any]:
        if not self.enabled:
            raise YooKassaClientError("Интеграция YooKassa не настроена")
        url = f"{self.api_base_url}{path}"
        variants = self._auth_variants()
        if not variants:
            raise YooKassaClientError("Интеграция YooKassa не настроена")

        last_error: YooKassaClientError | None = None
        for idx, (auth, bearer_token) in enumerate(variants):
            headers = {"Content-Type": "application/json"}
            if idempotence_key:
                headers["Idempotence-Key"] = idempotence_key
            if bearer_token:
                headers["Authorization"] = f"Bearer {bearer_token}"
            try:
                resp = requests.request(
                    method=method.upper(),
                    url=url,
                    auth=auth,
                    headers=headers,
                    json=payload,
                    timeout=self.timeout_sec,
                )
            except requests.RequestException as exc:
                raise YooKassaClientError("Не удалось связаться с YooKassa API") from exc

            body = (resp.text or "").strip()
            if resp.status_code >= 400:
                err = YooKassaClientError(
                    "YooKassa вернула ошибку",
                    status_code=resp.status_code,
                    body=body[:500],
                )
                last_error = err
                auth_failed = resp.status_code in {401, 403}
                has_next = idx < (len(variants) - 1)
                if auth_failed and has_next:
                    continue
                raise err

            if not body:
                return {}
            try:
                data = resp.json()
            except Exception as exc:
                raise YooKassaClientError(
                    "YooKassa вернула не-JSON ответ",
                    status_code=resp.status_code,
                    body=body[:500],
                ) from exc
            if isinstance(data, dict):
                return data
            return {"data": data}

        if last_error:
            raise last_error
        raise YooKassaClientError("Не удалось выполнить запрос к YooKassa")

    def create_payment(
        self,
        amount_rub: int,
        description: str,
        metadata: dict[str, Any] | None = None,
        capture: bool = True,
        currency: str = "RUB",
    ) -> dict[str, Any]:
        idempotence_key = str(uuid.uuid4())
        payload = {
            "amount": {
                "value": _amount_to_decimal_str(amount_rub),
                "currency": (currency or "RUB").strip().upper() or "RUB",
            },
            "capture": bool(capture),
            "confirmation": {
                "type": "redirect",
                "return_url": self.return_url,
            },
            "description": (description or "").strip()[:128],
            "metadata": metadata or {},
        }
        data = self._request("POST", "/payments", payload=payload, idempotence_key=idempotence_key)
        data["idempotence_key"] = idempotence_key
        return data

    def get_payment(self, payment_id: str) -> dict[str, Any]:
        pid = (payment_id or "").strip()
        if not pid:
            raise YooKassaClientError("Не передан payment_id для проверки")
        return self._request("GET", f"/payments/{pid}")
