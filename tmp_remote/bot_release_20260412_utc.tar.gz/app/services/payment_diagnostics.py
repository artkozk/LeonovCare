from __future__ import annotations

from typing import Any

from app.services.cardlink_client import CardlinkClient, CardlinkClientError, normalize_status


def extract_rub_amount(price_label: str | None) -> int:
    raw = str(price_label or "").strip()
    if not raw:
        return 0
    first_part = raw.split("+", 1)[0]
    digits = "".join(ch for ch in first_part if ch.isdigit())
    if digits:
        try:
            return max(int(digits), 0)
        except Exception:
            pass
    all_digits = "".join(ch for ch in raw if ch.isdigit())
    if not all_digits:
        return 0
    try:
        return max(int(all_digits), 0)
    except Exception:
        return 0


def build_enrollment_tariff_cases(enroll_tracks: dict[str, dict[str, Any]]) -> list[dict[str, Any]]:
    cases: list[dict[str, Any]] = []
    for track_key, track in (enroll_tracks or {}).items():
        track_title = str((track or {}).get("title") or track_key).strip() or track_key
        plans = (track or {}).get("plans") or []
        for plan in plans:
            plan_key = str((plan or {}).get("key") or "").strip()
            plan_title = str((plan or {}).get("title") or plan_key).strip() or plan_key
            amount = extract_rub_amount((plan or {}).get("price"))
            if amount <= 0:
                continue
            cases.append(
                {
                    "code": f"enroll:{track_key}:{plan_key or 'plan'}",
                    "point": "ENROLLMENT_PAYMENT",
                    "title": f"{track_title} / {plan_title}",
                    "amount": amount,
                }
            )
    return cases


def build_service_point_cases(interview_price_rub: int) -> list[dict[str, Any]]:
    return [
        {
            "code": "postpay:base",
            "point": "PAYMENT",
            "title": "Постоплата (базовый чек)",
            "amount": 1000,
        },
        {
            "code": "autoapply:site:200",
            "point": "AUTOAPPLY_PAYMENT",
            "title": "Автоотклики (пример 200 откликов)",
            "amount": 1200,
        },
        {
            "code": "interview_helper:non_student",
            "point": "INTERVIEW_HELPER_PAYMENT",
            "title": "Interview helper (не ученик)",
            "amount": max(int(interview_price_rub or 0), 1),
        },
    ]


def run_cardlink_diagnostics(
    client: CardlinkClient,
    enroll_tracks: dict[str, dict[str, Any]],
    interview_price_rub: int,
    owner_tg_id: int,
) -> dict[str, Any]:
    cases = build_enrollment_tariff_cases(enroll_tracks) + build_service_point_cases(interview_price_rub)
    results: list[dict[str, Any]] = []
    ok_count = 0
    fail_count = 0
    for case in cases:
        amount = max(int(case.get("amount") or 0), 1)
        result = {
            "code": case.get("code"),
            "point": case.get("point"),
            "title": case.get("title"),
            "amount": amount,
            "ok": False,
            "create_status": "",
            "status_check": "",
            "payment_id": "",
            "confirmation_url": "",
            "error": "",
        }
        try:
            created = client.create_payment(
                amount_rub=amount,
                description=f"Diag {case.get('point')} ({case.get('code')})",
                metadata={
                    "diag": True,
                    "diag_case": str(case.get("code") or ""),
                    "owner_tg_id": int(owner_tg_id),
                    "point": str(case.get("point") or ""),
                },
            )
            payment_id = str(created.get("id") or "").strip()
            if not payment_id:
                raise CardlinkClientError("Cardlink не вернула id счёта в диагностике")
            result["payment_id"] = payment_id
            result["create_status"] = str(created.get("status") or "").strip() or "NEW"
            result["confirmation_url"] = str(created.get("confirmation_url") or "").strip()
            try:
                checked = client.get_payment(payment_id)
                checked_status = str(checked.get("status") or "").strip()
                result["status_check"] = checked_status or "UNKNOWN"
                result["ok"] = True
            except CardlinkClientError as exc:
                result["status_check"] = "ERROR"
                result["error"] = str(exc)
            if result["ok"]:
                ok_count += 1
            else:
                fail_count += 1
        except CardlinkClientError as exc:
            result["error"] = str(exc)
            fail_count += 1
        results.append(result)

    return {
        "total": len(results),
        "ok": ok_count,
        "failed": fail_count,
        "results": results,
    }


def format_cardlink_diagnostics_report(report: dict[str, Any]) -> str:
    total = int(report.get("total") or 0)
    ok = int(report.get("ok") or 0)
    failed = int(report.get("failed") or 0)
    lines = [
        "<b>Проверка оплаты (Cardlink)</b>",
        f"Проверено точек: <b>{total}</b>",
        f"Успешно: <b>{ok}</b> • Ошибок: <b>{failed}</b>",
        "",
    ]
    for row in report.get("results") or []:
        mark = "✅" if row.get("ok") else "❌"
        amount = int(row.get("amount") or 0)
        point = str(row.get("point") or "").strip()
        title = str(row.get("title") or "").strip() or str(row.get("code") or "")
        create_status = normalize_status(str(row.get("create_status") or ""))
        checked_status = normalize_status(str(row.get("status_check") or ""))
        lines.append(
            f"{mark} <b>{point}</b> — {title}\n"
            f"Сумма: <b>{amount} ₽</b> • create: <code>{create_status}</code> • status: <code>{checked_status}</code>"
        )
        if row.get("error"):
            lines.append(f"Ошибка: <code>{str(row.get('error'))[:220]}</code>")
        pid = str(row.get("payment_id") or "").strip()
        if pid:
            lines.append(f"id: <code>{pid}</code>")
        lines.append("")
    return "\n".join(lines).strip()
