"""Фоновый watcher реакций (мульти-аккаунт, мульти-канал).

Периодически проверяет свежие посты в каналах и ставит реакции
со всех авторизованных аккаунтов владельца.
"""

from __future__ import annotations

import asyncio
import datetime as dt
import json
import logging
import os
import random
import threading
from pathlib import Path
from typing import TYPE_CHECKING, Any

from app.db import repo_owner_reactions, repo_owner_tg_accounts
from app.services.owner_outreach_scripts import reaction_channels, reactions_auto_enabled
from app.services.tg_proxy import build_client_kwargs

if TYPE_CHECKING:
    from app.config import Config

logger = logging.getLogger(__name__)

REACTIONS = ["🏆", "🔥", "💯", "👍", "🤝"]
CHECK_INTERVAL_SEC = 20.0
MESSAGES_PER_CHANNEL = 5
MIN_REACTION_AGE_SEC = 10 * 60


def _message_age_sec(message: Any) -> float | None:
    ts = getattr(message, "date", None)
    if ts is None:
        return None
    if not isinstance(ts, dt.datetime):
        return None
    if ts.tzinfo is None:
        ts = ts.replace(tzinfo=dt.timezone.utc)
    now_utc = dt.datetime.now(dt.timezone.utc)
    return max((now_utc - ts.astimezone(dt.timezone.utc)).total_seconds(), 0.0)


def _read_json(path: Path) -> dict[str, Any]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _authorized_session(session_file: str, account_id: int, tg_meta: Path) -> bool:
    session_exists = Path(str(session_file or "").strip()).exists()
    st = _read_json(tg_meta / f"qr_status_{account_id}.json")
    state = str(st.get("status") or "").strip().lower()
    if state == "authorized":
        return session_exists
    if state in {"error", "pending", "expired"}:
        return False
    return session_exists


def _tools_tg_dir(cfg: "Config") -> Path:
    raw = str(getattr(cfg, "OWNER_TOOLS_DIR", "owner_tools_data") or "owner_tools_data").strip()
    p = Path(raw)
    if not p.is_absolute():
        p = (Path.cwd() / p).resolve()
    return p / "telegram"


def _watch_thread_main(cfg: "Config") -> None:
    try:
        from telethon import TelegramClient, functions, types
        from telethon.sessions import StringSession
    except Exception as exc:
        logger.warning("Telethon недоступен, watcher реакций не запущен: %s", exc)
        return

    owner_id = int(getattr(cfg, "OWNER_SUPERUSER_ID", 0) or 0)
    if owner_id <= 0:
        return

    tg_meta = _tools_tg_dir(cfg)

    proxy_raw = (
        str(os.getenv("OWNER_TG_PROXY") or "").strip()
        or str(os.getenv("OWNER_TG_MTPROXY") or "").strip()
    )

    async def _run_loop() -> None:
        from app.db import connect as db_connect

        session_cache: dict[tuple[int, str, str], str] = {}
        client_kwargs, proxy_resolved = build_client_kwargs(proxy_raw)
        if proxy_resolved:
            logger.info(
                "Watcher реакций: прокси включен (%s).",
                str(proxy_resolved[2]),
            )
        while True:
            try:
                conn = db_connect(cfg)
                try:
                    if not reactions_auto_enabled(conn):
                        await asyncio.sleep(3.0)
                        continue
                    channels = reaction_channels(conn)
                    raw_accounts = repo_owner_tg_accounts.list_all(conn, owner_id)
                finally:
                    try:
                        conn.close()
                    except Exception:
                        pass

                if not channels:
                    await asyncio.sleep(10.0)
                    continue

                accounts: list[dict[str, Any]] = []
                for acc in raw_accounts:
                    aid = int(acc["id"] or 0)
                    api_id = int(acc["api_id"] or 0)
                    api_hash = str(acc["api_hash"] or "").strip()
                    session_file = str(acc["session_file"] or "").strip()
                    if aid <= 0 or api_id <= 0 or not api_hash or not session_file:
                        continue
                    if not _authorized_session(session_file, aid, tg_meta):
                        continue
                    accounts.append(
                        {
                            "id": aid,
                            "title": str(acc["title"] or f"account-{aid}"),
                            "api_id": api_id,
                            "api_hash": api_hash,
                            "session_file": session_file,
                        }
                    )

                if not accounts:
                    await asyncio.sleep(12.0)
                    continue

                for acc in accounts:
                    cache_key = (acc["api_id"], acc["api_hash"], acc["session_file"])
                    string_session = session_cache.get(cache_key)
                    if not string_session:
                        bootstrap = TelegramClient(
                            acc["session_file"],
                            acc["api_id"],
                            acc["api_hash"],
                            **client_kwargs,
                        )
                        try:
                            await bootstrap.connect()
                            if not await bootstrap.is_user_authorized():
                                logger.warning(
                                    "Watcher реакций: аккаунт %s не авторизован.", acc["title"]
                                )
                                continue
                            string_session = StringSession.save(bootstrap.session)
                            if not string_session:
                                logger.warning(
                                    "Watcher реакций: не удалось собрать StringSession (%s).", acc["title"]
                                )
                                continue
                            session_cache[cache_key] = string_session
                        except Exception as exc:
                            logger.warning(
                                "Watcher реакций: ошибка bootstrap (%s): %s",
                                acc["title"],
                                exc,
                            )
                            continue
                        finally:
                            try:
                                await bootstrap.disconnect()
                            except Exception:
                                pass

                    client = TelegramClient(
                        StringSession(string_session),
                        acc["api_id"],
                        acc["api_hash"],
                        **client_kwargs,
                    )
                    try:
                        await client.connect()
                        if not await client.is_user_authorized():
                            session_cache.pop(cache_key, None)
                            logger.warning(
                                "Watcher реакций: StringSession не авторизована (%s).",
                                acc["title"],
                            )
                            continue
                        for ch in channels:
                            try:
                                entity = await client.get_entity(ch)
                            except Exception as exc:
                                logger.info(
                                    "Watcher реакций: не нашел канал @%s для %s: %s",
                                    ch,
                                    acc["title"],
                                    exc,
                                )
                                continue
                            try:
                                await client(
                                    functions.channels.JoinChannelRequest(channel=entity)
                                )
                            except Exception:
                                pass
                            try:
                                messages = await client.get_messages(entity, limit=MESSAGES_PER_CHANNEL)
                            except Exception as exc:
                                logger.info(
                                    "Watcher реакций: не удалось получить сообщения @%s (%s): %s",
                                    ch,
                                    acc["title"],
                                    exc,
                                )
                                continue
                            for msg in messages:
                                if not getattr(msg, "id", None):
                                    continue
                                if not (getattr(msg, "message", None) or getattr(msg, "media", None)):
                                    continue
                                age_sec = _message_age_sec(msg)
                                if age_sec is not None and age_sec < MIN_REACTION_AGE_SEC:
                                    continue
                                c2 = db_connect(cfg)
                                try:
                                    if not reactions_auto_enabled(c2):
                                        break
                                    if repo_owner_reactions.already_reacted_ok(
                                        c2,
                                        owner_id,
                                        ch,
                                        int(msg.id),
                                        account_id=int(acc["id"]),
                                    ):
                                        continue
                                    selected = random.sample(REACTIONS, k=min(3, len(REACTIONS)))
                                    try:
                                        await client(
                                            functions.messages.SendReactionRequest(
                                                peer=entity,
                                                msg_id=int(msg.id),
                                                big=False,
                                                add_to_recent=True,
                                                reaction=[
                                                    types.ReactionEmoji(emoticon=emo) for emo in selected
                                                ],
                                            )
                                        )
                                        repo_owner_reactions.add(
                                            c2,
                                            cfg.TZ,
                                            owner_tg_id=owner_id,
                                            account_id=int(acc["id"]),
                                            channel=ch,
                                            message_id=int(msg.id),
                                            reaction=",".join(selected),
                                            status="ok",
                                            error_text=None,
                                            payload={"source": "auto_watch"},
                                        )
                                    except Exception as exc:
                                        repo_owner_reactions.add(
                                            c2,
                                            cfg.TZ,
                                            owner_tg_id=owner_id,
                                            account_id=int(acc["id"]),
                                            channel=ch,
                                            message_id=int(msg.id),
                                            reaction=",".join(selected),
                                            status="failed",
                                            error_text=str(exc)[:500],
                                            payload={"source": "auto_watch"},
                                        )
                                finally:
                                    try:
                                        c2.close()
                                    except Exception:
                                        pass
                    except Exception as exc:
                        logger.info(
                            "Watcher реакций: ошибка в аккаунте %s: %s",
                            acc["title"],
                            exc,
                        )
                    finally:
                        try:
                            await client.disconnect()
                        except Exception:
                            pass

                await asyncio.sleep(CHECK_INTERVAL_SEC)
            except Exception as exc:
                logger.exception("Watcher реакций: ошибка цикла: %s", exc)
                await asyncio.sleep(10.0)

    asyncio.run(_run_loop())


def start_owner_reaction_watch(cfg: "Config") -> None:
    threading.Thread(
        target=_watch_thread_main,
        args=(cfg,),
        daemon=True,
        name="owner-reaction-watch",
    ).start()
    logger.info("Поток watcher реакций запущен.")
