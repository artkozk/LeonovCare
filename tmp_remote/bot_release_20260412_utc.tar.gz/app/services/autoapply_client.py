from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass
from typing import Any
from urllib.parse import quote

import requests

logger = logging.getLogger(__name__)


@dataclass(slots=True)
class AutoApplyClientError(RuntimeError):
    message: str
    status_code: int | None = None
    body: str = ""

    def __str__(self) -> str:
        code = f" (HTTP {self.status_code})" if self.status_code is not None else ""
        tail = f": {self.body}" if self.body else ""
        return f"{self.message}{code}{tail}"


class AutoApplyClient:
    def __init__(self, base_url: str, internal_token: str, timeout_sec: int = 45) -> None:
        self.base_url = (base_url or "").strip().rstrip("/")
        self.internal_token = (internal_token or "").strip()
        self.timeout_sec = max(int(timeout_sec or 45), 5)

    @property
    def enabled(self) -> bool:
        return bool(self.base_url and self.internal_token)

    def _headers(self) -> dict[str, str]:
        return {
            "Content-Type": "application/json",
            "X-Internal-Token": self.internal_token,
        }

    def _account_path(self, login: str) -> str:
        return quote(str(login or "").strip(), safe="")

    def _run_snapshot(self, login: str) -> dict[str, Any]:
        try:
            stats = self.account_stats(login)
        except AutoApplyClientError:
            return {}
        if not isinstance(stats, dict):
            return {}
        return stats

    def _recover_run_from_stats(
        self,
        login: str,
        before_stats: dict[str, Any] | None,
        tries: int = 80,
        sleep_sec: float = 2.0,
    ) -> dict[str, Any] | None:
        before_last_run = str((before_stats or {}).get("lastRunAt") or "").strip()
        for _ in range(max(int(tries or 0), 1)):
            now_stats = self._run_snapshot(login)
            if not now_stats:
                time.sleep(max(float(sleep_sec or 0), 0.2))
                continue
            last_run_at = str(now_stats.get("lastRunAt") or "").strip()
            if not last_run_at:
                time.sleep(max(float(sleep_sec or 0), 0.2))
                continue
            if before_last_run and last_run_at == before_last_run:
                time.sleep(max(float(sleep_sec or 0), 0.2))
                continue
            last_status = str(now_stats.get("lastRunStatus") or "").strip().upper()
            sent = int(now_stats.get("lastSentCount") or 0)
            ok = last_status in {"OK", "SUCCESS", "DONE"}
            details = f"RECOVERED_FROM_STATS:{last_status or 'UNKNOWN'}"
            return {
                "ok": ok,
                "login": str(login or "").strip(),
                "details": details,
                "sent": sent,
                "results": [],
            }
        return None

    def _request(
        self,
        method: str,
        path: str,
        payload: dict[str, Any] | None = None,
        timeout_sec: int | None = None,
    ) -> dict[str, Any]:
        if not self.enabled:
            raise AutoApplyClientError("Интеграция автооткликов не настроена")
        url = f"{self.base_url}{path}"
        timeout = max(int(timeout_sec or self.timeout_sec), 5)
        req_body = json.dumps(payload or {}, ensure_ascii=False)
        logger.info("[AUTOAPPLY][HTTP_REQ] method=%s url=%s body=%s", method.upper(), url, req_body)
        try:
            resp = requests.request(
                method=method.upper(),
                url=url,
                headers=self._headers(),
                json=payload,
                timeout=timeout,
            )
        except requests.RequestException as exc:
            logger.exception(
                "[AUTOAPPLY][HTTP_ERR] method=%s url=%s body=%s err=%s",
                method.upper(),
                url,
                req_body,
                type(exc).__name__,
            )
            raise AutoApplyClientError("Не удалось связаться с сервисом автооткликов") from exc

        body = (resp.text or "").strip()
        logger.info(
            "[AUTOAPPLY][HTTP_RESP] method=%s url=%s status=%s body=%s",
            method.upper(),
            url,
            resp.status_code,
            body,
        )
        if resp.status_code >= 400:
            raise AutoApplyClientError(
                "Сервис автооткликов вернул ошибку",
                status_code=resp.status_code,
                body=body[:500],
            )
        if not body:
            return {}
        try:
            data = resp.json()
        except Exception as exc:
            raise AutoApplyClientError("Сервис автооткликов вернул не-JSON ответ", status_code=resp.status_code, body=body[:500]) from exc
        if isinstance(data, dict):
            return data
        return {"data": data}

    def create_account(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self._request("POST", "/api/internal/accounts", payload)

    def delete_account(self, login: str) -> dict[str, Any]:
        return self._request("DELETE", f"/api/internal/accounts/{self._account_path(login)}")

    def account_stats(self, login: str) -> dict[str, Any]:
        return self._request("GET", f"/api/internal/accounts/{self._account_path(login)}/stats")

    def check_health(self) -> dict[str, Any]:
        return self._request("GET", "/actuator/health")

    def run_account(self, login: str) -> dict[str, Any]:
        payload = {"login": str(login or "").strip()}
        before_stats = self._run_snapshot(login)
        run_timeout = max(int(self.timeout_sec or 45), 210)
        try:
            return self._request("POST", "/api/internal/accounts/run", payload, timeout_sec=run_timeout)
        except AutoApplyClientError as exc:
            if exc.status_code is None:
                recovered = self._recover_run_from_stats(login, before_stats)
                if recovered is not None:
                    return recovered
            # Backward compatibility: older service builds expose /{login}/run.
            if exc.status_code not in {404, 405}:
                raise
        before_stats = self._run_snapshot(login)
        try:
            return self._request(
                "POST",
                f"/api/internal/accounts/{self._account_path(login)}/run",
                timeout_sec=run_timeout,
            )
        except AutoApplyClientError as exc:
            if exc.status_code is None:
                recovered = self._recover_run_from_stats(login, before_stats)
                if recovered is not None:
                    return recovered
            raise
