from __future__ import annotations

import json
import sqlite3
from typing import Any

from app.db import repo_settings


SCRIPT4_SETTINGS_KEY = "owner.outreach.script4.json"
AI_ENABLED_KEY = "owner.outreach.ai.enabled"
OPENAI_MODEL_KEY = "owner.outreach.ai.model"
AI_AUTO_ENABLED_KEY = "owner.outreach.ai.auto_enabled"
AI_AUTO_INTERVAL_SEC_KEY = "owner.outreach.ai.auto_interval_sec"
AI_GUARDRAILS_KEY = "owner.outreach.ai.guardrails"
ACTIVE_CHANNEL_KEY = "owner.reactions.channel"
ACTIVE_CHANNELS_KEY = "owner.reactions.channels"
AUTO_REACTIONS_ENABLED_KEY = "owner.reactions.auto_enabled"
OUTREACH_RUNTIME_CFG_PREFIX = "owner.outreach.runtime"

DIRECTIONS: tuple[str, ...] = ("java", "frontend", "golang", "python")
SEND_MODE_ALL = "all"
SEND_MODE_SELECTED = "selected"

DEFAULT_SEND_DELAY_SEC = 30
DEFAULT_PER_ACCOUNT_MAX = 20
DEFAULT_AI_AUTO_INTERVAL_SEC = 10
DEFAULT_OPENAI_MODEL = "gpt-5.4-mini"


def _sanitize_script_text(text: str) -> str:
    s = str(text or "").strip()
    if not s:
        return ""
    # Убираем неестественные формулировки в первых касаниях.
    s = s.replace("написал по делу.", "написал.")
    s = s.replace(
        "Если увижу, что смогу реально помочь, предложу следующий шаг. ",
        "После этого дам конкретные рекомендации и следующий практический шаг. ",
    )
    return s.strip()


def _default_ai_guardrails() -> dict[str, Any]:
    return {
        # Фразы, которые запрещены в исходящем AI-сообщении.
        "forbidden_substrings": [
            "пишу по делу",
            "написал по делу",
            "получилось посмотреть",
            "без созвона",
        ],
        # Регексы в python-формате (re.search).
        "forbidden_regex": [
            r"\bесли\s+тема\s+актуаль",
            r"\bесли\s+это\s+актуаль",
            r"\bбез\s+созвон",
        ],
        # Ограничение длины одного сообщения, чтобы не уходить в «полотно».
        "max_message_chars": 900,
    }


def _normalize_ai_guardrails(payload: dict[str, Any] | None) -> dict[str, Any]:
    src = payload or {}
    base = _default_ai_guardrails()
    out: dict[str, Any] = {
        "forbidden_substrings": [],
        "forbidden_regex": [],
        "max_message_chars": int(base["max_message_chars"]),
    }

    raw_sub = src.get("forbidden_substrings")
    if isinstance(raw_sub, list):
        seen: set[str] = set()
        for item in raw_sub:
            s = str(item or "").strip().lower()
            if not s or s in seen:
                continue
            seen.add(s)
            out["forbidden_substrings"].append(s)
    if not out["forbidden_substrings"]:
        out["forbidden_substrings"] = list(base["forbidden_substrings"])

    raw_re = src.get("forbidden_regex")
    if isinstance(raw_re, list):
        seen_re: set[str] = set()
        for item in raw_re:
            s = str(item or "").strip()
            if not s or s in seen_re:
                continue
            seen_re.add(s)
            out["forbidden_regex"].append(s)
    if not out["forbidden_regex"]:
        out["forbidden_regex"] = list(base["forbidden_regex"])

    try:
        max_chars = int(src.get("max_message_chars") or base["max_message_chars"])
    except Exception:
        max_chars = int(base["max_message_chars"])
    out["max_message_chars"] = max(120, min(max_chars, 3000))
    return out


def _default_script4() -> dict[str, list[str]]:
    common_steps = [
        (
            "Тогда давай так: я задам тебе несколько коротких вопросов, чтобы понять твою ситуацию, цель и где у тебя "
            "сейчас основной стопор. После этого предложу конкретный план действий "
            "и следующий практический шаг."
        ),
        (
            "Тогда сначала коротко:\n"
            "сколько у тебя сейчас опыта?\n"
            "в каком направлении работаешь?\n"
            "какая у тебя сейчас основная цель: смена компании, рост по деньгам, подготовка к собеседованиям "
            "или поиск первой работы?"
        ),
        (
            "Что уже пробовал делать сам?\n"
            "Где сейчас основной затык: мало ответов, мало интервью, слабая упаковка, сложности на "
            "собеседованиях или не хватает технической базы?"
        ),
        (
            "На какой результат хочешь выйти?\n"
            "И в какие сроки это для тебя актуально?"
        ),
        (
            "Тогда правильно тебя понял:\n"
            "сейчас у тебя [ситуация],\n"
            "цель — [цель],\n"
            "основной стопор — [боль].\n"
            "Все так?"
        ),
        (
            "Предлагаю короткий созвон на 20-30 минут. На нем разберем твою текущую ситуацию, поймем, где у тебя "
            "основные потери, и я дам рекомендации, которые можно применить сразу. Когда тебе удобнее — сегодня или завтра?"
        ),
    ]
    return {
        "java": [
            (
                "Привет.\n"
                "Увидел твой профиль, решил написать.\n"
                "Я помогаю Java-разработчикам лучше проходить собеседования и выходить на более сильные предложения: "
                "систематизируем теорию, разбираем проектный опыт, проводим мок-собесы, усиливаем резюме и стратегию откликов.\n"
                "Сам я больше 6 лет в коммерческой разработке.\n"
                "Сейчас для тебя тема собеседований или смены работы вообще актуальна?"
            ),
        ]
        + common_steps,
        "frontend": [
            (
                "Привет.\n"
                "Увидел твой профиль и решил написать.\n"
                "Я помогаю IT-специалистам усиливать не только поиск работы, но и техническую готовность к рынку: "
                "резюме, стратегия поиска, собеседования, проектный опыт, мок-интервью.\n"
                "Сам я больше 6 лет в коммерческой разработке.\n"
                "Подскажи, для тебя сейчас актуальна тема смены работы / роста по доходу / подготовки к собеседованиям?"
            ),
        ]
        + common_steps,
        "golang": [
            (
                "Привет.\n"
                "Увидел твой профиль и написал.\n"
                "Я работаю с IT-специалистами по двум направлениям: усиливаем упаковку и стратегию поиска, "
                "а параллельно подтягиваем техподготовку под реальные собеседования.\n"
                "Сам я больше 6 лет в коммерческой разработке.\n"
                "Подскажи, у тебя сейчас актуален вопрос смены работы или роста по рынку?"
            ),
        ]
        + common_steps,
        "python": [
            (
                "Привет.\n"
                "Увидел, что ты открыт к предложениям, поэтому написал.\n"
                "Я помогаю IT-специалистам усиливать конверсию в интервью и проходить собеседования увереннее: "
                "от резюме и стратегии поиска до техподготовки и мок-интервью.\n"
                "Сам я больше 6 лет в коммерческой разработке.\n"
                "Сейчас для тебя тема смены работы, роста по доходу или подготовки к собеседованиям актуальна?"
            ),
        ]
        + common_steps,
    }


def _normalize_direction(direction: str | None) -> str:
    d = str(direction or "").strip().lower()
    return d if d in DIRECTIONS else "python"


def _normalize_channel(raw: str | None) -> str:
    ch = str(raw or "").strip()
    if not ch:
        return ""
    ch = ch.replace("https://t.me/", "").replace("http://t.me/", "").replace("t.me/", "").lstrip("@")
    return ch


def _runtime_cfg_key(owner_tg_id: int) -> str:
    return f"{OUTREACH_RUNTIME_CFG_PREFIX}:{int(owner_tg_id)}"


def _normalize_runtime_cfg(payload: dict[str, Any] | None) -> dict[str, Any]:
    raw = payload or {}
    mode = str(raw.get("send_mode") or SEND_MODE_ALL).strip().lower()
    if mode not in {SEND_MODE_ALL, SEND_MODE_SELECTED}:
        mode = SEND_MODE_ALL
    selected_raw = raw.get("selected_account_ids")
    selected_ids: list[int] = []
    if isinstance(selected_raw, list):
        seen: set[int] = set()
        for item in selected_raw:
            try:
                aid = int(item)
            except Exception:
                continue
            if aid <= 0 or aid in seen:
                continue
            seen.add(aid)
            selected_ids.append(aid)
    delay_sec = int(raw.get("delay_sec") or DEFAULT_SEND_DELAY_SEC)
    delay_sec = max(0, min(delay_sec, 3600))
    per_account_max = int(raw.get("per_account_max") or DEFAULT_PER_ACCOUNT_MAX)
    per_account_max = max(1, min(per_account_max, 500))
    return {
        "send_mode": mode,
        "selected_account_ids": selected_ids,
        "delay_sec": delay_sec,
        "per_account_max": per_account_max,
    }


def get_script4(conn: sqlite3.Connection) -> dict[str, list[str]]:
    raw = str(repo_settings.get(conn, SCRIPT4_SETTINGS_KEY, "") or "").strip()
    base = _default_script4()
    if not raw:
        return base
    try:
        payload = json.loads(raw)
    except Exception:
        return base
    if not isinstance(payload, dict):
        return base
    out = dict(base)
    for d in DIRECTIONS:
        steps_raw = payload.get(d)
        if not isinstance(steps_raw, list):
            continue
        steps: list[str] = []
        for item in steps_raw:
            text = str(item or "").strip()
            if text:
                steps.append(text)
        if steps:
            out[d] = steps
    return out


def set_script_step(conn: sqlite3.Connection, direction: str, step_index: int, text: str) -> bool:
    d = _normalize_direction(direction)
    idx = int(step_index or 0)
    if idx < 0:
        return False
    value = str(text or "").strip()
    if len(value) < 3:
        return False
    script = get_script4(conn)
    steps = list(script.get(d) or [])
    while len(steps) <= idx:
        steps.append("")
    steps[idx] = value
    script[d] = steps
    repo_settings.set(conn, SCRIPT4_SETTINGS_KEY, json.dumps(script, ensure_ascii=False))
    return True


def get_first_message(conn: sqlite3.Connection, direction: str) -> str:
    d = _normalize_direction(direction)
    script = get_script4(conn)
    steps = script.get(d) or []
    if steps and str(steps[0]).strip():
        return _sanitize_script_text(str(steps[0]).strip())
    return _sanitize_script_text(_default_script4()[d][0])


def get_step(conn: sqlite3.Connection, direction: str, step_index: int) -> str:
    d = _normalize_direction(direction)
    script = get_script4(conn)
    steps = script.get(d) or []
    idx = max(int(step_index or 0), 0)
    if idx < len(steps) and str(steps[idx]).strip():
        return _sanitize_script_text(str(steps[idx]).strip())
    defaults = _default_script4().get(d) or []
    if idx < len(defaults):
        return _sanitize_script_text(defaults[idx])
    return ""


def ai_enabled(conn: sqlite3.Connection) -> bool:
    raw = str(repo_settings.get(conn, AI_ENABLED_KEY, "0") or "").strip().lower()
    return raw in {"1", "true", "yes", "on"}


def set_ai_enabled(conn: sqlite3.Connection, enabled: bool) -> None:
    repo_settings.set(conn, AI_ENABLED_KEY, "1" if enabled else "0")


def ai_auto_enabled(conn: sqlite3.Connection) -> bool:
    raw = str(repo_settings.get(conn, AI_AUTO_ENABLED_KEY, "0") or "").strip().lower()
    return raw in {"1", "true", "yes", "on"}


def set_ai_auto_enabled(conn: sqlite3.Connection, enabled: bool) -> None:
    repo_settings.set(conn, AI_AUTO_ENABLED_KEY, "1" if enabled else "0")


def ai_auto_interval_sec(conn: sqlite3.Connection) -> int:
    raw = str(repo_settings.get(conn, AI_AUTO_INTERVAL_SEC_KEY, str(DEFAULT_AI_AUTO_INTERVAL_SEC)) or "").strip()
    try:
        n = int(raw)
    except Exception:
        n = DEFAULT_AI_AUTO_INTERVAL_SEC
    return max(10, min(n, 3600))


def set_ai_auto_interval_sec(conn: sqlite3.Connection, seconds: int) -> int:
    n = max(10, min(int(seconds or 0), 3600))
    repo_settings.set(conn, AI_AUTO_INTERVAL_SEC_KEY, str(n))
    return n


def openai_model(conn: sqlite3.Connection) -> str:
    raw = str(repo_settings.get(conn, OPENAI_MODEL_KEY, DEFAULT_OPENAI_MODEL) or "").strip()
    return raw or DEFAULT_OPENAI_MODEL


def set_openai_model(conn: sqlite3.Connection, model: str) -> None:
    repo_settings.set(conn, OPENAI_MODEL_KEY, str(model or "").strip() or DEFAULT_OPENAI_MODEL)


def ai_guardrails(conn: sqlite3.Connection) -> dict[str, Any]:
    raw = str(repo_settings.get(conn, AI_GUARDRAILS_KEY, "") or "").strip()
    if not raw:
        return _normalize_ai_guardrails({})
    try:
        payload = json.loads(raw)
    except Exception:
        payload = {}
    if not isinstance(payload, dict):
        payload = {}
    return _normalize_ai_guardrails(payload)


def set_ai_guardrails(conn: sqlite3.Connection, payload: dict[str, Any]) -> dict[str, Any]:
    normalized = _normalize_ai_guardrails(payload)
    repo_settings.set(conn, AI_GUARDRAILS_KEY, json.dumps(normalized, ensure_ascii=False))
    return normalized


def reset_ai_guardrails(conn: sqlite3.Connection) -> dict[str, Any]:
    normalized = _normalize_ai_guardrails({})
    repo_settings.set(conn, AI_GUARDRAILS_KEY, json.dumps(normalized, ensure_ascii=False))
    return normalized


def outreach_runtime_config(conn: sqlite3.Connection, owner_tg_id: int) -> dict[str, Any]:
    raw = str(repo_settings.get(conn, _runtime_cfg_key(owner_tg_id), "") or "").strip()
    if not raw:
        return _normalize_runtime_cfg({})
    try:
        payload = json.loads(raw)
    except Exception:
        return _normalize_runtime_cfg({})
    if not isinstance(payload, dict):
        return _normalize_runtime_cfg({})
    return _normalize_runtime_cfg(payload)


def set_outreach_runtime_config(
    conn: sqlite3.Connection,
    owner_tg_id: int,
    patch: dict[str, Any],
) -> dict[str, Any]:
    current = outreach_runtime_config(conn, owner_tg_id)
    merged = dict(current)
    for key in ("send_mode", "selected_account_ids", "delay_sec", "per_account_max"):
        if key in patch:
            merged[key] = patch[key]
    normalized = _normalize_runtime_cfg(merged)
    repo_settings.set(conn, _runtime_cfg_key(owner_tg_id), json.dumps(normalized, ensure_ascii=False))
    return normalized


def reaction_channels(conn: sqlite3.Connection) -> list[str]:
    raw = str(repo_settings.get(conn, ACTIVE_CHANNELS_KEY, "") or "").strip()
    out: list[str] = []
    if raw:
        try:
            payload = json.loads(raw)
        except Exception:
            payload = None
        if isinstance(payload, list):
            seen: set[str] = set()
            for item in payload:
                ch = _normalize_channel(item)
                key = ch.lower()
                if len(ch) < 3 or key in seen:
                    continue
                seen.add(key)
                out.append(ch)
    if out:
        return out
    one = _normalize_channel(repo_settings.get(conn, ACTIVE_CHANNEL_KEY, "olegleonoff"))
    return [one or "olegleonoff"]


def set_reaction_channels(conn: sqlite3.Connection, channels: list[str]) -> bool:
    seen: set[str] = set()
    out: list[str] = []
    for item in channels:
        ch = _normalize_channel(item)
        key = ch.lower()
        if len(ch) < 3 or key in seen:
            continue
        seen.add(key)
        out.append(ch)
    repo_settings.set(conn, ACTIVE_CHANNELS_KEY, json.dumps(out, ensure_ascii=False))
    if out:
        repo_settings.set(conn, ACTIVE_CHANNEL_KEY, out[0])
    return True


def reaction_channel(conn: sqlite3.Connection) -> str:
    channels = reaction_channels(conn)
    return channels[0] if channels else "olegleonoff"


def set_reaction_channel(conn: sqlite3.Connection, channel: str) -> bool:
    ch = _normalize_channel(channel)
    if len(ch) < 3:
        return False
    channels = reaction_channels(conn)
    keep = [item for item in channels if item.lower() != ch.lower()]
    set_reaction_channels(conn, [ch] + keep)
    return True


def reactions_auto_enabled(conn: sqlite3.Connection) -> bool:
    raw = str(repo_settings.get(conn, AUTO_REACTIONS_ENABLED_KEY, "0") or "").strip().lower()
    return raw in {"1", "true", "yes", "on"}


def set_reactions_auto_enabled(conn: sqlite3.Connection, enabled: bool) -> None:
    repo_settings.set(conn, AUTO_REACTIONS_ENABLED_KEY, "1" if enabled else "0")
