from __future__ import annotations

import sqlite3

from app.db import repo_settings

KEY_PINGS_ENABLED = "admin.notify.pings.enabled"
KEY_REMINDERS_ENABLED = "admin.notify.reminders.enabled"
KEY_EVENTS_ENABLED = "admin.notify.events.enabled"
KEY_DAILY_SCHEDULE_ENABLED = "admin.notify.daily_schedule.enabled"


def _scoped_key(key: str, admin_user_id: int | None = None) -> str:
    if admin_user_id is None:
        return key
    try:
        uid = int(admin_user_id)
    except Exception:
        return key
    if uid <= 0:
        return key
    return f"{key}:{uid}"


def _read_bool(conn: sqlite3.Connection, key: str, default: bool = True) -> bool:
    raw = str(repo_settings.get(conn, key, "1" if default else "0") or "").strip().lower()
    if raw in {"1", "true", "yes", "on"}:
        return True
    if raw in {"0", "false", "no", "off"}:
        return False
    return bool(default)


def _write_bool(conn: sqlite3.Connection, key: str, enabled: bool) -> None:
    repo_settings.set(conn, key, "1" if bool(enabled) else "0")


def pings_enabled(conn: sqlite3.Connection, admin_user_id: int | None = None) -> bool:
    return _read_bool(conn, _scoped_key(KEY_PINGS_ENABLED, admin_user_id), True)


def reminders_enabled(conn: sqlite3.Connection, admin_user_id: int | None = None) -> bool:
    return _read_bool(conn, _scoped_key(KEY_REMINDERS_ENABLED, admin_user_id), True)


def events_enabled(conn: sqlite3.Connection, admin_user_id: int | None = None) -> bool:
    return _read_bool(conn, _scoped_key(KEY_EVENTS_ENABLED, admin_user_id), True)


def daily_schedule_enabled(conn: sqlite3.Connection, admin_user_id: int | None = None) -> bool:
    return _read_bool(conn, _scoped_key(KEY_DAILY_SCHEDULE_ENABLED, admin_user_id), True)


def snapshot(conn: sqlite3.Connection, admin_user_id: int | None = None) -> dict[str, bool]:
    return {
        "pings": pings_enabled(conn, admin_user_id),
        "reminders": reminders_enabled(conn, admin_user_id),
        "events": events_enabled(conn, admin_user_id),
        "daily_schedule": daily_schedule_enabled(conn, admin_user_id),
    }


def set_pings_enabled(conn: sqlite3.Connection, enabled: bool, admin_user_id: int | None = None) -> None:
    _write_bool(conn, _scoped_key(KEY_PINGS_ENABLED, admin_user_id), enabled)


def set_reminders_enabled(conn: sqlite3.Connection, enabled: bool, admin_user_id: int | None = None) -> None:
    _write_bool(conn, _scoped_key(KEY_REMINDERS_ENABLED, admin_user_id), enabled)


def set_events_enabled(conn: sqlite3.Connection, enabled: bool, admin_user_id: int | None = None) -> None:
    _write_bool(conn, _scoped_key(KEY_EVENTS_ENABLED, admin_user_id), enabled)


def set_daily_schedule_enabled(conn: sqlite3.Connection, enabled: bool, admin_user_id: int | None = None) -> None:
    _write_bool(conn, _scoped_key(KEY_DAILY_SCHEDULE_ENABLED, admin_user_id), enabled)
