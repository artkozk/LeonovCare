from __future__ import annotations

import sqlite3

from telebot import TeleBot
from telebot.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from app.handlers.common import is_admin
from app.db import repo_states
from app.services.autoapply_queries import (
    CORE_AUTOAPPLY_DIRECTIONS,
    DEFAULT_QUERY_BY_DIRECTION,
    list_core_queries,
    normalize_direction,
    reset_core_queries,
    set_core_query,
)


HH_STATE = "HH_ACCESS"
HH_AUTOQUERY_STATE = "HH_AUTOQUERY_EDIT"


def _has_hh(r: sqlite3.Row) -> bool:
    phone = (r["hh_phone"] or "").strip()
    email = (r["hh_email"] or "").strip()
    pwd = (r["hh_password"] or "").strip()
    birth = (r["hh_birth_date"] or "").strip() if "hh_birth_date" in r.keys() else ""
    loc = (r["hh_location"] or "").strip() if "hh_location" in r.keys() else ""
    smin = r["hh_salary_min"] if "hh_salary_min" in r.keys() else None
    scomf = r["hh_salary_comfort"] if "hh_salary_comfort" in r.keys() else None
    return bool(phone or email or pwd or birth or loc or smin or scomf)


def _list_hh_students(conn: sqlite3.Connection, page: int, page_size: int = 8) -> tuple[list[sqlite3.Row], int]:
    # Only students that have at least something filled.
    total = conn.execute(
        "SELECT COUNT(1) AS c FROM students WHERE archived=0 AND ("
        "COALESCE(hh_phone,'')!='' OR COALESCE(hh_email,'')!='' OR COALESCE(hh_password,'')!='' OR "
        "COALESCE(hh_birth_date,'')!='' OR COALESCE(hh_location,'')!='' OR "
        "COALESCE(hh_salary_min,0)!=0 OR COALESCE(hh_salary_comfort,0)!=0)"
    ).fetchone()["c"]

    rows = conn.execute(
        "SELECT id, fio, username, hh_phone, hh_email, hh_password, hh_birth_date, hh_location, hh_salary_min, hh_salary_comfort "
        "FROM students "
        "WHERE archived=0 AND ("
        "COALESCE(hh_phone,'')!='' OR COALESCE(hh_email,'')!='' OR COALESCE(hh_password,'')!='' OR "
        "COALESCE(hh_birth_date,'')!='' OR COALESCE(hh_location,'')!='' OR "
        "COALESCE(hh_salary_min,0)!=0 OR COALESCE(hh_salary_comfort,0)!=0) "
        "ORDER BY fio COLLATE NOCASE "
        "LIMIT ? OFFSET ?",
        (page_size, page * page_size),
    ).fetchall()
    return rows, int(total or 0)


def _hh_list_text(rows: list[sqlite3.Row], page: int, total: int, page_size: int) -> str:
    if total == 0:
        return "<b>Доступы HH</b>\n\nПока нет ни одного ученика с заполненными доступами."

    start = page * page_size + 1
    end = min((page + 1) * page_size, total)
    lines = [f"<b>Доступы HH</b>\n{start}–{end} из {total}\n"]
    for r in rows:
        fio = (r["fio"] or "—").strip()
        uname = (r["username"] or "").strip()
        suffix = f" (@{uname})" if uname else ""
        lines.append(f"• {fio}{suffix}")
    lines.append("\nНажми на ученика, чтобы открыть." )
    return "\n".join(lines)


def _hh_list_kb(rows: list[sqlite3.Row], page: int, total: int, page_size: int) -> InlineKeyboardMarkup:
    kb = InlineKeyboardMarkup()
    for r in rows:
        fio = (r["fio"] or "—").strip()
        kb.row(InlineKeyboardButton(fio, callback_data=f"hh:open:{int(r['id'])}"))

    nav = []
    if page > 0:
        nav.append(InlineKeyboardButton("◀️", callback_data="hh:nav:prev"))
    nav.append(InlineKeyboardButton(f"{page+1}/{max(1, (total + page_size - 1)//page_size)}", callback_data="noop"))
    if (page + 1) * page_size < total:
        nav.append(InlineKeyboardButton("▶️", callback_data="hh:nav:next"))
    if nav:
        kb.row(*nav)

    kb.row(InlineKeyboardButton("⚙️ Запросы автооткликов", callback_data="hh:autoq"))
    kb.row(InlineKeyboardButton("⬅️ Назад", callback_data="m:main"))
    return kb


def _hh_open_text(r: sqlite3.Row, show_pwd: bool) -> str:
    fio = (r["fio"] or "—").strip()
    uname = (r["username"] or "").strip()
    phone = (r["hh_phone"] or "").strip() or "—"
    email = (r["hh_email"] or "").strip() or "—"
    pwd_raw = (r["hh_password"] or "").strip()
    pwd = pwd_raw if (show_pwd and pwd_raw) else ("•" * 8 if pwd_raw else "—")

    birth = (r["hh_birth_date"] or "").strip() or "—"
    loc = (r["hh_location"] or "").strip() or "—"
    def _money(v):
        return f"{int(v):,}".replace(",", " ") + " ₽" if v not in (None, 0, "0") else "—"

    lines = ["<b>HH доступы</b>", f"\n<b>{fio}</b>"]
    if uname:
        lines.append(f"tg: @{uname}")
    lines.append(f"HH телефон: <code>{phone}</code>")
    lines.append(f"HH email: <code>{email}</code>")
    lines.append(f"HH пароль: <code>{pwd}</code>")
    lines.append(f"Дата рождения: <code>{birth}</code>")
    lines.append(f"Локация: <code>{loc}</code>")
    lines.append(f"Фин ожидания (мин): <code>{_money(r['hh_salary_min'])}</code>")
    lines.append(f"Фин ожидания (комфорт): <code>{_money(r['hh_salary_comfort'])}</code>")
    return "\n".join(lines)


def _hh_open_kb(student_id: int, show_pwd: bool) -> InlineKeyboardMarkup:
    kb = InlineKeyboardMarkup()
    if show_pwd:
        kb.row(InlineKeyboardButton("🙈 Скрыть пароль", callback_data=f"hh:pwd:hide:{student_id}"))
    else:
        kb.row(InlineKeyboardButton("👁 Показать пароль", callback_data=f"hh:pwd:show:{student_id}"))
    kb.row(InlineKeyboardButton("⬅️ К списку", callback_data="hh:back"))
    return kb


def _autoq_label(direction: str) -> str:
    return {
        "java": "Java",
        "frontend": "Frontend",
        "golang": "Golang",
        "python": "Python",
    }.get(direction, direction)


def _autoq_text(conn: sqlite3.Connection) -> str:
    current = list_core_queries(conn)
    lines = ["<b>Запросы автооткликов (основные направления)</b>", ""]
    for d in CORE_AUTOAPPLY_DIRECTIONS:
        lines.append(f"• {_autoq_label(d)}: <code>{current.get(d) or DEFAULT_QUERY_BY_DIRECTION.get(d, '')}</code>")
    lines.append("")
    lines.append("Эти запросы используются автоматически, без вопроса пользователю.")
    return "\n".join(lines)


def _autoq_kb() -> InlineKeyboardMarkup:
    kb = InlineKeyboardMarkup()
    kb.row(
        InlineKeyboardButton("Java", callback_data="hh:autoq:edit:java"),
        InlineKeyboardButton("Frontend", callback_data="hh:autoq:edit:frontend"),
    )
    kb.row(
        InlineKeyboardButton("Golang", callback_data="hh:autoq:edit:golang"),
        InlineKeyboardButton("Python", callback_data="hh:autoq:edit:python"),
    )
    kb.row(InlineKeyboardButton("↺ Сбросить по умолчанию", callback_data="hh:autoq:reset"))
    kb.row(InlineKeyboardButton("⬅️ Назад", callback_data="m:hh"))
    return kb


def init(bot: TeleBot, ctx: dict) -> None:
    conn: sqlite3.Connection = ctx["conn"]

    def render_list(c: CallbackQuery, page: int):
        page_size = 8
        rows, total = _list_hh_students(conn, page, page_size)
        text = _hh_list_text(rows, page, total, page_size)
        kb = _hh_list_kb(rows, page, total, page_size)
        bot.edit_message_text(text, c.message.chat.id, c.message.message_id, reply_markup=kb)

    @bot.callback_query_handler(func=lambda c: c.data == "m:hh")
    def hh_menu(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        repo_states.set_state(conn, c.from_user.id, HH_STATE, {"page": 0, "open_id": None, "show_pwd": False})
        render_list(c, 0)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data in ("hh:nav:prev", "hh:nav:next"))
    def hh_nav(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        state, data = repo_states.get_state(conn, c.from_user.id)
        data = data if state == HH_STATE else {}
        page = int(data.get("page") or 0)
        if c.data.endswith("prev"):
            page = max(0, page - 1)
        else:
            page = page + 1
        data["page"] = page
        data["open_id"] = None
        data["show_pwd"] = False
        repo_states.set_state(conn, c.from_user.id, HH_STATE, data)
        render_list(c, page)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("hh:open:"))
    def hh_open(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        sid = int(c.data.split(":")[2])
        r = conn.execute(
            "SELECT id, fio, username, hh_phone, hh_email, hh_password, hh_birth_date, hh_location, hh_salary_min, hh_salary_comfort FROM students WHERE id=?",
            (sid,),
        ).fetchone()
        if not r or not _has_hh(r):
            bot.answer_callback_query(c.id, "Нет данных")
            return

        state, data = repo_states.get_state(conn, c.from_user.id)
        data = data if state == HH_STATE else {"page": 0}
        data["open_id"] = sid
        data["show_pwd"] = False
        repo_states.set_state(conn, c.from_user.id, HH_STATE, data)

        bot.edit_message_text(_hh_open_text(r, show_pwd=False), c.message.chat.id, c.message.message_id, reply_markup=_hh_open_kb(sid, False))
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("hh:pwd:"))
    def hh_pwd(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        parts = c.data.split(":")
        action = parts[2]
        sid = int(parts[3])
        show = action == "show"

        r = conn.execute(
            "SELECT id, fio, username, hh_phone, hh_email, hh_password, hh_birth_date, hh_location, hh_salary_min, hh_salary_comfort FROM students WHERE id=?",
            (sid,),
        ).fetchone()
        if not r:
            bot.answer_callback_query(c.id, "Не найден")
            return

        state, data = repo_states.get_state(conn, c.from_user.id)
        data = data if state == HH_STATE else {"page": 0}
        data["open_id"] = sid
        data["show_pwd"] = show
        repo_states.set_state(conn, c.from_user.id, HH_STATE, data)

        bot.edit_message_text(_hh_open_text(r, show_pwd=show), c.message.chat.id, c.message.message_id, reply_markup=_hh_open_kb(sid, show))
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data == "hh:back")
    def hh_back(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        state, data = repo_states.get_state(conn, c.from_user.id)
        data = data if state == HH_STATE else {"page": 0}
        page = int(data.get("page") or 0)
        data["open_id"] = None
        data["show_pwd"] = False
        repo_states.set_state(conn, c.from_user.id, HH_STATE, data)
        render_list(c, page)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data == "hh:autoq")
    def hh_autoq_menu(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        repo_states.clear_state(conn, int(c.from_user.id))
        bot.edit_message_text(_autoq_text(conn), c.message.chat.id, c.message.message_id, reply_markup=_autoq_kb())
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("hh:autoq:edit:"))
    def hh_autoq_edit(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        direction = normalize_direction(c.data.split(":")[3])
        if direction not in CORE_AUTOAPPLY_DIRECTIONS:
            bot.answer_callback_query(c.id, "Неизвестное направление")
            return
        current = list_core_queries(conn).get(direction) or DEFAULT_QUERY_BY_DIRECTION.get(direction, "")
        repo_states.set_state(conn, int(c.from_user.id), HH_AUTOQUERY_STATE, {"direction": direction})
        bot.send_message(
            c.message.chat.id,
            f"Новый запрос для <b>{_autoq_label(direction)}</b>.\n"
            f"Текущее значение: <code>{current}</code>\n"
            "Отправь новый текст одним сообщением.",
        )
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data == "hh:autoq:reset")
    def hh_autoq_reset(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        reset_core_queries(conn)
        bot.edit_message_text(
            _autoq_text(conn),
            c.message.chat.id,
            c.message.message_id,
            reply_markup=_autoq_kb(),
        )
        bot.answer_callback_query(c.id, "Сброшено")

    @bot.message_handler(
        func=lambda m: repo_states.get_state(conn, m.from_user.id)[0] == HH_AUTOQUERY_STATE,
        content_types=["text"],
    )
    def hh_autoq_set_value(m: Message):
        if not is_admin(ctx, m.from_user.id):
            return
        state, data = repo_states.get_state(conn, int(m.from_user.id))
        if state != HH_AUTOQUERY_STATE:
            return
        data = data or {}
        direction = normalize_direction(data.get("direction"))
        query = (m.text or "").strip()
        if direction not in CORE_AUTOAPPLY_DIRECTIONS:
            repo_states.clear_state(conn, int(m.from_user.id))
            bot.send_message(m.chat.id, "Направление не найдено. Открой настройки заново через раздел HH.")
            return
        if len(query) < 2:
            bot.send_message(m.chat.id, "Слишком коротко. Введи запрос минимум из 2 символов.")
            return
        if not set_core_query(conn, direction, query):
            bot.send_message(m.chat.id, "Не удалось сохранить запрос.")
            return
        repo_states.clear_state(conn, int(m.from_user.id))
        bot.send_message(
            m.chat.id,
            (
                f"Сохранено ✅\n"
                f"{_autoq_label(direction)}: <code>{query}</code>\n\n"
                f"{_autoq_text(conn)}"
            ),
            reply_markup=_autoq_kb(),
        )
