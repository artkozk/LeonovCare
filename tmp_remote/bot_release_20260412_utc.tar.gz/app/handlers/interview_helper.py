from __future__ import annotations

import html
import sqlite3
from datetime import datetime, timedelta, timezone

from telebot import TeleBot
from telebot.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup

from app.db import (
    repo_admins,
    repo_checkout_payments,
    repo_interview_helper_licenses,
    repo_states,
    repo_students,
)
from app.services.interview_helper_client import InterviewHelperClient, InterviewHelperClientError
from app.services.timeutils import now
from app.services.cardlink_client import CardlinkClient, CardlinkClientError, normalize_status as cardlink_status

STATE_INTERVIEW_HELPER = "u_interview_helper"


def init(bot: TeleBot, ctx: dict) -> None:
    conn: sqlite3.Connection = ctx["conn"]
    cfg = ctx["cfg"]
    tz = cfg.TZ
    cardlink_client = CardlinkClient(
        shop_id=cfg.CARDLINK_SHOP_ID,
        bearer_token=cfg.CARDLINK_BEARER_TOKEN,
        return_url=cfg.CARDLINK_RETURN_URL,
        timeout_sec=cfg.CARDLINK_TIMEOUT_SEC,
        api_base_url=cfg.CARDLINK_API_BASE_URL,
    )
    interview_client = InterviewHelperClient(
        base_url=cfg.INTERVIEW_API_BASE_URL,
        admin_username=cfg.INTERVIEW_API_ADMIN_USERNAME,
        admin_password=cfg.INTERVIEW_API_ADMIN_PASSWORD,
        timeout_sec=cfg.INTERVIEW_API_TIMEOUT_SEC,
    )

    def _is_admin(user_id: int) -> bool:
        return repo_admins.is_admin(conn, int(user_id), cfg.ADMIN_IDS)

    def _is_student(user_id: int) -> bool:
        return repo_students.get_by_owner(conn, int(user_id)) is not None

    def _price() -> int:
        return max(int(cfg.INTERVIEW_HELPER_PRICE_RUB or 500), 1)

    def _duration_days() -> int:
        return max(int(cfg.INTERVIEW_HELPER_DURATION_DAYS or 30), 1)

    def _download_url() -> str:
        return str(getattr(cfg, "INTERVIEW_HELPER_DOWNLOAD_URL", "") or "").strip()

    def _student_free_enabled() -> bool:
        return bool(getattr(cfg, "INTERVIEW_HELPER_STUDENT_FREE", False))

    def _menu_kb(show_key: bool, is_student: bool) -> InlineKeyboardMarkup:
        kb = InlineKeyboardMarkup()
        dl_url = _download_url()
        if dl_url:
            kb.row(InlineKeyboardButton("⬇️ Скачать Interview helper", url=dl_url))
        if is_student and _student_free_enabled():
            kb.row(InlineKeyboardButton("🎁 Получить/продлить бесплатно", callback_data="ih:pay:start"))
        else:
            kb.row(InlineKeyboardButton("💳 Оплатить и получить ключ", callback_data="ih:pay:start"))
        if show_key:
            kb.row(InlineKeyboardButton("🔑 Показать ключ", callback_data="ih:key:show"))
        kb.row(InlineKeyboardButton("⬅️ В меню", callback_data="v2:home"))
        return kb

    def _checkout_kb(local_payment_id: int, payment_url: str | None) -> InlineKeyboardMarkup:
        kb = InlineKeyboardMarkup()
        if payment_url:
            kb.row(InlineKeyboardButton("💳 Оплатить", url=payment_url))
        kb.row(InlineKeyboardButton("🔄 Проверить оплату", callback_data=f"ih:pay:check:{local_payment_id}"))
        kb.row(InlineKeyboardButton("⬅️ В меню", callback_data="v2:home"))
        return kb

    def _latest_license_text(owner_id: int) -> tuple[str, bool]:
        lic = repo_interview_helper_licenses.latest_for_user(conn, int(owner_id))
        if not lic:
            return "Лицензии пока нет.", False
        key = str(lic["license_key"] or "").strip()
        key_masked = key if len(key) <= 6 else f"{key[:4]}...{key[-4:]}"
        expires_at = str(lic["expires_at"] or "").strip() or "—"
        enabled = int(lic["enabled"] or 0) == 1
        status = "активна" if enabled else "неактивна"
        text = (
            f"Текущая лицензия: <code>{html.escape(key_masked)}</code>\n"
            f"Статус: <b>{status}</b>\n"
            f"Действует до: <b>{html.escape(expires_at)}</b>"
        )
        return text, bool(key)

    def _open_menu(chat_id: int, owner_id: int, message_id: int | None = None) -> None:
        lic_text, has_key = _latest_license_text(owner_id)
        is_student = _is_student(owner_id)
        if is_student and _student_free_enabled():
            tariff_line = f"Для ученика: <b>бесплатно</b> на <b>{_duration_days()} дн.</b>"
        elif cardlink_client.enabled:
            tariff_line = f"Тариф: <b>{_price()} ₽</b> на <b>{_duration_days()} дн.</b>"
        else:
            tariff_line = (
                f"Тариф: <b>{_price()} ₽</b> на <b>{_duration_days()} дн.</b>\n"
                "Оплата доступна через Cardlink, сейчас касса недоступна."
            )
        dl_url = _download_url()
        if dl_url:
            download_line = (
                "Скачать приложение: "
                f"<a href=\"{html.escape(dl_url)}\">Яндекс.Диск</a>"
            )
        else:
            download_line = "Скачать приложение: ссылка не настроена, напиши ментору."
        text = (
            "<b>Interview helper</b>\n"
            "Бот выдаёт лицензионный ключ на ограниченный срок.\n"
            f"{download_line}\n"
            f"{tariff_line}\n\n"
            f"{lic_text}"
        )
        if message_id is None:
            bot.send_message(chat_id, text, reply_markup=_menu_kb(has_key, is_student=is_student))
        else:
            bot.edit_message_text(text, chat_id, message_id, reply_markup=_menu_kb(has_key, is_student=is_student))

    def _active_license(owner_id: int) -> sqlite3.Row | None:
        lic = repo_interview_helper_licenses.latest_for_user(conn, int(owner_id))
        if not lic or int(lic["enabled"] or 0) != 1:
            return None
        expires_raw = str(lic["expires_at"] or "").strip()
        if not expires_raw:
            return lic
        try:
            expires_at = datetime.fromisoformat(expires_raw.replace("Z", "+00:00"))
        except Exception:
            return lic
        if expires_at.tzinfo is None:
            return lic
        if expires_at.astimezone(timezone.utc) > now(tz).astimezone(timezone.utc):
            return lic
        return None

    def _create_checkout(owner_id: int, chat_id: int, username: str | None) -> tuple[sqlite3.Row | None, str]:
        if not cardlink_client.enabled:
            return None, "Касса Cardlink не настроена. Оплата сейчас недоступна."
        amount = _price()
        try:
            provider = cardlink_client.create_payment(
                amount_rub=amount,
                description=f"Interview helper (TG {owner_id})",
                metadata={
                    "owner_tg_id": int(owner_id),
                    "service_key": "interview_helper",
                },
            )
        except CardlinkClientError as exc:
            return None, f"Не удалось создать платёж: {html.escape(str(exc))}"
        provider_payment_id = str(provider.get("id") or "").strip()
        if not provider_payment_id:
            return None, "Cardlink не вернула id платежа."
        confirmation_url = str(cardlink_client._extract_confirmation_url(provider)).strip()
        if not confirmation_url:
            try:
                probe = cardlink_client.get_payment(provider_payment_id)
                if isinstance(probe, dict):
                    provider = {**provider, "_status_probe": probe}
                    confirmation_url = str(cardlink_client._extract_confirmation_url(probe)).strip() or str(
                        cardlink_client._extract_confirmation_url(provider)
                    ).strip()
            except CardlinkClientError:
                pass
        if not confirmation_url:
            return None, "Cardlink не вернула ссылку оплаты. Проверь настройки магазина и попробуй ещё раз."
        local_id = repo_checkout_payments.create(
            conn,
            tz,
            owner_tg_id=owner_id,
            owner_chat_id=chat_id,
            owner_username=username,
            req_type="INTERVIEW_HELPER_PAYMENT",
            service_key="interview_helper",
            service_title="Interview helper",
            purpose=f"Оплата Interview helper (TG {owner_id})",
            amount=amount,
            currency=str(provider.get("amount", {}).get("currency") or "RUB"),
            provider="cardlink",
            provider_payment_id=provider_payment_id,
            idempotence_key=str(provider.get("idempotence_key") or "").strip() or None,
            status=cardlink_status(provider.get("status")),
            confirmation_url=confirmation_url,
            metadata={"owner_tg_id": owner_id, "service_key": "interview_helper"},
            provider_payload=provider,
        )
        return repo_checkout_payments.get(conn, local_id), ""

    def _refresh_checkout(local_payment_id: int) -> tuple[sqlite3.Row | None, str]:
        row = repo_checkout_payments.get(conn, int(local_payment_id))
        if not row:
            return None, "Платёж не найден."
        if not cardlink_client.enabled:
            return row, "Cardlink не настроена в текущем окружении."
        provider_payment_id = str(row["provider_payment_id"] or "").strip()
        if not provider_payment_id:
            return row, "Не найден provider_payment_id."
        try:
            provider = cardlink_client.get_payment(provider_payment_id)
        except CardlinkClientError as exc:
            return row, f"Не удалось обновить статус: {html.escape(str(exc))}"
        status = cardlink_status(provider.get("status"))
        confirmation = provider.get("confirmation") if isinstance(provider.get("confirmation"), dict) else {}
        confirmation_url = str(
            confirmation.get("confirmation_url")
            or confirmation.get("confirmationUrl")
            or provider.get("confirmation_url")
            or row["confirmation_url"]
            or ""
        ).strip()
        paid_at = str(provider.get("paid_at") or provider.get("captured_at") or "").strip() or None
        repo_checkout_payments.set_status(
            conn,
            tz,
            int(local_payment_id),
            status=status,
            provider_payload=provider,
            confirmation_url=confirmation_url or None,
            paid_at=paid_at,
        )
        return repo_checkout_payments.get(conn, int(local_payment_id)), ""

    def _issue_license(
        owner_id: int,
        chat_id: int,
        username: str | None,
        payment_row_id: int | None,
        note_suffix: str = "",
    ) -> tuple[sqlite3.Row | None, str]:
        if payment_row_id is not None:
            existing = repo_interview_helper_licenses.get_by_payment(conn, int(payment_row_id))
            if existing:
                return existing, ""
        if not interview_client.enabled:
            return None, "API Interview Helper не настроен."
        expires_local = now(tz) + timedelta(days=_duration_days())
        expires_utc = expires_local.astimezone(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")
        parts = [f"tg={owner_id}"]
        if payment_row_id is not None:
            parts.append(f"payment={int(payment_row_id)}")
        if note_suffix:
            parts.append(note_suffix.strip())
        note = ";".join(parts)
        try:
            response = interview_client.create_license(
                plan=cfg.INTERVIEW_API_PLAN,
                expires_at=expires_utc,
                note=note,
            )
        except InterviewHelperClientError as exc:
            return None, f"Не удалось выпустить ключ: {html.escape(str(exc))}"
        key = str(response.get("key") or response.get("licenseKey") or "").strip()
        if not key:
            return None, "API не вернул лицензионный ключ."
        try:
            status_info = interview_client.check_license_status(key)
        except InterviewHelperClientError as exc:
            return None, f"Ключ выдан, но не прошел проверку статуса: {html.escape(str(exc))}"
        status_txt = str(status_info.get("status") or "").strip().upper()
        valid_flag = status_info.get("valid")
        enabled_flag = status_info.get("enabled")
        if valid_flag is False or enabled_flag is False or status_txt in {"INVALID", "REVOKED", "BLOCKED", "EXPIRED"}:
            return None, (
                "Ключ выпущен API, но статус неактивный: "
                f"{html.escape(status_txt or 'UNKNOWN')}"
            )
        created_id = repo_interview_helper_licenses.create(
            conn,
            tz,
            owner_tg_id=owner_id,
            owner_chat_id=chat_id,
            owner_username=username,
            checkout_payment_id=payment_row_id,
            external_license_id=int(response.get("id")) if str(response.get("id") or "").isdigit() else None,
            license_key=key,
            plan=str(response.get("plan") or cfg.INTERVIEW_API_PLAN or "PRO"),
            enabled=bool(response.get("enabled", True)),
            expires_at=str(response.get("expiresAt") or expires_utc),
            note=note,
            payload={**response, "status_check": status_info},
        )
        if payment_row_id is not None:
            return (
                repo_interview_helper_licenses.latest_for_user(conn, owner_id)
                or repo_interview_helper_licenses.get_by_payment(conn, payment_row_id)
            ), "" if created_id else ""
        return repo_interview_helper_licenses.latest_for_user(conn, owner_id), "" if created_id else ""

    @bot.callback_query_handler(func=lambda c: c.data == "v2:interview_helper")
    def cb_ih_open(c: CallbackQuery):
        if _is_admin(c.from_user.id):
            bot.answer_callback_query(c.id, "Это пользовательский раздел")
            return
        repo_states.clear_state(conn, int(c.from_user.id), tz)
        _open_menu(c.message.chat.id, int(c.from_user.id), message_id=c.message.message_id)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data == "ih:key:show")
    def cb_ih_key_show(c: CallbackQuery):
        if _is_admin(c.from_user.id):
            bot.answer_callback_query(c.id, "Это пользовательский раздел")
            return
        lic = repo_interview_helper_licenses.latest_for_user(conn, int(c.from_user.id))
        if not lic:
            bot.answer_callback_query(c.id, "Ключ пока не выпускался")
            return
        key = str(lic["license_key"] or "").strip() or "—"
        expires = str(lic["expires_at"] or "").strip() or "—"
        bot.send_message(
            c.message.chat.id,
            "<b>Твой ключ Interview helper</b>\n"
            f"Ключ: <code>{html.escape(key)}</code>\n"
            f"Действует до: <b>{html.escape(expires)}</b>",
            reply_markup=_menu_kb(show_key=True, is_student=_is_student(int(c.from_user.id))),
        )
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data == "ih:pay:start")
    def cb_ih_pay_start(c: CallbackQuery):
        if _is_admin(c.from_user.id):
            bot.answer_callback_query(c.id, "Это пользовательский раздел")
            return
        owner_id = int(c.from_user.id)
        active = _active_license(owner_id)
        if active:
            bot.send_message(
                c.message.chat.id,
                "<b>Ключ уже активен ✅</b>\n"
                f"Ключ: <code>{html.escape(str(active['license_key'] or '—'))}</code>\n"
                f"Действует до: <b>{html.escape(str(active['expires_at'] or '—'))}</b>",
                reply_markup=_menu_kb(show_key=True, is_student=_is_student(owner_id)),
            )
            bot.answer_callback_query(c.id, "Ключ уже активен")
            return
        if _is_student(owner_id) and _student_free_enabled():
            lic, err_issue = _issue_license(
                owner_id,
                int(c.message.chat.id),
                c.from_user.username,
                payment_row_id=None,
                note_suffix="student_free",
            )
            if not lic:
                bot.send_message(
                    c.message.chat.id,
                    f"Не удалось выпустить ключ: {err_issue or 'неизвестная ошибка'}",
                    reply_markup=_menu_kb(show_key=False, is_student=True),
                )
                bot.answer_callback_query(c.id, "Ошибка выдачи")
                return
            repo_states.clear_state(conn, owner_id, tz)
            bot.send_message(
                c.message.chat.id,
                "<b>Ключ выдан бесплатно ✅</b>\n"
                f"Ключ: <code>{html.escape(str(lic['license_key'] or '—'))}</code>\n"
                f"Действует до: <b>{html.escape(str(lic['expires_at'] or '—'))}</b>",
                reply_markup=_menu_kb(show_key=True, is_student=True),
            )
            bot.answer_callback_query(c.id, "Ключ выдан")
            return

        if not cardlink_client.enabled:
            bot.send_message(
                c.message.chat.id,
                "Оплата доступна только через кассу Cardlink.\n"
                "Касса сейчас не настроена, попробуй позже.",
                reply_markup=_menu_kb(
                    show_key=bool(repo_interview_helper_licenses.latest_for_user(conn, owner_id)),
                    is_student=_is_student(owner_id),
                ),
            )
            bot.answer_callback_query(c.id, "Касса недоступна")
            return

        row, err = _create_checkout(owner_id, int(c.message.chat.id), c.from_user.username)
        if not row:
            bot.send_message(
                c.message.chat.id,
                err or "Не удалось создать платёж. Попробуй позже.",
                reply_markup=_menu_kb(
                    show_key=bool(repo_interview_helper_licenses.latest_for_user(conn, owner_id)),
                    is_student=_is_student(owner_id),
                ),
            )
            bot.answer_callback_query(c.id, "Ошибка оплаты")
            return
        local_id = int(row["id"])
        repo_states.set_state(
            conn,
            owner_id,
            STATE_INTERVIEW_HELPER,
            {"step": "checkout_wait", "checkout_payment_id": local_id},
            tz,
        )
        bot.send_message(
            c.message.chat.id,
            "<b>Оплата Interview helper</b>\n"
            f"Сумма: <b>{_price()} ₽</b>\n"
            "Нажми «Оплатить», затем «Проверить оплату».",
            reply_markup=_checkout_kb(local_id, str(row["confirmation_url"] or "")),
        )
        bot.answer_callback_query(c.id, "Ссылка на оплату готова")

    @bot.callback_query_handler(func=lambda c: c.data.startswith("ih:pay:check:"))
    def cb_ih_pay_check(c: CallbackQuery):
        if _is_admin(c.from_user.id):
            bot.answer_callback_query(c.id, "Это пользовательский раздел")
            return
        owner_id = int(c.from_user.id)
        payment_row_id = int(c.data.split(":")[3])
        row = repo_checkout_payments.get(conn, payment_row_id)
        if not row or int(row["owner_tg_id"] or 0) != owner_id:
            bot.answer_callback_query(c.id, "Платёж не найден")
            return
        row, err = _refresh_checkout(payment_row_id)
        if not row:
            bot.answer_callback_query(c.id, "Платёж не найден")
            return
        if err:
            bot.answer_callback_query(c.id, "Статус не обновлён")
            bot.send_message(c.message.chat.id, err)
            return
        status = str(row["status"] or "").strip().upper()
        if status in {repo_checkout_payments.STATUS_PENDING, repo_checkout_payments.STATUS_WAITING_CAPTURE}:
            bot.send_message(
                c.message.chat.id,
                "Платёж ещё не подтверждён. Если уже оплатил — попробуй ещё раз через 10-20 секунд.",
                reply_markup=_checkout_kb(payment_row_id, str(row["confirmation_url"] or "")),
            )
            bot.answer_callback_query(c.id, "Пока ожидаем")
            return
        if status != repo_checkout_payments.STATUS_SUCCEEDED:
            bot.send_message(
                c.message.chat.id,
                "Платёж не завершён. Попробуй оплатить снова.",
                reply_markup=_menu_kb(
                    show_key=bool(repo_interview_helper_licenses.latest_for_user(conn, owner_id)),
                    is_student=_is_student(owner_id),
                ),
            )
            bot.answer_callback_query(c.id, "Оплата не подтверждена")
            return
        if int(row["action_done"] or 0) == 1:
            lic = repo_interview_helper_licenses.get_by_payment(conn, payment_row_id)
            if lic:
                bot.send_message(
                    c.message.chat.id,
                    "<b>Оплата уже подтверждена</b>\n"
                    f"Ключ: <code>{html.escape(str(lic['license_key'] or '—'))}</code>",
                    reply_markup=_menu_kb(show_key=True, is_student=_is_student(owner_id)),
                )
            bot.answer_callback_query(c.id, "Уже подтверждено")
            return

        lic, err_issue = _issue_license(owner_id, int(c.message.chat.id), c.from_user.username, payment_row_id, note_suffix="cardlink")
        if not lic:
            bot.send_message(
                c.message.chat.id,
                f"Оплата прошла, но ключ пока не выпущен: {err_issue or 'неизвестная ошибка'}\n"
                "Попробуй «Проверить оплату» ещё раз через минуту.",
                reply_markup=_checkout_kb(payment_row_id, str(row["confirmation_url"] or "")),
            )
            bot.answer_callback_query(c.id, "Ключ ещё не выпущен")
            return

        repo_checkout_payments.mark_action_done(conn, tz, payment_row_id, note="interview_license_issued")
        repo_states.clear_state(conn, owner_id, tz)
        key = str(lic["license_key"] or "").strip() or "—"
        expires = str(lic["expires_at"] or "").strip() or "—"
        bot.send_message(
            c.message.chat.id,
            "<b>Оплата подтверждена ✅</b>\n"
            f"Твой ключ: <code>{html.escape(key)}</code>\n"
            f"Действует до: <b>{html.escape(expires)}</b>",
            reply_markup=_menu_kb(show_key=True, is_student=_is_student(owner_id)),
        )
        bot.answer_callback_query(c.id, "Ключ выдан")

    @bot.message_handler(commands=["ih_reset_keys_all"])
    def cmd_ih_reset_all(m):
        if not _is_admin(m.from_user.id):
            return
        before = repo_interview_helper_licenses.active_count(conn)
        changed = repo_interview_helper_licenses.deactivate_all(
            conn,
            tz,
            reason=f"admin_reset_by:{int(m.from_user.id)}",
        )
        after = repo_interview_helper_licenses.active_count(conn)
        bot.reply_to(
            m,
            "Interview Helper: активные ключи сброшены.\n"
            f"Было активно: {before}\n"
            f"Отключено: {changed}\n"
            f"Осталось активно: {after}",
        )
