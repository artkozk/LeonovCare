from __future__ import annotations

import sqlite3

from telebot import TeleBot
from telebot.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from app.db import repo_admins, repo_analytics, repo_states, repo_student_codes, repo_students
from app.services import admin_notification_settings
from app.ui.keyboards import admins_menu_kb

STATE_ADMIN_ADD = "ADM_ADD"


def init(bot: TeleBot, ctx: dict) -> None:
    conn: sqlite3.Connection = ctx["conn"]
    tz = ctx["cfg"].TZ

    def _is_admin(user_id: int) -> bool:
        return repo_admins.is_admin(conn, int(user_id), ctx["cfg"].ADMIN_IDS)

    def _can_manage_admins(user_id: int) -> bool:
        return repo_admins.has_permission(
            conn,
            int(user_id),
            ctx["cfg"].ADMIN_IDS,
            repo_admins.PERM_ADMINS_MANAGE,
        )

    def _base_admin_ids() -> set[int]:
        out: set[int] = set()
        for raw in ctx["cfg"].ADMIN_IDS or []:
            try:
                uid = int(raw)
            except Exception:
                continue
            if uid > 0:
                out.add(uid)
        return out

    def _display_username(user_id: int, fallback_username: str | None = None) -> str:
        uname = (fallback_username or "").strip().lstrip("@")
        if not uname:
            row = conn.execute(
                "SELECT username FROM user_profiles WHERE user_id=? LIMIT 1",
                (int(user_id),),
            ).fetchone()
            if row and row["username"]:
                uname = str(row["username"]).strip().lstrip("@")
        if not uname:
            s = repo_students.get_latest_by_owner(conn, int(user_id))
            if s and s["owner_username"]:
                uname = str(s["owner_username"]).strip().lstrip("@")
        return f"@{uname}" if uname else "—"

    def _grade_label(grade: str | None) -> str:
        g = repo_admins.normalize_grade(grade)
        return "full" if g == repo_admins.ADMIN_GRADE_FULL else "limited"

    def _role_after_admin_remove(user_id: int) -> str:
        latest_student = repo_students.get_latest_by_owner(conn, int(user_id))
        if latest_student and int(latest_student["archived"] or 0) == 0:
            return repo_analytics.ROLE_STUDENT
        if repo_student_codes.has_used_code(conn, int(user_id)):
            return repo_analytics.ROLE_STUDENT
        return repo_analytics.ROLE_REGULAR

    def _parse_target(text: str) -> tuple[int | None, str | None]:
        raw = (text or "").strip()
        if not raw:
            return None, None

        if raw.startswith("@"):
            uname = raw[1:].strip().lower()
            if not uname:
                return None, None
            row = conn.execute(
                "SELECT user_id, username FROM user_profiles WHERE lower(username)=? ORDER BY last_seen_at DESC LIMIT 1",
                (uname,),
            ).fetchone()
            if row:
                return int(row["user_id"]), str(row["username"] or "").strip()
            srow = conn.execute(
                "SELECT owner_tg_id, owner_username FROM students "
                "WHERE owner_tg_id IS NOT NULL AND lower(owner_username)=? "
                "ORDER BY id DESC LIMIT 1",
                (uname,),
            ).fetchone()
            if srow and srow["owner_tg_id"]:
                return int(srow["owner_tg_id"]), str(srow["owner_username"] or "").strip()
            return None, None

        digits = "".join(ch for ch in raw if ch.isdigit() or ch == "-")
        if not digits:
            return None, None
        try:
            uid = int(digits)
        except Exception:
            return None, None
        if uid <= 0:
            return None, None
        return uid, None

    def _remove_list_kb() -> InlineKeyboardMarkup:
        kb = InlineKeyboardMarkup()
        rows = conn.execute(
            "SELECT user_id, username, COALESCE(grade, 'full') AS grade "
            "FROM bot_admins WHERE is_active=1 ORDER BY updated_at DESC, user_id ASC LIMIT 30"
        ).fetchall()
        for r in rows:
            uid = int(r["user_id"])
            uname = _display_username(uid, str(r["username"] or ""))
            label = f"{uname} ({uid}) • {_grade_label(r['grade'])}"
            if len(label) > 56:
                label = label[:55] + "…"
            kb.row(InlineKeyboardButton(label, callback_data=f"adm:rm:{uid}"))
        kb.row(InlineKeyboardButton("⬅️ Назад", callback_data="m:admins"))
        return kb

    def _notify_state_label(enabled: bool) -> str:
        return "✅ Вкл" if enabled else "⛔ Выкл"

    def _notify_settings_text(admin_user_id: int) -> str:
        cfg = admin_notification_settings.snapshot(conn, admin_user_id)
        lines = [
            "<b>Уведомления ментора</b>",
            "",
            "Настройки применяются только к твоему аккаунту.",
            "",
            f"• Пинги/заявки: <b>{_notify_state_label(cfg['pings'])}</b>",
            f"• Напоминалки: <b>{_notify_state_label(cfg['reminders'])}</b>",
            f"• Уведомления о событиях: <b>{_notify_state_label(cfg['events'])}</b>",
            f"• Ежедневное расписание (06:00): <b>{_notify_state_label(cfg['daily_schedule'])}</b>",
        ]
        return "\n".join(lines)

    def _notify_settings_kb(admin_user_id: int) -> InlineKeyboardMarkup:
        cfg = admin_notification_settings.snapshot(conn, admin_user_id)
        back_cb = "m:admins" if _can_manage_admins(admin_user_id) else "m:events"
        kb = InlineKeyboardMarkup()
        kb.row(
            InlineKeyboardButton(
                f"Пинги: {_notify_state_label(cfg['pings'])}",
                callback_data="adm:notify:toggle:pings",
            )
        )
        kb.row(
            InlineKeyboardButton(
                f"Напоминалки: {_notify_state_label(cfg['reminders'])}",
                callback_data="adm:notify:toggle:reminders",
            )
        )
        kb.row(
            InlineKeyboardButton(
                f"События: {_notify_state_label(cfg['events'])}",
                callback_data="adm:notify:toggle:events",
            )
        )
        kb.row(
            InlineKeyboardButton(
                f"Ежедневное расписание: {_notify_state_label(cfg['daily_schedule'])}",
                callback_data="adm:notify:toggle:daily_schedule",
            )
        )
        kb.row(InlineKeyboardButton("⬅️ Назад", callback_data=back_cb))
        return kb

    @bot.callback_query_handler(func=lambda c: c.data == "adm:list")
    def cb_admin_list(c: CallbackQuery):
        if not _can_manage_admins(c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        base_ids = _base_admin_ids()
        dynamic_rows = conn.execute(
            "SELECT *, COALESCE(grade, 'full') AS grade "
            "FROM bot_admins ORDER BY is_active DESC, updated_at DESC, user_id ASC LIMIT 100"
        ).fetchall()

        lines = ["<b>Список админов</b>", ""]
        lines.append("Базовые (из конфига):")
        if base_ids:
            for uid in sorted(base_ids):
                lines.append(f"• {uid} {_display_username(uid)} — full (базовый)")
        else:
            lines.append("• не настроены")

        lines.append("")
        lines.append("Динамические (БД):")
        if not dynamic_rows:
            lines.append("• нет записей")
        else:
            for r in dynamic_rows:
                uid = int(r["user_id"])
                status = "активен" if int(r["is_active"] or 0) == 1 else "отключен"
                grade = _grade_label(r["grade"])
                added_by = int(r["added_by_admin_id"] or 0) if r["added_by_admin_id"] is not None else 0
                lines.append(
                    f"• {uid} {_display_username(uid, str(r['username'] or ''))} "
                    f"— {status}, grade: {grade}, добавил: {added_by if added_by > 0 else '—'}"
                )
        bot.send_message(c.message.chat.id, "\n".join(lines), reply_markup=admins_menu_kb())
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data == "adm:notify_settings")
    def cb_notify_settings(c: CallbackQuery):
        if not _is_admin(c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        admin_id = int(c.from_user.id)
        bot.edit_message_text(
            _notify_settings_text(admin_id),
            c.message.chat.id,
            c.message.message_id,
            reply_markup=_notify_settings_kb(admin_id),
        )
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("adm:notify:toggle:"))
    def cb_notify_toggle(c: CallbackQuery):
        if not _is_admin(c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        admin_id = int(c.from_user.id)
        key = c.data.split(":")[-1]
        if key == "pings":
            admin_notification_settings.set_pings_enabled(
                conn,
                not admin_notification_settings.pings_enabled(conn, admin_id),
                admin_id,
            )
        elif key == "reminders":
            admin_notification_settings.set_reminders_enabled(
                conn,
                not admin_notification_settings.reminders_enabled(conn, admin_id),
                admin_id,
            )
        elif key == "events":
            admin_notification_settings.set_events_enabled(
                conn,
                not admin_notification_settings.events_enabled(conn, admin_id),
                admin_id,
            )
        elif key == "daily_schedule":
            admin_notification_settings.set_daily_schedule_enabled(
                conn,
                not admin_notification_settings.daily_schedule_enabled(conn, admin_id),
                admin_id,
            )
        else:
            bot.answer_callback_query(c.id, "Неизвестная настройка")
            return
        bot.edit_message_text(
            _notify_settings_text(admin_id),
            c.message.chat.id,
            c.message.message_id,
            reply_markup=_notify_settings_kb(admin_id),
        )
        bot.answer_callback_query(c.id, "Обновлено")

    @bot.callback_query_handler(func=lambda c: c.data in {"adm:add", "adm:add:full", "adm:add:limited"})
    def cb_admin_add(c: CallbackQuery):
        if not _can_manage_admins(c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        grade = repo_admins.ADMIN_GRADE_FULL
        if c.data.endswith(":limited"):
            grade = repo_admins.ADMIN_GRADE_LIMITED
        repo_states.set_state(conn, int(c.from_user.id), STATE_ADMIN_ADD, {"grade": grade}, tz)
        bot.send_message(
            c.message.chat.id,
            "Введи Telegram ID нового админа или @username (пользователь должен уже заходить в бота).\n"
            f"Грейд для выдачи: <b>{_grade_label(grade)}</b>",
        )
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data == "adm:remove")
    def cb_admin_remove(c: CallbackQuery):
        if not _can_manage_admins(c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        rows = conn.execute(
            "SELECT 1 FROM bot_admins WHERE is_active=1 LIMIT 1"
        ).fetchall()
        if not rows:
            bot.send_message(c.message.chat.id, "Нет динамических админов для удаления.", reply_markup=admins_menu_kb())
            bot.answer_callback_query(c.id)
            return
        bot.send_message(c.message.chat.id, "Выбери админа для удаления:", reply_markup=_remove_list_kb())
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("adm:rm:"))
    def cb_admin_remove_pick(c: CallbackQuery):
        if not _can_manage_admins(c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        uid = int(c.data.split(":")[2])
        if uid in _base_admin_ids():
            bot.answer_callback_query(c.id, "Базового админа из конфига удалить нельзя")
            return
        if not repo_admins.deactivate(conn, tz, uid):
            bot.answer_callback_query(c.id, "Админ уже удалён или не найден")
            return
        repo_analytics.set_role(conn, tz, uid, _role_after_admin_remove(uid))
        bot.send_message(
            c.message.chat.id,
            f"Админ {uid} удалён из динамического списка.",
            reply_markup=admins_menu_kb(),
        )
        bot.answer_callback_query(c.id, "Удалено")

    @bot.callback_query_handler(func=lambda c: c.data == "adm:remove_all")
    def cb_admin_remove_all(c: CallbackQuery):
        if not _can_manage_admins(c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        rows = conn.execute(
            "SELECT user_id FROM bot_admins WHERE is_active=1 ORDER BY user_id"
        ).fetchall()
        if not rows:
            bot.send_message(c.message.chat.id, "Нет динамических админов для удаления.", reply_markup=admins_menu_kb())
            bot.answer_callback_query(c.id)
            return
        removed = 0
        for r in rows:
            uid = int(r["user_id"])
            if uid in _base_admin_ids():
                continue
            if repo_admins.deactivate(conn, tz, uid):
                repo_analytics.set_role(conn, tz, uid, _role_after_admin_remove(uid))
                removed += 1
        bot.send_message(
            c.message.chat.id,
            f"Удалено динамических админов: {removed}.",
            reply_markup=admins_menu_kb(),
        )
        bot.answer_callback_query(c.id, "Готово")

    @bot.message_handler(func=lambda m: repo_states.get_state(conn, m.from_user.id)[0] == STATE_ADMIN_ADD, content_types=["text"])
    def st_admin_add(m: Message):
        if not _can_manage_admins(m.from_user.id):
            return
        _, state_data = repo_states.get_state(conn, int(m.from_user.id))
        state_data = state_data or {}
        grade = repo_admins.normalize_grade(state_data.get("grade"))
        target_id, uname = _parse_target(m.text or "")
        if not target_id:
            bot.send_message(
                m.chat.id,
                "Не удалось определить пользователя. Отправь Telegram ID (числом) или @username.",
            )
            return
        if target_id in _base_admin_ids():
            repo_states.clear_state(conn, int(m.from_user.id), tz)
            bot.send_message(
                m.chat.id,
                f"Пользователь {target_id} уже является базовым админом из конфига (grade: full).",
                reply_markup=admins_menu_kb(),
            )
            return
        repo_admins.add_or_enable(
            conn,
            tz,
            user_id=target_id,
            added_by_admin_id=int(m.from_user.id),
            username=uname,
            grade=grade,
        )
        repo_analytics.set_role(conn, tz, target_id, repo_analytics.ROLE_ADMIN)
        repo_states.clear_state(conn, int(m.from_user.id), tz)
        bot.send_message(
            m.chat.id,
            f"Админ добавлен/обновлён: {target_id} {_display_username(target_id, uname)} (grade: {_grade_label(grade)})",
            reply_markup=admins_menu_kb(),
        )
        try:
            bot.send_message(
                int(target_id),
                "Тебе выданы права администратора в боте Leonov Care.\n"
                "Отправь /start, чтобы открыть админ-меню.",
            )
        except Exception:
            pass
