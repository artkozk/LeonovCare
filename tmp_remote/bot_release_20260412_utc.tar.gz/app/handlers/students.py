from __future__ import annotations
import html
import sqlite3
import datetime as dt
from telebot import TeleBot
from telebot.types import CallbackQuery, Message, InlineKeyboardMarkup, InlineKeyboardButton

from app.handlers.common import is_admin, send_main
from app.db import repo_broadcasts, repo_students, repo_states, repo_payments, repo_postpay, repo_reminders
from app.services.timeutils import now, iso, format_date_ddmmyyyy, parse_date_ddmm_past, add_months, format_dt_ddmmyyyy_hhmm
from app.services.postpay import post_total, recommended_payment, next_due_after_payment
from app.ui.keyboards import students_menu_kb, pick_list_kb, student_card_kb, student_cards_kb, edit_fields_kb
from app.ui import texts

PAGE_SIZE = 5
PREPAY_PRESET_AMOUNTS = (30000, 60000)


def _prepay_items() -> list[tuple[str, str]]:
    items: list[tuple[str, str]] = []
    for amount in PREPAY_PRESET_AMOUNTS:
        items.append((f"{int(amount):,}".replace(",", " "), f"add:pre:{int(amount)}"))
    items.extend(
        [
            ("Ввести вручную", "add:pre:manual"),
            ("Пропустить", "add:pre:0"),
        ]
    )
    return items


def _lead_source_label(raw: str | None) -> str:
    value = str(raw or "").strip()
    if not value:
        return "—"
    mapping = {
        "channel": "Канал",
        "cold": "Холодные",
        "referral": "Сарафанка",
        "om": "Ом",
        "канал": "Канал",
        "холодные": "Холодные",
        "сарафанка": "Сарафанка",
        "сарафарнка": "Сарафанка",
        "ом": "Ом",
    }
    return mapping.get(value.lower(), value)

def _get_filters(state_data: dict) -> dict:
    return state_data.get("filters") or {"archived": False}

def _set_filters(conn, user_id, tz, state_data, filters):
    state_data["filters"]=filters
    repo_states.set_state(conn, user_id, "ST_VIEW", state_data, tz)

def _render_students_page(conn: sqlite3.Connection, filters: dict, page: int):
    rows, has_prev, has_next = repo_students.list_students(conn, filters, page, PAGE_SIZE)
    if not rows:
        return "Ничего не найдено по текущим фильтрам.", InlineKeyboardMarkup(), False, False

    def _fmt_ymd(raw: str | None) -> str:
        text = str(raw or "").strip()
        if len(text) == 10 and text[4:5] == "-" and text[7:8] == "-":
            return f"{text[8:10]}.{text[5:7]}.{text[0:4]}"
        return text

    lines = []
    buttons = []
    for i, r in enumerate(rows, start=1):
        item = texts.student_list_item(r["fio"], r["username"], r["direction_name"], r["stage_name"])
        lines.append(f"{i}) {item}")
        join_date = str(r["join_date"] or "").strip()
        if join_date:
            lines.append(f"На обучении с: <b>{html.escape(join_date)}</b>")
        last_pay = _fmt_ymd(r["last_pay_date_key"])
        if last_pay:
            lines.append(f"Последнее пополнение: <b>{html.escape(last_pay)}</b>")
        fio = (r["fio"] or "").strip() or f"#{r['id']}"
        label = fio
        if r["username"]:
            label += f" {r['username']}"
        label = (label[:34] + "…") if len(label) > 35 else label
        buttons.append((label, f"st:open:{r['id']}"))
        lines.append("")

    msg = "\n".join(lines).strip()
    kb = InlineKeyboardMarkup()
    for label, cb in buttons:
        kb.row(InlineKeyboardButton(label, callback_data=cb))
    nav_row=[]
    if has_prev:
        nav_row.append(InlineKeyboardButton("◀️", callback_data="nav:prev"))
    if has_next:
        nav_row.append(InlineKeyboardButton("▶️", callback_data="nav:next"))
    if nav_row:
        kb.row(*nav_row)
    kb.row(InlineKeyboardButton("⬅️ Назад", callback_data="m:students"))
    return msg, kb, has_prev, has_next


def _is_http_url(raw: str | None) -> bool:
    text = str(raw or "").strip().lower()
    return text.startswith("http://") or text.startswith("https://")


def _sort_label(code: str | None) -> str:
    mode = str(code or "").strip().lower()
    if mode == "join_desc":
        return "Вступление: новые сверху"
    if mode == "join_asc":
        return "Вступление: старые сверху"
    if mode == "pay_desc":
        return "Пополнение: свежие сверху"
    if mode == "pay_asc":
        return "Пополнение: старые сверху"
    return "По умолчанию"


def _student_card_text(conn: sqlite3.Connection, sid: int, tz: str) -> str:
    s = repo_students.get_student(conn, sid)
    if not s:
        return "Ученик не найден."
    prepay_paid = repo_payments.sum_payments(conn, sid, "prepay")
    post_paid = repo_payments.sum_payments(conn, sid, "postpay")

    pp = repo_postpay.get(conn, sid)
    post_total_val = None
    post_rule = None
    post_next_due = None
    if pp and pp["enabled"]:
        post_total_val = post_total(s["offer_amount"], pp["total_percent"])
        post_next_due = pp["next_due_date"]
        sched = pp["schedule_type"]
        val = pp["per_period_value"]
        if sched == "percent_per_month":
            post_rule = f"{pp['total_percent']}% всего; {val}% в месяц"
        elif sched == "fixed_per_month":
            post_rule = f"{pp['total_percent']}% всего; {int(val)} ₽ в месяц"
        else:
            post_rule = f"{pp['total_percent']}% всего; кастом"
    elif pp:
        post_rule = f"{pp['total_percent']}% всего (постоплата выключена)"

    tariff_display = repo_students.tariff_label(s["tariff"])
    if s["tariff"] in ("post", "pre_post") and pp and pp["total_percent"] is not None:
        tariff_display = f"{tariff_display} ({pp['total_percent']}%)"

    last_pay = repo_payments.last_payment(conn, sid)
    last_pay_date = ""
    last_pay_type = ""
    last_pay_amount = 0
    if last_pay:
        last_pay_date = str(last_pay["pay_date"] or "").strip()
        if not last_pay_date:
            created_raw = str(last_pay["created_at"] or "").strip()
            if created_raw:
                last_pay_date = format_dt_ddmmyyyy_hhmm(created_raw, tz)
        last_pay_type = str(last_pay["pay_type"] or "").strip()
        last_pay_amount = int(last_pay["amount"] or 0)

    data = {
        "fio": s["fio"],
        "username": s["username"],
        "direction_name": s["direction_name"],
        "stage_name": s["stage_name"],
        "lead_source": _lead_source_label(s["lead_source"] if "lead_source" in s.keys() else None),
        "tariff_label": tariff_display,
        "comment": s["comment"],
        "prepay_paid": prepay_paid,
        "offer_amount": s["offer_amount"],
        "post_total": post_total_val,
        "post_paid": post_paid,
        "post_rule": post_rule,
        "post_next_due": post_next_due,
        "join_date": s["join_date"],
        "interviews_active": bool(s["interviews_active"]),
        "contract_url": str(s["contract_url"] or "").strip(),
        "last_payment_date": last_pay_date,
        "last_payment_type": last_pay_type,
        "last_payment_amount": last_pay_amount,
    }
    owner_tg_id = int(s["owner_tg_id"] or 0) if "owner_tg_id" in s.keys() and s["owner_tg_id"] else 0
    if owner_tg_id > 0:
        auto_totals = repo_broadcasts.user_auto_read_totals(conn, owner_tg_id)
        latest_rows = repo_broadcasts.user_auto_read_latest(conn, owner_tg_id, limit=5)
        latest_items: list[str] = []
        for r in latest_rows:
            sent_label = format_dt_ddmmyyyy_hhmm(r["sent_at"], tz) if r["sent_at"] else "—"
            status = "прочитано" if r["read_at"] else "не прочитано"
            latest_items.append(f"{sent_label} — {status}")
        data["auto_total"] = int(auto_totals["total_sent"] or 0)
        data["auto_read"] = int(auto_totals["total_read"] or 0)
        data["auto_latest"] = latest_items
    else:
        data["auto_total"] = 0
        data["auto_read"] = 0
        data["auto_latest"] = []
    if s["archived"]:
        data["comment"] = (data.get("comment") or "") + "\n(в архиве)"
    return texts.student_card(data)

def init(bot: TeleBot, ctx: dict) -> None:
    conn: sqlite3.Connection = ctx["conn"]
    tz = ctx["cfg"].TZ

    def _ensure_view_state(user_id: int):
        st, data = repo_states.get_state(conn, user_id)
        if st is None:
            repo_states.set_state(conn, user_id, "ST_VIEW", {"filters": {"archived": False}, "page": 0}, tz)

    def _show_cards(chat_id: int, message_id: int, user_id: int, idx: int | None = None):
        st, data = repo_states.get_state(conn, user_id)
        filters = _get_filters(data)
        ids = data.get("ids") if st == "ST_CARDS" else None
        if not isinstance(ids, list) or not ids:
            ids = repo_students.list_student_ids(conn, filters)
        if not ids:
            bot.edit_message_text("Ученики не найдены по текущим фильтрам.", chat_id, message_id, reply_markup=students_menu_kb())
            return

        if idx is None:
            idx = int(data.get("idx") or 0)
        idx = max(0, min(int(idx), len(ids) - 1))

        sid = int(ids[idx])
        text = _student_card_text(conn, sid, tz)
        header = f"<b>Ученик {idx+1}/{len(ids)}</b>\n"
        kb = student_cards_kb(sid, idx, len(ids), back_cb="m:students")

        repo_states.set_state(conn, user_id, "ST_CARDS", {"filters": filters, "ids": ids, "idx": idx}, tz)
        bot.edit_message_text(header + "\n" + text, chat_id, message_id, reply_markup=kb)

    @bot.callback_query_handler(func=lambda c: c.data == "st:list")
    def st_list(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        _ensure_view_state(c.from_user.id)
        st, data = repo_states.get_state(conn, c.from_user.id)
        filters = _get_filters(data)
        page = max(0, int(data.get("page") or 0))
        msg, kb, has_prev, has_next = _render_students_page(conn, filters, page)
        # Если после изменения фильтров текущая страница стала пустой, вернемся на первую.
        if page > 0 and not has_prev and not has_next and "Ничего не найдено" in msg:
            page = 0
            msg, kb, _, _ = _render_students_page(conn, filters, page)
        data["page"] = page
        repo_states.set_state(conn, c.from_user.id, "ST_VIEW", data, tz)
        bot.edit_message_text(msg, c.message.chat.id, c.message.message_id, reply_markup=kb)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data == "st:cards")
    def st_cards(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        _ensure_view_state(c.from_user.id)
        # reuse current filters (if they were set in ST_VIEW)
        st, data = repo_states.get_state(conn, c.from_user.id)
        filters = _get_filters(data)
        repo_states.set_state(conn, c.from_user.id, "ST_CARDS", {"filters": filters, "ids": [], "idx": 0}, tz)
        _show_cards(c.message.chat.id, c.message.message_id, c.from_user.id, idx=0)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data in ("st:card:prev", "st:card:next"))
    def st_cards_nav(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        st, data = repo_states.get_state(conn, c.from_user.id)
        if st != "ST_CARDS":
            # fallback to cards start
            repo_states.set_state(conn, c.from_user.id, "ST_CARDS", {"filters": {"archived": False}, "ids": [], "idx": 0}, tz)
            _show_cards(c.message.chat.id, c.message.message_id, c.from_user.id, idx=0)
            bot.answer_callback_query(c.id)
            return

        idx = int(data.get("idx") or 0)
        if c.data.endswith("prev"):
            idx -= 1
        else:
            idx += 1
        _show_cards(c.message.chat.id, c.message.message_id, c.from_user.id, idx=idx)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data in ("nav:prev","nav:next"))
    def st_nav(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        st, data = repo_states.get_state(conn, c.from_user.id)
        if st != "ST_VIEW" or data.get("view") not in (None,"students_list"):
            # default: treat as students list
            pass
        filters = _get_filters(data)
        page = int(data.get("page") or 0)
        if c.data == "nav:prev":
            page = max(0, page-1)
        else:
            page = page+1
        data["page"]=page
        data["view"]="students_list"
        repo_states.set_state(conn, c.from_user.id, "ST_VIEW", data, tz)
        msg, kb, _, _ = _render_students_page(conn, filters, page)
        bot.edit_message_text(msg, c.message.chat.id, c.message.message_id, reply_markup=kb)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data == "st:add")
    def st_add(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        repo_states.set_state(conn, c.from_user.id, "ST_ADD_FIO", {}, tz)
        bot.edit_message_text("Введи <b>ФИО</b> одной строкой:", c.message.chat.id, c.message.message_id,
                              reply_markup=pick_list_kb([("Отмена", "m:students")], "m:students"))
        bot.answer_callback_query(c.id)

    @bot.message_handler(
        func=lambda m: repo_states.get_state(conn, m.from_user.id)[0] in (
            "ST_ADD_FIO",
            "ST_ADD_USERNAME",
            "ST_ADD_PREPAY_TEXT",
            "ST_ADD_COMMENT_TEXT",
            "ST_ADD_JOIN_DATE_MANUAL",
            "ST_ADD_CONTRACT",
            "ST_ADD_POSTPAY_TOTAL_TEXT",
            "ST_ADD_POSTPAY_VALUE_TEXT",
            "ST_SEARCH_TEXT",
            "ST_EDIT_TEXT",
            "ST_POSTPAY_TOTAL",
            "ST_POSTPAY_VALUE",
            "ST_POSTPAY_DAYS",
            "ST_POSTPAY_NOTIFY_REPEAT",
        ),
        content_types=["text"],
    )
    def on_text(m: Message):
        if not is_admin(ctx, m.from_user.id):
            return
        st, data = repo_states.get_state(conn, m.from_user.id)
        if st is None:
            return
        txt = (m.text or "").strip()

        if st == "ST_ADD_FIO":
            if len(txt) < 3:
                bot.reply_to(m, "ФИО слишком короткое. Введи ещё раз."); return
            dup = repo_students.find_duplicate_student(conn, fio=txt)
            if dup:
                dup_username = (dup["username"] or "").strip()
                suffix = f" ({dup_username})" if dup_username else ""
                bot.reply_to(
                    m,
                    f"Ученик с таким ФИО уже зарегистрирован: <b>{dup['fio']}</b>{suffix}. "
                    "Создавать дубликат нельзя.",
                )
                return
            data["fio"]=txt
            repo_states.set_state(conn, m.from_user.id, "ST_ADD_USERNAME", data, tz)
            kb = pick_list_kb([("Пропустить", "add:skip_username")], "m:students")
            bot.send_message(m.chat.id, "Отправь <b>@username</b> (или нажми «Пропустить»):", reply_markup=kb)
            return

        if st == "ST_ADD_USERNAME":
            if txt.startswith("@"):
                data["username"]=txt
            else:
                # allow skip with '-'
                if txt in ("-", "—"):
                    data["username"]=None
                else:
                    data["username"]=txt
            if data.get("username"):
                dup = repo_students.find_duplicate_student(conn, username=data.get("username"))
                if dup:
                    bot.reply_to(
                        m,
                        f"Ученик с username @{str(dup['username'] or '').lstrip('@')} уже зарегистрирован "
                        f"(карточка #{dup['id']}). Создавать дубликат нельзя.",
                    )
                    return
            dirs = repo_students.list_directions(conn)
            items=[(d["name"], f"add:dir:{d['id']}") for d in dirs]
            repo_states.set_state(conn, m.from_user.id, "ST_ADD_DIRECTION", data, tz)
            bot.send_message(m.chat.id, "Выбери <b>направление</b>:", reply_markup=pick_list_kb(items, "m:students"))
            return

        if st == "ST_ADD_COMMENT":
            # not used
            return

        if st == "ST_ADD_COMMENT_TEXT":
            data["comment"]=txt if txt not in ("-", "—") else None
            repo_states.set_state(conn, m.from_user.id, "ST_ADD_JOIN_DATE", data, tz)
            kb = pick_list_kb([("Сегодня", "add:join_today"), ("Ввести дату", "add:join_manual")], "m:students")
            bot.send_message(m.chat.id, "Дата входа на обучение:", reply_markup=kb)
            return

        if st == "ST_ADD_JOIN_DATE_MANUAL":
            d = parse_date_ddmm_past(txt, tz)
            if not d:
                bot.reply_to(m, "Не понял дату. Формат: дд.мм (год сам) или дд.мм.гггг"); return
            data["join_date"]=format_date_ddmmyyyy(d)
            _ask_contract(m.chat.id, m.from_user.id, data)
            return

        if st == "ST_ADD_CONTRACT":
            if txt.lower() in ("-", "—", "пропустить"):
                data["contract_url"] = None
                _finish_create_student(bot, m.chat.id, m.from_user.id, data)
                return
            if not _is_http_url(txt):
                bot.reply_to(m, "Нужна ссылка, которая начинается с http:// или https://")
                return
            data["contract_url"] = txt.strip()
            _finish_create_student(bot, m.chat.id, m.from_user.id, data)
            return

        if st == "ST_ADD_POSTPAY_TOTAL_TEXT":
            try:
                total_percent = float(txt.replace(",", "."))
            except Exception:
                bot.reply_to(m, "Введи число, например 350"); return
            data["post_total_percent"] = total_percent
            repo_states.set_state(conn, m.from_user.id, "ST_ADD_POSTPAY_SCHED", data, tz)
            kb = pick_list_kb([
                ("50% в месяц", "add:pps:percent50"),
                ("Другой %/мес", "add:pps:percent_custom"),
                ("Фикс ₽/мес", "add:pps:fixed_custom"),
                ("Кастом", "add:pps:custom"),
            ], "m:students")
            bot.send_message(m.chat.id, "Постоплата: как платить каждый месяц?", reply_markup=kb)
            return

        if st == "ST_ADD_POSTPAY_VALUE_TEXT":
            sched = data.get("post_schedule_type")
            try:
                val = float(txt.replace(",", ".").replace(" ", ""))
            except Exception:
                bot.reply_to(m, "Введи число."); return
            data["post_per_period_value"] = val
            # дальше по потоку: предоплата (если есть) или комментарий
            if data.get("tariff") in ("pre", "pre_post"):
                repo_states.set_state(conn, m.from_user.id, "ST_ADD_PREPAY", data, tz)
                bot.send_message(m.chat.id, "Предоплата (сумма):", reply_markup=pick_list_kb(_prepay_items(), "m:students"))
            else:
                data["prepay_amount"] = 0
                _ask_comment(m.chat.id, m.from_user.id, data)
            return

        if st == "ST_ADD_PREPAY_TEXT":
            # произвольная сумма предоплаты
            digits = "".join(ch for ch in txt if ch.isdigit())
            data["prepay_amount"] = int(digits) if digits else 0
            _ask_comment(m.chat.id, m.from_user.id, data)
            return

        if st == "ST_SEARCH_TEXT":
            # show search results
            archived = bool(data.get("filters",{}).get("archived"))
            rows = repo_students.search_students(conn, txt, archived=archived, limit=20)
            if not rows:
                bot.send_message(m.chat.id, "Ничего не найдено.", reply_markup=students_menu_kb()); 
                repo_states.set_state(conn, m.from_user.id, "ST_VIEW", {"filters": _get_filters(data), "page": 0}, tz)
                return
            kb = InlineKeyboardMarkup()
            lines=[]
            for r in rows[:8]:
                lines.append(texts.student_list_item(r["fio"], r["username"], r["direction_name"], r["stage_name"]))
                lines.append("")
                kb.row(InlineKeyboardButton(f"Открыть: {r['fio'][:20]}", callback_data=f"st:open:{r['id']}"))
            kb.row(InlineKeyboardButton("⬅️ Назад", callback_data="m:students"))
            bot.send_message(m.chat.id, "Результаты поиска:\n\n" + "\n".join(lines).strip(), reply_markup=kb)
            repo_states.set_state(conn, m.from_user.id, "ST_VIEW", {"filters": _get_filters(data), "page": 0}, tz)
            return

        if st == "ST_EDIT_TEXT":
            sid = int(data["student_id"])
            field = data["field"]
            if field == "offer":
                # Постоплата должна начинаться только после оффера.
                if txt in ("-", "—", "0"):
                    repo_students.update_student(conn, sid, tz, offer_amount=None)
                    # сбросить старт/следующую дату постоплаты, если она была
                    pp = repo_postpay.get(conn, sid)
                    if pp and pp["enabled"]:
                        repo_postpay.upsert(conn, sid, start_date=None, next_due_date=None, student_next_notify_date=None)
                else:
                    try:
                        offer_val = int(txt.replace(" ", ""))
                    except Exception:
                        bot.reply_to(m, "Оффер должен быть числом (руб)."); return
                    repo_students.update_student(conn, sid, tz, offer_amount=offer_val)
                    # если включена постоплата и ещё не назначена дата —
                    # поставить первый платёж через 1 месяц.
                    pp = repo_postpay.get(conn, sid)
                    if pp and pp["enabled"] and pp["total_percent"] is not None:
                        today = now(tz).date()
                        today_str = format_date_ddmmyyyy(today)
                        if not pp["start_date"]:
                            repo_postpay.upsert(conn, sid, start_date=today_str)
                        # по ТЗ: платёж через месяц после добавления оффера
                        due = format_date_ddmmyyyy(add_months(today, 1))
                        repo_postpay.upsert(conn, sid, next_due_date=due, student_next_notify_date=due, enabled=1)
            elif field == "fio":
                if len(txt) < 3:
                    bot.reply_to(m, "ФИО слишком короткое. Введи ещё раз."); return
                dup = repo_students.find_duplicate_student(conn, fio=txt, exclude_student_id=sid)
                if dup:
                    bot.reply_to(m, f"Такой ФИО уже есть в карточке #{dup['id']}."); return
                repo_students.update_student(conn, sid, tz, fio=txt)
            elif field == "username":
                if txt in ("-", "—"):
                    repo_students.update_student(conn, sid, tz, username=None)
                else:
                    username_val = txt if txt.startswith("@") else "@" + txt
                    dup = repo_students.find_duplicate_student(conn, username=username_val, exclude_student_id=sid)
                    if dup:
                        bot.reply_to(m, f"Такой username уже есть в карточке #{dup['id']}."); return
                    repo_students.update_student(conn, sid, tz, username=username_val)
            elif field == "comment":
                repo_students.update_student(conn, sid, tz, comment=txt)
            elif field == "lead_source":
                repo_students.update_student(conn, sid, tz, lead_source=txt if txt not in ("-", "—") else None)
            elif field == "prepay_total":
                if txt in ("-", "—"):
                    target_total = 0
                else:
                    digits = "".join(ch for ch in txt if ch.isdigit())
                    if not digits:
                        bot.reply_to(m, "Нужно число, например 30000, или '-' чтобы обнулить."); return
                    target_total = int(digits)
                current_total = repo_payments.sum_payments(conn, sid, "prepay")
                delta = target_total - current_total
                if delta != 0:
                    s = repo_students.get_student(conn, sid)
                    pay_date = format_date_ddmmyyyy(now(tz).date())
                    if s and s["join_date"]:
                        pay_date = s["join_date"]
                    repo_payments.add_payment(
                        conn,
                        sid,
                        "prepay",
                        int(delta),
                        pay_date,
                        tz,
                        source="mentor",
                        note="admin adjust prepay total from card",
                    )
            elif field == "contract_url":
                repo_students.update_student(conn, sid, tz, contract_url=txt)
            elif field == "hh_phone":
                repo_students.update_student(conn, sid, tz, hh_phone=txt)
            elif field == "hh_email":
                repo_students.update_student(conn, sid, tz, hh_email=txt)
            elif field == "hh_password":
                repo_students.update_student(conn, sid, tz, hh_password=txt)
            elif field == "hh_birth_date":
                if txt in ("-", "—"):
                    repo_students.update_student(conn, sid, tz, hh_birth_date=None)
                else:
                    d = parse_date_ddmm_past(txt, tz)
                    if not d:
                        bot.reply_to(m, "Формат даты: дд.мм (год сам) или дд.мм.гггг"); return
                    repo_students.update_student(conn, sid, tz, hh_birth_date=format_date_ddmmyyyy(d))
            elif field == "hh_location":
                repo_students.update_student(conn, sid, tz, hh_location=txt if txt not in ("-", "—") else None)
            elif field == "hh_salary_min":
                if txt in ("-", "—"):
                    repo_students.update_student(conn, sid, tz, hh_salary_min=None)
                else:
                    digits = "".join(ch for ch in txt if ch.isdigit())
                    if not digits:
                        bot.reply_to(m, "Нужно число, например 120000, или '-' чтобы очистить."); return
                    repo_students.update_student(conn, sid, tz, hh_salary_min=int(digits))
            elif field == "hh_salary_comfort":
                if txt in ("-", "—"):
                    repo_students.update_student(conn, sid, tz, hh_salary_comfort=None)
                else:
                    digits = "".join(ch for ch in txt if ch.isdigit())
                    if not digits:
                        bot.reply_to(m, "Нужно число, например 180000, или '-' чтобы очистить."); return
                    repo_students.update_student(conn, sid, tz, hh_salary_comfort=int(digits))
            elif field == "join_date":
                d = parse_date_ddmm_past(txt, tz)
                if not d:
                    bot.reply_to(m, "Формат даты: дд.мм (год сам) или дд.мм.гггг"); return
                repo_students.update_student(conn, sid, tz, join_date=format_date_ddmmyyyy(d))
            repo_states.set_state(conn, m.from_user.id, "ST_VIEW", {"filters": {"archived": False}, "page": 0}, tz)
            bot.send_message(m.chat.id, "Готово. Обновил.", reply_markup=None)
            # show card again
            _send_student_card(m.chat.id, sid)
            return

        if st == "ST_POSTPAY_TOTAL":
            sid = int(data["student_id"])
            try:
                total_percent = float(txt.replace(",", "."))
            except Exception:
                bot.reply_to(m, "Введи число, например 350"); return
            repo_postpay.upsert(conn, sid, total_percent=total_percent, enabled=1)
            # go schedule type selection
            repo_states.set_state(conn, m.from_user.id, "ST_POSTPAY_SCHED", {"student_id": sid}, tz)
            kb = pick_list_kb([
                ("% в месяц", f"pp:sched:{sid}:percent_per_month"),
                ("Фикс ₽ в месяц", f"pp:sched:{sid}:fixed_per_month"),
                ("Кастом", f"pp:sched:{sid}:custom"),
            ], f"st:open:{sid}")
            bot.send_message(m.chat.id, "Выбери график постоплаты:", reply_markup=kb)
            return

        if st == "ST_POSTPAY_VALUE":
            sid = int(data["student_id"])
            sched = data["schedule_type"]
            try:
                val = float(txt.replace(",", ".").replace(" ", ""))
            except Exception:
                bot.reply_to(m, "Введи число."); return
            # Настройка постоплаты не должна ставить платёж "сегодня".
            # Дату первого платежа ставим только после добавления оффера.
            repo_postpay.upsert(conn, sid, schedule_type=sched, per_period_value=val, enabled=1)
            repo_states.set_state(conn, m.from_user.id, "ST_VIEW", {"filters": {"archived": False}, "page": 0}, tz)
            bot.send_message(m.chat.id, "Постоплата настроена.", reply_markup=None)
            _send_student_card(m.chat.id, sid)
            return

        if st == "ST_POSTPAY_DAYS":
            sid=int(data.get("student_id"))
            try:
                days = int(txt)
            except Exception:
                bot.send_message(m.chat.id, "Введи число (например 14):")
                return
            if days < 1:
                days = 1
            repo_postpay.upsert(conn, sid, schedule_type="every_n_days", per_period_value=float(days), enabled=1)
            repo_states.clear_state(conn, m.from_user.id, tz)
            msg, kb = _render_postpay_menu(sid)
            bot.send_message(m.chat.id, "✅ Сохранил график.")
            bot.send_message(m.chat.id, msg, reply_markup=kb)
            return

        if st == "ST_POSTPAY_NOTIFY_REPEAT":
            sid = int(data["student_id"])
            try:
                mins = int(txt.replace(" ", ""))
            except Exception:
                bot.reply_to(m, "Нужно число минут (например 10)"); return
            if mins < 1:
                bot.reply_to(m, "Минимум 1 минута"); return
            repo_postpay.upsert(conn, sid, student_notify_repeat_min=mins, enabled=1)
            repo_states.set_state(conn, m.from_user.id, "ST_VIEW", {"filters": {"archived": False}, "page": 0}, tz)
            bot.send_message(m.chat.id, "Частоту напоминаний ученику обновил.", reply_markup=None)
            _send_student_card(m.chat.id, sid)
            return

    def _send_student_card(chat_id: int, sid: int):
        text = _student_card_text(conn, sid, tz)
        s = repo_students.get_student(conn, sid)
        back_cb = "st:list"
        # in archive mode, keep back same
        kb = student_card_kb(sid, back_cb=back_cb)
        bot.send_message(chat_id, text, reply_markup=kb)

    def _finish_create_student(bot: TeleBot, chat_id: int, user_id: int, data: dict):
        fio = data["fio"]
        username = data.get("username")
        direction_id = data.get("direction_id")
        stage_id = data.get("stage_id")
        tariff = data.get("tariff", "post")
        comment = data.get("comment")
        join_date = data.get("join_date") or format_date_ddmmyyyy(now(tz).date())
        contract_url = (data.get("contract_url") or "").strip() or None
        duplicate = repo_students.find_duplicate_student(conn, fio=fio, username=username)
        if duplicate:
            dup_username = (duplicate["username"] or "").strip()
            suffix = f" ({dup_username})" if dup_username else ""
            repo_states.clear_state(conn, user_id, tz)
            bot.send_message(
                chat_id,
                f"⚠️ Ученик уже зарегистрирован: <b>{duplicate['fio']}</b>{suffix}. "
                "Вторую карточку создать нельзя.",
            )
            _send_student_card(chat_id, int(duplicate["id"]))
            send_main(bot, ctx, chat_id, user_id=user_id)
            return
        sid = repo_students.create_student(conn, tz,
            fio=fio, username=username, direction_id=direction_id, stage_id=stage_id,
            tariff=tariff, comment=comment, join_date=join_date, interviews_active=0, offer_amount=None,
            contract_url=contract_url, hh_phone=None, hh_email=None, hh_password=None,
            archived=0, archive_failed=0
        )

        # Постоплата — часть тарифа. Создаём настройку, но НЕ ставим дату платежа,
        # пока не задан оффер (по ТЗ первый платёж через месяц после оффера).
        if data.get("tariff") in ("post", "pre_post") and data.get("post_total_percent") is not None:
            repo_postpay.upsert(
                conn,
                sid,
                enabled=1,
                total_percent=float(data.get("post_total_percent")),
                schedule_type=data.get("post_schedule_type") or "percent_per_month",
                per_period_value=data.get("post_per_period_value"),
                start_date=None,
                next_due_date=None,
            )
        # initial prepay payment if provided
        prepay_amount = data.get("prepay_amount")
        if prepay_amount:
            from app.db import repo_payments
            repo_payments.add_payment(conn, sid, "prepay", int(prepay_amount), join_date, tz)
        # Автосоздание напоминалки при добавлении ученика отключено.
        # Напоминалки добавляются только вручную через раздел "Напоминалки".
        repo_states.clear_state(conn, user_id, tz)
        bot.send_message(chat_id, "✅ Ученик добавлен.")
        # по ТЗ — после добавления возвращаемся в главное меню
        send_main(bot, ctx, chat_id, user_id=user_id)

    @bot.callback_query_handler(func=lambda c: c.data == "st:search")
    def st_search(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        st, data = repo_states.get_state(conn, c.from_user.id)
        data = data or {}
        repo_states.set_state(conn, c.from_user.id, "ST_SEARCH_TEXT", data, tz)
        bot.send_message(c.message.chat.id, "Введи строку для поиска (ФИО / @username / телефон / комментарий):")
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("st:open:"))
    def st_open(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        sid = int(c.data.split(":")[2])
        text = _student_card_text(conn, sid, tz)
        kb = student_card_kb(sid, back_cb="st:list")
        bot.edit_message_text(text, c.message.chat.id, c.message.message_id, reply_markup=kb)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("st:contract:"))
    def st_contract(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        sid = int(c.data.split(":")[2])
        s = repo_students.get_student(conn, sid)
        if not s:
            bot.answer_callback_query(c.id, "Ученик не найден")
            return
        contract_url = str(s["contract_url"] or "").strip()
        if not contract_url:
            bot.answer_callback_query(c.id, "Ссылка на договор не заполнена")
            bot.send_message(
                c.message.chat.id,
                "Ссылка на договор пока не заполнена.\n"
                "Заполни её через: Изменить -> Договор/HH -> Ссылка на договор.",
                reply_markup=student_card_kb(sid, back_cb="st:list"),
            )
            return
        if _is_http_url(contract_url):
            kb = InlineKeyboardMarkup()
            kb.row(InlineKeyboardButton("🔗 Открыть договор", url=contract_url))
            kb.row(InlineKeyboardButton("⬅️ Назад", callback_data=f"st:open:{sid}"))
            try:
                bot.send_message(
                    c.message.chat.id,
                    f"Договор ученика: <b>{html.escape(str(s['fio'] or '').strip())}</b>",
                    reply_markup=kb,
                )
            except Exception:
                # Fallback: даже если inline-кнопка по какой-то причине не отправилась,
                # админ получает прямую ссылку.
                bot.send_message(
                    c.message.chat.id,
                    "Не удалось показать кнопку открытия. Вот ссылка на договор:\n"
                    f"{contract_url}",
                    reply_markup=student_card_kb(sid, back_cb="st:list"),
                )
        else:
            bot.send_message(
                c.message.chat.id,
                "Ссылка на договор сохранена в нестандартном формате:\n"
                f"<code>{html.escape(contract_url)}</code>",
                reply_markup=student_card_kb(sid, back_cb="st:list"),
            )
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data == "st:filters")
    def st_filters(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        _ensure_view_state(c.from_user.id)
        _, data = repo_states.get_state(conn, c.from_user.id)
        filters = _get_filters(data)
        lines = ["<b>Фильтры</b>"]
        if filters.get("direction_name"):
            lines.append(f"Направление: <b>{filters['direction_name']}</b>")
        if filters.get("stage_name"):
            lines.append(f"Этап: <b>{filters['stage_name']}</b>")
        if filters.get("tariff"):
            lines.append(f"Тариф: <b>{repo_students.tariff_label(filters['tariff'])}</b>")
        if filters.get("offer"):
            lines.append(f"Оффер: <b>{filters['offer']}</b>")
        lines.append(f"Сортировка: <b>{_sort_label(filters.get('sort'))}</b>")
        lines.append(f"Архив: <b>{'да' if filters.get('archived') else 'нет'}</b>")
        msg="\n".join(lines)
        kb = InlineKeyboardMarkup()
        kb.row(InlineKeyboardButton("Направление", callback_data="flt:dir"),
               InlineKeyboardButton("Этап", callback_data="flt:stg"))
        kb.row(InlineKeyboardButton("Тариф", callback_data="flt:tar"),
               InlineKeyboardButton("Оффер", callback_data="flt:offer"))
        kb.row(InlineKeyboardButton("Сортировка", callback_data="flt:sort"))
        kb.row(InlineKeyboardButton("Сбросить", callback_data="flt:reset"))
        kb.row(InlineKeyboardButton("⬅️ Назад", callback_data="m:students"))
        bot.edit_message_text(msg, c.message.chat.id, c.message.message_id, reply_markup=kb)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("flt:"))
    def flt_actions(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        _ensure_view_state(c.from_user.id)
        st, data = repo_states.get_state(conn, c.from_user.id)
        filters = _get_filters(data)

        act = c.data.split(":")[1]
        if act == "reset":
            filters = {"archived": filters.get("archived", False)}
            _set_filters(conn, c.from_user.id, tz, data, filters)
            bot.answer_callback_query(c.id, "Сброшено")
            bot.edit_message_text("<b>Ученики</b>", c.message.chat.id, c.message.message_id, reply_markup=students_menu_kb())
            return

        if act == "dir":
            dirs = repo_students.list_directions(conn)
            items=[(d["name"], f"flt:set_dir:{d['id']}") for d in dirs]
            bot.edit_message_text("Выбери направление:", c.message.chat.id, c.message.message_id,
                                  reply_markup=pick_list_kb(items, "st:filters"))
            bot.answer_callback_query(c.id); return
        if act == "stg":
            stgs = repo_students.list_stages(conn)
            items=[(s["name"], f"flt:set_stg:{s['id']}") for s in stgs]
            bot.edit_message_text("Выбери этап:", c.message.chat.id, c.message.message_id,
                                  reply_markup=pick_list_kb(items, "st:filters"))
            bot.answer_callback_query(c.id); return
        if act == "tar":
            items=[
                ("Предоплата", "flt:set_tar:pre"),
                ("Постоплата", "flt:set_tar:post"),
                ("Пред+Пост", "flt:set_tar:pre_post"),
                ("Снять фильтр", "flt:set_tar:"),
            ]
            bot.edit_message_text("Фильтр по тарифу:", c.message.chat.id, c.message.message_id,
                                  reply_markup=pick_list_kb(items, "st:filters"))
            bot.answer_callback_query(c.id); return
        if act == "offer":
            items=[
                ("Есть оффер", "flt:set_offer:yes"),
                ("Нет оффера", "flt:set_offer:no"),
                ("Снять фильтр", "flt:set_offer:"),
            ]
            bot.edit_message_text("Фильтр по офферу:", c.message.chat.id, c.message.message_id,
                                  reply_markup=pick_list_kb(items, "st:filters"))
            bot.answer_callback_query(c.id); return
        if act == "sort":
            items = [
                ("По умолчанию", "flt:set_sort:default"),
                ("Вступление: новые сверху", "flt:set_sort:join_desc"),
                ("Вступление: старые сверху", "flt:set_sort:join_asc"),
                ("Пополнение: свежие сверху", "flt:set_sort:pay_desc"),
                ("Пополнение: старые сверху", "flt:set_sort:pay_asc"),
            ]
            bot.edit_message_text(
                "Выбери сортировку списка:",
                c.message.chat.id,
                c.message.message_id,
                reply_markup=pick_list_kb(items, "st:filters"),
            )
            bot.answer_callback_query(c.id); return

        # set values
        if act == "set_dir":
            did = int(c.data.split(":")[2])
            name = conn.execute("SELECT name FROM directions WHERE id=?", (did,)).fetchone()["name"]
            filters["direction_id"]=did
            filters["direction_name"]=name
        elif act == "set_stg":
            sid = int(c.data.split(":")[2])
            name = conn.execute("SELECT name FROM stages WHERE id=?", (sid,)).fetchone()["name"]
            filters["stage_id"]=sid
            filters["stage_name"]=name
        elif act == "set_tar":
            val = c.data.split(":")[2] if len(c.data.split(":"))>2 else ""
            if val:
                filters["tariff"]=val
            else:
                filters.pop("tariff", None)
        elif act == "set_offer":
            val = c.data.split(":")[2] if len(c.data.split(":"))>2 else ""
            if val:
                filters["offer"]=val
            else:
                filters.pop("offer", None)
        elif act == "set_sort":
            val = c.data.split(":")[2] if len(c.data.split(":")) > 2 else "default"
            if val == "default":
                filters.pop("sort", None)
            else:
                filters["sort"] = val

        _set_filters(conn, c.from_user.id, tz, data, filters)
        bot.answer_callback_query(c.id, "Ок")
        bot.edit_message_text("<b>Ученики</b>", c.message.chat.id, c.message.message_id, reply_markup=students_menu_kb())

    @bot.callback_query_handler(func=lambda c: c.data == "st:archive_toggle")
    def st_archive_toggle(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        _ensure_view_state(c.from_user.id)
        _, data = repo_states.get_state(conn, c.from_user.id)
        filters=_get_filters(data)
        filters["archived"] = not bool(filters.get("archived"))
        # clean names might not match archived context but ok
        _set_filters(conn, c.from_user.id, tz, data, filters)
        bot.answer_callback_query(c.id, "Переключил")
        bot.edit_message_text("<b>Ученики</b>", c.message.chat.id, c.message.message_id, reply_markup=students_menu_kb())

    @bot.callback_query_handler(func=lambda c: c.data.startswith("add:"))
    def add_callbacks(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        st, data = repo_states.get_state(conn, c.from_user.id)
        if st not in (
            "ST_ADD_USERNAME",
            "ST_ADD_DIRECTION",
            "ST_ADD_STAGE",
            "ST_ADD_TARIFF",
            "ST_ADD_POSTPAY_TOTAL",
            "ST_ADD_POSTPAY_SCHED",
            "ST_ADD_PREPAY",
            "ST_ADD_COMMENT_TEXT",
            "ST_ADD_JOIN_DATE",
            "ST_ADD_JOIN_DATE_MANUAL",
            "ST_ADD_CONTRACT",
        ):
            bot.answer_callback_query(c.id); return
        parts = c.data.split(":")
        act = parts[1]
        if act == "skip_username":
            data["username"]=None
            dirs = repo_students.list_directions(conn)
            items=[(d["name"], f"add:dir:{d['id']}") for d in dirs]
            repo_states.set_state(conn, c.from_user.id, "ST_ADD_DIRECTION", data, tz)
            bot.send_message(c.message.chat.id, "Выбери <b>направление</b>:", reply_markup=pick_list_kb(items, "m:students"))
            bot.answer_callback_query(c.id); return
        if act == "dir":
            did=int(parts[2])
            data["direction_id"]=did
            stgs = repo_students.list_stages(conn)
            items=[(s["name"], f"add:stg:{s['id']}") for s in stgs]
            repo_states.set_state(conn, c.from_user.id, "ST_ADD_STAGE", data, tz)
            bot.send_message(c.message.chat.id, "Выбери <b>этап</b>:", reply_markup=pick_list_kb(items, "m:students"))
            bot.answer_callback_query(c.id); return
        if act == "stg":
            stgid=int(parts[2])
            data["stage_id"]=stgid
            items=[
                ("Предоплата + Постоплата", "add:tar:pre_post"),
                ("Только постоплата", "add:tar:post"),
                ("Только предоплата", "add:tar:pre"),
            ]
            repo_states.set_state(conn, c.from_user.id, "ST_ADD_TARIFF", data, tz)
            bot.send_message(c.message.chat.id, "Выбери <b>тариф</b>:", reply_markup=pick_list_kb(items, "m:students"))
            bot.answer_callback_query(c.id); return
        if act == "tar":
            tariff=parts[2]
            data["tariff"]=tariff
            # Если в тарифе есть постоплата — сначала настраиваем её (процент + график).
            if tariff in ("post", "pre_post"):
                repo_states.set_state(conn, c.from_user.id, "ST_ADD_POSTPAY_TOTAL", data, tz)
                kb = pick_list_kb([
                    ("300%", "add:pp:300"),
                    ("350%", "add:pp:350"),
                    ("400%", "add:pp:400"),
                    ("500%", "add:pp:500"),
                    ("600%", "add:pp:600"),
                    ("Ввести вручную", "add:pp:manual"),
                ], "m:students")
                bot.send_message(c.message.chat.id, "Постоплата: выбери <b>% всего</b> (например 350):", reply_markup=kb)
                bot.answer_callback_query(c.id); return

            # Только предоплата
            if tariff == "pre":
                repo_states.set_state(conn, c.from_user.id, "ST_ADD_PREPAY", data, tz)
                bot.send_message(c.message.chat.id, "Предоплата (сумма):", reply_markup=pick_list_kb(_prepay_items(), "m:students"))
            else:
                data["prepay_amount"]=0
                _ask_comment(c.message.chat.id, c.from_user.id, data)
            bot.answer_callback_query(c.id); return

        # выбор процента постоплаты (как часть тарифа)
        if act == "pp":
            val = parts[2]
            if val == "manual":
                repo_states.set_state(conn, c.from_user.id, "ST_ADD_POSTPAY_TOTAL_TEXT", data, tz)
                bot.send_message(c.message.chat.id, "Введи общий процент постоплаты (например 350):")
                bot.answer_callback_query(c.id); return
            try:
                data["post_total_percent"] = float(val)
            except Exception:
                bot.answer_callback_query(c.id, "Ошибка"); return
            repo_states.set_state(conn, c.from_user.id, "ST_ADD_POSTPAY_SCHED", data, tz)
            kb = pick_list_kb([
                ("50% в месяц", "add:pps:percent50"),
                ("Другой %/мес", "add:pps:percent_custom"),
                ("Фикс ₽/мес", "add:pps:fixed_custom"),
                ("Кастом", "add:pps:custom"),
            ], "m:students")
            bot.send_message(c.message.chat.id, "Постоплата: как платить каждый месяц?", reply_markup=kb)
            bot.answer_callback_query(c.id); return

        # выбор графика постоплаты
        if act == "pps":
            kind = parts[2]
            if kind == "percent50":
                data["post_schedule_type"] = "percent_per_month"
                data["post_per_period_value"] = 50.0
            elif kind == "percent_custom":
                data["post_schedule_type"] = "percent_per_month"
                repo_states.set_state(conn, c.from_user.id, "ST_ADD_POSTPAY_VALUE_TEXT", data, tz)
                bot.send_message(c.message.chat.id, "Введи % в месяц (например 50):")
                bot.answer_callback_query(c.id); return
            elif kind == "fixed_custom":
                data["post_schedule_type"] = "fixed_per_month"
                repo_states.set_state(conn, c.from_user.id, "ST_ADD_POSTPAY_VALUE_TEXT", data, tz)
                bot.send_message(c.message.chat.id, "Введи сумму ₽ в месяц (например 30000):")
                bot.answer_callback_query(c.id); return
            else:
                data["post_schedule_type"] = "custom"
                data["post_per_period_value"] = None

            # дальше по потоку
            if data.get("tariff") in ("pre", "pre_post"):
                repo_states.set_state(conn, c.from_user.id, "ST_ADD_PREPAY", data, tz)
                bot.send_message(c.message.chat.id, "Предоплата (сумма):", reply_markup=pick_list_kb(_prepay_items(), "m:students"))
            else:
                data["prepay_amount"] = 0
                _ask_comment(c.message.chat.id, c.from_user.id, data)
            bot.answer_callback_query(c.id); return
        if act == "pre":
            v = parts[2]
            if v == "manual":
                repo_states.set_state(conn, c.from_user.id, "ST_ADD_PREPAY_TEXT", data, tz)
                bot.send_message(c.message.chat.id, "Введи сумму предоплаты (например 12500):")
                bot.answer_callback_query(c.id); return
            amt=int(v)
            data["prepay_amount"]=amt
            _ask_comment(c.message.chat.id, c.from_user.id, data)
            bot.answer_callback_query(c.id); return
        if act == "comment_skip":
            data["comment"]=None
            repo_states.set_state(conn, c.from_user.id, "ST_ADD_JOIN_DATE", data, tz)
            kb = pick_list_kb([("Сегодня", "add:join_today"), ("Ввести дату", "add:join_manual")], "m:students")
            bot.send_message(c.message.chat.id, "Дата входа на обучение:", reply_markup=kb)
            bot.answer_callback_query(c.id); return
        if act == "join_today":
            data["join_date"]=format_date_ddmmyyyy(now(tz).date())
            _ask_contract(c.message.chat.id, c.from_user.id, data)
            bot.answer_callback_query(c.id); return
        if act == "join_manual":
            repo_states.set_state(conn, c.from_user.id, "ST_ADD_JOIN_DATE_MANUAL", data, tz)
            bot.send_message(c.message.chat.id, "Введи дату в формате дд.мм.гггг:")
            bot.answer_callback_query(c.id); return
        if act == "contract_skip":
            data["contract_url"] = None
            _finish_create_student(bot, c.message.chat.id, c.from_user.id, data)
            bot.answer_callback_query(c.id); return

    def _ask_comment(chat_id: int, user_id: int, data: dict):
        repo_states.set_state(conn, user_id, "ST_ADD_COMMENT_TEXT", data, tz)
        kb = pick_list_kb([("Пропустить", "add:comment_skip")], "m:students")
        bot.send_message(chat_id, "Комментарий (можно '-', или нажми «Пропустить»):", reply_markup=kb)

    def _ask_contract(chat_id: int, user_id: int, data: dict):
        repo_states.set_state(conn, user_id, "ST_ADD_CONTRACT", data, tz)
        kb = pick_list_kb([("Пропустить", "add:contract_skip")], "m:students")
        bot.send_message(
            chat_id,
            "Ссылка на договор (http/https). Можно вставить ссылку или нажать «Пропустить».",
            reply_markup=kb,
        )

    @bot.callback_query_handler(func=lambda c: c.data.startswith("st:edit:"))
    def st_edit(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        sid=int(c.data.split(":")[2])
        bot.edit_message_text("Что изменить?", c.message.chat.id, c.message.message_id, reply_markup=edit_fields_kb(sid))
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("ed:"))
    def edit_field_pick(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        _, sid, field = c.data.split(":")
        sid=int(sid)
        if field == "postpay_rule":
            msg, kb = _render_postpay_menu(sid)
            bot.edit_message_text(msg, c.message.chat.id, c.message.message_id, reply_markup=kb)
            bot.answer_callback_query(c.id)
            return
        if field in ("direction","stage","tariff"):
            if field == "direction":
                dirs=repo_students.list_directions(conn)
                items=[(d["name"], f"edset:{sid}:direction:{d['id']}") for d in dirs]
                bot.edit_message_text("Выбери направление:", c.message.chat.id, c.message.message_id,
                                      reply_markup=pick_list_kb(items, f"st:open:{sid}"))
            elif field == "stage":
                stgs=repo_students.list_stages(conn)
                items=[(s["name"], f"edset:{sid}:stage:{s['id']}") for s in stgs]
                bot.edit_message_text("Выбери этап:", c.message.chat.id, c.message.message_id,
                                      reply_markup=pick_list_kb(items, f"st:open:{sid}"))
            elif field == "tariff":
                items=[
                    ("Предоплата", f"edset:{sid}:tariff:pre"),
                    ("Постоплата", f"edset:{sid}:tariff:post"),
                    ("Пред+Пост", f"edset:{sid}:tariff:pre_post"),
                ]
                bot.edit_message_text("Выбери тариф:", c.message.chat.id, c.message.message_id,
                                      reply_markup=pick_list_kb(items, f"st:open:{sid}"))
            bot.answer_callback_query(c.id); return

        if field == "interviews":
            s=repo_students.get_student(conn, sid)
            new = 0 if s and s["interviews_active"] else 1
            repo_students.update_student(conn, sid, tz, interviews_active=new)
            bot.answer_callback_query(c.id, "Ок")
            bot.edit_message_text(_student_card_text(conn, sid, tz), c.message.chat.id, c.message.message_id,
                                  reply_markup=student_card_kb(sid, back_cb="st:list"))
            return

        if field == "private":
            items=[
                ("Ссылка на договор", f"edtxt:{sid}:contract_url"),
                ("Телефон", f"edtxt:{sid}:hh_phone"),
                ("Почта HH", f"edtxt:{sid}:hh_email"),
                ("Пароль HH", f"edtxt:{sid}:hh_password"),
                ("Дата рождения HH", f"edtxt:{sid}:hh_birth_date"),
                ("Локация HH", f"edtxt:{sid}:hh_location"),
                ("ЗП минимум HH", f"edtxt:{sid}:hh_salary_min"),
                ("ЗП комфорт HH", f"edtxt:{sid}:hh_salary_comfort"),
            ]
            bot.edit_message_text("Что изменить (приватные поля):", c.message.chat.id, c.message.message_id,
                                  reply_markup=pick_list_kb(items, f"st:open:{sid}"))
            bot.answer_callback_query(c.id); return

        # text edit
        repo_states.set_state(conn, c.from_user.id, "ST_EDIT_TEXT", {"student_id": sid, "field": field}, tz)
        hints = {
            "fio": "Введи новое ФИО:",
            "username": "Введи новый @username (или без @):",
            "comment": "Введи комментарий:",
            "lead_source": "Введи источник лида (например: Канал, Холодные, Сарафанка, Ом). '-' чтобы очистить:",
            "offer": "Введи размер оффера (число, ₽). '-' чтобы убрать:",
            "prepay_total": "Введи целевую сумму предоплаты (₽). '-' чтобы обнулить:",
            "join_date": "Введи новую дату входа (дд.мм или дд.мм.гггг):",
        }
        bot.send_message(c.message.chat.id, hints.get(field, "Введи значение:"))
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("edtxt:"))
    def edit_private_text(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        _, sid, field = c.data.split(":")
        sid=int(sid)
        repo_states.set_state(conn, c.from_user.id, "ST_EDIT_TEXT", {"student_id": sid, "field": field}, tz)
        bot.send_message(c.message.chat.id, "Введи значение (или '-' чтобы очистить):")
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("edset:"))
    def edit_set(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        _, sid, field, val = c.data.split(":")
        sid=int(sid)
        if field == "direction":
            repo_students.update_student(conn, sid, tz, direction_id=int(val))
        elif field == "stage":
            new_stage_id = int(val)
            repo_students.update_student(conn, sid, tz, stage_id=new_stage_id)
            try:
                from app.db import repo_stage_rules
                repo_stage_rules.sync_student_auto_reminder(conn, tz, sid, new_stage_id)
            except Exception:
                pass
        elif field == "tariff":
            repo_students.update_student(conn, sid, tz, tariff=val)
        bot.answer_callback_query(c.id, "Ок")
        bot.edit_message_text(_student_card_text(conn, sid, tz), c.message.chat.id, c.message.message_id,
                              reply_markup=student_card_kb(sid, back_cb="st:list"))

    def _render_postpay_menu(sid: int) -> tuple[str, InlineKeyboardMarkup]:
        pp = repo_postpay.get(conn, sid)
        msg = "<b>Постоплата</b>\n"
        if pp and pp["enabled"]:
            msg += f"Процент всего: <b>{pp['total_percent']}</b>%\n"
            stype = pp["schedule_type"]
            pv = pp["per_period_value"]
            if stype == "every_n_days":
                sched_line = f"каждые {int(pv or 0)} дней"
            elif stype == "percent_per_month":
                sched_line = f"{pv}% в месяц"
            elif stype == "fixed_per_month":
                sched_line = f"{int(pv or 0)} ₽ в месяц"
            else:
                sched_line = f"{stype} ({pv})"
            msg += f"График: <b>{sched_line}</b>\n"
            nxt = pp['next_due_date']
            if nxt:
                msg += f"Следующий платёж: <b>{nxt}</b>"
            else:
                msg += "Первый платёж: <b>после оффера</b> (+1 месяц)"
            try:
                notify_on = int(pp["student_notify_enabled"] or 0) == 1
            except Exception:
                notify_on = True
            rep = pp["student_notify_repeat_min"] if (hasattr(pp, "keys") and "student_notify_repeat_min" in pp.keys() and pp["student_notify_repeat_min"] is not None) else ctx["cfg"].ALERT_REPEAT_MIN
            msg += f"\n\nУведомления ученику: <b>{'Вкл' if notify_on else 'Выкл'}</b>"
            msg += f"\nПовтор (мин): <b>{rep}</b>"
            items=[("Изменить % всего", f"pp:set_total:{sid}"),
                   ("График: каждые N дней", f"pp:set_days:{sid}"),
                   ("Уведомления ученику: Вкл/Выкл", f"pp:notify_toggle:{sid}"),
                   ("Частота напоминаний ученику", f"pp:set_notify_repeat:{sid}"),
                   ("Выключить постоплату", f"pp:disable:{sid}")]
        else:
            msg += "Постоплата не настроена или выключена."
            items=[("Настроить % всего", f"pp:set_total:{sid}")]
        return msg, pick_list_kb(items, f"st:open:{sid}")

    @bot.callback_query_handler(func=lambda c: c.data.startswith("st:post:"))
    def postpay_menu(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        sid=int(c.data.split(":")[2])
        msg, kb = _render_postpay_menu(sid)
        bot.edit_message_text(msg, c.message.chat.id, c.message.message_id, reply_markup=kb)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("pp:"))
    def postpay_actions(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        parts=c.data.split(":")
        act=parts[1]
        if act=="set_total":
            sid=int(parts[2])
            repo_states.set_state(conn, c.from_user.id, "ST_POSTPAY_TOTAL", {"student_id": sid}, tz)
            bot.send_message(c.message.chat.id, "Введи общий процент постоплаты (например 350):")
            bot.answer_callback_query(c.id); return

        if act=="set_days":
            sid=int(parts[2])
            repo_states.set_state(conn, c.from_user.id, "ST_POSTPAY_DAYS", {"student_id": sid}, tz)
            bot.send_message(c.message.chat.id, "Введи интервал между платежами в днях (например 14 для 2 раза в месяц):")
            bot.answer_callback_query(c.id); return
        if act=="sched":
            sid=int(parts[2]); sched=parts[3]
            repo_postpay.upsert(conn, sid, schedule_type=sched, enabled=1)
            repo_states.set_state(conn, c.from_user.id, "ST_POSTPAY_VALUE", {"student_id": sid, "schedule_type": sched}, tz)
            prompt = "Введи % в месяц (например 50):" if sched=="percent_per_month" else ("Введи сумму ₽ в месяц:" if sched=="fixed_per_month" else "Введи любое число (будет сохранено как метка):")
            bot.send_message(c.message.chat.id, prompt)
            bot.answer_callback_query(c.id); return
        if act=="disable":
            sid=int(parts[2])
            repo_postpay.disable(conn, sid)
            bot.answer_callback_query(c.id, "Выключил")
            bot.edit_message_text(_student_card_text(conn, sid, tz), c.message.chat.id, c.message.message_id,
                                  reply_markup=student_card_kb(sid, back_cb="st:list"))
            return

        if act=="notify_toggle":
            sid=int(parts[2])
            pp=repo_postpay.get(conn, sid)
            cur = 1
            try:
                cur = int(pp["student_notify_enabled"] or 0) if pp else 1
            except Exception:
                cur = 1
            repo_postpay.upsert(conn, sid, student_notify_enabled=(0 if cur==1 else 1), enabled=1)
            bot.answer_callback_query(c.id, "Ок")
            msg, kb = _render_postpay_menu(sid)
            bot.edit_message_text(msg, c.message.chat.id, c.message.message_id, reply_markup=kb)
            return

        if act=="set_notify_repeat":
            sid=int(parts[2])
            repo_states.set_state(conn, c.from_user.id, "ST_POSTPAY_NOTIFY_REPEAT", {"student_id": sid}, tz)
            bot.send_message(c.message.chat.id, "Введи частоту напоминаний ученику (в минутах), например 10:")
            bot.answer_callback_query(c.id)
            return

    @bot.callback_query_handler(func=lambda c: c.data.startswith("st:arch:"))
    def student_archive(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        sid=int(c.data.split(":")[2])
        s=repo_students.get_student(conn, sid)
        if s and s["archived"]:
            # restore
            repo_students.restore_student(conn, sid, tz)
            bot.answer_callback_query(c.id, "Восстановил")
            bot.edit_message_text(_student_card_text(conn, sid, tz), c.message.chat.id, c.message.message_id,
                                  reply_markup=student_card_kb(sid, back_cb="st:list"))
            return
        kb = InlineKeyboardMarkup()
        kb.row(InlineKeyboardButton("Да, провалена", callback_data=f"arch:fail:{sid}"),
               InlineKeyboardButton("Нет", callback_data=f"arch:nofail:{sid}"))
        kb.row(InlineKeyboardButton("Отмена", callback_data=f"st:open:{sid}"))
        bot.edit_message_text("Перенести в архив. Сделка провалена?", c.message.chat.id, c.message.message_id, reply_markup=kb)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("arch:"))
    def arch_confirm(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        _, kind, sid = c.data.split(":")
        sid=int(sid)
        failed = True if kind=="fail" else False
        repo_students.archive_student(conn, sid, failed, tz)
        bot.answer_callback_query(c.id, "В архиве")
        bot.edit_message_text(_student_card_text(conn, sid, tz), c.message.chat.id, c.message.message_id,
                              reply_markup=student_card_kb(sid, back_cb="st:list"))

    # redirect buttons handled in other modules (payments/reminders/events):
    # st:pay:<id>, st:rem:<id>, st:ev_add:<id> will be processed there first if registered after.
