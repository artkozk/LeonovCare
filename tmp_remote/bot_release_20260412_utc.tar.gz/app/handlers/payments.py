from __future__ import annotations
import sqlite3
import datetime as dt
from collections import defaultdict
from telebot import TeleBot
from telebot.types import CallbackQuery, Message, InlineKeyboardMarkup, InlineKeyboardButton

from app.handlers.common import is_admin
from app.db import repo_states, repo_postpay, repo_payments, repo_students
from app.services.cardlink_client import CardlinkClient
from app.services.payment_diagnostics import run_cardlink_diagnostics, format_cardlink_diagnostics_report
from app.services.timeutils import now, iso, format_date_ddmmyyyy, parse_date_ddmm_past, format_dt_ddmmyyyy_hhmm
from app.services.postpay import post_total, recommended_payment, next_due_after_payment
from app.ui.keyboards import payments_menu_kb, pick_list_kb, open_student_kb
from app.ui.formatters import money

def init(bot: TeleBot, ctx: dict) -> None:
    conn: sqlite3.Connection = ctx["conn"]
    cfg = ctx["cfg"]
    tz = cfg.TZ
    cardlink_client = CardlinkClient(
        shop_id=cfg.CARDLINK_SHOP_ID,
        bearer_token=cfg.CARDLINK_BEARER_TOKEN,
        return_url=cfg.CARDLINK_RETURN_URL,
        timeout_sec=cfg.CARDLINK_TIMEOUT_SEC,
        api_base_url=cfg.CARDLINK_API_BASE_URL,
    )

    def _list_due(from_date: str, to_date: str) -> tuple[str, InlineKeyboardMarkup]:
        rows = repo_postpay.list_due(conn, from_date, to_date)
        if not rows:
            return "Нет ожидаемых платежей в этом диапазоне.", payments_menu_kb()
        lines=[]
        kb=InlineKeyboardMarkup()
        for r in rows[:10]:
            sid=int(r["student_id"])
            offer=r["offer_amount"]
            total = post_total(offer, r["total_percent"])
            paid = repo_payments.sum_payments(conn, sid, "postpay")
            remaining = max(0, (total or 0) - paid) if total is not None else None
            rem_str = money(remaining) if remaining is not None else "—"
            lines.append(f"• <b>{r['fio']}</b> — срок <b>{r['next_due_date']}</b>, осталось {rem_str}")
            kb.row(
                InlineKeyboardButton("👤", callback_data=f"st:open:{sid}"),
                InlineKeyboardButton("💰 Внести", callback_data=f"py:add_for:{sid}"),
            )
        kb.row(InlineKeyboardButton("⬅️ Назад", callback_data="m:payments"))
        return "Ожидаемые платежи:\n" + "\n".join(lines), kb

    def _parse_payment_day(pay_date_raw: str | None, created_at_raw: str | None) -> dt.date | None:
        raw = str(pay_date_raw or "").strip()
        for fmt in ("%d.%m.%Y", "%d.%m.%y", "%Y-%m-%d"):
            try:
                return dt.datetime.strptime(raw, fmt).date()
            except Exception:
                pass
        created = str(created_at_raw or "").strip()
        if created:
            try:
                return dt.datetime.fromisoformat(created.replace("Z", "+00:00")).date()
            except Exception:
                pass
        return None

    def _parse_payment_dt(pay_date_raw: str | None, created_at_raw: str | None) -> dt.datetime | None:
        created = str(created_at_raw or "").strip()
        if created:
            try:
                return dt.datetime.fromisoformat(created.replace("Z", "+00:00"))
            except Exception:
                pass
        raw = str(pay_date_raw or "").strip()
        for fmt in ("%d.%m.%Y", "%d.%m.%y", "%Y-%m-%d"):
            try:
                return dt.datetime.strptime(raw, fmt)
            except Exception:
                pass
        return None

    def _budget_slice(
        from_day: dt.date | None = None,
        to_day: dt.date | None = None,
        student_id: int | None = None,
    ) -> dict:
        query = (
            "SELECT p.id, p.student_id, p.pay_type, p.amount, p.pay_date, p.source, p.created_at, "
            "s.fio, s.username, s.owner_username, s.archived "
            "FROM payments p "
            "JOIN students s ON s.id=p.student_id "
        )
        args: list = []
        if student_id is not None:
            query += "WHERE p.student_id=? "
            args.append(int(student_id))
        query += "ORDER BY p.id DESC"
        rows = conn.execute(query, tuple(args)).fetchall()

        total_amount = 0
        prepay_amount = 0
        postpay_amount = 0
        payments_count = 0
        students = set()
        by_student: dict[int, dict] = defaultdict(dict)
        last_payment_dt: dt.datetime | None = None

        for r in rows:
            pay_day = _parse_payment_day(r["pay_date"], r["created_at"])
            if pay_day is None:
                continue
            if from_day and pay_day < from_day:
                continue
            if to_day and pay_day > to_day:
                continue
            amount = int(r["amount"] or 0)
            sid = int(r["student_id"] or 0)
            payment_dt = _parse_payment_dt(r["pay_date"], r["created_at"])
            if payment_dt and (last_payment_dt is None or payment_dt > last_payment_dt):
                last_payment_dt = payment_dt
            total_amount += amount
            payments_count += 1
            students.add(sid)
            if str(r["pay_type"] or "").strip() == "prepay":
                prepay_amount += amount
            else:
                postpay_amount += amount

            if sid not in by_student:
                by_student[sid] = {
                    "student_id": sid,
                    "fio": str(r["fio"] or "—").strip(),
                    "username": str(r["username"] or "").strip(),
                    "owner_username": str(r["owner_username"] or "").strip(),
                    "archived": int(r["archived"] or 0),
                    "total_sum": 0,
                    "prepay_sum": 0,
                    "postpay_sum": 0,
                    "payments_count": 0,
                    "last_payment_dt": None,
                }
            by_student[sid]["total_sum"] += amount
            by_student[sid]["payments_count"] += 1
            prev_dt = by_student[sid]["last_payment_dt"]
            if payment_dt and (prev_dt is None or payment_dt > prev_dt):
                by_student[sid]["last_payment_dt"] = payment_dt
            if str(r["pay_type"] or "").strip() == "prepay":
                by_student[sid]["prepay_sum"] += amount
            else:
                by_student[sid]["postpay_sum"] += amount

        top_students = sorted(by_student.values(), key=lambda x: int(x["total_sum"]), reverse=True)
        return {
            "total_amount": total_amount,
            "prepay_amount": prepay_amount,
            "postpay_amount": postpay_amount,
            "payments_count": payments_count,
            "students_count": len(students),
            "top_students": top_students,
            "last_payment_dt": last_payment_dt,
        }

    def _budget_text(
        title: str,
        stats: dict,
        from_day: dt.date | None = None,
        to_day: dt.date | None = None,
        student_label: str | None = None,
    ) -> str:
        lines = [f"<b>{title}</b>", ""]
        if student_label:
            lines.append(f"Ученик: <b>{student_label}</b>")
        if from_day and to_day:
            lines.append(f"Период: <b>{from_day.strftime('%d.%m.%Y')} — {to_day.strftime('%d.%m.%Y')}</b>")
        elif from_day:
            lines.append(f"Период: с <b>{from_day.strftime('%d.%m.%Y')}</b>")
        lines.extend(
            [
                f"Всего поступило: <b>{money(int(stats.get('total_amount', 0)))}</b>",
                f"Предоплата: <b>{money(int(stats.get('prepay_amount', 0)))}</b>",
                f"Постоплата: <b>{money(int(stats.get('postpay_amount', 0)))}</b>",
                f"Платежей: <b>{int(stats.get('payments_count', 0))}</b>",
                f"Уникальных учеников: <b>{int(stats.get('students_count', 0))}</b>",
            ]
        )
        last_dt = stats.get("last_payment_dt")
        if isinstance(last_dt, dt.datetime):
            lines.append(f"Последнее пополнение в выборке: <b>{format_dt_ddmmyyyy_hhmm(last_dt.isoformat(), tz)}</b>")
        else:
            lines.append("Последнее пополнение в выборке: <b>—</b>")
        lines.extend(["", "<b>Топ пополнений</b>:"])
        top = stats.get("top_students") or []
        if not top:
            lines.append("• платежей за период нет")
        else:
            for row in top[:12]:
                uname = f"@{row['username'].lstrip('@')}" if row.get("username") else "—"
                lines.append(
                    f"• {row['fio']} (id:{row['student_id']}, {uname}) — "
                    f"<b>{money(int(row['total_sum'] or 0))}</b> "
                    f"(пред: {money(int(row['prepay_sum'] or 0))}, пост: {money(int(row['postpay_sum'] or 0))})"
                )
                r_last_dt = row.get("last_payment_dt")
                if isinstance(r_last_dt, dt.datetime):
                    lines.append(f"  дата последнего пополнения: <b>{format_dt_ddmmyyyy_hhmm(r_last_dt.isoformat(), tz)}</b>")
        return "\n".join(lines)

    def _budget_kb(back_cb: str = "m:payments") -> InlineKeyboardMarkup:
        kb = InlineKeyboardMarkup()
        kb.row(
            InlineKeyboardButton("Текущий месяц", callback_data="py:budget:month"),
            InlineKeyboardButton("Последние 30 дней", callback_data="py:budget:30d"),
        )
        kb.row(
            InlineKeyboardButton("За период", callback_data="py:budget:period"),
            InlineKeyboardButton("По ученику", callback_data="py:budget:student"),
        )
        kb.row(InlineKeyboardButton("⬅️ Назад", callback_data=back_cb))
        return kb

    def _budget_student_kb(student_id: int) -> InlineKeyboardMarkup:
        kb = InlineKeyboardMarkup()
        kb.row(InlineKeyboardButton("Период по этому ученику", callback_data=f"py:budget:student_period:{int(student_id)}"))
        kb.row(InlineKeyboardButton("Открыть карточку", callback_data=f"st:open:{int(student_id)}"))
        kb.row(InlineKeyboardButton("⬅️ К бюджету", callback_data="py:budget"))
        return kb

    @bot.callback_query_handler(func=lambda c: c.data == "py:today")
    def py_today(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        today_str = format_date_ddmmyyyy(now(tz).date())
        msg, kb = _list_due(today_str, today_str)
        bot.edit_message_text(msg, c.message.chat.id, c.message.message_id, reply_markup=kb)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data == "py:week")
    def py_week(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        d = now(tz).date()
        from_str = format_date_ddmmyyyy(d)
        to_str = format_date_ddmmyyyy(d + dt.timedelta(days=7))
        msg, kb = _list_due(from_str, to_str)
        bot.edit_message_text(msg, c.message.chat.id, c.message.message_id, reply_markup=kb)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data == "py:budget")
    def py_budget(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        today = now(tz).date()
        from_day = today.replace(day=1)
        stats = _budget_slice(from_day=from_day, to_day=today)
        bot.edit_message_text(
            _budget_text("Бюджет: текущий месяц", stats, from_day, today),
            c.message.chat.id,
            c.message.message_id,
            reply_markup=_budget_kb(),
        )
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data == "py:cardlink_check")
    def py_cardlink_check(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        if not cardlink_client.enabled:
            bot.send_message(
                c.message.chat.id,
                "Cardlink не настроен: проверь `CARDLINK_SHOP_ID`, `CARDLINK_BEARER_TOKEN`, `CARDLINK_API_BASE_URL`.",
                reply_markup=payments_menu_kb(),
            )
            bot.answer_callback_query(c.id, "Cardlink не настроен")
            return
        bot.answer_callback_query(c.id, "Проверяю оплату, это займет 10-30 секунд...")
        bot.send_message(c.message.chat.id, "Запускаю проверку оплаты по всем тарифам и точкам...")
        from app.handlers.user import ENROLL_TRACKS  # lazy import to avoid heavy startup dependency
        report = run_cardlink_diagnostics(
            cardlink_client,
            ENROLL_TRACKS,
            int(cfg.INTERVIEW_HELPER_PRICE_RUB or 500),
            int(c.from_user.id),
        )
        bot.send_message(
            c.message.chat.id,
            format_cardlink_diagnostics_report(report),
            reply_markup=payments_menu_kb(),
        )

    @bot.callback_query_handler(func=lambda c: c.data in {"py:budget:month", "py:budget:30d"})
    def py_budget_quick(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        today = now(tz).date()
        if c.data.endswith(":month"):
            from_day = today.replace(day=1)
            title = "Бюджет: текущий месяц"
        else:
            from_day = today - dt.timedelta(days=29)
            title = "Бюджет: последние 30 дней"
        stats = _budget_slice(from_day=from_day, to_day=today)
        bot.edit_message_text(
            _budget_text(title, stats, from_day, today),
            c.message.chat.id,
            c.message.message_id,
            reply_markup=_budget_kb(),
        )
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data == "py:budget:period")
    def py_budget_period(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        repo_states.set_state(conn, c.from_user.id, "PY_BUDGET_PERIOD", {}, tz)
        bot.send_message(
            c.message.chat.id,
            "Введи период в формате: <code>01.04.2026-30.04.2026</code>",
        )
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data == "py:budget:student")
    def py_budget_student(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        repo_states.set_state(conn, c.from_user.id, "PY_BUDGET_STUDENT", {}, tz)
        bot.send_message(c.message.chat.id, "Введи ФИО, @username или id ученика:")
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("py:budget:student_pick:"))
    def py_budget_student_pick(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        sid = int(c.data.split(":")[3])
        student = repo_students.get_student(conn, sid)
        if not student:
            bot.answer_callback_query(c.id, "Ученик не найден")
            return
        stats = _budget_slice(student_id=sid)
        label = str(student["fio"] or "").strip() or f"#{sid}"
        bot.send_message(
            c.message.chat.id,
            _budget_text("Бюджет по ученику", stats, student_label=label),
            reply_markup=_budget_student_kb(sid),
        )
        repo_states.clear_state(conn, c.from_user.id, tz)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("py:budget:student_period:"))
    def py_budget_student_period(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        sid = int(c.data.split(":")[3])
        student = repo_students.get_student(conn, sid)
        if not student:
            bot.answer_callback_query(c.id, "Ученик не найден")
            return
        repo_states.set_state(conn, c.from_user.id, "PY_BUDGET_STUDENT_PERIOD", {"student_id": sid}, tz)
        bot.send_message(
            c.message.chat.id,
            f"Введи период для <b>{student['fio']}</b> в формате: <code>01.04.2026-30.04.2026</code>",
        )
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data == "py:debts")
    def py_debts(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        # list top remaining for all enabled postpay
        rows = conn.execute(
            "SELECT pp.*, s.fio, s.offer_amount FROM student_postpay pp JOIN students s ON s.id=pp.student_id "
            "WHERE s.archived=0 AND pp.enabled=1"
        ).fetchall()
        items=[]
        for r in rows:
            sid=int(r["student_id"])
            total=post_total(r["offer_amount"], r["total_percent"])
            if total is None:
                continue
            paid=repo_payments.sum_payments(conn, sid, "postpay")
            rem=max(0,total-paid)
            items.append((rem, sid, r["fio"]))
        items.sort(reverse=True)
        lines=[]
        kb=InlineKeyboardMarkup()
        for rem, sid, fio in items[:12]:
            lines.append(f"• <b>{fio}</b> — осталось {money(rem)}")
            kb.row(InlineKeyboardButton("Открыть", callback_data=f"st:open:{sid}"),
                   InlineKeyboardButton("Внести", callback_data=f"py:add_for:{sid}"))
        kb.row(InlineKeyboardButton("⬅️ Назад", callback_data="m:payments"))
        bot.edit_message_text("Долги по постоплате:\n" + "\n".join(lines) if lines else "Нет активных долгов.",
                              c.message.chat.id, c.message.message_id, reply_markup=kb)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data == "py:add")
    def py_add(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        repo_states.set_state(conn, c.from_user.id, "PY_FIND_STUDENT", {}, tz)
        bot.send_message(c.message.chat.id, "Введи часть ФИО или @username ученика:")
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("py:add_for:"))
    def py_add_for(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        sid=int(c.data.split(":")[2])
        data={"student_id": sid}
        repo_states.set_state(conn, c.from_user.id, "PY_PICK_TYPE", data, tz)
        _ask_type(c.message.chat.id, sid)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("st:pay:"))
    def st_payments(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        sid=int(c.data.split(":")[2])
        s=repo_students.get_student(conn, sid)
        if not s:
            bot.answer_callback_query(c.id, "Не найдено"); return
        pre=repo_payments.sum_payments(conn, sid, "prepay")
        post=repo_payments.sum_payments(conn, sid, "postpay")
        pp=repo_postpay.get(conn, sid)
        total = post_total(s["offer_amount"], pp["total_percent"]) if pp else None
        msg = f"<b>Платежи — {s['fio']}</b>\nПредоплата: <b>{money(pre)}</b>\nПостоплата: <b>{money(post)}</b>"
        if total is not None:
            msg += f"\nПостоплата всего: <b>{money(total)}</b>\nОсталось: <b>{money(max(0,total-post))}</b>"
        rows=repo_payments.list_payments(conn, sid, limit=10)
        if rows:
            msg += "\n\n<b>Последние платежи</b>"
            for r in rows:
                pay_date = str(r["pay_date"] or "").strip() or "—"
                created = format_dt_ddmmyyyy_hhmm(r["created_at"], tz) if r["created_at"] else "—"
                msg += f"\n• {pay_date} (внесён: {created}) — {r['pay_type']} — {money(r['amount'])}"
        kb=InlineKeyboardMarkup()
        kb.row(InlineKeyboardButton("➕ Внести платёж", callback_data=f"py:add_for:{sid}"))
        kb.row(InlineKeyboardButton("⬅️ Назад", callback_data=f"st:open:{sid}"))
        bot.edit_message_text(msg, c.message.chat.id, c.message.message_id, reply_markup=kb)
        bot.answer_callback_query(c.id)

    def _ask_type(chat_id: int, sid: int):
        kb=InlineKeyboardMarkup()
        kb.row(InlineKeyboardButton("Предоплата", callback_data="py:type:prepay"),
               InlineKeyboardButton("Постоплата", callback_data="py:type:postpay"))
        kb.row(InlineKeyboardButton("Отмена", callback_data=f"st:open:{sid}"))
        bot.send_message(chat_id, "Тип платежа:", reply_markup=kb)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("py:type:"))
    def py_type(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        st, data = repo_states.get_state(conn, c.from_user.id)
        if st != "PY_PICK_TYPE":
            bot.answer_callback_query(c.id); return
        pay_type=c.data.split(":")[2]
        data["pay_type"]=pay_type
        repo_states.set_state(conn, c.from_user.id, "PY_AMOUNT", data, tz)
        sid=int(data["student_id"])
        # suggest amount
        if pay_type=="postpay":
            s=repo_students.get_student(conn, sid)
            pp=repo_postpay.get(conn, sid)
            rec=None
            if s and pp:
                rec=recommended_payment(s["offer_amount"], pp["schedule_type"], pp["per_period_value"])
            if rec:
                kb=InlineKeyboardMarkup()
                kb.row(InlineKeyboardButton(f"Внести {money(rec)}", callback_data=f"py:amt:{rec}"))
                kb.row(InlineKeyboardButton("Ввести вручную", callback_data="py:amt_custom"))
                kb.row(InlineKeyboardButton("Отмена", callback_data=f"st:open:{sid}"))
                bot.send_message(c.message.chat.id, "Сумма:", reply_markup=kb)
            else:
                bot.send_message(c.message.chat.id, "Введи сумму (руб):")
        else:
            bot.send_message(c.message.chat.id, "Введи сумму (руб):")
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("py:amt:") or c.data=="py:amt_custom")
    def py_amt_pick(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        st, data = repo_states.get_state(conn, c.from_user.id)
        if st != "PY_AMOUNT":
            bot.answer_callback_query(c.id); return
        if c.data=="py:amt_custom":
            repo_states.set_state(conn, c.from_user.id, "PY_AMOUNT_MANUAL", data, tz)
            bot.send_message(c.message.chat.id, "Введи сумму (руб):")
            bot.answer_callback_query(c.id); return
        amt=int(c.data.split(":")[2])
        data["amount"]=amt
        _ask_date(c.message.chat.id, c.from_user.id, data)
        bot.answer_callback_query(c.id)

    def _ask_date(chat_id: int, user_id: int, data: dict):
        repo_states.set_state(conn, user_id, "PY_DATE", data, tz)
        today_str = format_date_ddmmyyyy(now(tz).date())
        kb=InlineKeyboardMarkup()
        kb.row(InlineKeyboardButton(f"Сегодня ({today_str})", callback_data="py:date_today"),
               InlineKeyboardButton("Ввести дату", callback_data="py:date_manual"))
        sid=int(data["student_id"])
        kb.row(InlineKeyboardButton("Отмена", callback_data=f"st:open:{sid}"))
        bot.send_message(chat_id, "Дата платежа:", reply_markup=kb)

    @bot.callback_query_handler(func=lambda c: c.data in ("py:date_today","py:date_manual"))
    def py_date_pick(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        st, data = repo_states.get_state(conn, c.from_user.id)
        if st != "PY_DATE":
            bot.answer_callback_query(c.id); return
        if c.data=="py:date_manual":
            repo_states.set_state(conn, c.from_user.id, "PY_DATE_MANUAL", data, tz)
            bot.send_message(c.message.chat.id, "Введи дату: дд.мм (год сам) или дд.мм.гггг")
            bot.answer_callback_query(c.id); return
        data["pay_date"]=format_date_ddmmyyyy(now(tz).date())
        _save_payment(c.message.chat.id, c.from_user.id, data)
        bot.answer_callback_query(c.id)

    @bot.message_handler(
        func=lambda m: repo_states.get_state(conn, m.from_user.id)[0]
        in (
            "PY_FIND_STUDENT",
            "PY_AMOUNT",
            "PY_AMOUNT_MANUAL",
            "PY_DATE_MANUAL",
            "PY_BUDGET_PERIOD",
            "PY_BUDGET_STUDENT",
            "PY_BUDGET_STUDENT_PERIOD",
        ),
        content_types=["text"],
    )
    def py_text(m: Message):
        if not is_admin(ctx, m.from_user.id):
            return
        st, data = repo_states.get_state(conn, m.from_user.id)
        if st == "PY_BUDGET_PERIOD":
            raw = (m.text or "").strip().replace("—", "-").replace("–", "-")
            parts = [p.strip() for p in raw.split("-") if p.strip()]
            if len(parts) != 2:
                bot.send_message(m.chat.id, "Формат периода: 01.04.2026-30.04.2026")
                return
            d1 = parse_date_ddmm_past(parts[0], tz)
            d2 = parse_date_ddmm_past(parts[1], tz)
            if not d1 or not d2:
                bot.send_message(m.chat.id, "Не понял даты. Пример: 01.04.2026-30.04.2026")
                return
            if d1 > d2:
                d1, d2 = d2, d1
            stats = _budget_slice(from_day=d1, to_day=d2)
            repo_states.clear_state(conn, m.from_user.id, tz)
            bot.send_message(
                m.chat.id,
                _budget_text("Бюджет: выбранный период", stats, d1, d2),
                reply_markup=_budget_kb(),
            )
            return
        if st == "PY_BUDGET_STUDENT":
            text = (m.text or "").strip()
            sid: int | None = None
            if text.isdigit():
                sid = int(text)
            if sid is not None:
                student = repo_students.get_student(conn, sid)
                if student:
                    stats = _budget_slice(student_id=sid)
                    label = str(student["fio"] or "").strip() or f"#{sid}"
                    repo_states.clear_state(conn, m.from_user.id, tz)
                    bot.send_message(
                        m.chat.id,
                        _budget_text("Бюджет по ученику", stats, student_label=label),
                        reply_markup=_budget_student_kb(sid),
                    )
                    return
            rows = repo_students.search_students(conn, text, archived=False, limit=8)
            if not rows:
                bot.send_message(m.chat.id, "Не нашёл ученика. Попробуй ФИО, @username или id.")
                return
            if len(rows) == 1:
                sid = int(rows[0]["id"])
                student = repo_students.get_student(conn, sid)
                stats = _budget_slice(student_id=sid)
                label = str(student["fio"] or "").strip() if student else str(rows[0]["fio"] or "").strip()
                repo_states.clear_state(conn, m.from_user.id, tz)
                bot.send_message(
                    m.chat.id,
                    _budget_text("Бюджет по ученику", stats, student_label=label),
                    reply_markup=_budget_student_kb(sid),
                )
                return
            kb = InlineKeyboardMarkup()
            for r in rows:
                label = str(r["fio"] or "").strip() or f"#{r['id']}"
                kb.row(InlineKeyboardButton(label[:40], callback_data=f"py:budget:student_pick:{int(r['id'])}"))
            kb.row(InlineKeyboardButton("⬅️ Назад", callback_data="py:budget"))
            bot.send_message(m.chat.id, "Нашёл несколько учеников. Выбери нужного:", reply_markup=kb)
            return
        if st == "PY_BUDGET_STUDENT_PERIOD":
            sid = int((data or {}).get("student_id") or 0)
            student = repo_students.get_student(conn, sid)
            if sid <= 0 or not student:
                repo_states.clear_state(conn, m.from_user.id, tz)
                bot.send_message(m.chat.id, "Не нашёл ученика для отчёта.", reply_markup=_budget_kb())
                return
            raw = (m.text or "").strip().replace("—", "-").replace("–", "-")
            parts = [p.strip() for p in raw.split("-") if p.strip()]
            if len(parts) != 2:
                bot.send_message(m.chat.id, "Формат периода: 01.04.2026-30.04.2026")
                return
            d1 = parse_date_ddmm_past(parts[0], tz)
            d2 = parse_date_ddmm_past(parts[1], tz)
            if not d1 or not d2:
                bot.send_message(m.chat.id, "Не понял даты. Пример: 01.04.2026-30.04.2026")
                return
            if d1 > d2:
                d1, d2 = d2, d1
            stats = _budget_slice(from_day=d1, to_day=d2, student_id=sid)
            repo_states.clear_state(conn, m.from_user.id, tz)
            bot.send_message(
                m.chat.id,
                _budget_text(
                    "Бюджет по ученику: выбранный период",
                    stats,
                    from_day=d1,
                    to_day=d2,
                    student_label=str(student["fio"] or "").strip() or f"#{sid}",
                ),
                reply_markup=_budget_student_kb(sid),
            )
            return
        if st == "PY_FIND_STUDENT":
            rows=repo_students.search_students(conn, m.text, archived=False, limit=8)
            if not rows:
                bot.send_message(m.chat.id, "Не нашёл. Попробуй ещё раз:"); return
            kb=InlineKeyboardMarkup()
            for r in rows:
                kb.row(InlineKeyboardButton(r["fio"][:28], callback_data=f"py:pick_student:{r['id']}"))
            kb.row(InlineKeyboardButton("Отмена", callback_data="m:payments"))
            bot.send_message(m.chat.id, "Выбери ученика:", reply_markup=kb)
            return
        if st == "PY_AMOUNT":
            # manual amount entry (no suggested)
            try:
                amt=int(m.text.strip().replace(" ", ""))
            except Exception:
                bot.send_message(m.chat.id, "Нужно число."); return
            data["amount"]=amt
            _ask_date(m.chat.id, m.from_user.id, data)
            return
        if st == "PY_AMOUNT_MANUAL":
            try:
                amt=int(m.text.strip().replace(" ", ""))
            except Exception:
                bot.send_message(m.chat.id, "Нужно число."); return
            data["amount"]=amt
            _ask_date(m.chat.id, m.from_user.id, data)
            return
        if st == "PY_DATE_MANUAL":
            d=parse_date_ddmm_past(m.text.strip(), tz)
            if not d:
                bot.send_message(m.chat.id, "Формат: дд.мм (год сам) или дд.мм.гггг"); return
            data["pay_date"]=format_date_ddmmyyyy(d)
            _save_payment(m.chat.id, m.from_user.id, data)
            return

    @bot.callback_query_handler(func=lambda c: c.data.startswith("py:pick_student:"))
    def py_pick_student(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        st, data = repo_states.get_state(conn, c.from_user.id)
        if st != "PY_FIND_STUDENT":
            bot.answer_callback_query(c.id); return
        sid=int(c.data.split(":")[2])
        data={"student_id": sid}
        repo_states.set_state(conn, c.from_user.id, "PY_PICK_TYPE", data, tz)
        _ask_type(c.message.chat.id, sid)
        bot.answer_callback_query(c.id)

    def _save_payment(chat_id: int, user_id: int, data: dict):
        sid=int(data["student_id"])
        pay_type=data.get("pay_type","postpay")
        amt=int(data["amount"])
        pay_date=data.get("pay_date") or format_date_ddmmyyyy(now(tz).date())
        repo_payments.add_payment(conn, sid, pay_type, amt, pay_date, tz)
        # update postpay schedule if needed
        if pay_type=="postpay":
            pp=repo_postpay.get(conn, sid)
            if pp and pp["enabled"]:
                new_due = next_due_after_payment(pp["next_due_date"], pay_date, pp["schedule_type"], pp["per_period_value"])
                repo_postpay.upsert(conn, sid, next_due_date=new_due, student_next_notify_date=new_due, enabled=1)
                # auto-disable if fully paid
                s=repo_students.get_student(conn, sid)
                total=post_total(s["offer_amount"], pp["total_percent"]) if s else None
                if total is not None:
                    paid=repo_payments.sum_payments(conn, sid, "postpay")
                    if paid >= total:
                        repo_postpay.disable(conn, sid)
        repo_states.clear_state(conn, user_id, tz)
        # stop any pending payment alerts for student immediately after saving payment
        try:
            s = repo_students.get_student(conn, sid)
            schat = int(s["owner_chat_id"]) if s and s["owner_chat_id"] else None
        except Exception:
            schat = None
        if schat:
            conn.execute(
                "UPDATE alerts SET status='SEEN', updated_at=? WHERE status='PENDING' AND alert_type='PAYMENT' AND related_table='students' AND related_id=? AND chat_id=?",
                (iso(now(tz)), sid, schat),
            )
            conn.commit()
        bot.send_message(chat_id, "✅ Платёж сохранён.", reply_markup=payments_menu_kb())
