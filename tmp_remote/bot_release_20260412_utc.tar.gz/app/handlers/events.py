from __future__ import annotations
import html
import sqlite3
import datetime as dt
import re
import threading
from telebot import TeleBot
from telebot.types import CallbackQuery, Message, InlineKeyboardMarkup, InlineKeyboardButton

from app.handlers.common import is_admin
from app.db import (
    repo_admins,
    repo_analytics,
    repo_settings,
    repo_states,
    repo_events,
    repo_students,
    repo_owner_outreach,
)
from app.services import admin_notification_settings
from app.services.timeutils import now, iso, start_of_day, end_of_day, add_days, parse_datetime_ddmmyyyy_hhmm, format_dt_ddmmyyyy_hhmm, tzinfo
from app.ui.keyboards import events_menu_kb, pick_list_kb

EVENT_TYPES = [
    ("HR", "HR"),
    ("Тех", "TECH"),
    ("Созвон", "CALL"),
    ("Другое", "OTHER"),
]

EVENT_TYPE_LABEL = {
    "HR": "HR",
    "TECH": "Тех",
    "CALL": "Созвон",
    "OTHER": "Другое",
}

ADMIN_CHAT_KEY = "ADMIN_CHAT_ID"
CALL_SLOT_DURATION_MIN = 30
CALL_REMIND_BEFORE_MIN = 60
RESCHEDULE_LIMIT_HOURS = 24
CANCEL_LIMIT_HOURS = 12
CALL_KIND_STUDENT = "student"
CALL_KIND_DIAGNOSTIC = "diagnostic"
DIAGNOSTIC_CALL_LIMIT = 1
_BOOKING_LOCK = threading.Lock()
CALL_RESUME_STATE = "U_CALL_RESUME_WAIT"

def _etype_label(code: str) -> str:
    return EVENT_TYPE_LABEL.get(code or "", code or "—")


def _day_key(d: dt.date) -> str:
    return d.strftime("%Y%m%d")


def _parse_day_key(s: str) -> dt.date:
    return dt.datetime.strptime(s, "%Y%m%d").date()


def _floor_to_30(m: dt.datetime) -> dt.datetime:
    mm = (m.minute // 30) * 30
    return m.replace(minute=mm, second=0, microsecond=0)


def _calc_next_alert(start_at: dt.datetime, remind_before_min: int, tz: str) -> dt.datetime:
    base = start_at
    if base.tzinfo is None:
        base = base.replace(tzinfo=tzinfo(tz))
    before = max(0, int(remind_before_min or 0))
    candidate = base - dt.timedelta(minutes=before)
    n = now(tz).replace(microsecond=0)
    # Если событие поставили "впритык", напоминание должно сработать на ближайшем тике планировщика.
    if candidate <= n:
        return n + dt.timedelta(seconds=5)
    return candidate.replace(microsecond=0)


def _slot_starts(day: dt.date, tz: str) -> list[dt.datetime]:
    tz_i = tzinfo(tz)
    cur = dt.datetime.combine(day, dt.time(9, 0)).replace(tzinfo=tz_i)
    end = dt.datetime.combine(day, dt.time(19, 30)).replace(tzinfo=tz_i)
    out: list[dt.datetime] = []
    while cur <= end:
        out.append(cur)
        cur = cur + dt.timedelta(minutes=30)
    return out


def _money(v) -> str:
    try:
        if v is None:
            return "—"
        n = int(v)
        if n <= 0:
            return "—"
        return f"{n:,}".replace(",", " ") + " ₽"
    except Exception:
        return "—"


def _is_http_url(raw: str | None) -> bool:
    text = str(raw or "").strip().lower()
    return text.startswith("http://") or text.startswith("https://")


def _norm_tg(raw: str | None) -> str:
    text = str(raw or "").strip()
    if not text:
        return ""
    if text.startswith("https://t.me/") or text.startswith("http://t.me/"):
        text = text.rsplit("/", 1)[-1]
    text = text.split("?", 1)[0].split("#", 1)[0].strip()
    if not text:
        return ""
    if not text.startswith("@"):
        text = "@" + text
    return text.lower()


def _snippet(text: str | None, limit: int = 220) -> str:
    raw = " ".join(str(text or "").replace("\n", " ").split()).strip()
    if len(raw) <= limit:
        return raw
    return raw[: max(limit - 1, 1)].rstrip() + "…"


def _extract_dialog_facts(text: str) -> list[str]:
    src = str(text or "").lower()
    facts: list[str] = []
    m_years = re.search(r"(\d{1,2})\s*(?:\+)?\s*(лет|года|год)", src)
    if m_years:
        facts.append(f"Опыт: {m_years.group(1)} {m_years.group(2)}")
    m_salary = re.search(r"(\d{2,3})\s*[кkк]", src)
    if m_salary:
        facts.append(f"Ожидания: {m_salary.group(1)}к")
    if "собесед" in src:
        facts.append("Фокус: собеседования")
    elif "работ" in src or "оффер" in src:
        facts.append("Фокус: поиск работы")
    elif "резюм" in src:
        facts.append("Фокус: резюме")
    if "java" in src:
        facts.append("Направление: java")
    elif "python" in src:
        facts.append("Направление: python")
    elif "golang" in src or "go " in src or "go-разработ" in src:
        facts.append("Направление: golang")
    elif "frontend" in src or "react" in src:
        facts.append("Направление: frontend")
    # deduplicate while preserving order
    out: list[str] = []
    seen: set[str] = set()
    for item in facts:
        if item in seen:
            continue
        seen.add(item)
        out.append(item)
    return out[:5]


def _extract_script_answers(text: str) -> dict[str, str]:
    src = str(text or "")
    low = src.lower()
    out: dict[str, str] = {}

    m_exp = re.search(r"(\d{1,2}\+?)\s*(лет|года|год|месяц|месяцев)", low)
    if m_exp:
        out["experience"] = f"{m_exp.group(1)} {m_exp.group(2)}"

    stack_map = [
        ("java", "Java"),
        ("python", "Python"),
        ("golang", "Golang"),
        ("go", "Go"),
        ("php", "PHP"),
        ("javascript", "JavaScript"),
        ("typescript", "TypeScript"),
        ("frontend", "Frontend"),
        ("backend", "Backend"),
        ("fullstack", "Fullstack"),
        ("react", "React"),
        ("c++", "C++"),
    ]
    stack: list[str] = []
    seen: set[str] = set()
    for key, label in stack_map:
        if re.search(rf"\b{re.escape(key)}\b", low) and label not in seen:
            seen.add(label)
            stack.append(label)
    if stack:
        out["stack"] = ", ".join(stack[:8])

    rows = [x.strip() for x in src.splitlines() if str(x or "").strip()]
    for row in reversed(rows):
        r = row.lower()
        if "goal" not in out and any(k in r for k in ("цель", "хочу", "ищу", "тк", "net", "зарплат", "доход", "стабильн", "проект")):
            out["goal"] = _snippet(row, 170)
        if "blocker" not in out and any(k in r for k in ("затык", "не хватает", "автоотказ", "не зовут", "сложн", "проблем")):
            out["blocker"] = _snippet(row, 170)
        if "timeline" not in out and any(k in r for k in ("срок", "сроки", "месяц", "недел", "квартал", "до конца")):
            out["timeline"] = _snippet(row, 150)
        if len(out) >= 5:
            break
    return out

def init(bot: TeleBot, ctx: dict) -> None:
    conn: sqlite3.Connection = ctx["conn"]
    tz = ctx["cfg"].TZ

    def _active_student(user_id: int) -> sqlite3.Row | None:
        s = repo_students.get_by_owner(conn, int(user_id))
        if not s:
            return None
        if int(s["archived"] or 0) == 1:
            return None
        return s

    def _mentor_chat_ids() -> list[int]:
        out: set[int] = set()
        for uid in repo_admins.list_notify_ids(conn, ctx["cfg"].ADMIN_IDS):
            out.add(int(uid))
        raw_admin_chat = repo_settings.get(conn, ADMIN_CHAT_KEY, None)
        if raw_admin_chat:
            try:
                out.add(int(raw_admin_chat))
            except Exception:
                pass
        return sorted(out)

    def _notify_mentors(text: str, kb: InlineKeyboardMarkup | None = None) -> None:
        for chat_id in _mentor_chat_ids():
            if not admin_notification_settings.events_enabled(conn, int(chat_id)):
                continue
            try:
                bot.send_message(int(chat_id), text, reply_markup=kb)
            except Exception:
                continue

    def _resume_request_kb() -> InlineKeyboardMarkup:
        kb = InlineKeyboardMarkup()
        kb.row(InlineKeyboardButton("❌ Отмена", callback_data="u:slots:resume_cancel"))
        kb.row(InlineKeyboardButton("⬅️ К слотам", callback_data=f"u:slots:day:{_day_key(_user_booking_min_day())}"))
        return kb

    def _profile_context_summary(owner_tg_id: int, student_id: int | None = None) -> str:
        st = None
        try:
            if int(student_id or 0) > 0:
                st = repo_students.get_student(conn, int(student_id))
        except Exception:
            st = None
        if st is None:
            try:
                st = repo_students.get_by_owner(conn, int(owner_tg_id))
            except Exception:
                st = None
        if st is None:
            return ""
        parts: list[str] = []
        fio = str(st["fio"] or "").strip() if "fio" in st.keys() else ""
        direction = str(st["direction"] or "").strip() if "direction" in st.keys() else ""
        stage = str(st["stage"] or "").strip() if "stage" in st.keys() else ""
        tariff = str(st["tariff"] or "").strip() if "tariff" in st.keys() else ""
        if fio:
            parts.append(f"Ученик: {fio}")
        if direction:
            parts.append(f"Направление: {direction}")
        if stage:
            parts.append(f"Этап: {stage}")
        if tariff:
            parts.append(f"Тариф: {tariff}")
        return "; ".join(parts)

    def _call_context_summary(owner_tg_id: int, username: str | None, student_id: int | None = None) -> str:
        target = _norm_tg(username)
        profile_fallback = _profile_context_summary(owner_tg_id, student_id)
        if not target:
            return profile_fallback or "Данных по диалогу пока нет."
        try:
            rows = repo_owner_outreach.list_recent(conn, int(owner_tg_id), limit=800)
        except Exception:
            return profile_fallback or "Данных по диалогу пока нет."
        matched = [r for r in rows if _norm_tg(r["telegram"]) == target]
        if not matched:
            return profile_fallback or "Данных по диалогу пока нет."

        latest = matched[0]
        status_map = {
            "sent": "отправлено",
            "send_failed": "ошибка отправки",
            "blocked": "блок/ограничение",
            "no_reply": "без ответа",
            "replied": "ответил",
            "not_interested": "не интересно",
            "interested": "интересно",
            "call_booked": "созвон назначен",
            "call_done": "созвон проведен",
        }
        status = status_map.get(str(latest["status"] or "").strip().lower(), "неизвестно")
        inbound = str(latest["inbound_text"] or "").strip()
        outbound = str(latest["outbound_text"] or "").strip()

        # Берем несколько последних касаний, чтобы ментор видел контекст, а не одну реплику.
        collected_inbound: list[str] = []
        collected_outbound: list[str] = []
        for row in matched[:12]:
            inb = str(row["inbound_text"] or "").strip()
            outb = str(row["outbound_text"] or "").strip()
            if inb:
                collected_inbound.append(inb)
            if outb:
                collected_outbound.append(outb)
        basis = "\n".join(collected_inbound or [inbound or outbound])
        answers = _extract_script_answers(basis)
        facts = _extract_dialog_facts(basis)
        lines = [f"Статус в отписе: {status}"]
        if answers.get("experience"):
            lines.append(f"Опыт: {html.escape(answers['experience'])}")
        if answers.get("stack"):
            lines.append(f"Стек: {html.escape(answers['stack'])}")
        if answers.get("goal"):
            lines.append("Цель: " + html.escape(answers["goal"]))
        if answers.get("blocker"):
            lines.append("Стопор: " + html.escape(answers["blocker"]))
        if answers.get("timeline"):
            lines.append("Срок: " + html.escape(answers["timeline"]))
        if facts:
            lines.append("Коротко по диалогу: " + html.escape("; ".join(facts)))
        if inbound:
            lines.append("Последний ответ лида: " + html.escape(_snippet(inbound)))
        elif outbound:
            lines.append("Последнее сообщение бота: " + html.escape(_snippet(outbound)))
        if profile_fallback:
            lines.append("Профиль: " + html.escape(profile_fallback))
        return "\n".join(lines)

    def _send_link_to_user(owner_tg_id: int, event_id: int, link: str, when_iso: str) -> None:
        if int(owner_tg_id or 0) <= 0 or not _is_http_url(link):
            return
        kb = InlineKeyboardMarkup()
        kb.row(InlineKeyboardButton("🔗 Подключиться", url=link))
        kb.row(InlineKeyboardButton("📋 Мои созвоны", callback_data="u:calls:list"))
        try:
            bot.send_message(
                int(owner_tg_id),
                "Ссылка на созвон готова ✅\n"
                f"Когда: <b>{format_dt_ddmmyyyy_hhmm(when_iso, tz)}</b>\n"
                "Открой кнопку ниже.",
                reply_markup=kb,
            )
        except Exception:
            pass

    def _send_link_update_notifications(event_row: sqlite3.Row, link: str) -> None:
        eid = int(event_row["id"])
        when_iso = str(event_row["start_at"])
        when_h = format_dt_ddmmyyyy_hhmm(when_iso, tz)
        kb = InlineKeyboardMarkup()
        kb.row(InlineKeyboardButton("🔗 Подключиться", url=link))
        kb.row(InlineKeyboardButton("Открыть событие", callback_data=f"ev:open:{eid}"))
        _notify_mentors(
            "<b>Ссылка на созвон обновлена</b>\n"
            f"Событие: <b>#{eid}</b>\n"
            f"Когда: <b>{when_h}</b>",
            kb,
        )
        owner_tg_id = int(event_row["owner_tg_id"] or 0) if "owner_tg_id" in event_row.keys() and event_row["owner_tg_id"] else 0
        _send_link_to_user(owner_tg_id, eid, link, when_iso)

    def _student_calls_menu_kb() -> InlineKeyboardMarkup:
        kb = InlineKeyboardMarkup()
        kb.row(InlineKeyboardButton("🕘 Забронировать слот", callback_data=f"u:slots:day:{_day_key(now(tz).date())}"))
        kb.row(InlineKeyboardButton("📋 Мои созвоны", callback_data="u:calls:list"))
        kb.row(InlineKeyboardButton("⬅️ В меню", callback_data="u:cancel"))
        return kb

    def _diagnostic_calls_menu_kb(can_book: bool) -> InlineKeyboardMarkup:
        kb = InlineKeyboardMarkup()
        if can_book:
            kb.row(InlineKeyboardButton("🕘 Забронировать слот", callback_data=f"u:slots:day:{_day_key(now(tz).date())}"))
        kb.row(InlineKeyboardButton("📋 Мой созвон", callback_data="u:calls:list"))
        kb.row(InlineKeyboardButton("⬅️ В меню", callback_data="u:cancel"))
        return kb

    def _diagnostic_calls_stats(owner_user_id: int) -> dict:
        used_total = repo_events.owner_call_count(
            conn,
            int(owner_user_id),
            call_kind=CALL_KIND_DIAGNOSTIC,
            include_inactive=True,
        )
        upcoming = repo_events.list_owner_calls(
            conn,
            int(owner_user_id),
            from_iso=iso(now(tz)),
            limit=1,
            call_kind=CALL_KIND_DIAGNOSTIC,
        )
        return {
            "used_total": int(used_total),
            "can_book": int(used_total) < DIAGNOSTIC_CALL_LIMIT,
            "upcoming": upcoming,
        }

    def _diagnostic_calls_text(owner_user_id: int) -> str:
        stats = _diagnostic_calls_stats(owner_user_id)
        lines = [
            "<b>Диагностический созвон</b>",
            "Привет, тут можешь записаться на диагностический созвон длиной не более 30 минут.",
            f"Лимит: <b>{DIAGNOSTIC_CALL_LIMIT}</b> созвон для не-ученика.",
        ]
        if stats["upcoming"]:
            when = format_dt_ddmmyyyy_hhmm(stats["upcoming"][0]["start_at"], tz)
            lines.append(f"У тебя уже есть бронь: <b>{when}</b>.")
        elif not stats["can_book"]:
            lines.append("Лимит уже использован, новая запись недоступна.")
        else:
            lines.append("Показываются только будущие и свободные слоты со следующего дня (09:00–19:30, шаг 30 минут).")
        lines.append(f"Перенос: не позже чем за {RESCHEDULE_LIMIT_HOURS} часа.")
        lines.append(f"Отмена: не позже чем за {CANCEL_LIMIT_HOURS} часов.")
        return "\n".join(lines)

    def _resolve_user_call_mode(owner_user_id: int) -> tuple[str, sqlite3.Row | None]:
        student = _active_student(owner_user_id)
        if student:
            return CALL_KIND_STUDENT, student
        return CALL_KIND_DIAGNOSTIC, None

    def _student_slot_free(
        start_at: dt.datetime,
        duration_min: int = CALL_SLOT_DURATION_MIN,
        exclude_event_id: int | None = None,
    ) -> bool:
        if start_at <= now(tz):
            return False
        end_at = start_at + dt.timedelta(minutes=max(5, int(duration_min)))
        overlaps = repo_events.find_overlaps(conn, start_at, end_at, tz, exclude_event_id=exclude_event_id)
        return len(overlaps) == 0

    def _is_allowed_student_slot(start_at: dt.datetime) -> bool:
        if start_at.minute not in {0, 30}:
            return False
        t = start_at.time()
        return dt.time(9, 0) <= t <= dt.time(19, 30)

    def _user_booking_min_day() -> dt.date:
        return now(tz).date() + dt.timedelta(days=1)

    def _is_user_booking_day_allowed(start_at: dt.datetime) -> bool:
        return start_at.date() >= _user_booking_min_day()

    def _student_slots_view(
        owner_user_id: int,
        day: dt.date,
        move_event_id: int | None = None,
        call_kind: str = CALL_KIND_STUDENT,
    ) -> tuple[str, InlineKeyboardMarkup]:
        min_day = _user_booking_min_day()
        if day < min_day:
            day = min_day

        slots = _slot_starts(day, tz)
        now_dt = now(tz)
        start_title = "диагностический созвон" if call_kind == CALL_KIND_DIAGNOSTIC else "созвон"
        title = f"<b>{'Перенос созвона' if move_event_id else f'Запись на {start_title}'}</b> • {day.strftime('%d.%m.%Y')}\n\n"
        title += "Показываются только будущие и свободные слоты.\nБронирование доступно только начиная со следующего дня."

        kb = InlineKeyboardMarkup()
        prev_d = day - dt.timedelta(days=1)
        next_d = day + dt.timedelta(days=1)
        if move_event_id is None:
            if day > min_day:
                kb.row(InlineKeyboardButton("⬅️", callback_data=f"u:slots:day:{_day_key(prev_d)}"))
            kb.row(
                InlineKeyboardButton("Завтра", callback_data=f"u:slots:day:{_day_key(min_day)}"),
                InlineKeyboardButton("➡️", callback_data=f"u:slots:day:{_day_key(next_d)}"),
            )
        else:
            if day > min_day:
                kb.row(InlineKeyboardButton("⬅️", callback_data=f"u:slots:move_day:{int(move_event_id)}:{_day_key(prev_d)}"))
            kb.row(
                InlineKeyboardButton("Завтра", callback_data=f"u:slots:move_day:{int(move_event_id)}:{_day_key(min_day)}"),
                InlineKeyboardButton("➡️", callback_data=f"u:slots:move_day:{int(move_event_id)}:{_day_key(next_d)}"),
            )

        row_btns: list[InlineKeyboardButton] = []
        free_count = 0
        for sl in slots:
            if sl <= now_dt:
                continue
            if not _student_slot_free(sl, CALL_SLOT_DURATION_MIN, exclude_event_id=move_event_id):
                continue
            free_count += 1
            label = sl.strftime("%H:%M")
            if move_event_id is None:
                cb = f"u:slots:book:{_day_key(day)}:{sl.strftime('%H%M')}"
            else:
                cb = f"u:slots:move_pick:{int(move_event_id)}:{_day_key(day)}:{sl.strftime('%H%M')}"
            row_btns.append(InlineKeyboardButton(label, callback_data=cb))
            if len(row_btns) >= 3:
                kb.row(*row_btns)
                row_btns = []
        if row_btns:
            kb.row(*row_btns)

        if free_count == 0:
            title += "\n\nСвободных слотов на этот день нет."

        back_cb = f"u:call:open:{int(move_event_id)}" if move_event_id is not None else "u:calls"
        kb.row(InlineKeyboardButton("⬅️ Назад", callback_data=back_cb))
        return title, kb

    def _parse_slot_dt(day_key: str, hhmm: str) -> dt.datetime | None:
        try:
            day = _parse_day_key(day_key)
            hh = int(hhmm[:2])
            mm = int(hhmm[2:])
            return dt.datetime.combine(day, dt.time(hh, mm)).replace(tzinfo=tzinfo(tz))
        except Exception:
            return None

    def _call_can_reschedule(start_at: dt.datetime) -> bool:
        return (start_at - now(tz)) >= dt.timedelta(hours=RESCHEDULE_LIMIT_HOURS)

    def _call_can_cancel(start_at: dt.datetime) -> bool:
        return (start_at - now(tz)) >= dt.timedelta(hours=CANCEL_LIMIT_HOURS)

    def _student_call_actions_kb(event_id: int, can_move: bool, can_cancel: bool, link: str | None = None) -> InlineKeyboardMarkup:
        kb = InlineKeyboardMarkup()
        if _is_http_url(link):
            kb.row(InlineKeyboardButton("🔗 Подключиться", url=str(link)))
        if can_move:
            kb.row(InlineKeyboardButton("✏️ Перенести", callback_data=f"u:call:move:{int(event_id)}"))
        if can_cancel:
            kb.row(InlineKeyboardButton("❌ Отменить", callback_data=f"u:call:cancel:{int(event_id)}"))
        kb.row(InlineKeyboardButton("⬅️ К моим созвонам", callback_data="u:calls:list"))
        return kb

    def _student_label(student: sqlite3.Row) -> str:
        fio = (student["fio"] or "—").strip()
        username = (student["username"] or "").strip()
        if username and not username.startswith("@"):
            username = "@" + username
        owner_tg = student["owner_tg_id"] if "owner_tg_id" in student.keys() else None
        tail = f" ({username})" if username else ""
        if owner_tg:
            tail += f" [TG {int(owner_tg)}]"
        return f"{fio}{tail}"

    def _notify_call_created(
        student: sqlite3.Row,
        start_at_iso: str,
        event_id: int,
        dialog_context: str = "",
    ) -> None:
        start = format_dt_ddmmyyyy_hhmm(start_at_iso, tz)
        text = (
            "<b>Новая бронь созвона</b>\n"
            f"Ученик: { _student_label(student) }\n"
            f"Когда: <b>{start}</b>\n"
            "Статус: подтверждено автоматически."
        )
        if dialog_context:
            text += "\n\n<b>Контекст диалога</b>\n" + dialog_context
        kb = InlineKeyboardMarkup()
        kb.row(InlineKeyboardButton("Открыть событие", callback_data=f"ev:open:{int(event_id)}"))
        kb.row(InlineKeyboardButton("Открыть ученика", callback_data=f"st:open:{int(student['id'])}"))
        _notify_mentors(text, kb)

    def _notify_call_moved(student: sqlite3.Row, event_id: int, old_start_iso: str, new_start_iso: str) -> None:
        text = (
            "<b>Изменение брони созвона</b>\n"
            f"Ученик: { _student_label(student) }\n"
            f"Было: <b>{format_dt_ddmmyyyy_hhmm(old_start_iso, tz)}</b>\n"
            f"Стало: <b>{format_dt_ddmmyyyy_hhmm(new_start_iso, tz)}</b>"
        )
        kb = InlineKeyboardMarkup()
        kb.row(InlineKeyboardButton("Открыть событие", callback_data=f"ev:open:{int(event_id)}"))
        kb.row(InlineKeyboardButton("Открыть ученика", callback_data=f"st:open:{int(student['id'])}"))
        _notify_mentors(text, kb)

    def _notify_call_canceled(student: sqlite3.Row, old_start_iso: str) -> None:
        text = (
            "<b>Отмена брони созвона</b>\n"
            f"Ученик: { _student_label(student) }\n"
            f"Отменён слот: <b>{format_dt_ddmmyyyy_hhmm(old_start_iso, tz)}</b>"
        )
        kb = InlineKeyboardMarkup()
        kb.row(InlineKeyboardButton("Открыть ученика", callback_data=f"st:open:{int(student['id'])}"))
        _notify_mentors(text, kb)

    def _owner_user_label(owner_tg_id: int, username: str | None) -> str:
        uname = (username or "").strip()
        if uname and not uname.startswith("@"):
            uname = "@" + uname
        return f"{uname or '—'} [TG {int(owner_tg_id)}]"

    def _notify_diagnostic_call_created(
        owner_tg_id: int,
        username: str | None,
        start_at_iso: str,
        event_id: int,
        dialog_context: str = "",
    ) -> None:
        text = (
            "<b>Новая запись на диагностический созвон</b>\n"
            f"Пользователь: {_owner_user_label(owner_tg_id, username)}\n"
            f"Когда: <b>{format_dt_ddmmyyyy_hhmm(start_at_iso, tz)}</b>\n"
            "Формат: до 30 минут."
        )
        if dialog_context:
            text += "\n\n<b>Контекст диалога</b>\n" + dialog_context
        kb = InlineKeyboardMarkup()
        kb.row(InlineKeyboardButton("Открыть событие", callback_data=f"ev:open:{int(event_id)}"))
        _notify_mentors(text, kb)

    def _notify_diagnostic_call_moved(owner_tg_id: int, username: str | None, event_id: int, old_start_iso: str, new_start_iso: str) -> None:
        text = (
            "<b>Перенос диагностического созвона</b>\n"
            f"Пользователь: {_owner_user_label(owner_tg_id, username)}\n"
            f"Было: <b>{format_dt_ddmmyyyy_hhmm(old_start_iso, tz)}</b>\n"
            f"Стало: <b>{format_dt_ddmmyyyy_hhmm(new_start_iso, tz)}</b>"
        )
        kb = InlineKeyboardMarkup()
        kb.row(InlineKeyboardButton("Открыть событие", callback_data=f"ev:open:{int(event_id)}"))
        _notify_mentors(text, kb)

    def _notify_diagnostic_call_canceled(owner_tg_id: int, username: str | None, old_start_iso: str) -> None:
        text = (
            "<b>Отмена диагностического созвона</b>\n"
            f"Пользователь: {_owner_user_label(owner_tg_id, username)}\n"
            f"Отменён слот: <b>{format_dt_ddmmyyyy_hhmm(old_start_iso, tz)}</b>"
        )
        _notify_mentors(text, None)

    def _send_resume_to_mentors(
        owner_tg_id: int,
        username: str | None,
        event_id: int,
        start_at_iso: str,
        resume_file_id: str,
        dialog_context: str = "",
    ) -> None:
        if not resume_file_id:
            return
        uname = (username or "").strip()
        if uname and not uname.startswith("@"):
            uname = "@" + uname
        caption = (
            "<b>Резюме перед созвоном</b>\n"
            f"Пользователь: {uname or '—'} [TG {int(owner_tg_id)}]\n"
            f"Когда: <b>{format_dt_ddmmyyyy_hhmm(start_at_iso, tz)}</b>\n"
            f"Событие: <b>#{int(event_id)}</b>"
        )
        plain_ctx = re.sub(r"<[^>]+>", "", str(dialog_context or ""))
        plain_ctx = html.unescape(plain_ctx).strip()
        if not plain_ctx:
            plain_ctx = "Данных по диалогу пока нет."
        caption += "\n\nSummary: " + html.escape(_snippet(plain_ctx, 350))
        for chat_id in _mentor_chat_ids():
            if not admin_notification_settings.events_enabled(conn, int(chat_id)):
                continue
            try:
                bot.send_document(int(chat_id), resume_file_id, caption=caption)
            except Exception:
                continue

    def _overlap_hint(overlap: sqlite3.Row | None) -> str:
        if not overlap:
            return "Слот уже занят."
        try:
            os = dt.datetime.fromisoformat(str(overlap["start_at"]))
            oe = os + dt.timedelta(minutes=int(overlap["duration_min"] or 0))
            et = _etype_label(str(overlap["event_type"] or ""))
            who = str(overlap["fio"] or "").strip()
            if not who:
                ou = str(overlap["owner_username"] or "").strip()
                if ou:
                    who = ou if ou.startswith("@") else "@" + ou
            who_part = f", {who}" if who else ""
            return f"Слот занят: {os.strftime('%H:%M')}-{oe.strftime('%H:%M')} ({et}{who_part})"
        except Exception:
            return "Слот уже занят."

    def _resolve_user_call(event_id: int, owner_user_id: int) -> tuple[str | None, sqlite3.Row | None, sqlite3.Row | None]:
        student = _active_student(owner_user_id)
        if student:
            e = repo_events.get_student_call(conn, event_id, int(student["id"]))
            if e:
                return CALL_KIND_STUDENT, e, student
        e_diag = repo_events.get_owner_call(conn, event_id, owner_user_id, call_kind=CALL_KIND_DIAGNOSTIC)
        if e_diag:
            return CALL_KIND_DIAGNOSTIC, e_diag, None
        return None, None, student

    @bot.callback_query_handler(func=lambda c: c.data == "u:calls")
    def user_calls_menu(c: CallbackQuery):
        if is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Это раздел ученика")
            return
        owner_id = int(c.from_user.id)
        mode, student = _resolve_user_call_mode(owner_id)
        if mode == CALL_KIND_STUDENT and student is not None:
            bot.edit_message_text(
                "<b>Созвоны с ментором</b>\n"
                "Можно бронировать только свободные будущие слоты начиная со следующего дня (09:00–19:30, шаг 30 минут).\n"
                f"Перенос: не позже чем за {RESCHEDULE_LIMIT_HOURS} часа.\n"
                f"Отмена: не позже чем за {CANCEL_LIMIT_HOURS} часов.",
                c.message.chat.id,
                c.message.message_id,
                reply_markup=_student_calls_menu_kb(),
            )
            bot.answer_callback_query(c.id)
            return

        diag_stats = _diagnostic_calls_stats(owner_id)
        bot.edit_message_text(
            _diagnostic_calls_text(owner_id),
            c.message.chat.id,
            c.message.message_id,
            reply_markup=_diagnostic_calls_menu_kb(bool(diag_stats["can_book"])),
        )
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("u:slots:day:"))
    def user_slots_day(c: CallbackQuery):
        if is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Это раздел ученика")
            return
        owner_id = int(c.from_user.id)
        mode, student = _resolve_user_call_mode(owner_id)
        if mode == CALL_KIND_DIAGNOSTIC:
            diag_stats = _diagnostic_calls_stats(owner_id)
            if not bool(diag_stats["can_book"]):
                bot.answer_callback_query(c.id, "Лимит диагностического созвона уже использован")
                bot.edit_message_text(
                    _diagnostic_calls_text(owner_id),
                    c.message.chat.id,
                    c.message.message_id,
                    reply_markup=_diagnostic_calls_menu_kb(False),
                )
                return
        elif student is None:
            bot.answer_callback_query(c.id, "Профиль ученика не найден")
            return
        day_key = c.data.split(":")[3]
        day = _parse_day_key(day_key)
        text, kb = _student_slots_view(owner_id, day, move_event_id=None, call_kind=mode)
        bot.edit_message_text(text, c.message.chat.id, c.message.message_id, reply_markup=kb)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("u:slots:book:"))
    def user_slots_book(c: CallbackQuery):
        if is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Это раздел ученика")
            return
        owner_id = int(c.from_user.id)
        mode, student = _resolve_user_call_mode(owner_id)
        if mode == CALL_KIND_STUDENT and student is None:
            bot.answer_callback_query(c.id, "Профиль ученика не найден")
            return
        if mode == CALL_KIND_DIAGNOSTIC:
            diag_stats = _diagnostic_calls_stats(owner_id)
            if not bool(diag_stats["can_book"]):
                bot.answer_callback_query(c.id, "Лимит диагностического созвона уже использован")
                bot.edit_message_text(
                    _diagnostic_calls_text(owner_id),
                    c.message.chat.id,
                    c.message.message_id,
                    reply_markup=_diagnostic_calls_menu_kb(False),
                )
                return
        parts = c.data.split(":")
        if len(parts) != 5:
            bot.answer_callback_query(c.id, "Некорректный слот")
            return
        day_key, hhmm = parts[3], parts[4]
        start_at = _parse_slot_dt(day_key, hhmm)
        if not start_at:
            bot.answer_callback_query(c.id, "Некорректное время")
            return
        if not _is_allowed_student_slot(start_at):
            bot.answer_callback_query(c.id, "Доступны только слоты с 09:00 до 19:30")
            return
        if not _is_user_booking_day_allowed(start_at):
            bot.answer_callback_query(c.id, "Бронирование доступно только со следующего дня")
            text, kb = _student_slots_view(owner_id, _parse_day_key(day_key), move_event_id=None, call_kind=mode)
            bot.edit_message_text(text, c.message.chat.id, c.message.message_id, reply_markup=kb)
            return
        if start_at <= now(tz):
            bot.answer_callback_query(c.id, "Это время уже не актуально")
            text, kb = _student_slots_view(owner_id, _parse_day_key(day_key), move_event_id=None, call_kind=mode)
            bot.edit_message_text(text, c.message.chat.id, c.message.message_id, reply_markup=kb)
            return
        if not _student_slot_free(start_at, CALL_SLOT_DURATION_MIN):
            bot.answer_callback_query(c.id, "Слот уже занят, выбери другой")
            text, kb = _student_slots_view(owner_id, _parse_day_key(day_key), move_event_id=None, call_kind=mode)
            bot.edit_message_text(text, c.message.chat.id, c.message.message_id, reply_markup=kb)
            return
        repo_states.set_state(
            conn,
            owner_id,
            CALL_RESUME_STATE,
            {
                "mode": mode,
                "day_key": day_key,
                "hhmm": hhmm,
                "chat_id": int(c.message.chat.id),
                "message_id": int(c.message.message_id),
                "student_id": int(student["id"]) if student is not None else None,
                "owner_username": c.from_user.username,
            },
            tz,
        )
        when = format_dt_ddmmyyyy_hhmm(iso(start_at), tz)
        bot.edit_message_text(
            "Перед бронированием отправь резюме в формате PDF.\n"
            f"Выбранный слот: <b>{when}</b>\n\n"
            "После получения PDF я отправлю заявку ментору и подтвержу бронь.",
            c.message.chat.id,
            c.message.message_id,
            reply_markup=_resume_request_kb(),
        )
        bot.answer_callback_query(c.id, "Жду PDF-резюме")

    @bot.callback_query_handler(func=lambda c: c.data == "u:slots:resume_cancel")
    def user_slots_resume_cancel(c: CallbackQuery):
        if is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Это раздел ученика")
            return
        owner_id = int(c.from_user.id)
        st, data = repo_states.get_state(conn, owner_id)
        if st == CALL_RESUME_STATE:
            repo_states.clear_state(conn, owner_id, tz)
        mode, _student = _resolve_user_call_mode(owner_id)
        day = _user_booking_min_day()
        if isinstance(data, dict) and data.get("day_key"):
            try:
                day = _parse_day_key(str(data["day_key"]))
            except Exception:
                day = _user_booking_min_day()
        text, kb = _student_slots_view(owner_id, day, move_event_id=None, call_kind=mode)
        bot.edit_message_text(text, c.message.chat.id, c.message.message_id, reply_markup=kb)
        bot.answer_callback_query(c.id, "Отменено")

    @bot.message_handler(
        content_types=["document", "text"],
        func=lambda m: repo_states.get_state(conn, m.from_user.id)[0] == CALL_RESUME_STATE,
    )
    def user_slots_resume_upload(m: Message):
        if is_admin(ctx, m.from_user.id):
            return
        owner_id = int(m.from_user.id)
        st, data = repo_states.get_state(conn, owner_id)
        if st != CALL_RESUME_STATE:
            return
        payload = data or {}

        if m.content_type != "document":
            bot.reply_to(
                m,
                "Нужно отправить именно PDF-файл резюме.\n"
                "Если передумал — нажми «Отмена» в карточке выбора слота.",
                reply_markup=_resume_request_kb(),
            )
            return

        doc = m.document
        file_name = str(getattr(doc, "file_name", "") or "").strip().lower()
        mime = str(getattr(doc, "mime_type", "") or "").strip().lower()
        is_pdf = mime == "application/pdf" or file_name.endswith(".pdf")
        if not is_pdf:
            bot.reply_to(m, "Файл должен быть в формате PDF. Пришли, пожалуйста, PDF-резюме.")
            return

        day_key = str(payload.get("day_key") or "").strip()
        hhmm = str(payload.get("hhmm") or "").strip()
        mode = str(payload.get("mode") or CALL_KIND_DIAGNOSTIC).strip() or CALL_KIND_DIAGNOSTIC
        student_id = int(payload.get("student_id") or 0) or None
        start_at = _parse_slot_dt(day_key, hhmm)
        if not start_at:
            repo_states.clear_state(conn, owner_id, tz)
            if mode == CALL_KIND_STUDENT:
                kb = _student_calls_menu_kb()
            else:
                kb = _diagnostic_calls_menu_kb(True)
            bot.send_message(m.chat.id, "Слот устарел. Выбери время заново.", reply_markup=kb)
            return
        if not _is_allowed_student_slot(start_at) or not _is_user_booking_day_allowed(start_at) or start_at <= now(tz):
            repo_states.clear_state(conn, owner_id, tz)
            if mode == CALL_KIND_STUDENT:
                kb = _student_calls_menu_kb()
            else:
                kb = _diagnostic_calls_menu_kb(True)
            bot.send_message(m.chat.id, "Слот уже неактуален. Выбери другой.", reply_markup=kb)
            return
        if not _student_slot_free(start_at, CALL_SLOT_DURATION_MIN):
            repo_states.clear_state(conn, owner_id, tz)
            day = start_at.date()
            text, kb = _student_slots_view(owner_id, day, move_event_id=None, call_kind=mode)
            bot.send_message(m.chat.id, "Этот слот уже занят. Выбери другой.", reply_markup=kb)
            return

        if mode == CALL_KIND_DIAGNOSTIC:
            diag_stats = _diagnostic_calls_stats(owner_id)
            if not bool(diag_stats["can_book"]):
                repo_states.clear_state(conn, owner_id, tz)
                bot.send_message(
                    m.chat.id,
                    "Лимит диагностического созвона уже использован.",
                    reply_markup=_diagnostic_calls_menu_kb(False),
                )
                return

        before = CALL_REMIND_BEFORE_MIN
        next_alert = _calc_next_alert(start_at, before, tz)
        with _BOOKING_LOCK:
            event_id, overlaps = repo_events.create_if_free(
                conn,
                tz,
                student_id=student_id,
                event_type="CALL",
                company=None,
                role=None,
                direction=None,
                link=None,
                start_at_iso=iso(start_at),
                duration_min=CALL_SLOT_DURATION_MIN,
                remind_before_min=before,
                next_alert_at_iso=iso(next_alert),
                owner_tg_id=owner_id,
                call_kind=mode,
            )
        if not event_id:
            ov = overlaps[0] if overlaps else None
            day = start_at.date()
            text, kb = _student_slots_view(owner_id, day, move_event_id=None, call_kind=mode)
            bot.send_message(m.chat.id, f"{_overlap_hint(ov)}\nВыбери другой слот.", reply_markup=kb)
            repo_states.clear_state(conn, owner_id, tz)
            return

        repo_states.clear_state(conn, owner_id, tz)
        dialog_context = _call_context_summary(
            owner_id,
            str(payload.get("owner_username") or m.from_user.username or ""),
            student_id=int(student_id or 0) if student_id else None,
        )
        try:
            repo_analytics.log_event(
                conn,
                tz,
                owner_id,
                "calls.booking.created",
                {"event_id": int(event_id), "start_at": iso(start_at), "resume_pdf": True},
                username=m.from_user.username,
            )
        except Exception:
            pass

        if mode == CALL_KIND_STUDENT:
            student = repo_students.get_student(conn, int(student_id or 0)) if student_id else None
            if student is not None:
                _notify_call_created(student, iso(start_at), event_id, dialog_context=dialog_context)
            _send_resume_to_mentors(
                owner_id,
                str(payload.get("owner_username") or m.from_user.username or ""),
                event_id,
                iso(start_at),
                str(doc.file_id),
                dialog_context=dialog_context,
            )
            bot.send_message(
                m.chat.id,
                "✅ Слот забронирован.\n"
                f"Созвон: <b>{format_dt_ddmmyyyy_hhmm(iso(start_at), tz)}</b>\n"
                "Резюме отправлено ментору.",
                reply_markup=_student_calls_menu_kb(),
            )
            return

        _notify_diagnostic_call_created(
            owner_id,
            str(payload.get("owner_username") or m.from_user.username or ""),
            iso(start_at),
            event_id,
            dialog_context=dialog_context,
        )
        _send_resume_to_mentors(
            owner_id,
            str(payload.get("owner_username") or m.from_user.username or ""),
            event_id,
            iso(start_at),
            str(doc.file_id),
            dialog_context=dialog_context,
        )
        bot.send_message(
            m.chat.id,
            "✅ Диагностический созвон забронирован.\n"
            f"Когда: <b>{format_dt_ddmmyyyy_hhmm(iso(start_at), tz)}</b>\n"
            "Длительность: до 30 минут.\n"
            "Резюме отправлено ментору.",
            reply_markup=_diagnostic_calls_menu_kb(False),
        )

    @bot.callback_query_handler(func=lambda c: c.data == "u:calls:list")
    def user_calls_list(c: CallbackQuery):
        if is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Это раздел ученика")
            return
        owner_id = int(c.from_user.id)
        mode, student = _resolve_user_call_mode(owner_id)
        if mode == CALL_KIND_STUDENT and student is not None:
            rows = repo_events.list_student_calls(conn, int(student["id"]), from_iso=iso(now(tz)), limit=25)
        else:
            rows = repo_events.list_owner_calls(
                conn,
                owner_id,
                from_iso=iso(now(tz)),
                limit=25,
                call_kind=CALL_KIND_DIAGNOSTIC,
            )
        if not rows:
            empty_text = "У тебя пока нет забронированных созвонов."
            kb = _student_calls_menu_kb()
            if mode == CALL_KIND_DIAGNOSTIC:
                empty_text = "У тебя пока нет забронированного диагностического созвона."
                diag_stats = _diagnostic_calls_stats(owner_id)
                kb = _diagnostic_calls_menu_kb(bool(diag_stats["can_book"]))
            bot.edit_message_text(
                empty_text,
                c.message.chat.id,
                c.message.message_id,
                reply_markup=kb,
            )
            bot.answer_callback_query(c.id)
            return
        title = "<b>Мои созвоны</b>" if mode == CALL_KIND_STUDENT else "<b>Мой диагностический созвон</b>"
        lines = [title, "", "Выбери созвон:"]
        kb = InlineKeyboardMarkup()
        for e in rows:
            when = format_dt_ddmmyyyy_hhmm(e["start_at"], tz)
            lines.append(f"• {when}")
            kb.row(InlineKeyboardButton(when, callback_data=f"u:call:open:{int(e['id'])}"))
        kb.row(InlineKeyboardButton("⬅️ Назад", callback_data="u:calls"))
        bot.edit_message_text("\n".join(lines), c.message.chat.id, c.message.message_id, reply_markup=kb)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("u:call:open:"))
    def user_call_open(c: CallbackQuery):
        if is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Это раздел ученика")
            return
        owner_id = int(c.from_user.id)
        event_id = int(c.data.split(":")[3])
        mode, e, _student = _resolve_user_call(event_id, owner_id)
        if not e:
            bot.answer_callback_query(c.id, "Созвон не найден")
            return
        start_dt = dt.datetime.fromisoformat(e["start_at"])
        can_move = _call_can_reschedule(start_dt)
        can_cancel = _call_can_cancel(start_dt)
        title = "<b>Мой созвон</b>" if mode == CALL_KIND_STUDENT else "<b>Мой диагностический созвон</b>"
        msg = (
            f"{title}\n"
            f"Когда: <b>{format_dt_ddmmyyyy_hhmm(e['start_at'], tz)}</b>\n"
            f"Длительность: <b>{int(e['duration_min'] or CALL_SLOT_DURATION_MIN)} мин</b>\n"
            f"Перенос: не позже чем за {RESCHEDULE_LIMIT_HOURS} часа до начала.\n"
            f"Отмена: не позже чем за {CANCEL_LIMIT_HOURS} часов до начала."
        )
        if _is_http_url(e["link"]):
            msg += f"\nСсылка: {e['link']}"
        if not can_move:
            msg += "\n\nПеренос уже недоступен."
        if not can_cancel:
            msg += "\nОтмена уже недоступна."
        bot.edit_message_text(
            msg,
            c.message.chat.id,
            c.message.message_id,
            reply_markup=_student_call_actions_kb(event_id, can_move, can_cancel, link=str(e["link"] or "")),
        )
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("u:call:move:"))
    def user_call_move(c: CallbackQuery):
        if is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Это раздел ученика")
            return
        owner_id = int(c.from_user.id)
        event_id = int(c.data.split(":")[3])
        mode, e, _student = _resolve_user_call(event_id, owner_id)
        if not e:
            bot.answer_callback_query(c.id, "Созвон не найден")
            return
        start_dt = dt.datetime.fromisoformat(e["start_at"])
        if not _call_can_reschedule(start_dt):
            bot.answer_callback_query(c.id, f"Перенос доступен только за {RESCHEDULE_LIMIT_HOURS} часа")
            return
        day = max(_user_booking_min_day(), start_dt.date())
        text, kb = _student_slots_view(owner_id, day, move_event_id=event_id, call_kind=mode or CALL_KIND_STUDENT)
        bot.edit_message_text(text, c.message.chat.id, c.message.message_id, reply_markup=kb)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("u:slots:move_day:"))
    def user_call_move_day(c: CallbackQuery):
        if is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Это раздел ученика")
            return
        parts = c.data.split(":")
        if len(parts) != 5:
            bot.answer_callback_query(c.id, "Некорректный запрос")
            return
        event_id = int(parts[3])
        owner_id = int(c.from_user.id)
        mode, e, _student = _resolve_user_call(event_id, owner_id)
        if not e:
            bot.answer_callback_query(c.id, "Созвон не найден")
            return
        day = _parse_day_key(parts[4])
        text, kb = _student_slots_view(owner_id, day, move_event_id=event_id, call_kind=mode or CALL_KIND_STUDENT)
        bot.edit_message_text(text, c.message.chat.id, c.message.message_id, reply_markup=kb)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("u:slots:move_pick:"))
    def user_call_move_pick(c: CallbackQuery):
        if is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Это раздел ученика")
            return
        owner_id = int(c.from_user.id)
        parts = c.data.split(":")
        if len(parts) != 6:
            bot.answer_callback_query(c.id, "Некорректный запрос")
            return
        event_id = int(parts[3])
        day_key = parts[4]
        hhmm = parts[5]
        mode, e, student = _resolve_user_call(event_id, owner_id)
        if not e:
            bot.answer_callback_query(c.id, "Созвон не найден")
            return
        old_start = str(e["start_at"])
        old_start_dt = dt.datetime.fromisoformat(old_start)
        if not _call_can_reschedule(old_start_dt):
            bot.answer_callback_query(c.id, f"Перенос доступен только за {RESCHEDULE_LIMIT_HOURS} часа")
            return
        target_start = _parse_slot_dt(day_key, hhmm)
        if not target_start or target_start <= now(tz):
            bot.answer_callback_query(c.id, "Это время уже неактуально")
            return
        if not _is_allowed_student_slot(target_start):
            bot.answer_callback_query(c.id, "Доступны только слоты с 09:00 до 19:30")
            return
        if not _is_user_booking_day_allowed(target_start):
            bot.answer_callback_query(c.id, "Перенос доступен только на даты со следующего дня")
            text, kb = _student_slots_view(owner_id, _parse_day_key(day_key), move_event_id=event_id, call_kind=mode or CALL_KIND_STUDENT)
            bot.edit_message_text(text, c.message.chat.id, c.message.message_id, reply_markup=kb)
            return
        if not _student_slot_free(target_start, CALL_SLOT_DURATION_MIN, exclude_event_id=event_id):
            bot.answer_callback_query(c.id, "Слот занят, выбери другой")
            text, kb = _student_slots_view(owner_id, _parse_day_key(day_key), move_event_id=event_id, call_kind=mode or CALL_KIND_STUDENT)
            bot.edit_message_text(text, c.message.chat.id, c.message.message_id, reply_markup=kb)
            return

        before = int(e["remind_before_min"] or CALL_REMIND_BEFORE_MIN)
        next_alert = _calc_next_alert(target_start, before, tz)
        with _BOOKING_LOCK:
            moved, overlaps = repo_events.move_if_free(
                conn,
                event_id=event_id,
                tz=tz,
                start_at_iso=iso(target_start),
                duration_min=CALL_SLOT_DURATION_MIN,
                next_alert_at_iso=iso(next_alert),
            )
        if not moved:
            bot.answer_callback_query(c.id, _overlap_hint(overlaps[0] if overlaps else None))
            text, kb = _student_slots_view(owner_id, _parse_day_key(day_key), move_event_id=event_id, call_kind=mode or CALL_KIND_STUDENT)
            bot.edit_message_text(text, c.message.chat.id, c.message.message_id, reply_markup=kb)
            return
        try:
            repo_analytics.log_event(
                conn,
                tz,
                int(c.from_user.id),
                "calls.booking.moved",
                {"event_id": event_id, "from": old_start, "to": iso(target_start)},
                username=c.from_user.username,
            )
        except Exception:
            pass
        if mode == CALL_KIND_STUDENT and student is not None:
            _notify_call_moved(student, event_id, old_start, iso(target_start))
            bot.edit_message_text(
                f"✅ Созвон перенесён.\n"
                f"Новый слот: <b>{format_dt_ddmmyyyy_hhmm(iso(target_start), tz)}</b>\n"
                "Ментор уведомлён.",
                c.message.chat.id,
                c.message.message_id,
                reply_markup=_student_calls_menu_kb(),
            )
        else:
            _notify_diagnostic_call_moved(owner_id, c.from_user.username, event_id, old_start, iso(target_start))
            bot.edit_message_text(
                f"✅ Диагностический созвон перенесён.\n"
                f"Новый слот: <b>{format_dt_ddmmyyyy_hhmm(iso(target_start), tz)}</b>\n"
                "Ментор уведомлён.",
                c.message.chat.id,
                c.message.message_id,
                reply_markup=_diagnostic_calls_menu_kb(False),
            )
        bot.answer_callback_query(c.id, "Перенесено")

    @bot.callback_query_handler(func=lambda c: c.data.startswith("u:call:cancel:"))
    def user_call_cancel_ask(c: CallbackQuery):
        if is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Это раздел ученика")
            return
        owner_id = int(c.from_user.id)
        event_id = int(c.data.split(":")[3])
        _mode, e, _student = _resolve_user_call(event_id, owner_id)
        if not e:
            bot.answer_callback_query(c.id, "Созвон не найден")
            return
        start_dt = dt.datetime.fromisoformat(e["start_at"])
        if not _call_can_cancel(start_dt):
            bot.answer_callback_query(c.id, f"Отмена доступна только за {CANCEL_LIMIT_HOURS} часов")
            return
        kb = InlineKeyboardMarkup()
        kb.row(InlineKeyboardButton("Да, отменить", callback_data=f"u:call:cancelok:{event_id}"))
        kb.row(InlineKeyboardButton("Нет", callback_data=f"u:call:open:{event_id}"))
        bot.edit_message_text(
            f"Отменить созвон <b>{format_dt_ddmmyyyy_hhmm(e['start_at'], tz)}</b>?",
            c.message.chat.id,
            c.message.message_id,
            reply_markup=kb,
        )
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("u:call:cancelok:"))
    def user_call_cancel_ok(c: CallbackQuery):
        if is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Это раздел ученика")
            return
        owner_id = int(c.from_user.id)
        event_id = int(c.data.split(":")[3])
        mode, e, student = _resolve_user_call(event_id, owner_id)
        if not e:
            bot.answer_callback_query(c.id, "Созвон не найден")
            return
        start_dt = dt.datetime.fromisoformat(e["start_at"])
        if not _call_can_cancel(start_dt):
            bot.answer_callback_query(c.id, f"Отмена доступна только за {CANCEL_LIMIT_HOURS} часов")
            return
        repo_events.update(conn, event_id, tz, active=0)
        try:
            repo_analytics.log_event(
                conn,
                tz,
                int(c.from_user.id),
                "calls.booking.canceled",
                {"event_id": event_id, "start_at": e["start_at"]},
                username=c.from_user.username,
            )
        except Exception:
            pass
        if mode == CALL_KIND_STUDENT and student is not None:
            _notify_call_canceled(student, str(e["start_at"]))
            bot.edit_message_text(
                "✅ Созвон отменён.\nМентор уведомлён.",
                c.message.chat.id,
                c.message.message_id,
                reply_markup=_student_calls_menu_kb(),
            )
        else:
            _notify_diagnostic_call_canceled(owner_id, c.from_user.username, str(e["start_at"]))
            bot.edit_message_text(
                "✅ Диагностический созвон отменён.\nМентор уведомлён.",
                c.message.chat.id,
                c.message.message_id,
                reply_markup=_diagnostic_calls_menu_kb(False),
            )
        bot.answer_callback_query(c.id, "Отменено")

    @bot.callback_query_handler(func=lambda c: c.data == "ev:today")
    def ev_today(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        n = now(tz)
        ds = start_of_day(n.date(), tz)
        de = end_of_day(n.date(), tz)
        rows = repo_events.list_upcoming(conn, iso(ds), iso(de))
        if not rows:
            bot.edit_message_text("Сегодня событий нет.", c.message.chat.id, c.message.message_id, reply_markup=events_menu_kb())
            bot.answer_callback_query(c.id); return
        lines=[]
        kb=InlineKeyboardMarkup()
        for e in rows[:10]:
            who = e["fio"] or "—"
            comp = e["company"] if (hasattr(e, "keys") and "company" in e.keys() and e["company"]) else None
            tail = f" — {comp}" if comp else ""
            when = format_dt_ddmmyyyy_hhmm(e["start_at"], tz)
            when_short = (when[:5] + " " + when[-5:]) if len(when) >= 16 else when
            et = _etype_label(e["event_type"])
            lines.append(f"• <b>{et}</b> • {who} — {when}{tail}")
            btn = f"{who} • {when_short}"[:60]
            kb.row(InlineKeyboardButton(btn, callback_data=f"ev:open:{e['id']}"))
        kb.row(InlineKeyboardButton("⬅️ Назад", callback_data="m:events"))
        bot.edit_message_text("События на сегодня:\n" + "\n".join(lines), c.message.chat.id, c.message.message_id, reply_markup=kb)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data == "ev:week")
    def ev_week(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        n = now(tz)
        ds = start_of_day(n.date(), tz)
        de = add_days(ds, 7)
        rows = repo_events.list_upcoming(conn, iso(ds), iso(de))
        if not rows:
            bot.edit_message_text("На неделе событий нет.", c.message.chat.id, c.message.message_id, reply_markup=events_menu_kb())
            bot.answer_callback_query(c.id); return
        lines=[]
        kb=InlineKeyboardMarkup()
        for e in rows[:12]:
            who = e["fio"] or "—"
            comp = e["company"] if (hasattr(e, "keys") and "company" in e.keys() and e["company"]) else None
            tail = f" — {comp}" if comp else ""
            when = format_dt_ddmmyyyy_hhmm(e["start_at"], tz)
            when_short = (when[:5] + " " + when[-5:]) if len(when) >= 16 else when
            et = _etype_label(e["event_type"])
            lines.append(f"• <b>{et}</b> • {who} — {when}{tail}")
            btn = f"{who} • {when_short}"[:60]
            kb.row(InlineKeyboardButton(btn, callback_data=f"ev:open:{e['id']}"))
        kb.row(InlineKeyboardButton("⬅️ Назад", callback_data="m:events"))
        bot.edit_message_text("События на неделе:\n" + "\n".join(lines), c.message.chat.id, c.message.message_id, reply_markup=kb)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data == "ev:tomorrow")
    def ev_tomorrow(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        base = now(tz).date() + dt.timedelta(days=1)
        ds = start_of_day(base, tz)
        de = end_of_day(base, tz)
        rows = repo_events.list_upcoming(conn, iso(ds), iso(de))
        if not rows:
            bot.edit_message_text("На завтра событий нет.", c.message.chat.id, c.message.message_id, reply_markup=events_menu_kb())
            bot.answer_callback_query(c.id); return
        lines = []
        kb = InlineKeyboardMarkup()
        for e in rows[:10]:
            who = e["fio"] or "—"
            comp = e["company"] if (hasattr(e, "keys") and "company" in e.keys() and e["company"]) else None
            tail = f" — {comp}" if comp else ""
            when = format_dt_ddmmyyyy_hhmm(e["start_at"], tz)
            when_short = (when[:5] + " " + when[-5:]) if len(when) >= 16 else when
            et = _etype_label(e["event_type"])
            lines.append(f"• <b>{et}</b> • {who} — {when}{tail}")
            btn = f"{who} • {when_short}"[:60]
            kb.row(InlineKeyboardButton(btn, callback_data=f"ev:open:{e['id']}"))
        kb.row(InlineKeyboardButton("⬅️ Назад", callback_data="m:events"))
        bot.edit_message_text("События на завтра:\n" + "\n".join(lines), c.message.chat.id, c.message.message_id, reply_markup=kb)
        bot.answer_callback_query(c.id)

    def _slots_view(day: dt.date) -> tuple[str, InlineKeyboardMarkup]:
        rows = repo_events.list_for_day(conn, day, tz)

        slots = _slot_starts(day, tz)
        slot_len = dt.timedelta(minutes=30)

        # map slot -> list of event rows to show (start-of-event only)
        display: dict[dt.datetime, list[sqlite3.Row]] = {}
        occupied: set[dt.datetime] = set()

        for e in rows:
            try:
                s = dt.datetime.fromisoformat(e["start_at"])
                dur = int(e["duration_min"] or 0)
                en = s + dt.timedelta(minutes=dur)

                # occupied slots: any 30-min window that intersects event interval
                for sl in slots:
                    if sl < en and (sl + slot_len) > s:
                        occupied.add(sl)

                disp = _floor_to_30(s)
                # clamp display slot to schedule bounds
                if disp < slots[0]:
                    disp = slots[0]
                if disp > slots[-1]:
                    disp = slots[-1]
                display.setdefault(disp, []).append(e)
            except Exception:
                continue

        title = f"<b>Слоты</b> • {day.strftime('%d.%m.%Y')}\n\n"
        if not rows:
            title += "Событий нет. Выбери свободное время."
        else:
            title += "Свободные слоты — кнопки с временем. Занятые — начало события."

        kb = InlineKeyboardMarkup()
        prev_d = day - dt.timedelta(days=1)
        next_d = day + dt.timedelta(days=1)
        kb.row(
            InlineKeyboardButton("⬅️", callback_data=f"slots:day:{_day_key(prev_d)}"),
            InlineKeyboardButton("Сегодня", callback_data=f"slots:day:{_day_key(now(tz).date())}"),
            InlineKeyboardButton("➡️", callback_data=f"slots:day:{_day_key(next_d)}"),
        )

        row_btns: list[InlineKeyboardButton] = []
        for sl in slots:
            if sl in occupied:
                if sl not in display:
                    continue
                # if overlaps exist (legacy), show stacked with short label
                for ev in display.get(sl, [])[:2]:
                    s = dt.datetime.fromisoformat(ev["start_at"])
                    en = s + dt.timedelta(minutes=int(ev["duration_min"] or 0))
                    who = str(ev["fio"] or "").strip()
                    if not who:
                        owner_u = str(ev["owner_username"] or "").strip()
                        if owner_u:
                            who = owner_u if owner_u.startswith("@") else "@" + owner_u
                    label = f"{s.strftime('%H:%M')}-{en.strftime('%H:%M')} ({_etype_label(ev['event_type'])})"
                    if who:
                        label += f" {who}"
                    row_btns.append(InlineKeyboardButton(label[:60], callback_data=f"ev:open:{ev['id']}"))
            else:
                label = sl.strftime("%H:%M")
                row_btns.append(
                    InlineKeyboardButton(
                        label,
                        callback_data=f"slots:free:{_day_key(day)}:{sl.strftime('%H%M')}"
                    )
                )

            if len(row_btns) >= 3:
                kb.row(*row_btns)
                row_btns = []
        if row_btns:
            kb.row(*row_btns)

        kb.row(InlineKeyboardButton("⬅️ Назад", callback_data="m:events"))
        return title, kb

    @bot.callback_query_handler(func=lambda c: c.data == "ev:slots")
    def ev_slots(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        day = now(tz).date()
        text, kb = _slots_view(day)
        bot.edit_message_text(text, c.message.chat.id, c.message.message_id, reply_markup=kb)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("slots:day:"))
    def slots_day(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        key = c.data.split(":", 2)[2]
        day = _parse_day_key(key)
        text, kb = _slots_view(day)
        bot.edit_message_text(text, c.message.chat.id, c.message.message_id, reply_markup=kb)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("slots:free:"))
    def slots_free(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        _, _, day_key, hhmm = c.data.split(":", 3)
        day = _parse_day_key(day_key)
        hh = int(hhmm[:2]); mm = int(hhmm[2:])
        start = dt.datetime.combine(day, dt.time(hh, mm)).replace(tzinfo=tzinfo(tz))
        data = {"preset_start_at": iso(start)}
        repo_states.set_state(conn, c.from_user.id, "EV_PICK_TYPE", data, tz)
        _ask_type(c.message.chat.id, c.from_user.id, data)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data == "ev:list")
    def ev_list(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        rows = repo_events.list_all_upcoming(conn, limit=20)
        if not rows:
            bot.edit_message_text("Предстоящих событий нет.", c.message.chat.id, c.message.message_id, reply_markup=events_menu_kb())
            bot.answer_callback_query(c.id); return
        lines=[]
        kb=InlineKeyboardMarkup()
        for e in rows[:15]:
            who = e["fio"] or "—"
            comp = e["company"] if (hasattr(e, "keys") and "company" in e.keys() and e["company"]) else None
            tail = f" — {comp}" if comp else ""
            when = format_dt_ddmmyyyy_hhmm(e["start_at"], tz)
            when_short = (when[:5] + " " + when[-5:]) if len(when) >= 16 else when
            et = _etype_label(e["event_type"])
            lines.append(f"• <b>{et}</b> • {who} — {when}{tail}")
            btn = f"{who} • {when_short}"[:60]
            kb.row(InlineKeyboardButton(btn, callback_data=f"ev:open:{e['id']}"))
        kb.row(InlineKeyboardButton("⬅️ Назад", callback_data="m:events"))
        bot.edit_message_text("Предстоящие события:\n" + "\n".join(lines), c.message.chat.id, c.message.message_id, reply_markup=kb)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data == "ev:add")
    def ev_add(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        data={}
        repo_states.set_state(conn, c.from_user.id, "EV_PICK_TYPE", data, tz)
        _ask_type(c.message.chat.id, c.from_user.id, data)
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("st:ev_add:"))
    def ev_add_from_student(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        sid=int(c.data.split(":")[2])
        data={"student_id": sid}
        repo_states.set_state(conn, c.from_user.id, "EV_PICK_TYPE", data, tz)
        _ask_type(c.message.chat.id, c.from_user.id, data)
        bot.answer_callback_query(c.id)

    def _ask_type(chat_id: int, user_id: int, data: dict):
        items=[(label, f"ev:type:{code}") for label, code in EVENT_TYPES]
        bot.send_message(chat_id, "Формат события:", reply_markup=pick_list_kb(items, "m:events"))

    @bot.callback_query_handler(func=lambda c: c.data.startswith("ev:type:"))
    def ev_type(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        st, data = repo_states.get_state(conn, c.from_user.id)
        if st != "EV_PICK_TYPE":
            bot.answer_callback_query(c.id); return
        data["event_type"]=c.data.split(":")[2]
        # if no student selected, ask optional link to student
        if not data.get("student_id"):
            repo_states.set_state(conn, c.from_user.id, "EV_FIND_STUDENT_OPT", data, tz)
            bot.send_message(c.message.chat.id, "Введи часть ФИО/@username ученика (или '-' чтобы без ученика):")
        else:
            repo_states.set_state(conn, c.from_user.id, "EV_LINK_INPUT", data, tz)
            bot.send_message(c.message.chat.id, "Ссылка на собес/созвон (или '-' если нет):")
        bot.answer_callback_query(c.id)

    @bot.message_handler(func=lambda m: repo_states.get_state(conn, m.from_user.id)[0] in (
        "EV_FIND_STUDENT_OPT","EV_LINK_INPUT","EV_COMPANY_INPUT","EV_DIRECTION_INPUT","EV_ROLE_INPUT","EV_START_INPUT"
    ), content_types=["text"])
    def ev_text(m: Message):
        if not is_admin(ctx, m.from_user.id):
            return
        st, data = repo_states.get_state(conn, m.from_user.id)
        if st == "EV_FIND_STUDENT_OPT":
            txt=m.text.strip()
            if txt in ("-", "—"):
                data["student_id"]=None
                repo_states.set_state(conn, m.from_user.id, "EV_LINK_INPUT", data, tz)
                bot.send_message(m.chat.id, "Ссылка на собес/созвон (или '-' если нет):")
                return
            rows = repo_students.search_students(conn, txt, archived=False, limit=8)
            if not rows:
                bot.send_message(m.chat.id, "Не нашёл. Попробуй ещё раз или '-'"); return
            kb=InlineKeyboardMarkup()
            for r in rows:
                kb.row(InlineKeyboardButton(r["fio"][:28], callback_data=f"ev:pick_student:{r['id']}"))
            kb.row(InlineKeyboardButton("Без ученика", callback_data="ev:pick_student:0"))
            bot.send_message(m.chat.id, "Выбери ученика:", reply_markup=kb)
            return
        if st == "EV_LINK_INPUT":
            link=m.text.strip()
            data["link"]=None if link in ("-","—") else link
            repo_states.set_state(conn, m.from_user.id, "EV_COMPANY_INPUT", data, tz)
            bot.send_message(m.chat.id, "Компания (или '-' если не надо):")
            return

        if st == "EV_COMPANY_INPUT":
            txt=m.text.strip()
            data["company"]=None if txt in ("-","—") else txt
            # direction: try take from student, but allow override
            repo_states.set_state(conn, m.from_user.id, "EV_DIRECTION_INPUT", data, tz)
            bot.send_message(m.chat.id, "Направление/роль (например Java Backend) (или '-' если не надо):")
            return

        if st == "EV_DIRECTION_INPUT":
            txt=m.text.strip()
            data["direction"]=None if txt in ("-","—") else txt
            repo_states.set_state(conn, m.from_user.id, "EV_ROLE_INPUT", data, tz)
            bot.send_message(m.chat.id, "Этап собеса/позиция (например Middle Java, TeamLead) (или '-' если не надо):")
            return

        if st == "EV_ROLE_INPUT":
            txt=m.text.strip()
            data["role"]=None if txt in ("-","—") else txt
            # If user picked a slot, skip manual date entry.
            if data.get("preset_start_at"):
                data["start_at"] = data["preset_start_at"]
                repo_states.set_state(conn, m.from_user.id, "EV_PICK_DURATION", data, tz)
                items=[("30 мин", "ev:dur:30"), ("60 мин", "ev:dur:60"), ("90 мин", "ev:dur:90"), ("120 мин", "ev:dur:120")]
                bot.send_message(m.chat.id, "Длительность:", reply_markup=pick_list_kb(items, "m:events"))
                return

            repo_states.set_state(conn, m.from_user.id, "EV_START_INPUT", data, tz)
            bot.send_message(m.chat.id, "Введи дату и время: <b>дд.мм ЧЧ:ММ</b> (год подставлю сам) или <b>дд.мм.гггг ЧЧ:ММ</b>\nНапример: 14.02 18:30")
            return
        if st == "EV_START_INPUT":
            dt_obj = parse_datetime_ddmmyyyy_hhmm(m.text.strip(), tz)
            if not dt_obj:
                bot.send_message(m.chat.id, "Не понял. Формат: дд.мм.гггг ЧЧ:ММ"); return
            data["start_at"]=iso(dt_obj)
            repo_states.set_state(conn, m.from_user.id, "EV_PICK_DURATION", data, tz)
            items=[("30 мин", "ev:dur:30"), ("60 мин", "ev:dur:60"), ("90 мин", "ev:dur:90"), ("120 мин", "ev:dur:120")]
            bot.send_message(m.chat.id, "Длительность:", reply_markup=pick_list_kb(items, "m:events"))
            return
        if st == "EV_NOTE":  # unused
            return

    @bot.callback_query_handler(func=lambda c: c.data.startswith("ev:pick_student:"))
    def ev_pick_student(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        st, data = repo_states.get_state(conn, c.from_user.id)
        if st != "EV_FIND_STUDENT_OPT":
            bot.answer_callback_query(c.id); return
        sid=int(c.data.split(":")[2])
        data["student_id"]=None if sid==0 else sid
        repo_states.set_state(conn, c.from_user.id, "EV_LINK_INPUT", data, tz)
        bot.send_message(c.message.chat.id, "Ссылка на собес/созвон (или '-' если нет):")
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("ev:dur:"))
    def ev_dur(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        st, data = repo_states.get_state(conn, c.from_user.id)
        if st != "EV_PICK_DURATION":
            bot.answer_callback_query(c.id); return
        data["duration_min"]=int(c.data.split(":")[2])
        repo_states.set_state(conn, c.from_user.id, "EV_PICK_BEFORE", data, tz)
        items=[("За 60 мин", "ev:before:60"), ("За 120 мин", "ev:before:120"), ("За 180 мин", "ev:before:180"), ("Сейчас", "ev:before:0")]
        bot.send_message(c.message.chat.id, "Когда напомнить:", reply_markup=pick_list_kb(items, "m:events"))
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("ev:before:"))
    def ev_before(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        st, data = repo_states.get_state(conn, c.from_user.id)
        if st != "EV_PICK_BEFORE":
            bot.answer_callback_query(c.id); return
        before=int(c.data.split(":")[2])
        data["remind_before_min"]=before

        # overlap protection
        try:
            start_at = dt.datetime.fromisoformat(data["start_at"])
            dur = int(data.get("duration_min", 60))
            end_at = start_at + dt.timedelta(minutes=dur)
            overlaps = repo_events.find_overlaps(conn, start_at, end_at, tz)
        except Exception:
            overlaps = []

        if overlaps and not data.get("allow_overlap"):
            lines = []
            for ov in overlaps[:6]:
                try:
                    os = dt.datetime.fromisoformat(ov["start_at"])
                    oe = os + dt.timedelta(minutes=int(ov["duration_min"] or 0))
                    lines.append(f"• {os.strftime('%d.%m %H:%M')}-{oe.strftime('%H:%M')} ({_etype_label(ov['event_type'])})")
                except Exception:
                    continue
            msg = "⚠️ В это время уже есть событие.\n\n" + "\n".join(lines) + "\n\nВыбери другое время."
            kb = InlineKeyboardMarkup()
            kb.row(InlineKeyboardButton("🕘 Открыть слоты", callback_data=f"slots:day:{_day_key(start_at.date())}"))
            kb.row(InlineKeyboardButton("❌ Отмена", callback_data="m:events"))
            bot.edit_message_text(msg, c.message.chat.id, c.message.message_id, reply_markup=kb)
            bot.answer_callback_query(c.id)
            return

        # create event
        next_alert = _calc_next_alert(start_at, before, tz)
        with _BOOKING_LOCK:
            eid, overlaps2 = repo_events.create_if_free(
                conn,
                tz,
                student_id=data.get("student_id"),
                event_type=data.get("event_type", "OTHER"),
                company=data.get("company"),
                role=data.get("role"),
                direction=data.get("direction"),
                link=data.get("link"),
                start_at_iso=data["start_at"],
                duration_min=int(data.get("duration_min", 60)),
                remind_before_min=before,
                next_alert_at_iso=iso(next_alert),
            )
        if not eid:
            ov = overlaps2[0] if overlaps2 else None
            hint = _overlap_hint(ov)
            kb = InlineKeyboardMarkup()
            kb.row(InlineKeyboardButton("🕘 Открыть слоты", callback_data=f"slots:day:{_day_key(start_at.date())}"))
            kb.row(InlineKeyboardButton("⬅️ Назад", callback_data="m:events"))
            bot.edit_message_text(f"⚠️ {hint}\n\nВыбери другое время.", c.message.chat.id, c.message.message_id, reply_markup=kb)
            bot.answer_callback_query(c.id)
            return
        repo_states.clear_state(conn, c.from_user.id, tz)
        bot.send_message(c.message.chat.id, f"✅ Событие создано (id={eid}).", reply_markup=events_menu_kb())
        bot.answer_callback_query(c.id)


    @bot.callback_query_handler(func=lambda c: c.data == "ev:overlap_force")
    def ev_overlap_force(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        bot.answer_callback_query(c.id, "Наложение событий отключено")
        bot.edit_message_text(
            "Создание поверх занятого времени отключено. Выбери другой слот.",
            c.message.chat.id,
            c.message.message_id,
            reply_markup=events_menu_kb(),
        )



    # -------------------------
    # Просмотр / редактирование / удаление
    # -------------------------

    @bot.callback_query_handler(func=lambda c: c.data.startswith("ev:open:"))
    def ev_open(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        eid = int(c.data.split(":")[2])
        e = repo_events.get(conn, eid)
        if not e:
            bot.answer_callback_query(c.id, "Не найдено"); return

        owner_tg = int(e["owner_tg_id"] or 0) if ("owner_tg_id" in e.keys() and e["owner_tg_id"] is not None) else 0
        owner_username = (e["owner_username"] or "").strip() if ("owner_username" in e.keys()) else ""
        if owner_username and not owner_username.startswith("@"):
            owner_username = "@" + owner_username
        who = e["fio"] or (f"{owner_username or '—'} [TG {owner_tg}]" if owner_tg > 0 else "—")
        link_val = e["link"]
        link = link_val or "—"
        company = (e["company"] or "—") if (hasattr(e, "keys") and "company" in e.keys()) else "—"
        direction = (e["direction"] or "—") if (hasattr(e, "keys") and "direction" in e.keys()) else "—"
        role = (e["role"] or "—") if (hasattr(e, "keys") and "role" in e.keys()) else "—"
        call_kind = (e["call_kind"] or "—") if ("call_kind" in e.keys()) else "—"
        before = e["remind_before_min"] if e["remind_before_min"] is not None else "—"
        when = format_dt_ddmmyyyy_hhmm(e["start_at"], tz)
        et = _etype_label(e["event_type"])
        msg = (
            f"<b>Событие #{eid}</b>\n"
            f"Тип: <b>{et}</b>\n"
            f"Режим созвона: {call_kind}\n"
            f"Ученик: {who}\n"
            f"Компания: {company}\n"
            f"Направление: {direction}\n"
            f"Позиция/этап: {role}\n"
            f"Когда: <b>{when}</b>\n"
            f"Длительность: {e['duration_min']} мин\n"
            f"Напомнить за: {before} мин\n"
            f"Ссылка: {link}"
        )

        kb = InlineKeyboardMarkup()
        kb.row(
            InlineKeyboardButton("✏️ Дата/время", callback_data=f"ev:edit:{eid}:when"),
            InlineKeyboardButton("✏️ Ссылка", callback_data=f"ev:edit:{eid}:link"),
        )
        kb.row(
            InlineKeyboardButton("✏️ Длительность", callback_data=f"ev:edit:{eid}:duration"),
            InlineKeyboardButton("✏️ Напоминание", callback_data=f"ev:edit:{eid}:before"),
        )
        kb.row(
            InlineKeyboardButton("✏️ Тип", callback_data=f"ev:edit:{eid}:type"),
            InlineKeyboardButton("✏️ Ученик", callback_data=f"ev:edit:{eid}:student"),
        )
        if link_val and isinstance(link_val, str) and link_val.startswith("http"):
            kb.row(InlineKeyboardButton("🔗 Открыть ссылку", url=link_val))
        kb.row(InlineKeyboardButton("🗑 Удалить", callback_data=f"ev:del:{eid}"))
        if e["student_id"] is not None:
            kb.row(InlineKeyboardButton("Открыть ученика", callback_data=f"st:open:{e['student_id']}"))
        kb.row(InlineKeyboardButton("⬅️ Назад", callback_data="m:events"))

        bot.edit_message_text(msg, c.message.chat.id, c.message.message_id, reply_markup=kb)
        bot.answer_callback_query(c.id)


    @bot.callback_query_handler(func=lambda c: c.data.startswith("ev:del:"))
    def ev_del(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        eid = int(c.data.split(":")[2])
        kb = InlineKeyboardMarkup()
        kb.row(InlineKeyboardButton("Да, удалить", callback_data=f"ev:delok:{eid}"))
        kb.row(InlineKeyboardButton("Отмена", callback_data=f"ev:open:{eid}"))
        bot.edit_message_text(f"Удалить событие #{eid}?", c.message.chat.id, c.message.message_id, reply_markup=kb)
        bot.answer_callback_query(c.id)


    @bot.callback_query_handler(func=lambda c: c.data.startswith("ev:delok:"))
    def ev_del_ok(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        eid = int(c.data.split(":")[2])
        repo_events.delete(conn, eid)
        bot.edit_message_text("Удалено.", c.message.chat.id, c.message.message_id, reply_markup=events_menu_kb())
        bot.answer_callback_query(c.id)


    @bot.callback_query_handler(func=lambda c: c.data.startswith("ev:edit:"))
    def ev_edit(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        _, _, eid_s, field = c.data.split(":")
        eid = int(eid_s)
        e = repo_events.get(conn, eid)
        if not e:
            bot.answer_callback_query(c.id, "Не найдено"); return

        if field == "type":
            items = [
                ("HR", f"ev:set_type:{eid}:HR"),
                ("Тех", f"ev:set_type:{eid}:TECH"),
                ("Созвон", f"ev:set_type:{eid}:CALL"),
                ("Другое", f"ev:set_type:{eid}:OTHER"),
            ]
            bot.edit_message_text(
                "Выбери тип события:",
                c.message.chat.id,
                c.message.message_id,
                reply_markup=pick_list_kb(items, f"ev:open:{eid}"),
            )
            bot.answer_callback_query(c.id)
            return

        if field == "student":
            repo_states.set_state(conn, c.from_user.id, "EV_PICK_STUDENT", {"eid": eid}, tz)
            bot.send_message(c.message.chat.id, "Введи @username или часть ФИО ученика для поиска:")
            bot.answer_callback_query(c.id)
            return

        repo_states.set_state(conn, c.from_user.id, "EV_EDIT_TEXT", {"eid": eid, "field": field}, tz)
        prompts = {
            "when": "Введи дату и время: дд.мм чч:мм (год сам) или дд.мм.гггг чч:мм (например 18.02 14:30)",
            "link": "Введи ссылку (или '-' чтобы очистить):",
            "duration": "Длительность в минутах (число):",
            "before": "Напомнить за сколько минут? (например 10) или 0 чтобы отключить:",
        }
        bot.send_message(c.message.chat.id, prompts.get(field, "Введи значение:"))
        bot.answer_callback_query(c.id)


    @bot.callback_query_handler(func=lambda c: c.data.startswith("ev:set_type:"))
    def ev_set_type(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        _, _, eid_s, t = c.data.split(":", 3)
        eid = int(eid_s)
        repo_events.update(conn, eid, tz, event_type=t)
        bot.answer_callback_query(c.id, "Ок")


    def _ev_state_active(m: Message) -> bool:
        if not m.from_user:
            return False
        st, _ = repo_states.get_state(conn, m.from_user.id)
        return st in {"EV_EDIT_TEXT", "EV_PICK_STUDENT"}


    @bot.message_handler(func=_ev_state_active)
    def ev_text_router(m: Message):
        if not is_admin(ctx, m.from_user.id):
            return
        st, data = repo_states.get_state(conn, m.from_user.id)
        data = data or {}

        if st == "EV_PICK_STUDENT":
            q = (m.text or "").strip()
            rows = repo_students.search_students(conn, q, archived=False, limit=10)
            if not rows:
                bot.reply_to(m, "Не нашёл. Введи другую строку:")
                return
            eid = int(data["eid"])
            items = []
            for s in rows:
                items.append((f"{s['fio']} (@{s['username'] or '—'})", f"ev:set_student:{eid}:{s['id']}"))
            bot.send_message(m.chat.id, "Выбери ученика:", reply_markup=pick_list_kb(items, f"ev:open:{eid}"))
            return

        if st == "EV_EDIT_TEXT":
            eid = int(data["eid"])
            field = data["field"]
            txt = (m.text or "").strip()

            if field == "when":
                start_dt = parse_datetime_ddmmyyyy_hhmm(txt, tz)
                if not start_dt:
                    bot.reply_to(m, "Неверный формат. Пример: 18.02 14:30")
                    return
                start_dt = start_dt.replace(tzinfo=tzinfo(tz), microsecond=0)
                start_iso = iso(start_dt)
                e = repo_events.get(conn, eid)
                dur = int(e["duration_min"] or 0)
                end_dt = start_dt + dt.timedelta(minutes=dur)
                overlaps = repo_events.find_overlaps(conn, start_dt, end_dt, tz, exclude_event_id=eid)
                if overlaps:
                    os = dt.datetime.fromisoformat(overlaps[0]["start_at"])
                    oe = os + dt.timedelta(minutes=int(overlaps[0]["duration_min"] or 0))
                    bot.reply_to(m, f"⚠️ В это время уже есть событие: {os.strftime('%d.%m %H:%M')}-{oe.strftime('%H:%M')}.\nОткрой слоты и выбери другое время.")
                    return
                before = int(e["remind_before_min"] or 0)
                next_alert = _calc_next_alert(start_dt, before, tz)
                repo_events.update(conn, eid, tz, start_at=start_iso, next_alert_at=iso(next_alert), alerted=0)

            elif field == "link":
                prev = repo_events.get(conn, eid)
                old_link = str(prev["link"] or "").strip() if prev else ""
                new_link = None if txt in ("-", "—", "") else txt
                repo_events.update(conn, eid, tz, link=new_link)
                if prev and _is_http_url(new_link):
                    if str(new_link).strip() != old_link:
                        updated = repo_events.get(conn, eid)
                        if updated:
                            _send_link_update_notifications(updated, str(new_link).strip())

            elif field == "duration":
                try:
                    n = int(txt)
                    n = max(5, n)
                except Exception:
                    bot.reply_to(m, "Введи число")
                    return
                e = repo_events.get(conn, eid)
                start_dt = dt.datetime.fromisoformat(e["start_at"])
                if start_dt.tzinfo is None:
                    start_dt = start_dt.replace(tzinfo=tzinfo(tz))
                end_dt = start_dt + dt.timedelta(minutes=n)
                overlaps = repo_events.find_overlaps(conn, start_dt, end_dt, tz, exclude_event_id=eid)
                if overlaps:
                    os = dt.datetime.fromisoformat(overlaps[0]["start_at"])
                    oe = os + dt.timedelta(minutes=int(overlaps[0]["duration_min"] or 0))
                    bot.reply_to(m, f"⚠️ При такой длительности будет пересечение с событием {os.strftime('%d.%m %H:%M')}-{oe.strftime('%H:%M')}.\nВыбери другую длительность/время.")
                    return
                repo_events.update(conn, eid, tz, duration_min=n)

            elif field == "before":
                try:
                    n = int(txt)
                    n = max(0, n)
                except Exception:
                    bot.reply_to(m, "Введи число")
                    return
                e = repo_events.get(conn, eid)
                start_dt = dt.datetime.fromisoformat(e["start_at"])
                if start_dt.tzinfo is None:
                    start_dt = start_dt.replace(tzinfo=tzinfo(tz))
                next_alert = _calc_next_alert(start_dt, n, tz)
                repo_events.update(conn, eid, tz, remind_before_min=n, next_alert_at=iso(next_alert), alerted=0)

            repo_states.clear_state(conn, m.from_user.id, tz)
            bot.reply_to(m, "Ок. Открой событие снова.")
            return


    @bot.callback_query_handler(func=lambda c: c.data.startswith("ev:set_student:"))
    def ev_set_student(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа"); return
        _, _, eid_s, sid_s = c.data.split(":")
        eid = int(eid_s)
        sid = int(sid_s)
        repo_events.update(conn, eid, tz, student_id=sid)
        repo_states.clear_state(conn, c.from_user.id, tz)
        bot.answer_callback_query(c.id, "Ок")
