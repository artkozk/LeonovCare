from __future__ import annotations
from telebot import TeleBot
from telebot.types import CallbackQuery
import sqlite3

from app.db import repo_admins
from app.handlers.common import is_admin, admin_has
from app.ui.keyboards import students_menu_kb, reminders_menu_kb, events_menu_kb, payments_menu_kb, stats_menu_kb, admins_menu_kb
from app.ui import texts

def init(bot: TeleBot, ctx: dict) -> None:
    conn: sqlite3.Connection = ctx["conn"]

    @bot.callback_query_handler(func=lambda c: c.data == "m:students")
    def go_students(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        bot.edit_message_text("<b>Ученики</b>", c.message.chat.id, c.message.message_id, reply_markup=students_menu_kb())
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data == "m:reminders")
    def go_reminders(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        bot.edit_message_text("<b>Напоминалки</b>", c.message.chat.id, c.message.message_id, reply_markup=reminders_menu_kb())
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data == "m:events")
    def go_events(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        bot.edit_message_text("<b>Уведомления</b>", c.message.chat.id, c.message.message_id, reply_markup=events_menu_kb())
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data == "m:payments")
    def go_payments(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        bot.edit_message_text("<b>Платежи</b>", c.message.chat.id, c.message.message_id, reply_markup=payments_menu_kb())
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data == "m:stats")
    def go_stats(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        bot.edit_message_text(
            "<b>Статистика</b>\nВыбери раздел:",
            c.message.chat.id,
            c.message.message_id,
            reply_markup=stats_menu_kb(
                show_payments=admin_has(ctx, c.from_user.id, repo_admins.PERM_STATS_PAYMENTS),
            ),
        )
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data == "m:admins")
    def go_admins(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        if not admin_has(ctx, c.from_user.id, repo_admins.PERM_ADMINS_MANAGE):
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        bot.edit_message_text("<b>Администраторы</b>\nУправление доступом:", c.message.chat.id, c.message.message_id, reply_markup=admins_menu_kb())
        bot.answer_callback_query(c.id)
