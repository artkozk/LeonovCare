from __future__ import annotations

import html
import json
import sqlite3
from datetime import timedelta, timezone

from telebot import TeleBot
from telebot.types import CallbackQuery

from app.db import (
    repo_admins,
    repo_requests,
    repo_students,
    repo_states,
    repo_payments,
    repo_settings,
    repo_postpay,
    repo_alerts,
    repo_analytics,
    repo_enrollment_contracts,
    repo_interview_helper_licenses,
)
from app.services.interview_helper_client import InterviewHelperClient, InterviewHelperClientError
from app.services.timeutils import now, format_date_ddmmyyyy, iso
from app.services.postpay import post_total, next_due_after_payment
from app.ui import texts
from app.ui.keyboards import request_open_kb, request_reject_confirm_kb, request_lead_source_kb


def init(bot: TeleBot, ctx: dict) -> None:
    conn: sqlite3.Connection = ctx["conn"]
    cfg = ctx["cfg"]
    tz = cfg.TZ
    interview_client = InterviewHelperClient(
        base_url=cfg.INTERVIEW_API_BASE_URL,
        admin_username=cfg.INTERVIEW_API_ADMIN_USERNAME,
        admin_password=cfg.INTERVIEW_API_ADMIN_PASSWORD,
        timeout_sec=cfg.INTERVIEW_API_TIMEOUT_SEC,
    )

    STATUS_LABELS = {
        "PENDING": "Ожидает",
        "APPROVED": "Одобрено",
        "REJECTED": "Отклонено",
    }

    PAYLOAD_FIELD_LABELS = {
        "owner_chat_id": "Чат пользователя",
        "owner_username": "Юзернейм пользователя",
        "service_title": "Услуга",
        "purpose": "Назначение платежа",
        "manual_handoff": "Ручное подтверждение через ментора",
        "source": "Источник",
        "pay_date": "Дата платежа",
        "amount": "Сумма",
        "recipient_inn": "ИНН получателя",
        "contract_id": "ID договора",
        "track_key": "Код трека",
        "track_title": "Трек",
        "plan_key": "Код тарифа",
        "plan_title": "Тариф",
        "price_label": "Цена по тарифу",
        "expected_amount": "Ожидаемая сумма",
        "event": "Событие",
        "reason": "Причина",
        "login": "Логин",
        "direction": "Направление",
        "service_key": "Код услуги",
        "target_applies": "Цель откликов",
        "query_text": "Поисковый запрос",
        "free_clicks": "Бесплатные отклики",
        "paid_clicks": "Платные отклики",
        "per_click": "Цена за отклик",
        "duration_days": "Период (дней)",
        "remaining_postpay": "Остаток постоплаты",
        "recommended_amount": "Рекомендуемый платеж",
        "fio": "ФИО",
        "username": "Юзернейм",
        "stage": "Этап",
        "tariff": "Тариф",
        "comment": "Комментарий",
        "lead_source": "Источник лида",
        "join_date": "Дата начала обучения",
        "contract_url": "Ссылка на договор",
        "prepay": "Предоплата",
        "post_total_percent": "Постоплата всего (%)",
        "post_monthly_percent": "Постоплата в месяц (%)",
        "hh_phone": "Телефон HH",
        "hh_email": "Почта HH",
        "hh_birth_date": "Дата рождения",
        "hh_location": "Локация",
        "hh_salary_min": "Ожидания по зарплате (минимум)",
        "hh_salary_comfort": "Ожидания по зарплате (комфорт)",
        "proof_file_id": "ID файла чека",
        "verification": "Проверка",
        "note": "Заметка",
        "error": "Ошибка",
    }

    VALUE_LABELS = {
        "source": {
            "mentor_handoff": "Через ментора",
            "autoapply_site": "Автоотклики с сайта",
            "student": "Ученик",
        },
        "lead_source": {
            "channel": "Канал",
            "cold": "Холодные",
            "referral": "Сарафанка",
            "om": "Ом",
        },
        "track_key": {
            "zero-offer": "С нуля до оффера",
            "interview-prep": "После курсов до оффера",
            "grade-salary": "Увеличение зарплаты",
        },
        "event": {
            "reissue_request": "Запрос на пересоздание",
        },
        "reason": {
            "contract_already_issued": "Договор уже выдавался",
        },
    }

    LEAD_SOURCE_LABELS = {
        "channel": "Канал",
        "cold": "Холодные",
        "referral": "Сарафанка",
        "om": "Ом",
    }
    LEAD_SOURCE_BY_LABEL = {v.lower(): k for k, v in LEAD_SOURCE_LABELS.items()}

    def is_admin(user_id: int) -> bool:
        return repo_admins.is_admin(conn, int(user_id), ctx["cfg"].ADMIN_IDS)

    def _admin_only(c: CallbackQuery) -> bool:
        if not is_admin(c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа")
            return False
        return True

    def _row_id(row) -> int | None:
        if not row:
            return None
        try:
            return int(row["id"])
        except Exception:
            try:
                return int(row[0])
            except Exception:
                return None

    def _ensure_ref(table: str, name: str | None) -> int | None:
        name = (name or "").strip()
        if not name:
            return None
        row = conn.execute(f"SELECT id FROM {table} WHERE lower(name)=lower(?) LIMIT 1", (name,)).fetchone()
        rid = _row_id(row)
        if rid:
            return rid
        # create if missing
        if table == "directions":
            conn.execute("INSERT OR IGNORE INTO directions(name, sort) VALUES(?, 999)", (name,))
        elif table == "stages":
            conn.execute("INSERT OR IGNORE INTO stages(name, sort) VALUES(?, 999)", (name,))
        conn.commit()
        row = conn.execute(f"SELECT id FROM {table} WHERE lower(name)=lower(?) LIMIT 1", (name,)).fetchone()
        return _row_id(row)

    def _notify_student(owner_tg_id: int, payload: dict, text: str) -> None:
        chat_id = payload.get("owner_chat_id") or owner_tg_id
        try:
            bot.send_message(int(chat_id), text)
        except Exception:
            pass

    def _freeze_request_actions(chat_id: int, message_id: int, req_id: int) -> None:
        try:
            bot.edit_message_reply_markup(
                chat_id,
                message_id,
                reply_markup=request_open_kb(req_id),
            )
        except Exception:
            pass

    def _status_label(raw: str | None) -> str:
        key = str(raw or "").strip().upper()
        return STATUS_LABELS.get(key, "Неизвестно")

    def _value_label(key: str, value) -> str:
        if value is None:
            return "—"
        if isinstance(value, bool):
            return "Да" if value else "Нет"
        if isinstance(value, (dict, list)):
            try:
                return json.dumps(value, ensure_ascii=False)
            except Exception:
                return "Сложные данные"
        text_val = str(value).strip()
        if not text_val:
            return "—"
        mapped = VALUE_LABELS.get(key, {}).get(text_val)
        return mapped if mapped else text_val

    def _payload_lines(payload: dict) -> list[str]:
        lines: list[str] = []
        unknown_idx = 0
        for key, value in (payload or {}).items():
            if key in {"hh_password"}:
                continue
            label = PAYLOAD_FIELD_LABELS.get(key)
            if not label:
                unknown_idx += 1
                label = f"Доп. поле {unknown_idx}"
            lines.append(f"{label}: {_value_label(key, value)}")
        return lines

    def _issue_interview_helper_license(
        owner_tg_id: int,
        owner_chat_id: int | None,
        owner_username: str | None,
        note_suffix: str,
    ) -> tuple[sqlite3.Row | None, str]:
        if not interview_client.enabled:
            return None, "API Interview Helper не настроен."
        days = max(int(cfg.INTERVIEW_HELPER_DURATION_DAYS or 30), 1)
        expires_local = now(tz) + timedelta(days=days)
        expires_utc = expires_local.astimezone(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")
        note = f"tg={int(owner_tg_id)}"
        if note_suffix:
            note = f"{note};{note_suffix}"
        try:
            response = interview_client.create_license(
                plan=cfg.INTERVIEW_API_PLAN,
                expires_at=expires_utc,
                note=note,
            )
        except InterviewHelperClientError as exc:
            return None, str(exc)
        key = str(response.get("key") or response.get("licenseKey") or "").strip()
        if not key:
            return None, "API не вернул лицензионный ключ."
        try:
            status_info = interview_client.check_license_status(key)
        except InterviewHelperClientError as exc:
            return None, f"Ключ выдан, но не прошел проверку статуса: {exc}"
        status_txt = str(status_info.get("status") or "").strip().upper()
        valid_flag = status_info.get("valid")
        enabled_flag = status_info.get("enabled")
        if valid_flag is False or enabled_flag is False or status_txt in {"INVALID", "REVOKED", "BLOCKED", "EXPIRED"}:
            return None, f"Ключ выпущен API, но статус неактивный: {status_txt or 'UNKNOWN'}"
        try:
            chat_id = int(owner_chat_id) if owner_chat_id is not None else None
        except Exception:
            chat_id = None
        repo_interview_helper_licenses.create(
            conn,
            tz,
            owner_tg_id=owner_tg_id,
            owner_chat_id=chat_id,
            owner_username=owner_username,
            checkout_payment_id=None,
            external_license_id=int(response.get("id")) if str(response.get("id") or "").isdigit() else None,
            license_key=key,
            plan=str(response.get("plan") or cfg.INTERVIEW_API_PLAN or "PRO"),
            enabled=bool(response.get("enabled", True)),
            expires_at=str(response.get("expiresAt") or expires_utc),
            note=note,
            payload={**response, "status_check": status_info},
        )
        return repo_interview_helper_licenses.latest_for_user(conn, owner_tg_id), ""

    @bot.callback_query_handler(func=lambda c: c.data.startswith("req:open:"))
    def cb_open(c: CallbackQuery):
        if not _admin_only(c):
            return
        req_id = int(c.data.split(":")[2])
        r = repo_requests.get(conn, req_id)
        if not r:
            bot.answer_callback_query(c.id, "Не найдено")
            return
        p = repo_requests.payload(r)
        details = _payload_lines(p)
        txt = (
            f"<b>[ЗАЯВКА]</b> {texts.request_title(r['req_type'])}\n"
            f"Номер заявки: {req_id}\n"
            f"Статус: {_status_label(r['status'])}\n"
            f"Telegram ID пользователя: {r['owner_tg_id']}\n\n"
            + ("\n".join(details) if details else "Детали отсутствуют")
        )
        bot.send_message(c.message.chat.id, txt)
        bot.answer_callback_query(c.id)

    def _approve_request(
        req_id: int,
        actor_chat_id: int,
        actor_message_id: int | None,
        lead_source: str | None = None,
    ) -> tuple[bool, str]:
        r = repo_requests.get(conn, req_id)
        if not r or r["status"] != "PENDING":
            if actor_message_id is not None:
                _freeze_request_actions(actor_chat_id, actor_message_id, req_id)
            return False, "Неактуально"

        p = repo_requests.payload(r)
        owner_tg_id = int(r["owner_tg_id"])
        notify_text = "Заявка подтверждена ментором ✅"

        # Find existing student by owner or by username
        s = repo_students.get_by_owner(conn, owner_tg_id)
        if r["req_type"] == "PROFILE":
            lead_source_raw = str(lead_source or "").strip()
            lead_source_key = LEAD_SOURCE_BY_LABEL.get(lead_source_raw.lower(), lead_source_raw.lower())
            if lead_source_key in LEAD_SOURCE_LABELS:
                lead_source_value = lead_source_key
            else:
                lead_source_value = lead_source_raw
            if not lead_source_value:
                return False, "Выбери источник лида"
            if not s:
                # create minimal student using existing admin flow helper
                ts = iso(now(tz))
                direction_id = _ensure_ref("directions", p.get("direction"))
                stage_id = _ensure_ref("stages", p.get("stage"))
                cur = conn.execute(
                    "INSERT INTO students(fio, username, direction_id, stage_id, tariff, comment, join_date, contract_url, created_at, updated_at, owner_tg_id, owner_chat_id, owner_username, lead_source) "
                    "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    (
                        p.get("fio") or "—",
                        (p.get("username") or "").lstrip("@") or None,
                        direction_id,
                        stage_id,
                        p.get("tariff") or "post",
                        p.get("comment") or "",
                        p.get("join_date") or format_date_ddmmyyyy(now(tz).date()),
                        p.get("contract_url"),
                        ts,
                        ts,
                        owner_tg_id,
                        int(p.get("owner_chat_id") or 0) or None,
                        p.get("owner_username"),
                        lead_source_value,
                    ),
                )
                conn.commit()
                student_id = int(cur.lastrowid)
            else:
                student_id = int(s["id"])
                direction_id = _ensure_ref("directions", p.get("direction")) or s["direction_id"]
                stage_id = _ensure_ref("stages", p.get("stage")) or s["stage_id"]
                repo_students.update_student(
                    conn,
                    student_id,
                    tz,
                    fio=p.get("fio") or s["fio"],
                    username=(p.get("username") or s["username"] or "").lstrip("@") or None,
                    direction_id=direction_id,
                    stage_id=stage_id,
                    tariff=p.get("tariff") or s["tariff"],
                    contract_url=p.get("contract_url") or s["contract_url"],
                    join_date=p.get("join_date") or s["join_date"],
                    comment=p.get("comment") or s["comment"],
                    lead_source=lead_source_value,
                )
                # owner info
                repo_students.set_owner(
                    conn,
                    tz,
                    student_id,
                    owner_tg_id,
                    int(p.get("owner_chat_id") or actor_chat_id),
                    p.get("owner_username"),
                )

            # если ученик указал предоплату — добавим как платёж (один раз)
            try:
                prepay = int(float(p.get("prepay") or 0))
            except Exception:
                prepay = 0
            if prepay > 0 and repo_payments.sum_payments(conn, student_id, "prepay") == 0:
                repo_payments.add_payment(
                    conn,
                    student_id,
                    "prepay",
                    prepay,
                    format_date_ddmmyyyy(now(tz).date()),
                    tz,
                    source="student",
                    note="prepay from form",
                )

            # postpay rule on student_postpay
            try:
                total_percent = float(p.get("post_total_percent") or 0)
                per_month = float(p.get("post_monthly_percent") or 50)
                if total_percent > 0:
                    conn.execute(
                        "INSERT INTO student_postpay(student_id,total_percent,schedule_type,per_period_value,period_unit,enabled) "
                        "VALUES(?,?,?,?,?,1) ON CONFLICT(student_id) DO UPDATE SET total_percent=excluded.total_percent, schedule_type=excluded.schedule_type, per_period_value=excluded.per_period_value, enabled=1",
                        (student_id, total_percent, "percent_per_month", per_month, "month"),
                    )
                    conn.commit()
            except Exception:
                pass

        elif r["req_type"] == "ACCOUNTS":
            if not s:
                return False, "Сначала одобри анкету"
            student_id = int(s["id"])
            repo_students.update_student(
                conn,
                student_id,
                tz,
                hh_phone=p.get("hh_phone"),
                hh_email=p.get("hh_email"),
                hh_password=p.get("hh_password"),
                hh_birth_date=p.get("hh_birth_date"),
                hh_location=p.get("hh_location"),
                hh_salary_min=p.get("hh_salary_min"),
                hh_salary_comfort=p.get("hh_salary_comfort"),
            )

        elif r["req_type"] == "PAYMENT":
            if not s:
                return False, "Сначала одобри анкету"
            student_id = int(s["id"])
            amount = int(p.get("amount") or 0)
            if amount > 0:
                pay_date_raw = str(p.get("pay_date") or "").strip()
                if len(pay_date_raw) == 10 and pay_date_raw[2] == "." and pay_date_raw[5] == ".":
                    pay_date = pay_date_raw
                else:
                    pay_date = format_date_ddmmyyyy(now(tz).date())
                verification = p.get("verification") if isinstance(p.get("verification"), dict) else {}
                note = "proof" if verification.get("ok", True) else "proof:review"
                repo_payments.add_payment(
                    conn,
                    student_id,
                    "postpay",
                    amount,
                    pay_date,
                    tz,
                    source="student",
                    proof_file_id=p.get("proof_file_id"),
                    note=note,
                )

                # advance schedule and reset student notifications to next due
                pp = repo_postpay.get(conn, student_id)
                if pp and pp["enabled"]:
                    new_due = next_due_after_payment(pp["next_due_date"], pay_date, pp["schedule_type"], pp["per_period_value"])
                    repo_postpay.upsert(conn, student_id, next_due_date=new_due, student_next_notify_date=new_due, enabled=1)

                    # auto-disable if fully paid
                    total = post_total(s["offer_amount"], pp["total_percent"])
                    if total is not None:
                        paid = repo_payments.sum_payments(conn, student_id, "postpay")
                        if paid >= total:
                            repo_postpay.disable(conn, student_id)

                # close any pending PAYMENT alerts in student's chat
                try:
                    schat = int(s["owner_chat_id"]) if s["owner_chat_id"] else None
                except Exception:
                    schat = None
                if schat:
                    conn.execute(
                        "UPDATE alerts SET status='SEEN', updated_at=? WHERE status='PENDING' AND alert_type='PAYMENT' AND related_table='students' AND related_id=? AND chat_id=?",
                        (iso(now(tz)), student_id, schat),
                    )
                    conn.commit()
        elif r["req_type"] == "ENROLLMENT_PAYMENT":
            amount = int(p.get("amount") or 0)
            pay_date_raw = str(p.get("pay_date") or "").strip()
            if len(pay_date_raw) == 10 and pay_date_raw[2] == "." and pay_date_raw[5] == ".":
                pay_date = pay_date_raw
            else:
                pay_date = format_date_ddmmyyyy(now(tz).date())

            verification = p.get("verification") if isinstance(p.get("verification"), dict) else {}
            note = "enrollment_proof" if verification.get("ok", True) else "enrollment_proof:review"
            if s and amount > 0:
                repo_payments.add_payment(
                    conn,
                    int(s["id"]),
                    "prepay",
                    amount,
                    pay_date,
                    tz,
                    source="student",
                    proof_file_id=p.get("proof_file_id"),
                    note=note,
                )

            contract = repo_enrollment_contracts.get_by_owner(conn, owner_tg_id)
            if contract:
                repo_enrollment_contracts.set_status(
                    conn,
                    tz,
                    owner_tg_id,
                    status="paid",
                    note=f"payment_req:{req_id}",
                )
        elif r["req_type"] == "INTERVIEW_HELPER_PAYMENT":
            lic, err = _issue_interview_helper_license(
                owner_tg_id=owner_tg_id,
                owner_chat_id=p.get("owner_chat_id"),
                owner_username=p.get("owner_username"),
                note_suffix=f"manual_payment_req:{req_id}",
            )
            if not lic:
                return False, f"Не удалось выпустить ключ: {err or 'неизвестная ошибка'}"
            notify_text = (
                "<b>Оплата подтверждена ментором ✅</b>\n"
                "Твой ключ Interview helper:\n"
                f"<code>{html.escape(str(lic['license_key'] or '—'))}</code>\n"
                f"Действует до: <b>{html.escape(str(lic['expires_at'] or '—'))}</b>"
            )

        repo_requests.set_status(conn, tz, req_id, "APPROVED")
        if r["req_type"] == "PROFILE":
            repo_analytics.set_role(conn, tz, owner_tg_id, repo_analytics.ROLE_STUDENT)
            repo_analytics.log_event(
                conn,
                tz,
                owner_tg_id,
                "funnel.student.profile_approved",
                {"req_id": req_id, "lead_source": str(lead_source or "").strip()},
            )
        _notify_student(owner_tg_id, p, notify_text)
        if actor_message_id is not None:
            _freeze_request_actions(actor_chat_id, actor_message_id, req_id)
        return True, "Одобрено"

    @bot.callback_query_handler(func=lambda c: c.data.startswith("req:ok:"))
    def cb_ok(c: CallbackQuery):
        if not _admin_only(c):
            return
        req_id = int(c.data.split(":")[2])
        r = repo_requests.get(conn, req_id)
        if not r:
            _freeze_request_actions(c.message.chat.id, c.message.message_id, req_id)
            bot.answer_callback_query(c.id, "Не найдено")
            return
        if r["status"] != "PENDING":
            _freeze_request_actions(c.message.chat.id, c.message.message_id, req_id)
            bot.answer_callback_query(c.id, "Неактуально")
            return
        if r["req_type"] == "PROFILE":
            bot.send_message(
                c.message.chat.id,
                "Выбери источник лида для этой карточки:",
                reply_markup=request_lead_source_kb(req_id),
            )
            bot.answer_callback_query(c.id, "Выбери источник")
            return

        ok, msg = _approve_request(req_id, c.message.chat.id, c.message.message_id, lead_source=None)
        bot.answer_callback_query(c.id, msg if not ok else "Одобрено")

    @bot.callback_query_handler(func=lambda c: c.data.startswith("req:src:"))
    def cb_profile_lead_source(c: CallbackQuery):
        if not _admin_only(c):
            return
        parts = c.data.split(":", 3)
        if len(parts) < 4 or not str(parts[2]).isdigit():
            bot.answer_callback_query(c.id, "Некорректные данные")
            return
        req_id = int(parts[2])
        source_code = str(parts[3] or "").strip().lower()

        if source_code == "custom":
            repo_states.set_state(
                conn,
                c.from_user.id,
                "REQ_PROFILE_LEAD_SOURCE_CUSTOM",
                {
                    "req_id": req_id,
                    "source_chat_id": int(c.message.chat.id),
                    "source_message_id": int(c.message.message_id),
                },
                tz,
            )
            bot.send_message(c.message.chat.id, "Введи источник лида текстом:")
            bot.answer_callback_query(c.id, "Жду текст")
            return

        if source_code not in LEAD_SOURCE_LABELS:
            bot.answer_callback_query(c.id, "Неизвестный источник")
            return

        repo_states.clear_state(conn, c.from_user.id, tz)
        ok, msg = _approve_request(req_id, c.message.chat.id, c.message.message_id, lead_source=source_code)
        bot.answer_callback_query(c.id, msg if not ok else "Одобрено")

    @bot.message_handler(
        func=lambda m: repo_states.get_state(conn, m.from_user.id)[0] == "REQ_PROFILE_LEAD_SOURCE_CUSTOM",
        content_types=["text"],
    )
    def st_profile_lead_source_custom(m):
        if not is_admin(m.from_user.id):
            return
        st, data = repo_states.get_state(conn, m.from_user.id)
        if st != "REQ_PROFILE_LEAD_SOURCE_CUSTOM":
            return

        txt = str(m.text or "").strip()
        if txt.lower() in {"отмена", "/cancel", "cancel"}:
            repo_states.clear_state(conn, m.from_user.id, tz)
            bot.send_message(m.chat.id, "Отменено.")
            return
        if len(txt) < 2:
            bot.reply_to(m, "Источник слишком короткий. Введи ещё раз или напиши «отмена».")
            return

        req_id = int(data.get("req_id") or 0)
        source_chat_id = int(data.get("source_chat_id") or m.chat.id)
        source_message_id = int(data.get("source_message_id") or 0) or None
        repo_states.clear_state(conn, m.from_user.id, tz)
        ok, msg = _approve_request(req_id, source_chat_id, source_message_id, lead_source=txt)
        if ok:
            bot.send_message(m.chat.id, "Источник сохранён. Заявка одобрена ✅")
        else:
            bot.send_message(m.chat.id, msg)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("req:ask_no:"))
    def cb_ask_no(c: CallbackQuery):
        if not _admin_only(c):
            return
        req_id = int(c.data.split(":")[2])
        r = repo_requests.get(conn, req_id)
        if not r or r["status"] != "PENDING":
            _freeze_request_actions(c.message.chat.id, c.message.message_id, req_id)
            bot.answer_callback_query(c.id, "Неактуально")
            return
        bot.send_message(
            c.message.chat.id,
            "Точно отклонить заявку?",
            reply_markup=request_reject_confirm_kb(req_id, source_message_id=c.message.message_id),
        )
        bot.answer_callback_query(c.id)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("req:no:"))
    def cb_no(c: CallbackQuery):
        if not _admin_only(c):
            return
        parts = c.data.split(":")
        req_id = int(parts[2])
        source_message_id = None
        if len(parts) > 3 and str(parts[3]).isdigit():
            source_message_id = int(parts[3])
        r = repo_requests.get(conn, req_id)
        if not r or r["status"] != "PENDING":
            _freeze_request_actions(c.message.chat.id, c.message.message_id, req_id)
            if source_message_id:
                _freeze_request_actions(c.message.chat.id, source_message_id, req_id)
            bot.answer_callback_query(c.id, "Неактуально")
            return
        p = repo_requests.payload(r)
        repo_requests.set_status(conn, tz, req_id, "REJECTED")
        if r["req_type"] == "PROFILE":
            repo_analytics.log_event(conn, tz, int(r["owner_tg_id"]), "funnel.student.profile_rejected", {"req_id": req_id})
        _notify_student(int(r["owner_tg_id"]), p, "Заявка отклонена ментором ❌\nИсправь и отправь заново через кнопку «Моя анкета».")
        _freeze_request_actions(c.message.chat.id, c.message.message_id, req_id)
        if source_message_id:
            _freeze_request_actions(c.message.chat.id, source_message_id, req_id)
        bot.answer_callback_query(c.id, "Отклонено")
