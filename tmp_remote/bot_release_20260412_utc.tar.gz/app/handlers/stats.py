from __future__ import annotations

import sqlite3
from collections import defaultdict
from datetime import datetime, timedelta

from aiogram.types import BufferedInputFile
from telebot import TeleBot
from telebot.apihelper import ApiTelegramException
from telebot.types import CallbackQuery
from telebot.types import InlineKeyboardButton, InlineKeyboardMarkup

from app.db import repo_admins
from app.db import repo_analytics, repo_autoapply_runs, repo_broadcasts, repo_events
from app.handlers.common import admin_has, is_admin
from app.services.timeutils import iso, now, parse_date_ddmmyyyy
from app.ui.formatters import esc
from app.ui.keyboards import stats_menu_kb


def _lead_source_key(raw: str | None) -> str:
    value_raw = str(raw or "").strip()
    value = value_raw.lower()
    if value in {"channel", "канал"}:
        return "channel"
    if value in {"cold", "холодные"}:
        return "cold"
    if value in {"referral", "сарафанка", "сарафарнка"}:
        return "referral"
    if value in {"om", "ом"}:
        return "om"
    if value in {"", "unknown", "none", "null"}:
        return "unknown"
    return value_raw


def _lead_source_label(raw: str | None) -> str:
    value = str(raw or "").strip().lower()
    if value == "channel":
        return "Канал"
    if value == "cold":
        return "Холодные"
    if value == "referral":
        return "Сарафанка"
    if value == "om":
        return "Ом"
    if value in {"", "unknown", "none", "null"}:
        return "Не указан"
    return str(raw or "").strip() or "Не указан"


def _lead_sources_stats(conn: sqlite3.Connection) -> list[dict]:
    rows = conn.execute(
        "SELECT lead_source, archived FROM students"
    ).fetchall()
    buckets: dict[str, dict] = {}
    for r in rows:
        key = _lead_source_key(r["lead_source"] if "lead_source" in r.keys() else None)
        item = buckets.setdefault(
            key,
            {
                "source": key,
                "source_label": _lead_source_label(key),
                "total": 0,
                "active": 0,
            },
        )
        item["total"] += 1
        if int(r["archived"] or 0) == 0:
            item["active"] += 1

    out: list[dict] = []
    for item in buckets.values():
        out.append(item)
    out.sort(key=lambda x: (-int(x["total"]), str(x["source"]).lower()))
    return out


def _payments_breakdown(conn: sqlite3.Connection, tz: str) -> dict:
    today_local = now(tz).date()
    mentor_from = today_local - timedelta(days=1)
    month_start = today_local.replace(day=1)

    by_source_map: dict[str, dict] = {}
    prepay_total_student = 0
    postpay_total_student = 0
    month_total_student = 0

    rows = conn.execute(
        "SELECT p.student_id, p.amount, p.pay_type, p.source, p.pay_date, p.created_at, "
        "s.fio, s.owner_username, s.owner_tg_id, s.archived "
        "FROM payments p "
        "LEFT JOIN students s ON s.id=p.student_id "
        "ORDER BY p.id DESC"
    ).fetchall()
    by_student: dict[int, dict] = {}
    by_owner: dict[int, set[int]] = {}
    for r in rows:
        src = str(r["source"] or "").strip().lower()
        if src == "student":
            source_label = "Ученик"
        elif src == "mentor":
            created_at = str(r["created_at"] or "").strip()
            try:
                d_created = datetime.fromisoformat(created_at.replace("Z", "+00:00")).date() if created_at else None
            except Exception:
                d_created = None
            if not d_created or d_created < mentor_from:
                continue
            source_label = "Ментор"
        else:
            # всё остальное полностью игнорируем
            continue

        sid = int(r["student_id"] or 0)
        if sid <= 0:
            continue
        item = by_student.setdefault(
            sid,
            {
                "student_id": sid,
                "fio": str(r["fio"] or "").strip() or "Без ФИО",
                "owner_username": str(r["owner_username"] or "").strip(),
                "owner_tg_id": int(r["owner_tg_id"] or 0),
                "archived": int(r["archived"] or 0),
                "payments_count": 0,
                "prepay_sum": 0,
                "postpay_sum": 0,
                "total_sum": 0,
                "last_payment_date": "",
            },
        )
        amount = int(r["amount"] or 0)
        pay_type = str(r["pay_type"] or "").strip()
        if pay_type == "postpay":
            postpay_total_student += amount
        else:
            prepay_total_student += amount

        created_at = str(r["created_at"] or "").strip()
        try:
            d_change = datetime.fromisoformat(created_at.replace("Z", "+00:00")).date() if created_at else None
        except Exception:
            d_change = None
        if not d_change:
            d_change = parse_date_ddmmyyyy(r["pay_date"])
        if d_change and month_start <= d_change <= today_local:
            month_total_student += amount

        src_item = by_source_map.setdefault(
            src,
            {"source": src, "source_label": source_label, "count": 0, "sum": 0},
        )
        src_item["count"] += 1
        src_item["sum"] += amount

        item["payments_count"] += 1
        item["total_sum"] += amount
        if pay_type == "postpay":
            item["postpay_sum"] += amount
        else:
            item["prepay_sum"] += amount
        pay_date = str(r["pay_date"] or "").strip()
        if pay_date and (not item["last_payment_date"] or pay_date > item["last_payment_date"]):
            item["last_payment_date"] = pay_date
        owner_tg_id = int(r["owner_tg_id"] or 0)
        if owner_tg_id > 0:
            by_owner.setdefault(owner_tg_id, set()).add(sid)

    by_student_rows = sorted(by_student.values(), key=lambda x: (-int(x["total_sum"]), int(x["student_id"])))
    multi_cards = []
    for owner_id, sids in by_owner.items():
        if len(sids) <= 1:
            continue
        # pick latest card's meta for readability
        cards = [by_student[sid] for sid in sids if sid in by_student]
        cards.sort(key=lambda x: int(x["student_id"]), reverse=True)
        top = cards[0] if cards else None
        if not top:
            continue
        total = sum(int(c["total_sum"]) for c in cards)
        multi_cards.append(
            {
                "owner_tg_id": owner_id,
                "fio": top["fio"],
                "owner_username": top["owner_username"],
                "cards_count": len(cards),
                "total_sum": total,
            }
        )
    multi_cards.sort(key=lambda x: (-int(x["total_sum"]), int(x["owner_tg_id"])))
    by_source = sorted(by_source_map.values(), key=lambda x: (-int(x["sum"]), x["source"]))

    return {
        "prepay_total_student": int(prepay_total_student),
        "postpay_total_student": int(postpay_total_student),
        "month_total_student": int(month_total_student),
        "by_source": by_source,
        "by_student": by_student_rows,
        "multi_cards_by_owner": multi_cards,
    }


def _role_label(role: str) -> str:
    r = (role or "").strip().lower()
    if r == "admin":
        return "админ"
    if r == "student":
        return "ученик"
    return "обычный"


def _autoapply_overview_text(conn: sqlite3.Connection) -> str:
    s = repo_autoapply_runs.summary(conn)
    if s["total"] <= 0:
        return "Автоотклики: <b>данных пока нет</b>"
    return (
        "Автоотклики: "
        f"запусков <b>{s['total']}</b>, "
        f"успешно <b>{s['launched']}</b>, "
        f"ошибок <b>{s['failed']}</b>, "
        f"уникальных пользователей <b>{s['owners']}</b>"
    )


def _calls_overview_text(conn: sqlite3.Connection, tz: str) -> str:
    s = repo_events.calls_summary(conn, from_iso=iso(now(tz)))
    if s["calls_total"] <= 0:
        return "Созвоны: <b>данных пока нет</b>"
    return (
        "Созвоны: "
        f"всего <b>{s['calls_total']}</b>, "
        f"активных <b>{s['calls_active']}</b>, "
        f"будущих <b>{s['calls_upcoming']}</b>\n"
        f"Из них диагностических: <b>{s['diagnostic_calls_total']}</b> "
        f"(будущих: <b>{s['diagnostic_calls_upcoming']}</b>, "
        f"уникальных пользователей: <b>{s['diagnostic_unique_users']}</b>)"
    )


def _overview_text(conn: sqlite3.Connection, tz: str) -> str:
    totals = repo_analytics.user_totals(conn)
    act = repo_analytics.dau_wau_mau(conn, tz)
    ret = repo_analytics.retention(conn)
    new_day = repo_analytics.new_users(conn, tz, 1)
    new_week = repo_analytics.new_users(conn, tz, 7)
    new_month = repo_analytics.new_users(conn, tz, 30)
    auto = repo_broadcasts.auto_read_totals(conn)
    return (
        "<b>Статистика: Обзор</b>\n\n"
        f"Пользователей всего: <b>{totals['all']}</b>\n"
        f"Новых за день/неделю/30д: <b>{new_day}</b> / <b>{new_week}</b> / <b>{new_month}</b>\n\n"
        f"Активные за 1/7/30 дней: <b>{act['dau']}</b> / <b>{act['wau']}</b> / <b>{act['mau']}</b>\n"
        f"Коэффициент активности (1д к 30д): <b>{act['stickiness']}%</b>\n\n"
        f"Удержание на 1/7/30 день: <b>{ret['d1']}%</b> / <b>{ret['d7']}%</b> / <b>{ret['d30']}%</b>\n"
        f"Размер когорты: <b>{ret['cohort']}</b>\n\n"
        f"Автосообщения: <b>{auto['total_read']}/{auto['total_sent']}</b> прочитано\n"
        f"Не нажали «Прочитано»: <b>{auto['total_unread']}</b>\n\n"
        f"{_autoapply_overview_text(conn)}\n"
        f"{_calls_overview_text(conn, tz)}"
    )


def _users_text(conn: sqlite3.Connection, tz: str) -> str:
    totals = repo_analytics.user_totals(conn)
    rows = conn.execute(
        "SELECT "
        "up.user_id, "
        "COALESCE(up.username, ("
        "  SELECT s.owner_username FROM students s "
        "  WHERE s.owner_tg_id=up.user_id "
        "  ORDER BY s.id DESC LIMIT 1"
        ")) AS username, "
        "up.role_type, up.first_seen_at, up.last_seen_at, up.last_start_at "
        "FROM user_profiles up "
        "ORDER BY up.last_seen_at DESC LIMIT 10"
    ).fetchall()
    lines = [
        "<b>Статистика: Пользователи</b>",
        "",
        f"Всего: <b>{totals['all']}</b>",
        f"Роли (админы/ученики/обычные): <b>{totals['admin']}</b> / <b>{totals['student']}</b> / <b>{totals['regular']}</b>",
        "",
        "Последние 10 активных:",
    ]
    for r in rows:
        uid = int(r["user_id"])
        role = _role_label(r["role_type"] or "regular")
        username = (r["username"] or "").strip()
        uname = f"@{username}" if username else "—"
        ls = r["last_seen_at"] or "—"
        fs = r["first_seen_at"] or "—"
        st = r["last_start_at"] or "—"
        auto = repo_broadcasts.user_auto_read_totals(conn, uid)
        autoapply = repo_autoapply_runs.summary_by_owner(conn, uid)
        calls = repo_events.owner_calls_summary(conn, uid, from_iso=iso(now(tz)))
        lines.append(f"• {uid} [{role}] {uname}")
        lines.append(f"  первый вход: {fs}")
        lines.append(f"  последний вход: {ls}")
        lines.append(f"  последний /start: {st}")
        lines.append(f"  автосообщения: {auto['total_read']}/{auto['total_sent']} прочитано")
        lines.append(
            f"  автоотклики: всего {autoapply['total']}, "
            f"успешно {autoapply['launched']}, ошибок {autoapply['failed']}"
        )
        lines.append(
            f"  созвоны: активных {calls['active']} "
            f"(диагностических {calls['diagnostic_calls']})"
        )

    lines.append("")
    lines.append("Автосообщения: кто прочитал, кто не нажал:")
    auto_rows = repo_broadcasts.auto_read_users(conn, limit=20)
    if not auto_rows:
        lines.append("• пока нет доставленных автосообщений")
    for r in auto_rows:
        uid = int(r["user_id"] or 0)
        username = (r["username"] or "").strip()
        uname = f"@{username}" if username else "—"
        total_sent = int(r["total_sent"] or 0)
        total_read = int(r["total_read"] or 0)
        unread = max(0, total_sent - total_read)
        lines.append(f"• {uid} {uname}: прочитано {total_read}/{total_sent}, не нажали {unread}")
    lines.append("")
    lines.append("Автоотклики по направлениям:")
    directions = repo_autoapply_runs.direction_stats(conn, limit=8)
    if not directions:
        lines.append("• данных пока нет")
    else:
        for d in directions:
            lines.append(
                f"• {d['direction']}: всего {d['total']}, успешно {d['launched']}, ошибок {d['failed']}"
            )
    return "\n".join(lines)


def _interaction_summary_by_user(conn: sqlite3.Connection, days: int = 30) -> dict[int, dict]:
    cutoff_row = conn.execute(
        "SELECT datetime('now', ?) AS c",
        (f"-{max(1, int(days))} day",),
    ).fetchone()
    cutoff = str(cutoff_row["c"] or "")
    rows = conn.execute(
        "SELECT user_id, event_name, COUNT(1) AS c, MAX(created_at) AS last_at "
        "FROM event_log "
        "WHERE created_at >= ? "
        "GROUP BY user_id, event_name",
        (cutoff,),
    ).fetchall()
    by_user: dict[int, dict] = {}
    for r in rows:
        uid = int(r["user_id"] or 0)
        if uid <= 0:
            continue
        payload = by_user.setdefault(
            uid,
            {
                "total": 0,
                "last_at": "",
                "events": defaultdict(int),
            },
        )
        event_name = str(r["event_name"] or "").strip()
        cnt = int(r["c"] or 0)
        payload["total"] += cnt
        payload["events"][event_name] += cnt
        last_at = str(r["last_at"] or "")
        if last_at and last_at > str(payload["last_at"] or ""):
            payload["last_at"] = last_at
    return by_user


def _users_list_txt(conn: sqlite3.Connection, days: int = 30) -> str:
    users = conn.execute(
        "SELECT "
        "up.user_id, "
        "COALESCE(up.username, ("
        "  SELECT s.owner_username FROM students s "
        "  WHERE s.owner_tg_id=up.user_id "
        "  ORDER BY s.id DESC LIMIT 1"
        ")) AS username, "
        "up.role_type, up.first_seen_at, up.last_seen_at, up.last_start_at "
        "FROM user_profiles up "
        "ORDER BY up.last_seen_at DESC, up.user_id DESC"
    ).fetchall()
    summary = _interaction_summary_by_user(conn, days=days)
    lines: list[str] = [f"Сводка взаимодействий пользователей за {days} дней", ""]
    for r in users:
        uid = int(r["user_id"] or 0)
        username = str(r["username"] or "").strip()
        uname = f"@{username}" if username else "—"
        role = _role_label(str(r["role_type"] or "regular"))
        first_seen = str(r["first_seen_at"] or "")
        last_seen = str(r["last_seen_at"] or "")
        last_start = str(r["last_start_at"] or "")
        info = summary.get(uid) or {"total": 0, "last_at": "", "events": {}}
        total = int(info.get("total") or 0)
        last_at = str(info.get("last_at") or "")
        events = info.get("events") or {}
        top = sorted(events.items(), key=lambda kv: (-int(kv[1]), kv[0]))[:6]
        top_text = ", ".join(f"{k}:{v}" for k, v in top) if top else "нет событий"
        lines.append(
            f"{uid} | {uname} | {role} | first={first_seen or '—'} | last={last_seen or '—'} | "
            f"/start={last_start or '—'} | interactions={total} | last_interaction={last_at or '—'}"
        )
        lines.append(f"  top: {top_text}")
    return "\n".join(lines)


def _users_list_html(conn: sqlite3.Connection, days: int = 30) -> str:
    users = conn.execute(
        "SELECT "
        "up.user_id, "
        "COALESCE(up.username, ("
        "  SELECT s.owner_username FROM students s "
        "  WHERE s.owner_tg_id=up.user_id "
        "  ORDER BY s.id DESC LIMIT 1"
        ")) AS username, "
        "up.role_type, up.first_seen_at, up.last_seen_at, up.last_start_at "
        "FROM user_profiles up "
        "ORDER BY up.last_seen_at DESC, up.user_id DESC"
    ).fetchall()
    summary = _interaction_summary_by_user(conn, days=days)
    parts = [
        "<html><head><meta charset='utf-8'>",
        "<style>body{font-family:Arial,sans-serif;padding:16px}table{border-collapse:collapse;width:100%}",
        "th,td{border:1px solid #ddd;padding:8px;vertical-align:top}th{background:#f3f3f3;text-align:left}</style>",
        "</head><body>",
        f"<h2>Сводка взаимодействий пользователей за {days} дней</h2>",
        "<table><thead><tr>"
        "<th>User ID</th><th>Username</th><th>Роль</th><th>Первый вход</th><th>Последний вход</th>"
        "<th>Последний /start</th><th>Взаимодействий</th><th>Последнее взаимодействие</th><th>Топ событий</th>"
        "</tr></thead><tbody>",
    ]
    for r in users:
        uid = int(r["user_id"] or 0)
        username = str(r["username"] or "").strip()
        uname = f"@{username}" if username else "—"
        role = _role_label(str(r["role_type"] or "regular"))
        first_seen = str(r["first_seen_at"] or "—")
        last_seen = str(r["last_seen_at"] or "—")
        last_start = str(r["last_start_at"] or "—")
        info = summary.get(uid) or {"total": 0, "last_at": "", "events": {}}
        total = int(info.get("total") or 0)
        last_at = str(info.get("last_at") or "—")
        events = info.get("events") or {}
        top = sorted(events.items(), key=lambda kv: (-int(kv[1]), kv[0]))[:6]
        top_html = "<br>".join(f"{esc(str(k))}: {int(v)}" for k, v in top) if top else "нет событий"
        parts.append(
            "<tr>"
            f"<td>{uid}</td>"
            f"<td>{esc(uname)}</td>"
            f"<td>{esc(role)}</td>"
            f"<td>{esc(first_seen)}</td>"
            f"<td>{esc(last_seen)}</td>"
            f"<td>{esc(last_start)}</td>"
            f"<td>{total}</td>"
            f"<td>{esc(last_at)}</td>"
            f"<td>{top_html}</td>"
            "</tr>"
        )
    parts.append("</tbody></table></body></html>")
    return "".join(parts)


def _event_log_rows(conn: sqlite3.Connection, limit: int = 50000) -> list[sqlite3.Row]:
    cap = max(100, int(limit or 0))
    return conn.execute(
        "SELECT "
        "e.id, e.created_at, e.user_id, e.event_name, COALESCE(e.payload_json, '') AS payload_json, "
        "COALESCE(up.username, ("
        "  SELECT s.owner_username FROM students s "
        "  WHERE s.owner_tg_id=e.user_id "
        "  ORDER BY s.id DESC LIMIT 1"
        ")) AS username, "
        "COALESCE(up.role_type, '') AS role_type "
        "FROM event_log e "
        "LEFT JOIN user_profiles up ON up.user_id=e.user_id "
        "ORDER BY e.id DESC LIMIT ?",
        (cap,),
    ).fetchall()


def _event_log_txt(conn: sqlite3.Connection, limit: int = 50000) -> str:
    rows = _event_log_rows(conn, limit=limit)
    lines = ["Лог действий пользователей (event_log)", ""]
    for r in rows:
        uid = int(r["user_id"] or 0)
        username = str(r["username"] or "").strip()
        uname = f"@{username}" if username else "—"
        role = _role_label(str(r["role_type"] or "regular"))
        lines.append(
            f"{int(r['id'])} | {r['created_at'] or ''} | uid={uid} {uname} [{role}] | "
            f"{r['event_name'] or ''} | payload={str(r['payload_json'] or '')}"
        )
    return "\n".join(lines)


def _event_log_html(conn: sqlite3.Connection, limit: int = 50000) -> str:
    rows = _event_log_rows(conn, limit=limit)
    parts = [
        "<html><head><meta charset='utf-8'>",
        "<style>body{font-family:Arial,sans-serif;padding:16px}table{border-collapse:collapse;width:100%}",
        "th,td{border:1px solid #ddd;padding:8px;vertical-align:top}th{background:#f3f3f3;text-align:left}</style>",
        "</head><body>",
        "<h2>Лог действий пользователей (event_log)</h2>",
        "<table><thead><tr>"
        "<th>ID</th><th>Время</th><th>User ID</th><th>Username</th><th>Роль</th><th>Событие</th><th>Payload</th>"
        "</tr></thead><tbody>",
    ]
    for r in rows:
        username = str(r["username"] or "").strip()
        uname = f"@{username}" if username else "—"
        role = _role_label(str(r["role_type"] or "regular"))
        parts.append(
            "<tr>"
            f"<td>{int(r['id'])}</td>"
            f"<td>{esc(str(r['created_at'] or ''))}</td>"
            f"<td>{int(r['user_id'] or 0)}</td>"
            f"<td>{esc(uname)}</td>"
            f"<td>{esc(role)}</td>"
            f"<td>{esc(str(r['event_name'] or ''))}</td>"
            f"<td><pre style='white-space:pre-wrap'>{esc(str(r['payload_json'] or ''))}</pre></td>"
            "</tr>"
        )
    parts.append("</tbody></table></body></html>")
    return "".join(parts)


def _materials_text(conn: sqlite3.Connection) -> str:
    funnel = repo_analytics.funnel_distinct_users(
        conn,
        [
            "funnel.materials.open",
            "funnel.materials.subscription_ok",
            "funnel.materials.direction_selected",
            "funnel.materials.step_open",
            "funnel.materials.step_done",
        ],
    )
    rows = repo_analytics.direction_progress(conn)
    drop = repo_analytics.material_step_dropoff(conn)[:8]
    lines = [
        "<b>Статистика: Материалы</b>",
        "",
        "Воронка (уникальные пользователи):",
        f"• открыли раздел: {funnel['funnel.materials.open']}",
        f"• прошли проверку подписки: {funnel['funnel.materials.subscription_ok']}",
        f"• выбрали направление: {funnel['funnel.materials.direction_selected']}",
        f"• открыли шаг: {funnel['funnel.materials.step_open']}",
        f"• отметили шаг как пройденный: {funnel['funnel.materials.step_done']}",
        "",
        "Прогресс по направлениям:",
    ]
    for r in rows:
        lines.append(
            f"• {r['direction']}: начали={r['started']}, в процессе={r['in_progress']}, "
            f"завершили={r['completed']}, средний прогресс={r['avg_percent']}%"
        )
    lines.append("")
    lines.append("Шаги с наибольшим оттоком:")
    if not drop:
        lines.append("• данных пока нет")
    else:
        for d in drop:
            lines.append(
                f"• {d['direction']} #{d['position']} ({esc(d['title'])}): открытий={d['opens']}, "
                f"падение={d['drop_abs']} ({d['drop_pct']}%)"
            )
    return "\n".join(lines)


def _student_funnel_text(conn: sqlite3.Connection) -> str:
    funnel = repo_analytics.funnel_distinct_users(
        conn,
        [
            "funnel.student.entry_click",
            "funnel.student.code_valid",
            "funnel.student.profile_submitted",
            "funnel.student.profile_approved",
            "funnel.student.code_invalid",
        ],
    )
    lines = [
        "<b>Статистика: Я ученик (воронка)</b>",
        "",
        f"Нажали «Я ученик»: <b>{funnel['funnel.student.entry_click']}</b>",
        f"Код валиден: <b>{funnel['funnel.student.code_valid']}</b>",
        f"Анкета отправлена: <b>{funnel['funnel.student.profile_submitted']}</b>",
        f"Анкета одобрена: <b>{funnel['funnel.student.profile_approved']}</b>",
        f"Невалидный код (попытки): <b>{funnel['funnel.student.code_invalid']}</b>",
    ]
    lead_sources = _lead_sources_stats(conn)
    lines.extend(["", "<b>Источники лидов (по карточкам учеников)</b>:"])
    if not lead_sources:
        lines.append("• данных пока нет")
    else:
        for row in lead_sources:
            lines.append(
                f"• {row['source_label']}: <b>{row['total']}</b> "
                f"(активных: {row['active']})"
            )
    return "\n".join(lines)


def _payments_text(conn: sqlite3.Connection, tz: str) -> str:
    p = _payments_breakdown(conn, tz)
    students_active = conn.execute("SELECT COUNT(1) AS c FROM students WHERE archived=0").fetchone()
    lines = [
        "<b>Статистика: Платежи</b>",
        "",
        f"Предоплата (реально пополнили): <b>{p['prepay_total_student']} ₽</b>",
        f"Постоплата (реально пополнили): <b>{p['postpay_total_student']} ₽</b>",
        f"Изменения за текущий месяц: <b>{p['month_total_student']} ₽</b>",
        f"Активных учеников: <b>{int(students_active['c'] or 0) if students_active else 0}</b>",
        "",
        "<b>Разбивка по источнику</b>:",
    ]
    by_source = p.get("by_source") or []
    if not by_source:
        lines.append("• данных нет")
    else:
        for row in by_source:
            lines.append(f"• {row['source_label']}: <b>{row['sum']} ₽</b> (операций: {row['count']})")

    lines.extend(["", "<b>Кто и сколько пополнил (топ-15)</b>:"])
    by_student = p.get("by_student") or []
    if not by_student:
        lines.append("• платежей пока нет")
    else:
        for row in by_student[:15]:
            uname = f"@{row['owner_username']}" if row.get("owner_username") else "—"
            archived_mark = " [архив]" if int(row.get("archived") or 0) == 1 else ""
            lines.append(
                f"• {esc(str(row['fio']))}{archived_mark} (id:{row['student_id']}, {esc(uname)}): "
                f"<b>{row['total_sum']} ₽</b> "
                f"(pre: {row['prepay_sum']} / post: {row['postpay_sum']}, платежей: {row['payments_count']})"
            )

    multi_cards = p.get("multi_cards_by_owner") or []
    if multi_cards:
        lines.extend(["", "<b>Проверка на дубли карточек</b>:"])
        for row in multi_cards[:8]:
            uname = f"@{row['owner_username']}" if row.get("owner_username") else "—"
            lines.append(
                f"• {esc(str(row['fio']))} ({esc(uname)}, user_id={row['owner_tg_id']}): "
                f"карточек {row['cards_count']}, суммарно {row['total_sum']} ₽"
            )

    lines.append("")
    lines.append("Полная детализация — в экспорте статистики (TXT/HTML).")
    out = "\n".join(lines)
    # Телеграм лимит 4096 символов
    if len(out) > 3900:
        out = out[:3900] + "\n…"
    return out


def _ops_text(conn: sqlite3.Connection) -> str:
    m = repo_analytics.operational_metrics(conn)
    return (
        "<b>Статистика: Операционка</b>\n\n"
        f"Алертов всего: <b>{m['alerts_total']}</b>\n"
        f"Алерты в ожидании/закрыты: <b>{m['alerts_pending']}</b> / <b>{m['alerts_seen']}</b>\n"
        f"Алертов доставлено: <b>{m['alerts_delivered']}</b>\n"
        f"Средняя задержка от срока до обновления: <b>{m['avg_alert_delay_min']} мин</b>\n"
        f"Ошибки планировщика: <b>{m['scheduler_errors']}</b>\n"
        f"Ошибки отправки алертов: <b>{m['alert_send_errors']}</b>"
    )


def _inactive_students(conn: sqlite3.Connection) -> list[dict]:
    rows = conn.execute(
        "SELECT s.id AS student_id, s.fio, s.direction_id, s.owner_tg_id, s.owner_username, "
        "d.name AS direction_name, "
        "COALESCE(up.last_start_at, '') AS last_start_at, "
        "(SELECT COUNT(1) FROM event_log e WHERE e.user_id=s.owner_tg_id) AS events_total "
        "FROM students s "
        "LEFT JOIN directions d ON d.id=s.direction_id "
        "LEFT JOIN user_profiles up ON up.user_id=s.owner_tg_id "
        "WHERE s.archived=0 AND s.owner_tg_id IS NOT NULL AND s.owner_tg_id > 0 "
        "ORDER BY s.id DESC"
    ).fetchall()
    by_owner: dict[int, dict] = {}
    for r in rows:
        owner_id = int(r["owner_tg_id"] or 0)
        if owner_id <= 0 or owner_id in by_owner:
            continue
        by_owner[owner_id] = {
            "owner_tg_id": owner_id,
            "owner_username": str(r["owner_username"] or "").strip(),
            "student_id": int(r["student_id"] or 0),
            "fio": str(r["fio"] or "").strip(),
            "direction_name": str(r["direction_name"] or "").strip(),
            "last_start_at": str(r["last_start_at"] or "").strip(),
            "events_total": int(r["events_total"] or 0),
        }
    out: list[dict] = []
    for item in by_owner.values():
        if item["last_start_at"]:
            continue
        if item["events_total"] > 0:
            continue
        out.append(item)
    out.sort(key=lambda x: (x["direction_name"], x["fio"], x["owner_tg_id"]))
    return out


def _inactive_students_text(conn: sqlite3.Connection) -> str:
    rows = _inactive_students(conn)
    lines = [
        "<b>Неактивные ученики</b>",
        "Критерий: ни одного /start и ни одного взаимодействия в логе.",
        "",
    ]
    if not rows:
        lines.append("✅ Таких учеников сейчас нет.")
        return "\n".join(lines)
    lines.append(f"Найдено: <b>{len(rows)}</b>")
    for r in rows:
        uname = f"@{r['owner_username']}" if r["owner_username"] else "—"
        lines.append(
            f"• {esc(r['fio'])} [{esc(r['direction_name'] or '—')}] | "
            f"user_id=<code>{r['owner_tg_id']}</code> | username={esc(uname)}"
        )
    lines.append("")
    lines.append("Можно нажать «Пинг неактивных», чтобы отправить им приглашение в бот.")
    return "\n".join(lines)


def _report_dict(conn: sqlite3.Connection, tz: str, include_payments: bool = True) -> dict:
    auto_totals = repo_broadcasts.auto_read_totals(conn)
    report = {
        "generated_at": now(tz).isoformat(),
        "users": {
            "totals": repo_analytics.user_totals(conn),
            "new_users": {
                "day": repo_analytics.new_users(conn, tz, 1),
                "week": repo_analytics.new_users(conn, tz, 7),
                "month": repo_analytics.new_users(conn, tz, 30),
            },
            "activity": repo_analytics.dau_wau_mau(conn, tz),
            "retention": repo_analytics.retention(conn),
        },
        "auto_messages": {
            "totals": auto_totals,
            "users": [
                {
                    "user_id": int(r["user_id"] or 0),
                    "username": (r["username"] or "").strip(),
                    "role_type": (r["role_type"] or "").strip(),
                    "total_sent": int(r["total_sent"] or 0),
                    "total_read": int(r["total_read"] or 0),
                }
                for r in repo_broadcasts.auto_read_users(conn, limit=200)
            ],
        },
        "autoapply": {
            "summary": repo_autoapply_runs.summary(conn),
            "by_direction": repo_autoapply_runs.direction_stats(conn, limit=50),
            "recent_failures": [
                {
                    "id": int(r["id"] or 0),
                    "owner_tg_id": int(r["owner_tg_id"] or 0),
                    "login": str(r["login"] or "").strip(),
                    "direction": str(r["direction"] or "").strip(),
                    "error_text": str(r["error_text"] or "").strip(),
                    "created_at": str(r["created_at"] or "").strip(),
                }
                for r in repo_autoapply_runs.recent_failures(conn, limit=30)
            ],
        },
        "calls": repo_events.calls_summary(conn, from_iso=iso(now(tz))),
        "funnels": {
            "materials": repo_analytics.funnel_distinct_users(
                conn,
                [
                    "funnel.materials.open",
                    "funnel.materials.subscription_ok",
                    "funnel.materials.direction_selected",
                    "funnel.materials.step_open",
                    "funnel.materials.step_done",
                ],
            ),
            "student": repo_analytics.funnel_distinct_users(
                conn,
                [
                    "funnel.student.entry_click",
                    "funnel.student.code_valid",
                    "funnel.student.profile_submitted",
                    "funnel.student.profile_approved",
                    "funnel.student.code_invalid",
                ],
            ),
            "lead_sources": _lead_sources_stats(conn),
        },
        "materials": {
            "direction_progress": repo_analytics.direction_progress(conn),
            "step_dropoff_top": repo_analytics.material_step_dropoff(conn)[:20],
        },
        "operations": repo_analytics.operational_metrics(conn),
        "inactive_students": _inactive_students(conn),
    }
    if include_payments:
        report["payments"] = _payments_breakdown(conn, tz)
    return report


def _report_txt(report: dict) -> str:
    users = report["users"]
    totals = users["totals"]
    lines = [
        "Сводный отчет статистики",
        f"Сформирован: {report.get('generated_at', '')}",
        "",
        "Пользователи:",
        f"- Всего: {totals['all']}",
        f"- Админы: {totals['admin']}",
        f"- Ученики: {totals['student']}",
        f"- Обычные: {totals['regular']}",
        "",
        "Активность:",
        f"- DAU: {users['activity'].get('dau', 0)}",
        f"- WAU: {users['activity'].get('wau', 0)}",
        f"- MAU: {users['activity'].get('mau', 0)}",
        f"- Stickiness: {users['activity'].get('stickiness', 0)}%",
        "",
        "Удержание:",
        f"- D1: {users['retention'].get('d1', 0)}%",
        f"- D7: {users['retention'].get('d7', 0)}%",
        f"- D30: {users['retention'].get('d30', 0)}%",
        "",
        "Автоотклики:",
    ]
    auto_sum = report.get("autoapply", {}).get("summary", {}) or {}
    lines.append(
        f"- Запусков: {auto_sum.get('total', 0)}, успешно: {auto_sum.get('launched', 0)}, ошибок: {auto_sum.get('failed', 0)}"
    )
    lines.append("")
    lines.append("По направлениям автооткликов:")
    for row in report.get("autoapply", {}).get("by_direction", []) or []:
        lines.append(f"- {row['direction']}: всего={row['total']}, успешно={row['launched']}, ошибок={row['failed']}")
    lines.append("")
    lines.append("Созвоны:")
    for k, v in (report.get("calls", {}) or {}).items():
        lines.append(f"- {k}: {v}")
    lead_sources = (
        report.get("funnels", {}).get("lead_sources")
        if isinstance(report.get("funnels", {}), dict)
        else []
    )
    lines.append("")
    lines.append("Источники лидов:")
    if isinstance(lead_sources, list) and lead_sources:
        for row in lead_sources:
            lines.append(
                f"- {row.get('source_label', row.get('source', 'Не указан'))}: "
                f"всего={row.get('total', 0)}, активных={row.get('active', 0)}"
            )
    else:
        lines.append("- данных нет")
    pay = report.get("payments") if isinstance(report.get("payments"), dict) else None
    if pay:
        lines.append("")
        lines.append("Платежи:")
        lines.append(f"- Предоплата (реально пополнили): {pay.get('prepay_total_student', 0)}")
        lines.append(f"- Постоплата (реально пополнили): {pay.get('postpay_total_student', 0)}")
        lines.append(f"- Изменения за текущий месяц: {pay.get('month_total_student', 0)}")
        by_source = pay.get("by_source") if isinstance(pay.get("by_source"), list) else []
        if by_source:
            lines.append("- По источнику:")
            for row in by_source:
                lines.append(f"  - {row.get('source_label', row.get('source', ''))}: {row.get('sum', 0)} (операций: {row.get('count', 0)})")
        by_student = pay.get("by_student") if isinstance(pay.get("by_student"), list) else []
        if by_student:
            lines.append("- Кто и сколько пополнил (топ-30):")
            for row in by_student[:30]:
                uname = ("@" + str(row.get("owner_username") or "").strip()) if str(row.get("owner_username") or "").strip() else "—"
                lines.append(
                    f"  - {row.get('fio', 'Без ФИО')} [id:{row.get('student_id', 0)}, {uname}]: "
                    f"{row.get('total_sum', 0)} (pre:{row.get('prepay_sum', 0)}, post:{row.get('postpay_sum', 0)}, платежей:{row.get('payments_count', 0)})"
                )
    return "\n".join(lines)


def _report_html(report: dict) -> str:
    users = report["users"]
    totals = users["totals"]
    auto_sum = report.get("autoapply", {}).get("summary", {}) or {}
    parts = [
        "<html><head><meta charset='utf-8'>",
        "<style>body{font-family:Arial,sans-serif;padding:16px}table{border-collapse:collapse;width:100%;margin-bottom:18px}",
        "th,td{border:1px solid #ddd;padding:8px;vertical-align:top}th{background:#f3f3f3;text-align:left}</style>",
        "</head><body>",
        "<h2>Сводный отчет статистики</h2>",
        f"<p>Сформирован: {esc(str(report.get('generated_at', '')))}</p>",
        "<h3>Пользователи</h3>",
        "<table><tr><th>Всего</th><th>Админы</th><th>Ученики</th><th>Обычные</th></tr>",
        f"<tr><td>{totals['all']}</td><td>{totals['admin']}</td><td>{totals['student']}</td><td>{totals['regular']}</td></tr></table>",
        "<h3>Активность</h3>",
        "<table><tr><th>DAU</th><th>WAU</th><th>MAU</th><th>Stickiness</th></tr>",
        f"<tr><td>{users['activity'].get('dau', 0)}</td><td>{users['activity'].get('wau', 0)}</td><td>{users['activity'].get('mau', 0)}</td><td>{users['activity'].get('stickiness', 0)}%</td></tr></table>",
        "<h3>Автоотклики</h3>",
        "<table><tr><th>Запусков</th><th>Успешно</th><th>Ошибок</th></tr>",
        f"<tr><td>{auto_sum.get('total', 0)}</td><td>{auto_sum.get('launched', 0)}</td><td>{auto_sum.get('failed', 0)}</td></tr></table>",
        "<h3>Автоотклики по направлениям</h3>",
        "<table><tr><th>Направление</th><th>Всего</th><th>Успешно</th><th>Ошибок</th></tr>",
    ]
    for row in report.get("autoapply", {}).get("by_direction", []) or []:
        parts.append(
            f"<tr><td>{esc(str(row['direction']))}</td><td>{int(row['total'])}</td>"
            f"<td>{int(row['launched'])}</td><td>{int(row['failed'])}</td></tr>"
        )
    parts.append("</table>")
    lead_sources = (
        report.get("funnels", {}).get("lead_sources")
        if isinstance(report.get("funnels", {}), dict)
        else []
    )
    parts.extend(
        [
            "<h3>Источники лидов</h3>",
            "<table><tr><th>Источник</th><th>Всего</th><th>Активных</th></tr>",
        ]
    )
    if isinstance(lead_sources, list) and lead_sources:
        for row in lead_sources:
            parts.append(
                f"<tr><td>{esc(str(row.get('source_label') or row.get('source') or 'Не указан'))}</td>"
                f"<td>{int(row.get('total') or 0)}</td>"
                f"<td>{int(row.get('active') or 0)}</td></tr>"
            )
    else:
        parts.append("<tr><td colspan='3'>данных нет</td></tr>")
    parts.append("</table>")
    pay = report.get("payments") if isinstance(report.get("payments"), dict) else None
    if pay:
        parts.extend(
            [
                "<h3>Платежи</h3>",
                "<table><tr><th>Предоплата (реально пополнили)</th><th>Постоплата (реально пополнили)</th><th>Изменения за текущий месяц</th></tr>",
                (
                    f"<tr><td>{int(pay.get('prepay_total_student', 0))}</td>"
                    f"<td>{int(pay.get('postpay_total_student', 0))}</td>"
                    f"<td>{int(pay.get('month_total_student', 0))}</td></tr></table>"
                ),
            ]
        )
        by_source = pay.get("by_source") if isinstance(pay.get("by_source"), list) else []
        if by_source:
            parts.extend(
                [
                    "<h4>По источнику</h4>",
                    "<table><tr><th>Источник</th><th>Сумма</th><th>Операций</th></tr>",
                ]
            )
            for row in by_source:
                parts.append(
                    f"<tr><td>{esc(str(row.get('source_label') or row.get('source') or ''))}</td>"
                    f"<td>{int(row.get('sum') or 0)}</td><td>{int(row.get('count') or 0)}</td></tr>"
                )
            parts.append("</table>")
        by_student = pay.get("by_student") if isinstance(pay.get("by_student"), list) else []
        if by_student:
            parts.extend(
                [
                    "<h4>Кто и сколько пополнил</h4>",
                    "<table><tr><th>Ученик</th><th>ID</th><th>Username</th><th>Итого</th><th>Пред</th><th>Пост</th><th>Платежей</th><th>Архив</th></tr>",
                ]
            )
            for row in by_student[:200]:
                uname = ("@" + str(row.get("owner_username") or "").strip()) if str(row.get("owner_username") or "").strip() else "—"
                parts.append(
                    f"<tr><td>{esc(str(row.get('fio') or 'Без ФИО'))}</td>"
                    f"<td>{int(row.get('student_id') or 0)}</td>"
                    f"<td>{esc(uname)}</td>"
                    f"<td>{int(row.get('total_sum') or 0)}</td>"
                    f"<td>{int(row.get('prepay_sum') or 0)}</td>"
                    f"<td>{int(row.get('postpay_sum') or 0)}</td>"
                    f"<td>{int(row.get('payments_count') or 0)}</td>"
                    f"<td>{'да' if int(row.get('archived') or 0) == 1 else 'нет'}</td></tr>"
                )
            parts.append("</table>")
    parts.append("</body></html>")
    return "".join(parts)


def init(bot: TeleBot, ctx: dict) -> None:
    conn: sqlite3.Connection = ctx["conn"]
    tz = ctx["cfg"].TZ

    def _show(c: CallbackQuery, text: str, reply_markup: InlineKeyboardMarkup | None = None) -> None:
        bot.edit_message_text(
            text,
            c.message.chat.id,
            c.message.message_id,
            reply_markup=reply_markup
            or stats_menu_kb(
                show_payments=admin_has(ctx, c.from_user.id, repo_admins.PERM_STATS_PAYMENTS),
            ),
        )
        bot.answer_callback_query(c.id)

    def _inactive_controls_kb(c: CallbackQuery, has_rows: bool) -> InlineKeyboardMarkup:
        kb = stats_menu_kb(
            show_payments=admin_has(ctx, c.from_user.id, repo_admins.PERM_STATS_PAYMENTS),
        )
        if has_rows:
            kb.row(InlineKeyboardButton("📨 Пинг неактивных", callback_data="stt:inactive:ping"))
        return kb

    @bot.callback_query_handler(func=lambda c: c.data in {"stt:overview", "stt:month", "stt:all"})
    def st_overview(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        _show(c, _overview_text(conn, tz))

    @bot.callback_query_handler(func=lambda c: c.data == "stt:users")
    def st_users(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        _show(c, _users_text(conn, tz))
        payload_txt = _users_list_txt(conn, days=30)
        raw_txt = payload_txt.encode("utf-8")
        bot.send_document(
            c.message.chat.id,
            BufferedInputFile(raw_txt, filename="users_interactions_30d.txt"),
            caption="Сводка взаимодействий пользователей за 30 дней (TXT)",
        )
        payload_html = _users_list_html(conn, days=30)
        raw_html = payload_html.encode("utf-8")
        bot.send_document(
            c.message.chat.id,
            BufferedInputFile(raw_html, filename="users_interactions_30d.html"),
            caption="Сводка взаимодействий пользователей за 30 дней (HTML)",
        )

    @bot.callback_query_handler(func=lambda c: c.data == "stt:materials")
    def st_materials(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        _show(c, _materials_text(conn))

    @bot.callback_query_handler(func=lambda c: c.data == "stt:student_funnel")
    def st_student_funnel(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        _show(c, _student_funnel_text(conn))

    @bot.callback_query_handler(func=lambda c: c.data == "stt:payments")
    def st_payments(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        if not admin_has(ctx, c.from_user.id, repo_admins.PERM_STATS_PAYMENTS):
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        _show(c, _payments_text(conn, tz))

    @bot.callback_query_handler(func=lambda c: c.data == "stt:ops")
    def st_ops(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        _show(c, _ops_text(conn))

    @bot.callback_query_handler(func=lambda c: c.data.startswith("stt:export:"))
    def st_export(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        include_payments = admin_has(ctx, c.from_user.id, repo_admins.PERM_STATS_PAYMENTS)
        fmt = c.data.split(":")[2]
        report = _report_dict(conn, tz, include_payments=include_payments)
        if fmt == "html":
            payload = _report_html(report)
            name = "stats_report.html"
        elif fmt == "txt":
            payload = _report_txt(report)
            name = "stats_report.txt"
        else:
            bot.answer_callback_query(c.id, "Неподдерживаемый формат")
            return

        raw = payload.encode("utf-8")
        bot.send_document(
            c.message.chat.id,
            BufferedInputFile(raw, filename=name),
            caption="Экспорт статистики",
        )
        _show(c, "<b>Статистика</b>\nЭкспорт отправлен файлом.")

    @bot.callback_query_handler(func=lambda c: c.data.startswith("stt:events:"))
    def st_events(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        fmt = c.data.split(":")[2]
        if fmt == "html":
            payload = _event_log_html(conn)
            name = "event_log.html"
        elif fmt == "txt":
            payload = _event_log_txt(conn)
            name = "event_log.txt"
        else:
            bot.answer_callback_query(c.id, "Неподдерживаемый формат")
            return
        raw = payload.encode("utf-8")
        bot.send_document(
            c.message.chat.id,
            BufferedInputFile(raw, filename=name),
            caption="Лог действий пользователей (event_log)",
        )
        _show(c, "<b>Статистика</b>\nЛог действий отправлен файлом.")

    @bot.callback_query_handler(func=lambda c: c.data == "stt:inactive")
    def st_inactive(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        rows = _inactive_students(conn)
        _show(c, _inactive_students_text(conn), reply_markup=_inactive_controls_kb(c, bool(rows)))

    @bot.callback_query_handler(func=lambda c: c.data == "stt:inactive:ping")
    def st_inactive_ping(c: CallbackQuery):
        if not is_admin(ctx, c.from_user.id):
            bot.answer_callback_query(c.id, "Нет доступа")
            return
        rows = _inactive_students(conn)
        if not rows:
            _show(c, "<b>Неактивные ученики</b>\n\n✅ Таких учеников сейчас нет.")
            return

        sent = 0
        failed = 0
        for r in rows:
            owner_id = int(r["owner_tg_id"] or 0)
            if owner_id <= 0:
                continue
            try:
                bot.send_message(
                    owner_id,
                    "Привет! Тебя добавили в Leonov Care.\n"
                    "Чтобы открыть меню и доступные функции, нажми /start",
                )
                sent += 1
            except ApiTelegramException:
                failed += 1
            except Exception:
                failed += 1

        repo_analytics.log_event(
            conn,
            tz,
            int(c.from_user.id),
            "stats.inactive_ping",
            {
                "total": len(rows),
                "sent": sent,
                "failed": failed,
            },
            username=c.from_user.username,
        )

        _show(
            c,
            "<b>Неактивные ученики</b>\n\n"
            f"Пинг выполнен.\nОтправлено: <b>{sent}</b>\nОшибок: <b>{failed}</b>",
            reply_markup=_inactive_controls_kb(c, bool(_inactive_students(conn))),
        )
