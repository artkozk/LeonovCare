from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

# Static defaults (can be overridden by env vars)
BOT_TOKEN = "PASTE_YOUR_BOT_TOKEN_HERE"
ADMIN_IDS = [123456789]
DB_PATH = "mentor_bot.db"
TZ = "Europe/Moscow"
ALERT_REPEAT_MIN = 10
SCHEDULER_TICK_SEC = 20
BOT_WORKER_THREADS = 16
DB_BUSY_TIMEOUT_SEC = 15
# Optional fallback for materials subscription gate.
# If DB setting is empty, this chat_id will be used for get_chat_member checks.
MATERIALS_GROUP_CHAT_ID = -1003730365848
MATERIALS_GROUP_INVITE_URL = "https://t.me/+pb_tR_aJNzo3YmQy"
AUTOAPPLY_API_BASE_URL = ""
AUTOAPPLY_INTERNAL_TOKEN = ""
AUTOAPPLY_TIMEOUT_SEC = 45
AUTOAPPLY_DEFAULT_HEADLESS = True
AUTOAPPLY_DEFAULT_SLOWMO_MS = 150
AUTOAPPLY_DEFAULT_QUERY_TEXT = ""
AUTOAPPLY_TEMP_UNAVAILABLE = False
AUTOAPPLY_TEMP_UNAVAILABLE_TEXT = "Временно недоступно"
OKIDOKI_SIGN_URL = ""
OKIDOKI_CREATE_CONTRACT_URL = ""
OKIDOKI_API_TOKEN = ""
OKIDOKI_PROFILE_PREFILL_ENABLED = False
CONTRACT_FILE_PATH = ""
CONTRACT_FILE_PATH_ZERO = ""
CONTRACT_FILE_PATH_NOT_ZERO = ""
MENTOR_CONTACT_URL = "https://t.me/leonovcare"
PAYMENT_EXPECTED_INN = "290125717910"
PAYMENT_MAX_AGE_DAYS = 90
PAYMENT_RECEIVER_NAME = "IP Oleg Leonov"
PAYMENT_BANK_NAME = ""
PAYMENT_ACCOUNT_NUMBER = ""
PAYMENT_CORR_ACCOUNT = ""
PAYMENT_BIK = ""
PAYMENT_LINK_URL = ""
PAYMENT_QR_URL = "https://qr.nspk.ru/BS10004G9CPFHB109PAR9OPU3759E1G9?type=01&bank=100000000008&sum=50000&cur=RUB&crc=F41C"
CARDLINK_SHOP_ID = ""
CARDLINK_BEARER_TOKEN = ""
CARDLINK_RETURN_URL = ""
CARDLINK_TIMEOUT_SEC = 30
CARDLINK_API_BASE_URL = "https://cardlink.link/api"
YOOKASSA_SHOP_ID = ""
YOOKASSA_SECRET_KEY = ""
YOOKASSA_RETURN_URL = ""
YOOKASSA_TIMEOUT_SEC = 30
YOOKASSA_OAUTH_TOKEN = ""
YOOKASSA_OAUTH_CLIENT_ID = ""
YOOKASSA_OAUTH_CLIENT_SECRET = ""
YOOKASSA_OAUTH_AUTH_CODE = ""
YOOKASSA_OAUTH_TOKEN_URL = "https://yookassa.ru/oauth/v2/token"
INTERVIEW_API_BASE_URL = ""
INTERVIEW_API_ADMIN_USERNAME = ""
INTERVIEW_API_ADMIN_PASSWORD = ""
INTERVIEW_API_PLAN = "PRO"
INTERVIEW_API_TIMEOUT_SEC = 20
INTERVIEW_HELPER_PRICE_RUB = 500
INTERVIEW_HELPER_DURATION_DAYS = 30
INTERVIEW_HELPER_DOWNLOAD_URL = "https://disk.yandex.ru/d/ESsTXWyxnsCc4w"
INTERVIEW_HELPER_STUDENT_FREE = False
OWNER_SUPERUSER_ID = 6553771455
OWNER_PARSER_ROOT = ""
OWNER_TOOLS_DIR = "owner_tools_data"
OWNER_TG_API_ID = 0
OWNER_TG_API_HASH = ""
OWNER_TG_LOGIN_TIMEOUT_SEC = 180
OWNER_TG_SEND_DELAY_SEC = 2.0
OWNER_OPENAI_API_KEY = ""
OWNER_OPENAI_MODEL = "gpt-5.4-mini"
OWNER_AI_PROVIDER = "proxy"
OWNER_AI_BASE_URL = ""
OWNER_AI_PROXY_AUTH = ""
OWNER_AI_HTTP_PROXY = ""
OWNER_AI_REQUEST_TIMEOUT_SEC = 30
OWNER_AI_STRICT_MODE = True


@dataclass(frozen=True)
class Config:
    BOT_TOKEN: str
    ADMIN_IDS: list[int]
    DB_PATH: str
    TZ: str
    ALERT_REPEAT_MIN: int
    SCHEDULER_TICK_SEC: int
    BOT_WORKER_THREADS: int
    DB_BUSY_TIMEOUT_SEC: int
    MATERIALS_GROUP_CHAT_ID: int | None = None
    MATERIALS_GROUP_INVITE_URL: str = ""
    AUTOAPPLY_API_BASE_URL: str = ""
    AUTOAPPLY_INTERNAL_TOKEN: str = ""
    AUTOAPPLY_TIMEOUT_SEC: int = 45
    AUTOAPPLY_DEFAULT_HEADLESS: bool = True
    AUTOAPPLY_DEFAULT_SLOWMO_MS: int = 150
    AUTOAPPLY_DEFAULT_QUERY_TEXT: str = ""
    AUTOAPPLY_TEMP_UNAVAILABLE: bool = True
    AUTOAPPLY_TEMP_UNAVAILABLE_TEXT: str = "Временно недоступно"
    OKIDOKI_SIGN_URL: str = ""
    OKIDOKI_CREATE_CONTRACT_URL: str = ""
    OKIDOKI_API_TOKEN: str = ""
    OKIDOKI_PROFILE_PREFILL_ENABLED: bool = False
    CONTRACT_FILE_PATH: str = ""
    CONTRACT_FILE_PATH_ZERO: str = ""
    CONTRACT_FILE_PATH_NOT_ZERO: str = ""
    MENTOR_CONTACT_URL: str = ""
    PAYMENT_EXPECTED_INN: str = ""
    PAYMENT_MAX_AGE_DAYS: int = 90
    PAYMENT_RECEIVER_NAME: str = ""
    PAYMENT_BANK_NAME: str = ""
    PAYMENT_ACCOUNT_NUMBER: str = ""
    PAYMENT_CORR_ACCOUNT: str = ""
    PAYMENT_BIK: str = ""
    PAYMENT_LINK_URL: str = ""
    PAYMENT_QR_URL: str = ""
    CARDLINK_SHOP_ID: str = ""
    CARDLINK_BEARER_TOKEN: str = ""
    CARDLINK_RETURN_URL: str = ""
    CARDLINK_TIMEOUT_SEC: int = 30
    CARDLINK_API_BASE_URL: str = "https://cardlink.link/api"
    YOOKASSA_SHOP_ID: str = ""
    YOOKASSA_SECRET_KEY: str = ""
    YOOKASSA_RETURN_URL: str = ""
    YOOKASSA_TIMEOUT_SEC: int = 30
    YOOKASSA_OAUTH_TOKEN: str = ""
    YOOKASSA_OAUTH_CLIENT_ID: str = ""
    YOOKASSA_OAUTH_CLIENT_SECRET: str = ""
    YOOKASSA_OAUTH_AUTH_CODE: str = ""
    YOOKASSA_OAUTH_TOKEN_URL: str = "https://yookassa.ru/oauth/v2/token"
    INTERVIEW_API_BASE_URL: str = ""
    INTERVIEW_API_ADMIN_USERNAME: str = ""
    INTERVIEW_API_ADMIN_PASSWORD: str = ""
    INTERVIEW_API_PLAN: str = "PRO"
    INTERVIEW_API_TIMEOUT_SEC: int = 20
    INTERVIEW_HELPER_PRICE_RUB: int = 500
    INTERVIEW_HELPER_DURATION_DAYS: int = 30
    INTERVIEW_HELPER_DOWNLOAD_URL: str = ""
    INTERVIEW_HELPER_STUDENT_FREE: bool = False
    OWNER_SUPERUSER_ID: int = 6553771455
    OWNER_PARSER_ROOT: str = ""
    OWNER_TOOLS_DIR: str = "owner_tools_data"
    OWNER_TG_API_ID: int = 0
    OWNER_TG_API_HASH: str = ""
    OWNER_TG_LOGIN_TIMEOUT_SEC: int = 180
    OWNER_TG_SEND_DELAY_SEC: float = 2.0
    OWNER_OPENAI_API_KEY: str = ""
    OWNER_OPENAI_MODEL: str = "gpt-5.4-mini"
    OWNER_AI_PROVIDER: str = "proxy"
    OWNER_AI_BASE_URL: str = ""
    OWNER_AI_PROXY_AUTH: str = ""
    OWNER_AI_HTTP_PROXY: str = ""
    OWNER_AI_REQUEST_TIMEOUT_SEC: int = 30
    OWNER_AI_STRICT_MODE: bool = True


def _env_str(name: str, default: str) -> str:
    raw = os.getenv(name)
    return (raw.strip() if raw is not None else default).strip()


def _env_int(name: str, default: int, min_value: int = 1) -> int:
    raw = os.getenv(name)
    if raw is None or not raw.strip():
        return max(min_value, int(default))
    try:
        return max(min_value, int(raw.strip()))
    except Exception:
        return max(min_value, int(default))


def _env_bool(name: str, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None or not raw.strip():
        return bool(default)
    val = raw.strip().lower()
    if val in {"1", "true", "yes", "y", "on"}:
        return True
    if val in {"0", "false", "no", "n", "off"}:
        return False
    return bool(default)


def _env_float(name: str, default: float, min_value: float = 0.0) -> float:
    raw = os.getenv(name)
    if raw is None or not raw.strip():
        try:
            return max(float(default), float(min_value))
        except Exception:
            return float(min_value)
    try:
        return max(float(raw.strip()), float(min_value))
    except Exception:
        try:
            return max(float(default), float(min_value))
        except Exception:
            return float(min_value)


def _resolve_default_parser_root(explicit: str) -> str:
    """Если OWNER_PARSER_ROOT не задан, ищем parser_hh-main рядом с проектом бота."""
    e = str(explicit or "").strip()
    if e:
        return e
    here = Path(__file__).resolve().parent.parent
    candidates = [
        here / "AutoHh" / "parser_hh",
        here.parent / "AutoHh" / "parser_hh",
        here.parent.parent / "AutoHh" / "parser_hh",
        here.parent.parent / "parser_hh-main",
        here.parent / "parser_hh-main",
        here / "parser_hh-main",
    ]
    for c in candidates:
        try:
            if c.is_dir() and (c / "application").is_dir():
                return str(c.resolve())
        except Exception:
            continue
    return ""


def _parse_admin_ids(default_admins: list[int]) -> list[int]:
    # ADMIN_IDS env format: "123,456,789"
    raw = os.getenv("ADMIN_IDS")
    source = default_admins
    if raw and raw.strip():
        source = [x.strip() for x in raw.split(",") if x.strip()]

    admins: list[int] = []
    for x in source or []:
        try:
            admins.append(int(x))
        except Exception:
            pass
    return admins


def _env_opt_int(name: str, default: int | None = None) -> int | None:
    raw = os.getenv(name)
    if raw is None or not raw.strip():
        return default
    try:
        return int(raw.strip())
    except Exception:
        return default


def _env_first(names: list[str], default: str = "") -> str:
    """Return first non-empty env var from a list of aliases."""
    for name in names:
        raw = os.getenv(str(name or ""))
        if raw is None:
            continue
        val = str(raw).strip()
        if val:
            return val
    return str(default or "").strip()


def load_config() -> Config:
    token = _env_str("BOT_TOKEN", BOT_TOKEN)
    if not token or token == "PASTE_YOUR_BOT_TOKEN_HERE":
        raise RuntimeError("Set BOT_TOKEN in app/config.py or BOT_TOKEN env var.")

    admins = _parse_admin_ids(ADMIN_IDS)
    if not admins or admins == [123456789]:
        raise RuntimeError("Set ADMIN_IDS in app/config.py or ADMIN_IDS env var.")

    return Config(
        BOT_TOKEN=token,
        ADMIN_IDS=admins,
        DB_PATH=_env_str("DB_PATH", DB_PATH),
        TZ=_env_str("TZ", TZ),
        ALERT_REPEAT_MIN=_env_int("ALERT_REPEAT_MIN", ALERT_REPEAT_MIN, min_value=1),
        SCHEDULER_TICK_SEC=_env_int("SCHEDULER_TICK_SEC", SCHEDULER_TICK_SEC, min_value=1),
        BOT_WORKER_THREADS=_env_int("BOT_WORKER_THREADS", BOT_WORKER_THREADS, min_value=2),
        DB_BUSY_TIMEOUT_SEC=_env_int("DB_BUSY_TIMEOUT_SEC", DB_BUSY_TIMEOUT_SEC, min_value=1),
        MATERIALS_GROUP_CHAT_ID=_env_opt_int("MATERIALS_GROUP_CHAT_ID", MATERIALS_GROUP_CHAT_ID),
        MATERIALS_GROUP_INVITE_URL=_env_str("MATERIALS_GROUP_INVITE_URL", MATERIALS_GROUP_INVITE_URL),
        AUTOAPPLY_API_BASE_URL=_env_str("AUTOAPPLY_API_BASE_URL", AUTOAPPLY_API_BASE_URL),
        AUTOAPPLY_INTERNAL_TOKEN=_env_str("AUTOAPPLY_INTERNAL_TOKEN", AUTOAPPLY_INTERNAL_TOKEN),
        AUTOAPPLY_TIMEOUT_SEC=_env_int("AUTOAPPLY_TIMEOUT_SEC", AUTOAPPLY_TIMEOUT_SEC, min_value=5),
        AUTOAPPLY_DEFAULT_HEADLESS=_env_bool("AUTOAPPLY_DEFAULT_HEADLESS", AUTOAPPLY_DEFAULT_HEADLESS),
        AUTOAPPLY_DEFAULT_SLOWMO_MS=_env_int("AUTOAPPLY_DEFAULT_SLOWMO_MS", AUTOAPPLY_DEFAULT_SLOWMO_MS, min_value=0),
        AUTOAPPLY_DEFAULT_QUERY_TEXT=_env_str("AUTOAPPLY_DEFAULT_QUERY_TEXT", AUTOAPPLY_DEFAULT_QUERY_TEXT),
        AUTOAPPLY_TEMP_UNAVAILABLE=_env_bool("AUTOAPPLY_TEMP_UNAVAILABLE", AUTOAPPLY_TEMP_UNAVAILABLE),
        AUTOAPPLY_TEMP_UNAVAILABLE_TEXT=_env_str("AUTOAPPLY_TEMP_UNAVAILABLE_TEXT", AUTOAPPLY_TEMP_UNAVAILABLE_TEXT),
        OKIDOKI_SIGN_URL=_env_str("OKIDOKI_SIGN_URL", OKIDOKI_SIGN_URL),
        OKIDOKI_CREATE_CONTRACT_URL=_env_str("OKIDOKI_CREATE_CONTRACT_URL", OKIDOKI_CREATE_CONTRACT_URL),
        OKIDOKI_API_TOKEN=_env_str("OKIDOKI_API_TOKEN", OKIDOKI_API_TOKEN),
        OKIDOKI_PROFILE_PREFILL_ENABLED=_env_bool("OKIDOKI_PROFILE_PREFILL_ENABLED", OKIDOKI_PROFILE_PREFILL_ENABLED),
        CONTRACT_FILE_PATH=_env_str("CONTRACT_FILE_PATH", CONTRACT_FILE_PATH),
        CONTRACT_FILE_PATH_ZERO=_env_str("CONTRACT_FILE_PATH_ZERO", CONTRACT_FILE_PATH_ZERO),
        CONTRACT_FILE_PATH_NOT_ZERO=_env_str("CONTRACT_FILE_PATH_NOT_ZERO", CONTRACT_FILE_PATH_NOT_ZERO),
        MENTOR_CONTACT_URL=_env_str("MENTOR_CONTACT_URL", MENTOR_CONTACT_URL),
        PAYMENT_EXPECTED_INN=_env_str("PAYMENT_EXPECTED_INN", PAYMENT_EXPECTED_INN),
        PAYMENT_MAX_AGE_DAYS=_env_int("PAYMENT_MAX_AGE_DAYS", PAYMENT_MAX_AGE_DAYS, min_value=1),
        PAYMENT_RECEIVER_NAME=_env_str("PAYMENT_RECEIVER_NAME", PAYMENT_RECEIVER_NAME),
        PAYMENT_BANK_NAME=_env_str("PAYMENT_BANK_NAME", PAYMENT_BANK_NAME),
        PAYMENT_ACCOUNT_NUMBER=_env_str("PAYMENT_ACCOUNT_NUMBER", PAYMENT_ACCOUNT_NUMBER),
        PAYMENT_CORR_ACCOUNT=_env_str("PAYMENT_CORR_ACCOUNT", PAYMENT_CORR_ACCOUNT),
        PAYMENT_BIK=_env_str("PAYMENT_BIK", PAYMENT_BIK),
        PAYMENT_LINK_URL=_env_str("PAYMENT_LINK_URL", PAYMENT_LINK_URL),
        PAYMENT_QR_URL=_env_str("PAYMENT_QR_URL", PAYMENT_QR_URL),
        CARDLINK_SHOP_ID=_env_first(
            [
                "CARDLINK_SHOP_ID",
                "CARDLINK_MERCHANT_ID",
                "CARDLINK_SHOP",
                "CARDLINK_SHOPID",
                "YOOKASSA_SHOP_ID",
            ],
            CARDLINK_SHOP_ID,
        ),
        CARDLINK_BEARER_TOKEN=_env_first(
            [
                "CARDLINK_BEARER_TOKEN",
                "CARDLINK_API_TOKEN",
                "CARDLINK_TOKEN",
                "CARDLINK_SECRET",
                "YOOKASSA_SECRET_KEY",
            ],
            CARDLINK_BEARER_TOKEN,
        ),
        CARDLINK_RETURN_URL=_env_str(
            "CARDLINK_RETURN_URL",
            _env_str("YOOKASSA_RETURN_URL", CARDLINK_RETURN_URL),
        ),
        CARDLINK_TIMEOUT_SEC=_env_int(
            "CARDLINK_TIMEOUT_SEC",
            _env_int("YOOKASSA_TIMEOUT_SEC", CARDLINK_TIMEOUT_SEC, min_value=5),
            min_value=5,
        ),
        CARDLINK_API_BASE_URL=_env_str("CARDLINK_API_BASE_URL", CARDLINK_API_BASE_URL),
        YOOKASSA_SHOP_ID=_env_str("YOOKASSA_SHOP_ID", YOOKASSA_SHOP_ID),
        YOOKASSA_SECRET_KEY=_env_str("YOOKASSA_SECRET_KEY", YOOKASSA_SECRET_KEY),
        YOOKASSA_RETURN_URL=_env_str("YOOKASSA_RETURN_URL", YOOKASSA_RETURN_URL),
        YOOKASSA_TIMEOUT_SEC=_env_int("YOOKASSA_TIMEOUT_SEC", YOOKASSA_TIMEOUT_SEC, min_value=5),
        YOOKASSA_OAUTH_TOKEN=_env_str("YOOKASSA_OAUTH_TOKEN", YOOKASSA_OAUTH_TOKEN),
        YOOKASSA_OAUTH_CLIENT_ID=_env_str("YOOKASSA_OAUTH_CLIENT_ID", YOOKASSA_OAUTH_CLIENT_ID),
        YOOKASSA_OAUTH_CLIENT_SECRET=_env_str("YOOKASSA_OAUTH_CLIENT_SECRET", YOOKASSA_OAUTH_CLIENT_SECRET),
        YOOKASSA_OAUTH_AUTH_CODE=_env_str("YOOKASSA_OAUTH_AUTH_CODE", YOOKASSA_OAUTH_AUTH_CODE),
        YOOKASSA_OAUTH_TOKEN_URL=_env_str("YOOKASSA_OAUTH_TOKEN_URL", YOOKASSA_OAUTH_TOKEN_URL),
        INTERVIEW_API_BASE_URL=_env_str("INTERVIEW_API_BASE_URL", INTERVIEW_API_BASE_URL),
        INTERVIEW_API_ADMIN_USERNAME=_env_str("INTERVIEW_API_ADMIN_USERNAME", INTERVIEW_API_ADMIN_USERNAME),
        INTERVIEW_API_ADMIN_PASSWORD=_env_str("INTERVIEW_API_ADMIN_PASSWORD", INTERVIEW_API_ADMIN_PASSWORD),
        INTERVIEW_API_PLAN=_env_str("INTERVIEW_API_PLAN", INTERVIEW_API_PLAN),
        INTERVIEW_API_TIMEOUT_SEC=_env_int("INTERVIEW_API_TIMEOUT_SEC", INTERVIEW_API_TIMEOUT_SEC, min_value=5),
        INTERVIEW_HELPER_PRICE_RUB=_env_int("INTERVIEW_HELPER_PRICE_RUB", INTERVIEW_HELPER_PRICE_RUB, min_value=1),
        INTERVIEW_HELPER_DURATION_DAYS=_env_int("INTERVIEW_HELPER_DURATION_DAYS", INTERVIEW_HELPER_DURATION_DAYS, min_value=1),
        INTERVIEW_HELPER_DOWNLOAD_URL=_env_str("INTERVIEW_HELPER_DOWNLOAD_URL", INTERVIEW_HELPER_DOWNLOAD_URL),
        INTERVIEW_HELPER_STUDENT_FREE=_env_bool("INTERVIEW_HELPER_STUDENT_FREE", INTERVIEW_HELPER_STUDENT_FREE),
        OWNER_SUPERUSER_ID=_env_int("OWNER_SUPERUSER_ID", OWNER_SUPERUSER_ID, min_value=1),
        OWNER_PARSER_ROOT=_resolve_default_parser_root(_env_str("OWNER_PARSER_ROOT", OWNER_PARSER_ROOT)),
        OWNER_TOOLS_DIR=_env_str("OWNER_TOOLS_DIR", OWNER_TOOLS_DIR),
        OWNER_TG_API_ID=_env_int("OWNER_TG_API_ID", OWNER_TG_API_ID, min_value=0),
        OWNER_TG_API_HASH=_env_str("OWNER_TG_API_HASH", OWNER_TG_API_HASH),
        OWNER_TG_LOGIN_TIMEOUT_SEC=_env_int("OWNER_TG_LOGIN_TIMEOUT_SEC", OWNER_TG_LOGIN_TIMEOUT_SEC, min_value=60),
        OWNER_TG_SEND_DELAY_SEC=_env_float("OWNER_TG_SEND_DELAY_SEC", OWNER_TG_SEND_DELAY_SEC, min_value=0.0),
        OWNER_OPENAI_API_KEY=_env_str("OWNER_OPENAI_API_KEY", OWNER_OPENAI_API_KEY),
        OWNER_OPENAI_MODEL=_env_str("OWNER_OPENAI_MODEL", OWNER_OPENAI_MODEL),
        OWNER_AI_PROVIDER=_env_str("OWNER_AI_PROVIDER", OWNER_AI_PROVIDER),
        OWNER_AI_BASE_URL=_env_str("OWNER_AI_BASE_URL", OWNER_AI_BASE_URL),
        OWNER_AI_PROXY_AUTH=_env_str("OWNER_AI_PROXY_AUTH", OWNER_AI_PROXY_AUTH),
        OWNER_AI_HTTP_PROXY=_env_str("OWNER_AI_HTTP_PROXY", OWNER_AI_HTTP_PROXY),
        OWNER_AI_REQUEST_TIMEOUT_SEC=_env_int("OWNER_AI_REQUEST_TIMEOUT_SEC", OWNER_AI_REQUEST_TIMEOUT_SEC, min_value=5),
        OWNER_AI_STRICT_MODE=_env_bool("OWNER_AI_STRICT_MODE", OWNER_AI_STRICT_MODE),
    )
