from __future__ import annotations

import html
import sqlite3
from functools import wraps

from telebot import TeleBot
from telebot.apihelper import ApiTelegramException

from app.config import Config
from app.db import repo_analytics
from app.handlers.registry import init_handlers


def build_app(cfg: Config, conn: sqlite3.Connection) -> tuple[TeleBot, dict]:
    bot = TeleBot(cfg.BOT_TOKEN, parse_mode="HTML", worker_threads=cfg.BOT_WORKER_THREADS)

    def _is_parse_entities_error(exc: ApiTelegramException) -> bool:
        if getattr(exc, "error_code", None) != 400:
            return False
        low = str(exc).lower()
        return "can't parse entities" in low or "unsupported start tag" in low

    def _plain_retry_kwargs(kwargs: dict) -> dict:
        patched = dict(kwargs or {})
        # Force plain-text fallback to avoid HTML parsing failures on dynamic logs/tracebacks.
        patched["parse_mode"] = None
        # Explicit entities may still force parser validation on Telegram side.
        patched.pop("entities", None)
        patched.pop("caption_entities", None)
        return patched

    def _as_plain_text(text: object) -> str:
        return html.escape(str(text or ""))

    # Telegram may return: "Bad Request: message is not modified" when we try to edit
    # an already identical message (common on repeated button taps). Swallow it globally.
    _orig_edit_message_text = bot.edit_message_text

    def _safe_edit_message_text(text, chat_id, message_id, *args, **kwargs):
        try:
            return _orig_edit_message_text(text, chat_id, message_id, *args, **kwargs)
        except ApiTelegramException as e:
            if getattr(e, "error_code", None) == 400 and "message is not modified" in str(e):
                return None
            if _is_parse_entities_error(e):
                return _orig_edit_message_text(
                    _as_plain_text(text),
                    chat_id,
                    message_id,
                    *args,
                    **_plain_retry_kwargs(kwargs),
                )
            raise

    bot.edit_message_text = _safe_edit_message_text  # type: ignore

    _orig_send_message = bot.send_message

    def _safe_send_message(chat_id, text, *args, **kwargs):
        try:
            return _orig_send_message(chat_id, text, *args, **kwargs)
        except ApiTelegramException as e:
            if _is_parse_entities_error(e):
                return _orig_send_message(
                    chat_id,
                    _as_plain_text(text),
                    *args,
                    **_plain_retry_kwargs(kwargs),
                )
            raise

    bot.send_message = _safe_send_message  # type: ignore

    def _wrap_caption_sender(method_name: str):
        original = getattr(bot, method_name)

        def _safe_sender(chat_id, media, *args, **kwargs):
            try:
                return original(chat_id, media, *args, **kwargs)
            except ApiTelegramException as e:
                if _is_parse_entities_error(e):
                    patched_kwargs = _plain_retry_kwargs(kwargs)
                    if "caption" in patched_kwargs and patched_kwargs.get("caption") is not None:
                        patched_kwargs["caption"] = _as_plain_text(patched_kwargs.get("caption"))
                    return original(chat_id, media, *args, **patched_kwargs)
                raise

        return _safe_sender

    bot.send_document = _wrap_caption_sender("send_document")  # type: ignore
    bot.send_photo = _wrap_caption_sender("send_photo")  # type: ignore
    bot.send_video = _wrap_caption_sender("send_video")  # type: ignore
    bot.send_animation = _wrap_caption_sender("send_animation")  # type: ignore
    bot.send_audio = _wrap_caption_sender("send_audio")  # type: ignore
    bot.send_voice = _wrap_caption_sender("send_voice")  # type: ignore

    _orig_edit_reply_markup = bot.edit_message_reply_markup

    def _safe_edit_message_reply_markup(chat_id, message_id, *args, **kwargs):
        try:
            return _orig_edit_reply_markup(chat_id, message_id, *args, **kwargs)
        except ApiTelegramException as e:
            if getattr(e, "error_code", None) == 400 and "message is not modified" in str(e):
                return None
            raise

    bot.edit_message_reply_markup = _safe_edit_message_reply_markup  # type: ignore

    def _safe_log_event(user_id: int, event_name: str, payload: dict, username: str | None) -> None:
        try:
            repo_analytics.log_event(
                conn,
                cfg.TZ,
                int(user_id),
                event_name,
                payload,
                username=username,
            )
        except Exception:
            # Analytics logging must never break bot behavior.
            return

    _orig_message_handler = bot.message_handler

    def _tracked_message_handler(*args, **kwargs):
        registrar = _orig_message_handler(*args, **kwargs)

        def _decorator(fn):
            @wraps(fn)
            def _wrapped(message, *f_args, **f_kwargs):
                user = getattr(message, "from_user", None)
                uid = int(getattr(user, "id", 0) or 0)
                username = getattr(user, "username", None)
                chat = getattr(message, "chat", None)
                chat_type = str(getattr(chat, "type", "") or "")
                text = str(getattr(message, "text", "") or "")
                if uid > 0:
                    if text.startswith("/"):
                        _safe_log_event(
                            uid,
                            "ui.command",
                            {
                                "command": text.split(maxsplit=1)[0][:64].lower(),
                                "chat_type": chat_type,
                            },
                            username,
                        )
                    else:
                        _safe_log_event(
                            uid,
                            "ui.message",
                            {
                                "chat_type": chat_type,
                                "text_len": len(text),
                            },
                            username,
                        )
                return fn(message, *f_args, **f_kwargs)

            return registrar(_wrapped)

        return _decorator

    bot.message_handler = _tracked_message_handler  # type: ignore

    _orig_callback_query_handler = bot.callback_query_handler

    def _tracked_callback_query_handler(*args, **kwargs):
        registrar = _orig_callback_query_handler(*args, **kwargs)

        def _decorator(fn):
            @wraps(fn)
            def _wrapped(call, *f_args, **f_kwargs):
                user = getattr(call, "from_user", None)
                uid = int(getattr(user, "id", 0) or 0)
                username = getattr(user, "username", None)
                data = str(getattr(call, "data", "") or "")
                if uid > 0:
                    _safe_log_event(
                        uid,
                        "ui.callback",
                        {
                            "data": data[:128],
                        },
                        username,
                    )
                return fn(call, *f_args, **f_kwargs)

            return registrar(_wrapped)

        return _decorator

    bot.callback_query_handler = _tracked_callback_query_handler  # type: ignore

    ctx = {
        "cfg": cfg,
        "conn": conn,
    }

    init_handlers(bot, ctx)

    return bot, ctx
