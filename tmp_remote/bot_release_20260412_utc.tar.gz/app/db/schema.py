from __future__ import annotations
import sqlite3

SCHEMA_SQL = r'''
CREATE TABLE IF NOT EXISTS settings(
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS directions(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE,
  sort INTEGER NOT NULL DEFAULT 100
);

CREATE TABLE IF NOT EXISTS stages(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE,
  sort INTEGER NOT NULL DEFAULT 100
);

CREATE TABLE IF NOT EXISTS students(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  fio TEXT NOT NULL,
  username TEXT,
  direction_id INTEGER,
  stage_id INTEGER,
  tariff TEXT NOT NULL DEFAULT 'post', -- pre, post, pre_post
  comment TEXT,
  join_date TEXT, -- dd.mm.yyyy
  interviews_active INTEGER NOT NULL DEFAULT 0,
  offer_amount INTEGER, -- rub
  contract_url TEXT,
  hh_phone TEXT,
  hh_email TEXT,
  hh_password TEXT,
  hh_birth_date TEXT, -- dd.mm.yyyy
  hh_location TEXT,
  hh_salary_min INTEGER, -- rub
  hh_salary_comfort INTEGER, -- rub
  owner_tg_id INTEGER,
  owner_chat_id INTEGER,
  owner_username TEXT,
  lead_source TEXT, -- channel, cold, referral, custom text
  archived INTEGER NOT NULL DEFAULT 0,
  archive_failed INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY(direction_id) REFERENCES directions(id),
  FOREIGN KEY(stage_id) REFERENCES stages(id)
);

CREATE INDEX IF NOT EXISTS idx_students_archived ON students(archived);
CREATE INDEX IF NOT EXISTS idx_students_direction ON students(direction_id);
CREATE INDEX IF NOT EXISTS idx_students_stage ON students(stage_id);

CREATE TABLE IF NOT EXISTS student_postpay(
  student_id INTEGER PRIMARY KEY,
  total_percent REAL, -- e.g. 350, 600
  schedule_type TEXT NOT NULL DEFAULT 'percent_per_month', -- percent_per_month, fixed_per_month, custom
  per_period_value REAL, -- e.g. 50 (% per month) or 30000 (rub)
  period_unit TEXT NOT NULL DEFAULT 'month',
  start_date TEXT, -- dd.mm.yyyy
  next_due_date TEXT, -- dd.mm.yyyy
  student_notify_enabled INTEGER NOT NULL DEFAULT 1,
  student_notify_repeat_min INTEGER,
  student_next_notify_date TEXT, -- dd.mm.yyyy (сдвиг уведомлений ученику, не меняя срок платежа)
  enabled INTEGER NOT NULL DEFAULT 0,
  FOREIGN KEY(student_id) REFERENCES students(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS payments(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  student_id INTEGER NOT NULL,
  pay_type TEXT NOT NULL, -- prepay, postpay
  amount INTEGER NOT NULL,
  pay_date TEXT NOT NULL, -- dd.mm.yyyy
  source TEXT, -- mentor, student
  proof_file_id TEXT,
  note TEXT,
  created_at TEXT NOT NULL,
  FOREIGN KEY(student_id) REFERENCES students(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_payments_student ON payments(student_id);

CREATE TABLE IF NOT EXISTS reminders(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  student_id INTEGER,
  title TEXT NOT NULL,
  note TEXT,
  freq_type TEXT NOT NULL DEFAULT 'daily', -- daily, every_n_days, weekly
  freq_value INTEGER NOT NULL DEFAULT 1,
  days_of_week TEXT, -- e.g. "1,3,5"
  time_of_day TEXT NOT NULL DEFAULT '12:00', -- HH:MM
  next_run_at TEXT NOT NULL, -- ISO local datetime
  enabled INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY(student_id) REFERENCES students(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_reminders_next ON reminders(next_run_at);
CREATE INDEX IF NOT EXISTS idx_reminders_enabled ON reminders(enabled);

CREATE TABLE IF NOT EXISTS events(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  student_id INTEGER,
  owner_tg_id INTEGER,
  call_kind TEXT, -- student, diagnostic
  event_type TEXT NOT NULL, -- HR, TECH, CALL, OTHER
  company TEXT,
  role TEXT,
  direction TEXT,
  link TEXT,
  start_at TEXT NOT NULL, -- ISO local datetime
  duration_min INTEGER NOT NULL DEFAULT 60,
  remind_before_min INTEGER NOT NULL DEFAULT 60,
  next_alert_at TEXT NOT NULL, -- ISO local datetime
  alerted INTEGER NOT NULL DEFAULT 0,
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY(student_id) REFERENCES students(id) ON DELETE SET NULL
);

CREATE INDEX IF NOT EXISTS idx_events_next_alert ON events(next_alert_at);
CREATE INDEX IF NOT EXISTS idx_events_active ON events(active);

CREATE TABLE IF NOT EXISTS alerts(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  alert_type TEXT NOT NULL, -- REMINDER, EVENT, PAYMENT
  related_table TEXT NOT NULL, -- reminders, events, students
  related_id INTEGER NOT NULL,
  student_id INTEGER,
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  due_at TEXT NOT NULL, -- ISO local datetime
  status TEXT NOT NULL DEFAULT 'PENDING', -- PENDING, SEEN
  message_id INTEGER,
  chat_id INTEGER NOT NULL,
  retry_after_min INTEGER NOT NULL DEFAULT 10,
  next_retry_at TEXT, -- ISO local datetime
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY(student_id) REFERENCES students(id) ON DELETE SET NULL
);

CREATE INDEX IF NOT EXISTS idx_alerts_status ON alerts(status);
CREATE INDEX IF NOT EXISTS idx_alerts_due ON alerts(due_at);
CREATE INDEX IF NOT EXISTS idx_alerts_retry ON alerts(next_retry_at);

CREATE TABLE IF NOT EXISTS user_states(
  user_id INTEGER PRIMARY KEY,
  state TEXT,
  data_json TEXT,
  updated_at TEXT NOT NULL
);


-- Requests from students (profile/accounts/payment proofs)
CREATE TABLE IF NOT EXISTS student_requests(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  owner_tg_id INTEGER NOT NULL,
  req_type TEXT NOT NULL, -- PROFILE, ACCOUNTS, PAYMENT
  student_id INTEGER,
  payload_json TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'PENDING', -- PENDING, APPROVED, REJECTED
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY(student_id) REFERENCES students(id) ON DELETE SET NULL
);

CREATE INDEX IF NOT EXISTS idx_requests_status ON student_requests(status);
CREATE INDEX IF NOT EXISTS idx_requests_owner ON student_requests(owner_tg_id);

CREATE TABLE IF NOT EXISTS enrollment_contracts(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  owner_tg_id INTEGER NOT NULL UNIQUE,
  owner_chat_id INTEGER,
  level_key TEXT NOT NULL, -- zero, not_zero
  track_key TEXT NOT NULL, -- zero-offer, interview-prep, grade-salary
  track_title TEXT NOT NULL,
  tariff_key TEXT NOT NULL,
  tariff_title TEXT NOT NULL,
  tariff_price TEXT NOT NULL,
  contract_file_path TEXT,
  sign_url TEXT,
  okidoki_request_json TEXT,
  okidoki_response_json TEXT,
  status TEXT NOT NULL DEFAULT 'sent', -- sent, signed, canceled
  note TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_enrollment_status ON enrollment_contracts(status, created_at);

CREATE TABLE IF NOT EXISTS autoapply_runs(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  owner_tg_id INTEGER NOT NULL,
  owner_chat_id INTEGER,
  login TEXT NOT NULL,
  direction TEXT NOT NULL,
  target_applies INTEGER NOT NULL DEFAULT 200,
  query_text TEXT,
  status TEXT NOT NULL DEFAULT 'created', -- created, launched, failed
  error_text TEXT,
  create_response_json TEXT,
  run_response_json TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_autoapply_runs_owner ON autoapply_runs(owner_tg_id, created_at);
CREATE INDEX IF NOT EXISTS idx_autoapply_runs_status ON autoapply_runs(status, created_at);


-- Stage reminder rules (этап = группа)
CREATE TABLE IF NOT EXISTS stage_reminder_rules(
  stage_id INTEGER PRIMARY KEY,
  enabled INTEGER NOT NULL DEFAULT 1,
  title TEXT NOT NULL DEFAULT 'Пинг',
  note TEXT NOT NULL DEFAULT 'Списаться, спросить прогресс и трудности.',
  freq_type TEXT NOT NULL DEFAULT 'daily', -- daily, every_n_days, weekly, once
  freq_value INTEGER NOT NULL DEFAULT 1,
  days_of_week TEXT, -- e.g. "1,3,5" (Mon=1..Sun=7)
  time_of_day TEXT NOT NULL DEFAULT '12:00',
  updated_at TEXT NOT NULL,
  FOREIGN KEY(stage_id) REFERENCES stages(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS student_stage_reminders(
  student_id INTEGER PRIMARY KEY,
  stage_id INTEGER NOT NULL,
  reminder_id INTEGER NOT NULL,
  FOREIGN KEY(student_id) REFERENCES students(id) ON DELETE CASCADE,
  FOREIGN KEY(stage_id) REFERENCES stages(id) ON DELETE CASCADE,
  FOREIGN KEY(reminder_id) REFERENCES reminders(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_stage_rules_enabled ON stage_reminder_rules(enabled);

CREATE TABLE IF NOT EXISTS student_access_codes(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  code TEXT NOT NULL UNIQUE,
  status TEXT NOT NULL DEFAULT 'active', -- active, used, revoked, expired
  created_by_admin_id INTEGER NOT NULL,
  created_at TEXT NOT NULL,
  expires_at TEXT, -- ISO local datetime
  used_by_user_id INTEGER,
  used_at TEXT, -- ISO local datetime
  revoked_at TEXT -- ISO local datetime
);

CREATE INDEX IF NOT EXISTS idx_student_codes_status ON student_access_codes(status);
CREATE INDEX IF NOT EXISTS idx_student_codes_expires ON student_access_codes(expires_at);
CREATE INDEX IF NOT EXISTS idx_student_codes_used_by ON student_access_codes(used_by_user_id);

CREATE TABLE IF NOT EXISTS material_steps(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  direction TEXT NOT NULL, -- java, golang, frontend, python
  position INTEGER NOT NULL,
  title TEXT NOT NULL,
  message_url TEXT NOT NULL,
  is_active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_material_steps_direction ON material_steps(direction, is_active, position);

CREATE TABLE IF NOT EXISTS material_topic_map(
  direction TEXT PRIMARY KEY,
  thread_id INTEGER NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS user_material_progress(
  user_id INTEGER NOT NULL,
  step_id INTEGER NOT NULL,
  is_done INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL,
  PRIMARY KEY(user_id, step_id),
  FOREIGN KEY(step_id) REFERENCES material_steps(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_material_progress_user ON user_material_progress(user_id, is_done);

CREATE TABLE IF NOT EXISTS user_profiles(
  user_id INTEGER PRIMARY KEY,
  role_type TEXT NOT NULL DEFAULT 'regular', -- admin, student, regular
  username TEXT,
  first_seen_at TEXT NOT NULL, -- ISO local datetime
  last_seen_at TEXT NOT NULL, -- ISO local datetime
  last_start_at TEXT -- ISO local datetime
);

CREATE INDEX IF NOT EXISTS idx_user_profiles_role ON user_profiles(role_type);
CREATE INDEX IF NOT EXISTS idx_user_profiles_last_seen ON user_profiles(last_seen_at);

CREATE TABLE IF NOT EXISTS event_log(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  event_name TEXT NOT NULL,
  user_id INTEGER NOT NULL,
  payload_json TEXT,
  created_at TEXT NOT NULL -- ISO local datetime
);

CREATE INDEX IF NOT EXISTS idx_event_log_event ON event_log(event_name, created_at);
CREATE INDEX IF NOT EXISTS idx_event_log_user ON event_log(user_id, created_at);

CREATE TABLE IF NOT EXISTS broadcast_campaigns(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  created_by_admin_id INTEGER NOT NULL,
  scope TEXT NOT NULL, -- all, student, regular, admin
  template_kind TEXT NOT NULL DEFAULT 'manual', -- manual, auto
  source_chat_id INTEGER NOT NULL,
  source_message_id INTEGER NOT NULL,
  auto_rule_id INTEGER,
  total_targets INTEGER NOT NULL DEFAULT 0,
  sent_count INTEGER NOT NULL DEFAULT 0,
  failed_count INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'created', -- created, sent, deleted
  created_at TEXT NOT NULL,
  sent_at TEXT,
  deleted_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_campaigns_kind ON broadcast_campaigns(template_kind, created_at);
CREATE INDEX IF NOT EXISTS idx_campaigns_rule ON broadcast_campaigns(auto_rule_id, created_at);

CREATE TABLE IF NOT EXISTS broadcast_deliveries(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  campaign_id INTEGER NOT NULL,
  user_id INTEGER NOT NULL,
  chat_id INTEGER NOT NULL,
  message_id INTEGER,
  status TEXT NOT NULL, -- sent, failed, deleted
  error_text TEXT,
  sent_at TEXT,
  read_at TEXT,
  read_by_user_id INTEGER,
  deleted_at TEXT,
  FOREIGN KEY(campaign_id) REFERENCES broadcast_campaigns(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_deliveries_campaign ON broadcast_deliveries(campaign_id, status);
CREATE INDEX IF NOT EXISTS idx_deliveries_user ON broadcast_deliveries(user_id, sent_at);

CREATE TABLE IF NOT EXISTS auto_broadcast_rules(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  created_by_admin_id INTEGER NOT NULL,
  scope TEXT NOT NULL, -- all, student, regular, admin
  inactivity_days INTEGER NOT NULL DEFAULT 7,
  source_chat_id INTEGER NOT NULL,
  source_message_id INTEGER NOT NULL,
  template_payload_json TEXT,
  read_ack_enabled INTEGER NOT NULL DEFAULT 0,
  enabled INTEGER NOT NULL DEFAULT 1,
  last_run_at TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_auto_rules_enabled ON auto_broadcast_rules(enabled, scope);

CREATE TABLE IF NOT EXISTS bot_admins(
  user_id INTEGER PRIMARY KEY,
  username TEXT,
  added_by_admin_id INTEGER,
  grade TEXT NOT NULL DEFAULT 'full', -- full, limited
  is_active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  removed_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_bot_admins_active ON bot_admins(is_active, updated_at);

CREATE TABLE IF NOT EXISTS checkout_payments(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  owner_tg_id INTEGER NOT NULL,
  owner_chat_id INTEGER,
  owner_username TEXT,
  req_type TEXT NOT NULL,
  service_key TEXT NOT NULL,
  service_title TEXT NOT NULL,
  purpose TEXT NOT NULL,
  amount INTEGER NOT NULL,
  currency TEXT NOT NULL DEFAULT 'RUB',
  provider TEXT NOT NULL DEFAULT 'yookassa',
  provider_payment_id TEXT NOT NULL UNIQUE,
  idempotence_key TEXT,
  status TEXT NOT NULL DEFAULT 'PENDING', -- PENDING, WAITING_FOR_CAPTURE, SUCCEEDED, CANCELED, FAILED
  confirmation_url TEXT,
  metadata_json TEXT,
  provider_payload_json TEXT,
  action_done INTEGER NOT NULL DEFAULT 0,
  action_done_at TEXT,
  action_note TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  paid_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_checkout_owner ON checkout_payments(owner_tg_id, created_at);
CREATE INDEX IF NOT EXISTS idx_checkout_status ON checkout_payments(status, action_done, created_at);
CREATE INDEX IF NOT EXISTS idx_checkout_provider ON checkout_payments(provider, provider_payment_id);

CREATE TABLE IF NOT EXISTS interview_helper_licenses(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  owner_tg_id INTEGER NOT NULL,
  owner_chat_id INTEGER,
  owner_username TEXT,
  checkout_payment_id INTEGER,
  external_license_id INTEGER,
  license_key TEXT NOT NULL,
  plan TEXT NOT NULL,
  enabled INTEGER NOT NULL DEFAULT 1,
  expires_at TEXT,
  note TEXT,
  payload_json TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY(checkout_payment_id) REFERENCES checkout_payments(id) ON DELETE SET NULL
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_interview_license_key ON interview_helper_licenses(license_key);
CREATE INDEX IF NOT EXISTS idx_interview_license_owner ON interview_helper_licenses(owner_tg_id, created_at);
CREATE INDEX IF NOT EXISTS idx_interview_license_expires ON interview_helper_licenses(expires_at, enabled);

CREATE TABLE IF NOT EXISTS owner_hh_jobs(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  owner_tg_id INTEGER NOT NULL,
  owner_chat_id INTEGER NOT NULL,
  direction TEXT NOT NULL DEFAULT 'python', -- java, frontend, golang, python
  script_version TEXT NOT NULL DEFAULT 'script4',
  ai_enabled INTEGER NOT NULL DEFAULT 0,
  search_text TEXT,
  search_link TEXT,
  parse_limit INTEGER NOT NULL DEFAULT 25,
  send_limit INTEGER NOT NULL DEFAULT 0,
  message_text TEXT,
  status TEXT NOT NULL DEFAULT 'created', -- created, running, done, failed
  stage TEXT NOT NULL DEFAULT 'queued', -- queued, parsing, parsed, sending, sent, done, failed
  parsed_total INTEGER NOT NULL DEFAULT 0,
  tg_found_total INTEGER NOT NULL DEFAULT 0,
  send_success INTEGER NOT NULL DEFAULT 0,
  send_failed INTEGER NOT NULL DEFAULT 0,
  output_file TEXT,
  contacts_file TEXT,
  report_file TEXT,
  error_text TEXT,
  parser_payload_json TEXT,
  sender_payload_json TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  started_at TEXT,
  finished_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_owner_hh_jobs_owner ON owner_hh_jobs(owner_tg_id, created_at);
CREATE INDEX IF NOT EXISTS idx_owner_hh_jobs_status ON owner_hh_jobs(status, updated_at);

CREATE TABLE IF NOT EXISTS owner_tg_accounts(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  owner_tg_id INTEGER NOT NULL,
  title TEXT NOT NULL,
  account_type TEXT NOT NULL DEFAULT 'standard', -- standard, polygon
  api_id INTEGER NOT NULL DEFAULT 0,
  api_hash TEXT NOT NULL DEFAULT '',
  session_file TEXT NOT NULL,
  is_active INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_owner_tg_accounts_owner ON owner_tg_accounts(owner_tg_id, is_active, id);

CREATE TABLE IF NOT EXISTS owner_outreach_leads(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  job_id INTEGER NOT NULL,
  telegram TEXT NOT NULL,
  direction TEXT NOT NULL DEFAULT 'python',
  status TEXT NOT NULL DEFAULT 'sent',
  send_error TEXT,
  inbound_text TEXT,
  outbound_text TEXT,
  ai_step INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  UNIQUE(job_id, telegram),
  FOREIGN KEY(job_id) REFERENCES owner_hh_jobs(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_owner_outreach_leads_job ON owner_outreach_leads(job_id, status);
CREATE INDEX IF NOT EXISTS idx_owner_outreach_leads_tg ON owner_outreach_leads(telegram);

CREATE TABLE IF NOT EXISTS owner_outreach_contacted(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  owner_tg_id INTEGER NOT NULL,
  telegram TEXT NOT NULL,
  telegram_norm TEXT NOT NULL,
  first_job_id INTEGER,
  first_account_id INTEGER,
  first_sent_at TEXT NOT NULL,
  last_job_id INTEGER,
  last_account_id INTEGER,
  last_sent_at TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  UNIQUE(owner_tg_id, telegram_norm),
  FOREIGN KEY(first_job_id) REFERENCES owner_hh_jobs(id) ON DELETE SET NULL,
  FOREIGN KEY(last_job_id) REFERENCES owner_hh_jobs(id) ON DELETE SET NULL,
  FOREIGN KEY(first_account_id) REFERENCES owner_tg_accounts(id) ON DELETE SET NULL,
  FOREIGN KEY(last_account_id) REFERENCES owner_tg_accounts(id) ON DELETE SET NULL
);

CREATE INDEX IF NOT EXISTS idx_owner_outreach_contacted_owner ON owner_outreach_contacted(owner_tg_id, updated_at);
CREATE INDEX IF NOT EXISTS idx_owner_outreach_contacted_norm ON owner_outreach_contacted(owner_tg_id, telegram_norm);

CREATE TABLE IF NOT EXISTS owner_outreach_parsed_pool(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  owner_tg_id INTEGER NOT NULL,
  telegram TEXT NOT NULL,
  telegram_norm TEXT NOT NULL,
  direction TEXT NOT NULL DEFAULT 'python',
  name TEXT,
  resume_id TEXT,
  resume_link TEXT,
  status TEXT NOT NULL DEFAULT 'ready', -- ready, contacted
  first_seen_job_id INTEGER,
  last_seen_job_id INTEGER,
  first_seen_at TEXT NOT NULL,
  last_seen_at TEXT NOT NULL,
  last_contacted_at TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  UNIQUE(owner_tg_id, telegram_norm),
  FOREIGN KEY(first_seen_job_id) REFERENCES owner_hh_jobs(id) ON DELETE SET NULL,
  FOREIGN KEY(last_seen_job_id) REFERENCES owner_hh_jobs(id) ON DELETE SET NULL
);

CREATE INDEX IF NOT EXISTS idx_owner_outreach_pool_owner ON owner_outreach_parsed_pool(owner_tg_id, status, updated_at);
CREATE INDEX IF NOT EXISTS idx_owner_outreach_pool_direction ON owner_outreach_parsed_pool(owner_tg_id, direction, status, updated_at);

CREATE TABLE IF NOT EXISTS owner_outreach_events(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  job_id INTEGER,
  lead_id INTEGER,
  event_type TEXT NOT NULL,
  payload_json TEXT,
  created_at TEXT NOT NULL,
  FOREIGN KEY(job_id) REFERENCES owner_hh_jobs(id) ON DELETE SET NULL,
  FOREIGN KEY(lead_id) REFERENCES owner_outreach_leads(id) ON DELETE SET NULL
);

CREATE INDEX IF NOT EXISTS idx_owner_outreach_events_job ON owner_outreach_events(job_id, created_at);
CREATE INDEX IF NOT EXISTS idx_owner_outreach_events_lead ON owner_outreach_events(lead_id, created_at);

CREATE TABLE IF NOT EXISTS owner_channel_reactions(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  owner_tg_id INTEGER NOT NULL,
  account_id INTEGER,
  channel TEXT NOT NULL,
  message_id INTEGER NOT NULL,
  reaction TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'ok',
  error_text TEXT,
  payload_json TEXT,
  created_at TEXT NOT NULL,
  FOREIGN KEY(account_id) REFERENCES owner_tg_accounts(id) ON DELETE SET NULL
);

CREATE INDEX IF NOT EXISTS idx_owner_channel_reactions_owner ON owner_channel_reactions(owner_tg_id, created_at);
CREATE INDEX IF NOT EXISTS idx_owner_channel_reactions_message ON owner_channel_reactions(channel, message_id, created_at);

CREATE TABLE IF NOT EXISTS mock_pairs(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  direction_id INTEGER NOT NULL,
  student_a_id INTEGER NOT NULL,
  student_b_id INTEGER,
  status TEXT NOT NULL DEFAULT 'waiting', -- waiting, paired, scheduled, canceled, done
  start_at TEXT, -- ISO local datetime
  meet_link TEXT,
  announced_at TEXT,
  scheduled_by_user_id INTEGER,
  canceled_by_user_id INTEGER,
  cancel_reason TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY(direction_id) REFERENCES directions(id),
  FOREIGN KEY(student_a_id) REFERENCES students(id) ON DELETE CASCADE,
  FOREIGN KEY(student_b_id) REFERENCES students(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_mock_pairs_status ON mock_pairs(status, direction_id, updated_at);
CREATE INDEX IF NOT EXISTS idx_mock_pairs_student_a ON mock_pairs(student_a_id, status, updated_at);
CREATE INDEX IF NOT EXISTS idx_mock_pairs_student_b ON mock_pairs(student_b_id, status, updated_at);

CREATE TABLE IF NOT EXISTS mock_subscribers(
  user_id INTEGER PRIMARY KEY,
  enabled INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY(user_id) REFERENCES user_profiles(user_id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_mock_subscribers_enabled ON mock_subscribers(enabled, updated_at);

'''

def ensure_schema(conn: sqlite3.Connection) -> None:
    conn.executescript(SCHEMA_SQL)
    # lightweight migrations for existing db files
    def _has_col(table: str, col: str) -> bool:
        cols = conn.execute(f"PRAGMA table_info({table})").fetchall()
        return any(r[1] == col for r in cols)

    # students: owner fields
    for col, ddl in [
        ("owner_tg_id", "ALTER TABLE students ADD COLUMN owner_tg_id INTEGER"),
        ("owner_chat_id", "ALTER TABLE students ADD COLUMN owner_chat_id INTEGER"),
        ("owner_username", "ALTER TABLE students ADD COLUMN owner_username TEXT"),
        ("lead_source", "ALTER TABLE students ADD COLUMN lead_source TEXT"),
        ("hh_birth_date", "ALTER TABLE students ADD COLUMN hh_birth_date TEXT"),
        ("hh_location", "ALTER TABLE students ADD COLUMN hh_location TEXT"),
        ("hh_salary_min", "ALTER TABLE students ADD COLUMN hh_salary_min INTEGER"),
        ("hh_salary_comfort", "ALTER TABLE students ADD COLUMN hh_salary_comfort INTEGER"),
    ]:
        try:
            if not _has_col("students", col):
                conn.execute(ddl)
        except Exception:
            pass

    # payments: proof fields
    for col, ddl in [
        ("source", "ALTER TABLE payments ADD COLUMN source TEXT"),
        ("proof_file_id", "ALTER TABLE payments ADD COLUMN proof_file_id TEXT"),
        ("note", "ALTER TABLE payments ADD COLUMN note TEXT"),
    ]:
        try:
            if not _has_col("payments", col):
                conn.execute(ddl)
        except Exception:
            pass

    conn.commit()

    # events: enrich interview/meeting metadata
    for col, ddl in [
        ("owner_tg_id", "ALTER TABLE events ADD COLUMN owner_tg_id INTEGER"),
        ("call_kind", "ALTER TABLE events ADD COLUMN call_kind TEXT"),
        ("company", "ALTER TABLE events ADD COLUMN company TEXT"),
        ("role", "ALTER TABLE events ADD COLUMN role TEXT"),
        ("direction", "ALTER TABLE events ADD COLUMN direction TEXT"),
    ]:
        try:
            if not _has_col("events", col):
                conn.execute(ddl)
        except Exception:
            pass

    try:
        conn.execute("CREATE INDEX IF NOT EXISTS idx_events_owner_kind ON events(owner_tg_id, call_kind, active, start_at)")
    except Exception:
        pass

    conn.commit()

    # student_postpay: student notification controls
    for col, ddl in [
        ("student_notify_enabled", "ALTER TABLE student_postpay ADD COLUMN student_notify_enabled INTEGER NOT NULL DEFAULT 1"),
        ("student_notify_repeat_min", "ALTER TABLE student_postpay ADD COLUMN student_notify_repeat_min INTEGER"),
        ("student_next_notify_date", "ALTER TABLE student_postpay ADD COLUMN student_next_notify_date TEXT"),
    ]:
        try:
            if not _has_col("student_postpay", col):
                conn.execute(ddl)
        except Exception:
            pass

    # auto broadcast rules: serialized template payload (sender-agnostic delivery)
    for col, ddl in [
        ("template_payload_json", "ALTER TABLE auto_broadcast_rules ADD COLUMN template_payload_json TEXT"),
        ("read_ack_enabled", "ALTER TABLE auto_broadcast_rules ADD COLUMN read_ack_enabled INTEGER NOT NULL DEFAULT 0"),
    ]:
        try:
            if not _has_col("auto_broadcast_rules", col):
                conn.execute(ddl)
        except Exception:
            pass

    # broadcast deliveries: read acknowledgements
    for col, ddl in [
        ("read_at", "ALTER TABLE broadcast_deliveries ADD COLUMN read_at TEXT"),
        ("read_by_user_id", "ALTER TABLE broadcast_deliveries ADD COLUMN read_by_user_id INTEGER"),
    ]:
        try:
            if not _has_col("broadcast_deliveries", col):
                conn.execute(ddl)
        except Exception:
            pass
    try:
        conn.execute("CREATE INDEX IF NOT EXISTS idx_deliveries_read ON broadcast_deliveries(campaign_id, read_at)")
    except Exception:
        pass

    # user_profiles: keep last known Telegram username for admin-friendly stats listing
    for col, ddl in [
        ("username", "ALTER TABLE user_profiles ADD COLUMN username TEXT"),
    ]:
        try:
            if not _has_col("user_profiles", col):
                conn.execute(ddl)
        except Exception:
            pass

    # material_steps: block grouping for channel-based roadmap
    for col, ddl in [
        ("block_number", "ALTER TABLE material_steps ADD COLUMN block_number INTEGER NOT NULL DEFAULT 0"),
        ("block_title", "ALTER TABLE material_steps ADD COLUMN block_title TEXT NOT NULL DEFAULT ''"),
    ]:
        try:
            if not _has_col("material_steps", col):
                conn.execute(ddl)
        except Exception:
            pass

    # checkout_payments: keep old databases forward-compatible
    for col, ddl in [
        ("provider", "ALTER TABLE checkout_payments ADD COLUMN provider TEXT NOT NULL DEFAULT 'yookassa'"),
        ("provider_payment_id", "ALTER TABLE checkout_payments ADD COLUMN provider_payment_id TEXT"),
        ("metadata_json", "ALTER TABLE checkout_payments ADD COLUMN metadata_json TEXT"),
        ("provider_payload_json", "ALTER TABLE checkout_payments ADD COLUMN provider_payload_json TEXT"),
        ("action_done", "ALTER TABLE checkout_payments ADD COLUMN action_done INTEGER NOT NULL DEFAULT 0"),
        ("action_done_at", "ALTER TABLE checkout_payments ADD COLUMN action_done_at TEXT"),
        ("action_note", "ALTER TABLE checkout_payments ADD COLUMN action_note TEXT"),
        ("paid_at", "ALTER TABLE checkout_payments ADD COLUMN paid_at TEXT"),
    ]:
        try:
            if not _has_col("checkout_payments", col):
                conn.execute(ddl)
        except Exception:
            pass

    # interview_helper_licenses: payload and state columns
    for col, ddl in [
        ("payload_json", "ALTER TABLE interview_helper_licenses ADD COLUMN payload_json TEXT"),
        ("enabled", "ALTER TABLE interview_helper_licenses ADD COLUMN enabled INTEGER NOT NULL DEFAULT 1"),
    ]:
        try:
            if not _has_col("interview_helper_licenses", col):
                conn.execute(ddl)
        except Exception:
            pass

    # bot_admins: role grade (full / limited)
    for col, ddl in [
        ("grade", "ALTER TABLE bot_admins ADD COLUMN grade TEXT NOT NULL DEFAULT 'full'"),
    ]:
        try:
            if not _has_col("bot_admins", col):
                conn.execute(ddl)
        except Exception:
            pass
    try:
        conn.execute("UPDATE bot_admins SET grade='full' WHERE grade IS NULL OR trim(grade)=''")
    except Exception:
        pass

    # owner_hh_jobs: enrich campaign fields
    for col, ddl in [
        ("direction", "ALTER TABLE owner_hh_jobs ADD COLUMN direction TEXT NOT NULL DEFAULT 'python'"),
        ("script_version", "ALTER TABLE owner_hh_jobs ADD COLUMN script_version TEXT NOT NULL DEFAULT 'script4'"),
        ("ai_enabled", "ALTER TABLE owner_hh_jobs ADD COLUMN ai_enabled INTEGER NOT NULL DEFAULT 0"),
    ]:
        try:
            if not _has_col("owner_hh_jobs", col):
                conn.execute(ddl)
        except Exception:
            pass

    # enrollment_contracts: keep OkiDoki raw payloads for profile prefill
    for col, ddl in [
        ("okidoki_request_json", "ALTER TABLE enrollment_contracts ADD COLUMN okidoki_request_json TEXT"),
        ("okidoki_response_json", "ALTER TABLE enrollment_contracts ADD COLUMN okidoki_response_json TEXT"),
    ]:
        try:
            if not _has_col("enrollment_contracts", col):
                conn.execute(ddl)
        except Exception:
            pass

    # owner_tg_accounts: account role/type (standard / polygon)
    for col, ddl in [
        ("account_type", "ALTER TABLE owner_tg_accounts ADD COLUMN account_type TEXT NOT NULL DEFAULT 'standard'"),
    ]:
        try:
            if not _has_col("owner_tg_accounts", col):
                conn.execute(ddl)
        except Exception:
            pass
    try:
        conn.execute(
            "UPDATE owner_tg_accounts SET account_type='standard' "
            "WHERE account_type IS NULL OR trim(account_type)=''"
        )
        conn.execute(
            "UPDATE owner_tg_accounts SET account_type='standard' "
            "WHERE lower(trim(account_type)) NOT IN ('standard','polygon')"
        )
        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_owner_tg_accounts_type "
            "ON owner_tg_accounts(owner_tg_id, account_type, is_active, id)"
        )
    except Exception:
        pass

    conn.commit()
