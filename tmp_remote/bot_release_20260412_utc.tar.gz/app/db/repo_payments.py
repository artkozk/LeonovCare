from __future__ import annotations
import sqlite3
from app.services.timeutils import now, iso

def add_payment(
    conn: sqlite3.Connection,
    student_id: int,
    pay_type: str,
    amount: int,
    pay_date: str,
    tz: str,
    source: str | None = None,
    proof_file_id: str | None = None,
    note: str | None = None,
) -> int:
    ts = iso(now(tz))
    cur = conn.execute(
        "INSERT INTO payments(student_id, pay_type, amount, pay_date, source, proof_file_id, note, created_at) "
        "VALUES(?,?,?,?,?,?,?,?)",
        (student_id, pay_type, int(amount), pay_date, source, proof_file_id, note, ts)
    )
    conn.commit()
    return int(cur.lastrowid)

def list_payments(conn: sqlite3.Connection, student_id: int, limit: int=30) -> list[sqlite3.Row]:
    return conn.execute(
        "SELECT * FROM payments WHERE student_id=? "
        "ORDER BY "
        "CASE "
        "  WHEN pay_date IS NULL OR trim(pay_date)='' THEN substr(created_at,1,10) "
        "  WHEN length(pay_date)=10 AND substr(pay_date,3,1)='.' THEN substr(pay_date,7,4)||'-'||substr(pay_date,4,2)||'-'||substr(pay_date,1,2) "
        "  WHEN length(pay_date)=10 AND substr(pay_date,5,1)='-' THEN pay_date "
        "  ELSE substr(created_at,1,10) "
        "END DESC, created_at DESC, id DESC "
        "LIMIT ?",
        (student_id, limit)
    ).fetchall()


def last_payment(conn: sqlite3.Connection, student_id: int) -> sqlite3.Row | None:
    rows = list_payments(conn, int(student_id), limit=1)
    return rows[0] if rows else None

def sum_payments(conn: sqlite3.Connection, student_id: int, pay_type: str) -> int:
    row = conn.execute("SELECT COALESCE(SUM(amount),0) AS s FROM payments WHERE student_id=? AND pay_type=?",
                       (student_id, pay_type)).fetchone()
    return int(row["s"]) if row else 0

def sum_all(conn: sqlite3.Connection) -> int:
    row = conn.execute("SELECT COALESCE(SUM(amount),0) AS s FROM payments").fetchone()
    return int(row["s"]) if row else 0
