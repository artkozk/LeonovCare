from __future__ import annotations
import sqlite3
from typing import Optional
from app.services.timeutils import now, iso, add_days

def exists_pending(conn: sqlite3.Connection, related_table: str, related_id: int, alert_type: str, chat_id: int | None = None) -> bool:
    row = conn.execute(
        "SELECT 1 FROM alerts WHERE status='PENDING' AND related_table=? AND related_id=? AND alert_type=? "
        + (" AND chat_id=?" if chat_id is not None else "") +
        " LIMIT 1",
        (related_table, related_id, alert_type, int(chat_id)) if chat_id is not None else (related_table, related_id, alert_type)
    ).fetchone()
    return row is not None

def create(conn: sqlite3.Connection, tz: str, chat_id: int, alert_type: str, related_table: str, related_id: int,
           student_id: int | None, title: str, body: str, due_at_iso: str, retry_after_min: int) -> int:
    ts = iso(now(tz))
    cur = conn.execute(
        "INSERT INTO alerts(alert_type, related_table, related_id, student_id, title, body, due_at, status, message_id, chat_id, retry_after_min, next_retry_at, created_at, updated_at) "
        "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (alert_type, related_table, related_id, student_id, title, body, due_at_iso, "PENDING", None, chat_id, int(retry_after_min), None, ts, ts)
    )
    conn.commit()
    return int(cur.lastrowid)

def list_to_send(conn: sqlite3.Connection, now_iso: str, chat_id: int) -> list[sqlite3.Row]:
    q = '''
    SELECT * FROM alerts
    WHERE status='PENDING' AND chat_id=?
      AND due_at <= ?
      AND (next_retry_at IS NULL OR next_retry_at <= ?)
    ORDER BY due_at
    LIMIT 20
    '''
    return conn.execute(q, (chat_id, now_iso, now_iso)).fetchall()


def list_chat_ids_to_send(conn: sqlite3.Connection, now_iso: str, limit: int = 50) -> list[int]:
    rows = conn.execute(
        "SELECT DISTINCT chat_id FROM alerts WHERE status='PENDING' AND due_at <= ? AND (next_retry_at IS NULL OR next_retry_at <= ?) LIMIT ?",
        (now_iso, now_iso, int(limit)),
    ).fetchall()
    return [int(r[0]) for r in rows]

def is_pending(conn: sqlite3.Connection, alert_id: int, chat_id: int | None = None) -> bool:
    q = "SELECT 1 FROM alerts WHERE id=? AND status='PENDING'"
    params: tuple[object, ...] = (int(alert_id),)
    if chat_id is not None:
        q += " AND chat_id=?"
        params = (int(alert_id), int(chat_id))
    row = conn.execute(q + " LIMIT 1", params).fetchone()
    return row is not None

def update_after_send(conn: sqlite3.Connection, alert_id: int, tz: str, message_id: int, next_retry_at_iso: str) -> bool:
    cur = conn.execute(
        "UPDATE alerts SET message_id=?, next_retry_at=?, updated_at=? WHERE id=? AND status='PENDING'",
        (message_id, next_retry_at_iso, iso(now(tz)), alert_id)
    )
    conn.commit()
    return int(cur.rowcount or 0) > 0

def mark_seen(conn: sqlite3.Connection, alert_id: int, tz: str) -> None:
    conn.execute(
        "UPDATE alerts SET status='SEEN', updated_at=? WHERE id=?",
        (iso(now(tz)), alert_id)
    )
    conn.commit()

def snooze(conn: sqlite3.Connection, alert_id: int, tz: str, next_retry_at_iso: str) -> bool:
    cur = conn.execute(
        "UPDATE alerts SET next_retry_at=?, updated_at=? WHERE id=? AND status='PENDING'",
        (next_retry_at_iso, iso(now(tz)), alert_id)
    )
    conn.commit()
    return int(cur.rowcount or 0) > 0

def get(conn: sqlite3.Connection, alert_id: int) -> Optional[sqlite3.Row]:
    return conn.execute("SELECT * FROM alerts WHERE id=?", (alert_id,)).fetchone()
