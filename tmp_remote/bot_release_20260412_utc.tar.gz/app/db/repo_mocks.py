from __future__ import annotations

import sqlite3
from typing import Optional

from app.services.timeutils import iso, now


ACTIVE_STATUSES = ("waiting", "paired", "scheduled")


def _pair_select_sql() -> str:
    return (
        "SELECT p.*, "
        "d.name AS direction_name, "
        "a.fio AS student_a_fio, a.username AS student_a_username, a.owner_tg_id AS student_a_owner_tg_id, "
        "b.fio AS student_b_fio, b.username AS student_b_username, b.owner_tg_id AS student_b_owner_tg_id "
        "FROM mock_pairs p "
        "LEFT JOIN directions d ON d.id=p.direction_id "
        "LEFT JOIN students a ON a.id=p.student_a_id "
        "LEFT JOIN students b ON b.id=p.student_b_id "
    )


def get_pair(conn: sqlite3.Connection, pair_id: int) -> Optional[sqlite3.Row]:
    return conn.execute(_pair_select_sql() + "WHERE p.id=? LIMIT 1", (int(pair_id),)).fetchone()


def get_active_pair_for_student(conn: sqlite3.Connection, student_id: int) -> Optional[sqlite3.Row]:
    q = (
        _pair_select_sql()
        + "WHERE p.status IN ('waiting','paired','scheduled') "
        + "AND (p.student_a_id=? OR p.student_b_id=?) "
        + "ORDER BY p.id DESC LIMIT 1"
    )
    return conn.execute(q, (int(student_id), int(student_id))).fetchone()


def find_waiting_pair(conn: sqlite3.Connection, direction_id: int, exclude_student_id: int) -> Optional[sqlite3.Row]:
    q = (
        _pair_select_sql()
        + "WHERE p.status='waiting' AND p.direction_id=? AND p.student_b_id IS NULL AND p.student_a_id<>? "
        + "ORDER BY p.created_at ASC, p.id ASC LIMIT 1"
    )
    return conn.execute(q, (int(direction_id), int(exclude_student_id))).fetchone()


def create_waiting_pair(conn: sqlite3.Connection, tz: str, direction_id: int, student_id: int) -> int:
    ts = iso(now(tz))
    cur = conn.execute(
        "INSERT INTO mock_pairs("
        "direction_id, student_a_id, student_b_id, status, created_at, updated_at"
        ") VALUES(?,?,?,?,?,?)",
        (int(direction_id), int(student_id), None, "waiting", ts, ts),
    )
    conn.commit()
    return int(cur.lastrowid)


def attach_partner(conn: sqlite3.Connection, tz: str, pair_id: int, partner_student_id: int) -> bool:
    ts = iso(now(tz))
    cur = conn.execute(
        "UPDATE mock_pairs SET student_b_id=?, status='paired', updated_at=? "
        "WHERE id=? AND status='waiting' AND student_b_id IS NULL",
        (int(partner_student_id), ts, int(pair_id)),
    )
    conn.commit()
    return int(cur.rowcount or 0) > 0


def set_start_time(conn: sqlite3.Connection, tz: str, pair_id: int, start_at_iso: str, by_user_id: int) -> bool:
    ts = iso(now(tz))
    cur = conn.execute(
        "UPDATE mock_pairs SET start_at=?, status=CASE WHEN status='canceled' THEN status ELSE 'scheduled' END, "
        "announced_at=NULL, scheduled_by_user_id=?, updated_at=? "
        "WHERE id=? AND status IN ('paired','scheduled')",
        (str(start_at_iso), int(by_user_id), ts, int(pair_id)),
    )
    conn.commit()
    return int(cur.rowcount or 0) > 0


def set_meet_link(conn: sqlite3.Connection, tz: str, pair_id: int, meet_link: str, by_user_id: int) -> bool:
    ts = iso(now(tz))
    cur = conn.execute(
        "UPDATE mock_pairs SET meet_link=?, status=CASE WHEN status='canceled' THEN status ELSE 'scheduled' END, "
        "announced_at=NULL, scheduled_by_user_id=?, updated_at=? "
        "WHERE id=? AND status IN ('paired','scheduled')",
        (str(meet_link).strip(), int(by_user_id), ts, int(pair_id)),
    )
    conn.commit()
    return int(cur.rowcount or 0) > 0


def cancel_pair(conn: sqlite3.Connection, tz: str, pair_id: int, by_user_id: int, reason: str | None = None) -> bool:
    ts = iso(now(tz))
    cur = conn.execute(
        "UPDATE mock_pairs SET status='canceled', canceled_by_user_id=?, cancel_reason=?, updated_at=? "
        "WHERE id=? AND status IN ('waiting','paired','scheduled')",
        (int(by_user_id), (reason or "").strip() or None, ts, int(pair_id)),
    )
    conn.commit()
    return int(cur.rowcount or 0) > 0


def mark_announced(conn: sqlite3.Connection, tz: str, pair_id: int) -> None:
    ts = iso(now(tz))
    conn.execute("UPDATE mock_pairs SET announced_at=?, updated_at=? WHERE id=?", (ts, ts, int(pair_id)))
    conn.commit()


def is_subscribed(conn: sqlite3.Connection, user_id: int) -> bool:
    row = conn.execute("SELECT enabled FROM mock_subscribers WHERE user_id=? LIMIT 1", (int(user_id),)).fetchone()
    return bool(int(row["enabled"] or 0)) if row else False


def set_subscribed(conn: sqlite3.Connection, tz: str, user_id: int, enabled: bool) -> None:
    ts = iso(now(tz))
    conn.execute(
        "INSERT INTO mock_subscribers(user_id, enabled, created_at, updated_at) VALUES(?,?,?,?) "
        "ON CONFLICT(user_id) DO UPDATE SET enabled=excluded.enabled, updated_at=excluded.updated_at",
        (int(user_id), 1 if enabled else 0, ts, ts),
    )
    conn.commit()


def list_subscribed_student_user_ids(conn: sqlite3.Connection) -> list[int]:
    rows = conn.execute(
        "SELECT ms.user_id "
        "FROM mock_subscribers ms "
        "JOIN students s ON s.owner_tg_id=ms.user_id AND s.archived=0 "
        "WHERE ms.enabled=1 "
        "GROUP BY ms.user_id "
        "ORDER BY ms.user_id"
    ).fetchall()
    return [int(r["user_id"]) for r in rows]
