from __future__ import annotations

import json
import re
import sqlite3
from urllib.parse import urlparse

from app.services.timeutils import now, iso


def get_by_owner(conn: sqlite3.Connection, owner_tg_id: int) -> sqlite3.Row | None:
    return conn.execute(
        "SELECT * FROM enrollment_contracts WHERE owner_tg_id=? LIMIT 1",
        (int(owner_tg_id),),
    ).fetchone()


def _extract_contract_id(contract_url: str | None) -> str | None:
    raw = str(contract_url or "").strip()
    if not raw:
        return None
    try:
        path = urlparse(raw).path or ""
    except Exception:
        path = raw
    m = re.search(r"/contract/([A-Za-z0-9_-]{8,64})", path)
    if not m:
        return None
    return m.group(1)


def find_by_contract_url(
    conn: sqlite3.Connection,
    contract_url: str,
    owner_tg_id: int | None = None,
) -> sqlite3.Row | None:
    """
    Ищет контракт OkiDoki по ссылке:
    1) точное совпадение sign_url;
    2) по contract id из URL внутри sign_url / сохранённых payload JSON.
    Сначала ищет в рамках owner_tg_id (если передан), затем глобально.
    """
    url = str(contract_url or "").strip()
    if not url:
        return None

    def _query(where_sql: str, params: tuple) -> sqlite3.Row | None:
        q = (
            "SELECT * FROM enrollment_contracts "
            f"WHERE {where_sql} "
            "ORDER BY id DESC LIMIT 1"
        )
        return conn.execute(q, params).fetchone()

    if owner_tg_id is not None:
        row = _query("owner_tg_id=? AND sign_url=?", (int(owner_tg_id), url))
        if row:
            return row
    row = _query("sign_url=?", (url,))
    if row:
        return row

    contract_id = _extract_contract_id(url)
    if not contract_id:
        return None
    like = f"%{contract_id}%"
    if owner_tg_id is not None:
        row = _query(
            "owner_tg_id=? AND (sign_url LIKE ? OR okidoki_request_json LIKE ? OR okidoki_response_json LIKE ?)",
            (int(owner_tg_id), like, like, like),
        )
        if row:
            return row
    return _query(
        "(sign_url LIKE ? OR okidoki_request_json LIKE ? OR okidoki_response_json LIKE ?)",
        (like, like, like),
    )


def create_once(
    conn: sqlite3.Connection,
    tz: str,
    owner_tg_id: int,
    owner_chat_id: int | None,
    level_key: str,
    track_key: str,
    track_title: str,
    tariff_key: str,
    tariff_title: str,
    tariff_price: str,
    contract_file_path: str | None,
    sign_url: str | None,
    okidoki_request_json: str | dict | None = None,
    okidoki_response_json: str | dict | None = None,
    status: str = "sent",
    note: str | None = None,
) -> int | None:
    ts = iso(now(tz))

    def _json_dump_or_none(value: str | dict | None) -> str | None:
        if value is None:
            return None
        if isinstance(value, str):
            raw = value.strip()
            return raw or None
        try:
            raw = json.dumps(value, ensure_ascii=False)
            return raw.strip() or None
        except Exception:
            return None

    cur = conn.execute(
        "INSERT OR IGNORE INTO enrollment_contracts("
        "owner_tg_id, owner_chat_id, level_key, track_key, track_title, tariff_key, tariff_title, tariff_price, "
        "contract_file_path, sign_url, okidoki_request_json, okidoki_response_json, status, note, created_at, updated_at"
        ") VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (
            int(owner_tg_id),
            int(owner_chat_id) if owner_chat_id is not None else None,
            (level_key or "").strip(),
            (track_key or "").strip(),
            (track_title or "").strip(),
            (tariff_key or "").strip(),
            (tariff_title or "").strip(),
            (tariff_price or "").strip(),
            (contract_file_path or "").strip() or None,
            (sign_url or "").strip() or None,
            _json_dump_or_none(okidoki_request_json),
            _json_dump_or_none(okidoki_response_json),
            (status or "sent").strip(),
            (note or "").strip() or None,
            ts,
            ts,
        ),
    )
    conn.commit()
    if int(cur.rowcount or 0) <= 0:
        return None
    return int(cur.lastrowid)


def set_status(conn: sqlite3.Connection, tz: str, owner_tg_id: int, status: str, note: str | None = None) -> None:
    ts = iso(now(tz))
    conn.execute(
        "UPDATE enrollment_contracts SET status=?, note=COALESCE(?, note), updated_at=? WHERE owner_tg_id=?",
        ((status or "").strip(), (note or "").strip() or None, ts, int(owner_tg_id)),
    )
    conn.commit()
