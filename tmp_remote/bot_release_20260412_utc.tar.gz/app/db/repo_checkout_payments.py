from __future__ import annotations

import json
import sqlite3
from typing import Any

from app.services.timeutils import iso, now

STATUS_PENDING = "PENDING"
STATUS_WAITING_CAPTURE = "WAITING_FOR_CAPTURE"
STATUS_SUCCEEDED = "SUCCEEDED"
STATUS_CANCELED = "CANCELED"
STATUS_FAILED = "FAILED"


def _ts(tz: str) -> str:
    return iso(now(tz))


def _status_norm(status: str | None) -> str:
    val = str(status or "").strip().upper()
    if val in {STATUS_PENDING, STATUS_WAITING_CAPTURE, STATUS_SUCCEEDED, STATUS_CANCELED, STATUS_FAILED}:
        return val
    return STATUS_PENDING


def _json_dump(value: dict[str, Any] | None) -> str:
    return json.dumps(value or {}, ensure_ascii=False)


def _json_load(raw: str | None) -> dict[str, Any]:
    if not raw:
        return {}
    try:
        data = json.loads(raw)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def create(
    conn: sqlite3.Connection,
    tz: str,
    owner_tg_id: int,
    owner_chat_id: int | None,
    owner_username: str | None,
    req_type: str,
    service_key: str,
    service_title: str,
    purpose: str,
    amount: int,
    currency: str,
    provider_payment_id: str,
    provider: str = "yookassa",
    idempotence_key: str | None = None,
    status: str = STATUS_PENDING,
    confirmation_url: str | None = None,
    metadata: dict[str, Any] | None = None,
    provider_payload: dict[str, Any] | None = None,
) -> int:
    ts = _ts(tz)
    cur = conn.execute(
        "INSERT INTO checkout_payments("
        "owner_tg_id, owner_chat_id, owner_username, req_type, service_key, service_title, purpose, amount, currency, "
        "provider, provider_payment_id, idempotence_key, status, confirmation_url, metadata_json, provider_payload_json, "
        "created_at, updated_at, paid_at"
        ") VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (
            int(owner_tg_id),
            int(owner_chat_id) if owner_chat_id is not None else None,
            (owner_username or "").strip().lstrip("@") or None,
            (req_type or "").strip(),
            (service_key or "").strip(),
            (service_title or "").strip(),
            (purpose or "").strip(),
            max(int(amount or 0), 0),
            (currency or "RUB").strip().upper() or "RUB",
            (provider or "yookassa").strip().lower() or "yookassa",
            (provider_payment_id or "").strip(),
            (idempotence_key or "").strip() or None,
            _status_norm(status),
            (confirmation_url or "").strip() or None,
            _json_dump(metadata),
            _json_dump(provider_payload),
            ts,
            ts,
            None,
        ),
    )
    conn.commit()
    return int(cur.lastrowid)


def get(conn: sqlite3.Connection, row_id: int) -> sqlite3.Row | None:
    return conn.execute(
        "SELECT * FROM checkout_payments WHERE id=? LIMIT 1",
        (int(row_id),),
    ).fetchone()


def get_by_provider_payment_id(conn: sqlite3.Connection, provider_payment_id: str) -> sqlite3.Row | None:
    return conn.execute(
        "SELECT * FROM checkout_payments WHERE provider_payment_id=? LIMIT 1",
        ((provider_payment_id or "").strip(),),
    ).fetchone()


def list_pending(conn: sqlite3.Connection, limit: int = 50) -> list[sqlite3.Row]:
    return conn.execute(
        "SELECT * FROM checkout_payments "
        "WHERE status IN (?, ?) AND action_done=0 "
        "ORDER BY created_at ASC LIMIT ?",
        (STATUS_PENDING, STATUS_WAITING_CAPTURE, max(1, int(limit))),
    ).fetchall()


def set_status(
    conn: sqlite3.Connection,
    tz: str,
    row_id: int,
    status: str,
    provider_payload: dict[str, Any] | None = None,
    confirmation_url: str | None = None,
    paid_at: str | None = None,
) -> None:
    ts = _ts(tz)
    row = get(conn, row_id)
    if not row:
        return
    next_payload = provider_payload if isinstance(provider_payload, dict) else _json_load(row["provider_payload_json"])
    next_url = (confirmation_url or "").strip() or (row["confirmation_url"] or None)
    status_norm = _status_norm(status)
    if status_norm == STATUS_SUCCEEDED:
        paid_value = (paid_at or "").strip() or (row["paid_at"] or ts)
    else:
        paid_value = row["paid_at"]
    conn.execute(
        "UPDATE checkout_payments SET status=?, provider_payload_json=?, confirmation_url=?, updated_at=?, paid_at=? WHERE id=?",
        (
            status_norm,
            _json_dump(next_payload),
            next_url,
            ts,
            paid_value,
            int(row_id),
        ),
    )
    conn.commit()


def mark_action_done(conn: sqlite3.Connection, tz: str, row_id: int, note: str | None = None) -> None:
    ts = _ts(tz)
    conn.execute(
        "UPDATE checkout_payments SET action_done=1, action_done_at=?, action_note=?, updated_at=? WHERE id=?",
        (ts, (note or "").strip() or None, ts, int(row_id)),
    )
    conn.commit()


def metadata(row: sqlite3.Row | None) -> dict[str, Any]:
    if not row:
        return {}
    return _json_load(row["metadata_json"] if "metadata_json" in row.keys() else None)


def provider_payload(row: sqlite3.Row | None) -> dict[str, Any]:
    if not row:
        return {}
    return _json_load(row["provider_payload_json"] if "provider_payload_json" in row.keys() else None)
