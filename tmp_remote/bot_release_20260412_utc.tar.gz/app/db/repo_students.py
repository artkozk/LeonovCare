from __future__ import annotations
import sqlite3
from typing import Any, Optional
from app.services.timeutils import now, iso

TARIFF_LABELS = {
    "pre": "Только предоплата",
    "post": "Только постоплата",
    "pre_post": "Предоплата + постоплата",
}

def tariff_label(code: str) -> str:
    return TARIFF_LABELS.get(code, code)

def list_directions(conn: sqlite3.Connection) -> list[sqlite3.Row]:
    return conn.execute("SELECT * FROM directions ORDER BY sort, name").fetchall()

def list_stages(conn: sqlite3.Connection) -> list[sqlite3.Row]:
    return conn.execute("SELECT * FROM stages ORDER BY sort, name").fetchall()


def _normalize_fio(value: str | None) -> str | None:
    raw = " ".join(str(value or "").strip().split())
    if not raw:
        return None
    return raw.lower()


def _normalize_username(value: str | None) -> str | None:
    raw = str(value or "").strip()
    if not raw:
        return None
    return raw.lstrip("@").lower()


def find_duplicate_student(
    conn: sqlite3.Connection,
    fio: str | None = None,
    username: str | None = None,
    exclude_student_id: int | None = None,
) -> Optional[sqlite3.Row]:
    fio_norm = _normalize_fio(fio)
    uname_norm = _normalize_username(username)

    conditions: list[str] = []
    args: list[Any] = []
    if fio_norm:
        conditions.append("lower(trim(s.fio))=?")
        args.append(fio_norm)
    if uname_norm:
        conditions.append("(s.username IS NOT NULL AND lower(trim(ltrim(s.username, '@')))=?)")
        args.append(uname_norm)
    if not conditions:
        return None

    q = (
        "SELECT s.id, s.fio, s.username, s.archived "
        "FROM students s "
        "WHERE (" + " OR ".join(conditions) + ")"
    )
    if exclude_student_id is not None:
        q += " AND s.id <> ?"
        args.append(int(exclude_student_id))
    q += " ORDER BY s.archived ASC, s.id ASC LIMIT 1"
    return conn.execute(q, tuple(args)).fetchone()

def create_student(conn: sqlite3.Connection, tz: str, **fields) -> int:
    ts = iso(now(tz))
    keys = ["fio","username","direction_id","stage_id","tariff","comment","join_date",
            "interviews_active","offer_amount","contract_url","hh_phone","hh_email","hh_password",
            "hh_birth_date","hh_location","hh_salary_min","hh_salary_comfort","lead_source",
            "archived","archive_failed","created_at","updated_at"]
    data = {k: fields.get(k) for k in keys}
    data["created_at"]=ts
    data["updated_at"]=ts
    cols=",".join(keys)
    qmarks=",".join(["?"]*len(keys))
    cur = conn.execute(f"INSERT INTO students({cols}) VALUES({qmarks})", [data[k] for k in keys])
    conn.commit()
    return int(cur.lastrowid)

def update_student(conn: sqlite3.Connection, student_id: int, tz: str, **fields) -> None:
    if not fields:
        return
    ts = iso(now(tz))
    fields["updated_at"]=ts
    parts=[]
    vals=[]
    for k,v in fields.items():
        parts.append(f"{k}=?")
        vals.append(v)
    vals.append(student_id)
    conn.execute(f"UPDATE students SET {', '.join(parts)} WHERE id=?", vals)
    conn.commit()

def get_student(conn: sqlite3.Connection, student_id: int) -> Optional[sqlite3.Row]:
    q = '''
    SELECT s.*, d.name AS direction_name, st.name AS stage_name
    FROM students s
    LEFT JOIN directions d ON d.id=s.direction_id
    LEFT JOIN stages st ON st.id=s.stage_id
    WHERE s.id=?
    '''
    return conn.execute(q, (student_id,)).fetchone()


def get_by_owner(conn: sqlite3.Connection, owner_tg_id: int) -> Optional[sqlite3.Row]:
    q = '''
    SELECT s.*, d.name AS direction_name, st.name AS stage_name
    FROM students s
    LEFT JOIN directions d ON d.id=s.direction_id
    LEFT JOIN stages st ON st.id=s.stage_id
    WHERE s.owner_tg_id=? AND s.archived=0
    ORDER BY s.id DESC
    LIMIT 1
    '''
    return conn.execute(q, (int(owner_tg_id),)).fetchone()


def get_latest_by_owner(conn: sqlite3.Connection, owner_tg_id: int) -> Optional[sqlite3.Row]:
    q = '''
    SELECT s.*, d.name AS direction_name, st.name AS stage_name
    FROM students s
    LEFT JOIN directions d ON d.id=s.direction_id
    LEFT JOIN stages st ON st.id=s.stage_id
    WHERE s.owner_tg_id=?
    ORDER BY s.id DESC
    LIMIT 1
    '''
    return conn.execute(q, (int(owner_tg_id),)).fetchone()


def set_owner(conn: sqlite3.Connection, tz: str, student_id: int, owner_tg_id: int, owner_chat_id: int, owner_username: str | None) -> None:
    ts = iso(now(tz))
    conn.execute(
        "UPDATE students SET owner_tg_id=?, owner_chat_id=?, owner_username=?, updated_at=? WHERE id=?",
        (int(owner_tg_id), int(owner_chat_id), owner_username, ts, int(student_id)),
    )
    conn.commit()

def search_students(conn: sqlite3.Connection, text: str, archived: bool=False, limit: int=20) -> list[sqlite3.Row]:
    t = (text or "").strip()
    if not t:
        return []
    like = f"%{t}%"
    q = '''
    SELECT s.id, s.fio, s.username, d.name AS direction_name, st.name AS stage_name
    FROM students s
    LEFT JOIN directions d ON d.id=s.direction_id
    LEFT JOIN stages st ON st.id=s.stage_id
    WHERE s.archived=?
      AND (s.fio LIKE ? OR s.username LIKE ? OR s.hh_phone LIKE ? OR s.comment LIKE ?)
    ORDER BY s.fio
    LIMIT ?
    '''
    return conn.execute(q, (1 if archived else 0, like, like, like, like, limit)).fetchall()

def _join_date_sort_expr(alias: str = "s") -> str:
    return (
        f"CASE "
        f"WHEN {alias}.join_date IS NULL OR trim({alias}.join_date)='' THEN '' "
        f"WHEN length({alias}.join_date)=10 AND substr({alias}.join_date,3,1)='.' "
        f"THEN substr({alias}.join_date,7,4)||'-'||substr({alias}.join_date,4,2)||'-'||substr({alias}.join_date,1,2) "
        f"WHEN length({alias}.join_date)=10 AND substr({alias}.join_date,5,1)='-' "
        f"THEN {alias}.join_date "
        f"ELSE '' END"
    )


def _students_order_sql(sort_mode: str | None) -> str:
    mode = str(sort_mode or "").strip().lower()
    join_expr = _join_date_sort_expr("s")
    if mode == "join_desc":
        return f"CASE WHEN {join_expr}='' THEN 1 ELSE 0 END, {join_expr} DESC, s.id DESC"
    if mode == "join_asc":
        return f"CASE WHEN {join_expr}='' THEN 1 ELSE 0 END, {join_expr} ASC, s.id ASC"
    if mode == "pay_desc":
        return (
            "CASE WHEN p.last_pay_date_key IS NULL OR p.last_pay_date_key='' THEN 1 ELSE 0 END, "
            "p.last_pay_date_key DESC, p.last_pay_created_at DESC, s.id DESC"
        )
    if mode == "pay_asc":
        return (
            "CASE WHEN p.last_pay_date_key IS NULL OR p.last_pay_date_key='' THEN 1 ELSE 0 END, "
            "p.last_pay_date_key ASC, p.last_pay_created_at ASC, s.id ASC"
        )
    return "d.sort, st.sort, s.fio"


def list_students(conn: sqlite3.Connection, filters: dict, page: int, page_size: int=5) -> tuple[list[sqlite3.Row], bool, bool]:
    archived = 1 if filters.get("archived") else 0
    where = ["s.archived=?"]
    args=[archived]
    if filters.get("direction_id"):
        where.append("s.direction_id=?")
        args.append(filters["direction_id"])
    if filters.get("stage_id"):
        where.append("s.stage_id=?")
        args.append(filters["stage_id"])
    if filters.get("tariff"):
        where.append("s.tariff=?")
        args.append(filters["tariff"])
    if filters.get("offer") == "yes":
        where.append("s.offer_amount IS NOT NULL")
    if filters.get("offer") == "no":
        where.append("s.offer_amount IS NULL")
    where_sql = " AND ".join(where)
    offset = max(page,0) * page_size
    q = f'''
    SELECT
      s.id,
      s.fio,
      s.username,
      s.join_date,
      d.name AS direction_name,
      st.name AS stage_name,
      p.last_pay_date_key,
      p.last_pay_created_at
    FROM students s
    LEFT JOIN directions d ON d.id=s.direction_id
    LEFT JOIN stages st ON st.id=s.stage_id
    LEFT JOIN (
      SELECT
        student_id,
        MAX(
          CASE
            WHEN pay_date IS NULL OR trim(pay_date)='' THEN substr(created_at,1,10)
            WHEN length(pay_date)=10 AND substr(pay_date,3,1)='.' THEN substr(pay_date,7,4)||'-'||substr(pay_date,4,2)||'-'||substr(pay_date,1,2)
            WHEN length(pay_date)=10 AND substr(pay_date,5,1)='-' THEN pay_date
            ELSE substr(created_at,1,10)
          END
        ) AS last_pay_date_key,
        MAX(created_at) AS last_pay_created_at
      FROM payments
      GROUP BY student_id
    ) p ON p.student_id=s.id
    WHERE {where_sql}
    ORDER BY {_students_order_sql(filters.get("sort"))}
    LIMIT ? OFFSET ?
    '''
    rows = conn.execute(q, (*args, page_size+1, offset)).fetchall()
    has_next = len(rows) > page_size
    rows = rows[:page_size]
    has_prev = page > 0
    return rows, has_prev, has_next


def list_student_ids(conn: sqlite3.Connection, filters: dict) -> list[int]:
    """Return ordered student ids for current filters (used by cards carousel)."""
    archived = 1 if filters.get("archived") else 0
    where = ["s.archived=?"]
    args=[archived]
    if filters.get("direction_id"):
        where.append("s.direction_id=?")
        args.append(filters["direction_id"])
    if filters.get("stage_id"):
        where.append("s.stage_id=?")
        args.append(filters["stage_id"])
    if filters.get("tariff"):
        where.append("s.tariff=?")
        args.append(filters["tariff"])
    if filters.get("offer") == "yes":
        where.append("s.offer_amount IS NOT NULL")
    if filters.get("offer") == "no":
        where.append("s.offer_amount IS NULL")
    where_sql = " AND ".join(where)
    q = f'''
    SELECT s.id
    FROM students s
    LEFT JOIN directions d ON d.id=s.direction_id
    LEFT JOIN stages st ON st.id=s.stage_id
    LEFT JOIN (
      SELECT
        student_id,
        MAX(
          CASE
            WHEN pay_date IS NULL OR trim(pay_date)='' THEN substr(created_at,1,10)
            WHEN length(pay_date)=10 AND substr(pay_date,3,1)='.' THEN substr(pay_date,7,4)||'-'||substr(pay_date,4,2)||'-'||substr(pay_date,1,2)
            WHEN length(pay_date)=10 AND substr(pay_date,5,1)='-' THEN pay_date
            ELSE substr(created_at,1,10)
          END
        ) AS last_pay_date_key,
        MAX(created_at) AS last_pay_created_at
      FROM payments
      GROUP BY student_id
    ) p ON p.student_id=s.id
    WHERE {where_sql}
    ORDER BY {_students_order_sql(filters.get("sort"))}
    '''
    rows = conn.execute(q, tuple(args)).fetchall()
    return [int(r[0]) for r in rows]

def archive_student(conn: sqlite3.Connection, student_id: int, failed: bool, tz: str) -> None:
    update_student(conn, student_id, tz, archived=1, archive_failed=1 if failed else 0)

def restore_student(conn: sqlite3.Connection, student_id: int, tz: str) -> None:
    update_student(conn, student_id, tz, archived=0, archive_failed=0)
