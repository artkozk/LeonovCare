from __future__ import annotations

import json
import sqlite3
from typing import Any

from app.services.timeutils import now, iso


def create(
    conn: sqlite3.Connection,
    tz: str,
    owner_tg_id: int,
    owner_chat_id: int | None,
    login: str,
    direction: str,
    target_applies: int,
    query_text: str,
    status: str,
    create_response: dict[str, Any] | None = None,
    run_response: dict[str, Any] | None = None,
    error_text: str | None = None,
) -> int:
    ts = iso(now(tz))
    cur = conn.execute(
        "INSERT INTO autoapply_runs("
        "owner_tg_id, owner_chat_id, login, direction, target_applies, query_text, status, "
        "error_text, create_response_json, run_response_json, created_at, updated_at"
        ") VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
        (
            int(owner_tg_id),
            int(owner_chat_id) if owner_chat_id is not None else None,
            (login or "").strip(),
            (direction or "").strip(),
            max(int(target_applies or 0), 0),
            (query_text or "").strip(),
            (status or "created").strip(),
            (error_text or "").strip() or None,
            json.dumps(create_response or {}, ensure_ascii=False),
            json.dumps(run_response or {}, ensure_ascii=False),
            ts,
            ts,
        ),
    )
    conn.commit()
    return int(cur.lastrowid)


def last_by_owner(conn: sqlite3.Connection, owner_tg_id: int) -> sqlite3.Row | None:
    return conn.execute(
        "SELECT * FROM autoapply_runs WHERE owner_tg_id=? ORDER BY id DESC LIMIT 1",
        (int(owner_tg_id),),
    ).fetchone()


def summary_by_owner(conn: sqlite3.Connection, owner_tg_id: int) -> dict[str, int]:
    row = conn.execute(
        "SELECT "
        "COUNT(1) AS total, "
        "SUM(CASE WHEN status='launched' THEN 1 ELSE 0 END) AS launched, "
        "SUM(CASE WHEN status='failed' THEN 1 ELSE 0 END) AS failed "
        "FROM autoapply_runs WHERE owner_tg_id=?",
        (int(owner_tg_id),),
    ).fetchone()
    return {
        "total": int((row["total"] if row else 0) or 0),
        "launched": int((row["launched"] if row else 0) or 0),
        "failed": int((row["failed"] if row else 0) or 0),
    }


def summary(conn: sqlite3.Connection) -> dict[str, int]:
    row = conn.execute(
        "SELECT "
        "COUNT(1) AS total, "
        "SUM(CASE WHEN status='launched' THEN 1 ELSE 0 END) AS launched, "
        "SUM(CASE WHEN status='failed' THEN 1 ELSE 0 END) AS failed, "
        "COUNT(DISTINCT owner_tg_id) AS owners "
        "FROM autoapply_runs"
    ).fetchone()
    return {
        "total": int((row["total"] if row else 0) or 0),
        "launched": int((row["launched"] if row else 0) or 0),
        "failed": int((row["failed"] if row else 0) or 0),
        "owners": int((row["owners"] if row else 0) or 0),
    }


def direction_stats(conn: sqlite3.Connection, limit: int = 20) -> list[dict[str, int | str]]:
    rows = conn.execute(
        "SELECT "
        "direction, "
        "COUNT(1) AS total, "
        "SUM(CASE WHEN status='launched' THEN 1 ELSE 0 END) AS launched, "
        "SUM(CASE WHEN status='failed' THEN 1 ELSE 0 END) AS failed "
        "FROM autoapply_runs "
        "GROUP BY direction "
        "ORDER BY total DESC, direction ASC "
        "LIMIT ?",
        (int(max(1, limit)),),
    ).fetchall()
    out: list[dict[str, int | str]] = []
    for r in rows:
        out.append(
            {
                "direction": str(r["direction"] or "").strip() or "unknown",
                "total": int(r["total"] or 0),
                "launched": int(r["launched"] or 0),
                "failed": int(r["failed"] or 0),
            }
        )
    return out


def recent_failures(conn: sqlite3.Connection, limit: int = 20) -> list[sqlite3.Row]:
    return conn.execute(
        "SELECT * FROM autoapply_runs "
        "WHERE status='failed' "
        "ORDER BY id DESC LIMIT ?",
        (int(max(1, limit)),),
    ).fetchall()


def parse_response_json(raw: str | None) -> dict[str, Any]:
    body = str(raw or "").strip()
    if not body:
        return {}
    try:
        parsed = json.loads(body)
    except Exception:
        return {}
    return parsed if isinstance(parsed, dict) else {"data": parsed}
