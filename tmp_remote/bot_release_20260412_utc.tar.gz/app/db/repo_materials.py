from __future__ import annotations

import sqlite3

from app.db import repo_settings
from app.services.timeutils import iso, now

DIRECTIONS: tuple[str, ...] = ("java", "golang", "frontend", "python")

SETTINGS_GROUP_CHAT_ID = "MATERIALS_GROUP_CHAT_ID"
SETTINGS_GROUP_INVITE_URL = "MATERIALS_GROUP_INVITE_URL"
SETTINGS_REQUIRE_SUBSCRIPTION = "MATERIALS_REQUIRE_SUBSCRIPTION"


def normalize_direction(direction: str | None) -> str | None:
    d = (direction or "").strip().lower()
    return d if d in DIRECTIONS else None


def list_steps(conn: sqlite3.Connection, direction: str, include_inactive: bool = False) -> list[sqlite3.Row]:
    d = normalize_direction(direction)
    if not d:
        return []
    if include_inactive:
        return conn.execute(
            "SELECT * FROM material_steps WHERE direction=? ORDER BY position, id",
            (d,),
        ).fetchall()
    return conn.execute(
        "SELECT * FROM material_steps WHERE direction=? AND is_active=1 ORDER BY position, id",
        (d,),
    ).fetchall()


def get_step(conn: sqlite3.Connection, step_id: int) -> sqlite3.Row | None:
    return conn.execute("SELECT * FROM material_steps WHERE id=? LIMIT 1", (int(step_id),)).fetchone()


def _max_position(conn: sqlite3.Connection, direction: str) -> int:
    row = conn.execute(
        "SELECT MAX(position) AS p FROM material_steps WHERE direction=? AND is_active=1",
        (direction,),
    ).fetchone()
    return int(row["p"] or 0) if row else 0


def add_step_end(conn: sqlite3.Connection, tz: str, direction: str, title: str, message_url: str) -> int:
    d = normalize_direction(direction)
    if not d:
        raise ValueError("invalid direction")
    pos = _max_position(conn, d) + 1
    ts = iso(now(tz))
    cur = conn.execute(
        "INSERT INTO material_steps(direction, position, title, message_url, is_active, created_at, updated_at) "
        "VALUES(?,?,?,?,1,?,?)",
        (d, pos, title.strip(), message_url.strip(), ts, ts),
    )
    conn.commit()
    return int(cur.lastrowid)


def insert_step_at(
    conn: sqlite3.Connection,
    tz: str,
    direction: str,
    position: int,
    title: str,
    message_url: str,
) -> int:
    d = normalize_direction(direction)
    if not d:
        raise ValueError("invalid direction")
    pos = max(1, int(position))
    ts = iso(now(tz))
    conn.execute(
        "UPDATE material_steps SET position=position+1, updated_at=? "
        "WHERE direction=? AND is_active=1 AND position>=?",
        (ts, d, pos),
    )
    cur = conn.execute(
        "INSERT INTO material_steps(direction, position, title, message_url, is_active, created_at, updated_at) "
        "VALUES(?,?,?,?,1,?,?)",
        (d, pos, title.strip(), message_url.strip(), ts, ts),
    )
    conn.commit()
    return int(cur.lastrowid)


def update_step(conn: sqlite3.Connection, tz: str, step_id: int, title: str | None = None, message_url: str | None = None) -> bool:
    fields: list[str] = []
    vals: list[object] = []
    if title is not None:
        fields.append("title=?")
        vals.append(title.strip())
    if message_url is not None:
        fields.append("message_url=?")
        vals.append(message_url.strip())
    if not fields:
        return False
    fields.append("updated_at=?")
    vals.append(iso(now(tz)))
    vals.append(int(step_id))
    cur = conn.execute(
        f"UPDATE material_steps SET {', '.join(fields)} WHERE id=?",
        tuple(vals),
    )
    conn.commit()
    return int(cur.rowcount or 0) > 0


def delete_step(conn: sqlite3.Connection, tz: str, step_id: int) -> bool:
    row = get_step(conn, step_id)
    if not row:
        return False
    direction = row["direction"]
    pos = int(row["position"] or 0)
    ts = iso(now(tz))
    conn.execute("DELETE FROM material_steps WHERE id=?", (int(step_id),))
    conn.execute(
        "UPDATE material_steps SET position=position-1, updated_at=? "
        "WHERE direction=? AND is_active=1 AND position>?",
        (ts, direction, pos),
    )
    conn.commit()
    return True


def get_settings(conn: sqlite3.Connection) -> dict:
    raw_chat = repo_settings.get(conn, SETTINGS_GROUP_CHAT_ID, "")
    chat_id = None
    if raw_chat:
        try:
            chat_id = int(raw_chat)
        except Exception:
            chat_id = None

    invite_url = (repo_settings.get(conn, SETTINGS_GROUP_INVITE_URL, "") or "").strip()
    raw_required = (repo_settings.get(conn, SETTINGS_REQUIRE_SUBSCRIPTION, "1") or "1").strip().lower()
    require_subscription = raw_required in {"1", "true", "yes", "on"}
    return {
        "group_chat_id": chat_id,
        "invite_url": invite_url,
        "require_subscription": require_subscription,
    }


def set_group_chat_id(conn: sqlite3.Connection, chat_id: int | None) -> None:
    repo_settings.set(conn, SETTINGS_GROUP_CHAT_ID, "" if chat_id is None else str(int(chat_id)))


def set_invite_url(conn: sqlite3.Connection, invite_url: str) -> None:
    repo_settings.set(conn, SETTINGS_GROUP_INVITE_URL, (invite_url or "").strip())


def set_require_subscription(conn: sqlite3.Connection, enabled: bool) -> None:
    repo_settings.set(conn, SETTINGS_REQUIRE_SUBSCRIPTION, "1" if enabled else "0")


# ---------------------------------------------------------------------------
# Block-based roadmap helpers
# ---------------------------------------------------------------------------

def list_blocks(conn: sqlite3.Connection, direction: str) -> list[sqlite3.Row]:
    d = normalize_direction(direction)
    if not d:
        return []
    return conn.execute(
        "SELECT block_number, block_title, COUNT(*) AS step_count "
        "FROM material_steps "
        "WHERE direction=? AND is_active=1 AND block_number>0 "
        "GROUP BY block_number "
        "ORDER BY block_number",
        (d,),
    ).fetchall()


def list_steps_in_block(conn: sqlite3.Connection, direction: str, block_number: int) -> list[sqlite3.Row]:
    d = normalize_direction(direction)
    if not d:
        return []
    return conn.execute(
        "SELECT * FROM material_steps "
        "WHERE direction=? AND is_active=1 AND block_number=? "
        "ORDER BY position, id",
        (d, int(block_number)),
    ).fetchall()


def has_blocks(conn: sqlite3.Connection, direction: str) -> bool:
    d = normalize_direction(direction)
    if not d:
        return False
    row = conn.execute(
        "SELECT COUNT(DISTINCT block_number) AS cnt "
        "FROM material_steps WHERE direction=? AND is_active=1 AND block_number>0",
        (d,),
    ).fetchone()
    return int(row["cnt"] or 0) > 0 if row else False


def upsert_auto_step(
    conn: sqlite3.Connection,
    tz: str,
    direction: str,
    block_number: int,
    block_title: str,
    position: int,
    title: str,
    message_url: str,
) -> int | None:
    """Insert or update a step from auto-parsing. Upserts by direction+block_number+position."""
    d = normalize_direction(direction)
    if not d:
        return None
    ts = iso(now(tz))
    existing = conn.execute(
        "SELECT id FROM material_steps "
        "WHERE direction=? AND block_number=? AND position=? AND is_active=1 LIMIT 1",
        (d, int(block_number), int(position)),
    ).fetchone()
    if existing:
        conn.execute(
            "UPDATE material_steps SET title=?, message_url=?, block_title=?, updated_at=? WHERE id=?",
            (title.strip(), message_url.strip(), (block_title or "").strip(), ts, int(existing["id"])),
        )
        conn.commit()
        return int(existing["id"])
    cur = conn.execute(
        "INSERT INTO material_steps"
        "(direction, position, title, message_url, block_number, block_title, is_active, created_at, updated_at) "
        "VALUES(?,?,?,?,?,?,1,?,?)",
        (d, int(position), title.strip(), message_url.strip(), int(block_number), (block_title or "").strip(), ts, ts),
    )
    conn.commit()
    return int(cur.lastrowid)


def find_step_by_url(conn: sqlite3.Connection, message_url: str) -> sqlite3.Row | None:
    return conn.execute(
        "SELECT * FROM material_steps WHERE message_url=? AND is_active=1 LIMIT 1",
        (message_url.strip(),),
    ).fetchone()


def update_step_full(
    conn: sqlite3.Connection,
    tz: str,
    step_id: int,
    *,
    title: str | None = None,
    message_url: str | None = None,
    block_number: int | None = None,
    block_title: str | None = None,
    position: int | None = None,
) -> bool:
    fields: list[str] = []
    vals: list[object] = []
    if title is not None:
        fields.append("title=?")
        vals.append(title.strip())
    if message_url is not None:
        fields.append("message_url=?")
        vals.append(message_url.strip())
    if block_number is not None:
        fields.append("block_number=?")
        vals.append(int(block_number))
    if block_title is not None:
        fields.append("block_title=?")
        vals.append(block_title.strip())
    if position is not None:
        fields.append("position=?")
        vals.append(int(position))
    if not fields:
        return False
    fields.append("updated_at=?")
    vals.append(iso(now(tz)))
    vals.append(int(step_id))
    cur = conn.execute(
        f"UPDATE material_steps SET {', '.join(fields)} WHERE id=?",
        tuple(vals),
    )
    conn.commit()
    return int(cur.rowcount or 0) > 0


# ---------------------------------------------------------------------------
# Topic mapping (group forum topic -> direction)
# ---------------------------------------------------------------------------

def set_topic_mapping(conn: sqlite3.Connection, direction: str, thread_id: int, tz: str) -> None:
    d = normalize_direction(direction)
    if not d:
        return
    ts = iso(now(tz))
    conn.execute(
        "INSERT INTO material_topic_map(direction, thread_id, updated_at) VALUES(?,?,?) "
        "ON CONFLICT(direction) DO UPDATE SET thread_id=excluded.thread_id, updated_at=excluded.updated_at",
        (d, int(thread_id), ts),
    )
    conn.commit()


def get_topic_mappings(conn: sqlite3.Connection) -> list[sqlite3.Row]:
    return conn.execute("SELECT direction, thread_id FROM material_topic_map ORDER BY direction").fetchall()


def get_direction_for_thread(conn: sqlite3.Connection, thread_id: int) -> str | None:
    row = conn.execute(
        "SELECT direction FROM material_topic_map WHERE thread_id=? LIMIT 1",
        (int(thread_id),),
    ).fetchone()
    return row["direction"] if row else None


def get_topic_for_direction(conn: sqlite3.Connection, direction: str) -> int | None:
    d = normalize_direction(direction)
    if not d:
        return None
    row = conn.execute(
        "SELECT thread_id FROM material_topic_map WHERE direction=? LIMIT 1",
        (d,),
    ).fetchone()
    return int(row["thread_id"]) if row else None


def remove_topic_mapping(conn: sqlite3.Connection, direction: str) -> None:
    d = normalize_direction(direction)
    if not d:
        return
    conn.execute("DELETE FROM material_topic_map WHERE direction=?", (d,))
    conn.commit()


def build_message_url(chat_id: int, message_id: int) -> str:
    abs_id = abs(int(chat_id))
    if abs_id > 10**12:
        abs_id = abs_id - 10**12
    return f"https://t.me/c/{abs_id}/{message_id}"
