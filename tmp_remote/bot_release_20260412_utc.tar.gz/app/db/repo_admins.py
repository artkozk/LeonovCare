from __future__ import annotations

import sqlite3

from app.services.timeutils import iso, now

ADMIN_GRADE_FULL = "full"
ADMIN_GRADE_LIMITED = "limited"

PERM_MATERIALS_MANAGE = "materials_manage"
PERM_ADMINS_MANAGE = "admins_manage"
PERM_BROADCASTS_MANAGE = "broadcasts_manage"
PERM_STATS_PAYMENTS = "stats_payments"
PERM_RECEIVE_NOTIFICATIONS = "receive_notifications"

_LIMITED_DENY: set[str] = {
    PERM_MATERIALS_MANAGE,
    PERM_ADMINS_MANAGE,
    PERM_BROADCASTS_MANAGE,
    PERM_STATS_PAYMENTS,
    PERM_RECEIVE_NOTIFICATIONS,
}


def normalize_grade(raw: str | None) -> str:
    val = str(raw or "").strip().lower()
    return ADMIN_GRADE_LIMITED if val == ADMIN_GRADE_LIMITED else ADMIN_GRADE_FULL


def _normalize_ids(items: list[int] | tuple[int, ...] | None) -> set[int]:
    out: set[int] = set()
    for raw in items or []:
        try:
            uid = int(raw)
        except Exception:
            continue
        if uid > 0:
            out.add(uid)
    return out


def list_dynamic_ids(conn: sqlite3.Connection) -> list[int]:
    rows = conn.execute(
        "SELECT user_id FROM bot_admins WHERE is_active=1 ORDER BY user_id"
    ).fetchall()
    out: list[int] = []
    for r in rows:
        try:
            uid = int(r["user_id"])
        except Exception:
            continue
        if uid > 0:
            out.append(uid)
    return out


def list_dynamic_notify_ids(conn: sqlite3.Connection) -> list[int]:
    rows = conn.execute(
        "SELECT user_id FROM bot_admins "
        "WHERE is_active=1 AND COALESCE(grade, 'full')='full' ORDER BY user_id"
    ).fetchall()
    out: list[int] = []
    for r in rows:
        try:
            uid = int(r["user_id"])
        except Exception:
            continue
        if uid > 0:
            out.append(uid)
    return out


def list_all_ids(conn: sqlite3.Connection, base_admin_ids: list[int] | tuple[int, ...] | None) -> list[int]:
    all_ids = _normalize_ids(base_admin_ids)
    all_ids.update(list_dynamic_ids(conn))
    return sorted(all_ids)


def list_notify_ids(conn: sqlite3.Connection, base_admin_ids: list[int] | tuple[int, ...] | None) -> list[int]:
    all_ids = _normalize_ids(base_admin_ids)
    all_ids.update(list_dynamic_notify_ids(conn))
    return sorted(all_ids)


def is_admin(conn: sqlite3.Connection, user_id: int, base_admin_ids: list[int] | tuple[int, ...] | None) -> bool:
    try:
        uid = int(user_id)
    except Exception:
        return False
    if uid <= 0:
        return False
    if uid in _normalize_ids(base_admin_ids):
        return True
    row = conn.execute(
        "SELECT 1 FROM bot_admins WHERE user_id=? AND is_active=1 LIMIT 1",
        (uid,),
    ).fetchone()
    return bool(row)


def admin_grade(conn: sqlite3.Connection, user_id: int, base_admin_ids: list[int] | tuple[int, ...] | None) -> str | None:
    try:
        uid = int(user_id)
    except Exception:
        return None
    if uid <= 0:
        return None
    if uid in _normalize_ids(base_admin_ids):
        return ADMIN_GRADE_FULL
    row = conn.execute(
        "SELECT COALESCE(grade, 'full') AS grade "
        "FROM bot_admins WHERE user_id=? AND is_active=1 LIMIT 1",
        (uid,),
    ).fetchone()
    if not row:
        return None
    return normalize_grade(row["grade"])


def has_permission(
    conn: sqlite3.Connection,
    user_id: int,
    base_admin_ids: list[int] | tuple[int, ...] | None,
    permission: str,
) -> bool:
    grade = admin_grade(conn, user_id, base_admin_ids)
    if grade is None:
        return False
    if grade == ADMIN_GRADE_FULL:
        return True
    return str(permission or "").strip() not in _LIMITED_DENY


def list_dynamic(conn: sqlite3.Connection) -> list[sqlite3.Row]:
    return conn.execute(
        "SELECT *, COALESCE(grade, 'full') AS grade "
        "FROM bot_admins ORDER BY is_active DESC, updated_at DESC, user_id ASC"
    ).fetchall()


def get_dynamic(conn: sqlite3.Connection, user_id: int) -> sqlite3.Row | None:
    return conn.execute(
        "SELECT *, COALESCE(grade, 'full') AS grade FROM bot_admins WHERE user_id=? LIMIT 1",
        (int(user_id),),
    ).fetchone()


def add_or_enable(
    conn: sqlite3.Connection,
    tz: str,
    user_id: int,
    added_by_admin_id: int,
    username: str | None = None,
    grade: str = ADMIN_GRADE_FULL,
) -> None:
    ts = iso(now(tz))
    uname = (username or "").strip().lstrip("@") or None
    normalized_grade = normalize_grade(grade)
    conn.execute(
        "INSERT INTO bot_admins(user_id, username, added_by_admin_id, grade, is_active, created_at, updated_at, removed_at) "
        "VALUES(?,?,?,?,?,?,?,NULL) "
        "ON CONFLICT(user_id) DO UPDATE SET "
        "username=COALESCE(excluded.username, bot_admins.username), "
        "added_by_admin_id=excluded.added_by_admin_id, "
        "grade=excluded.grade, "
        "is_active=1, "
        "updated_at=excluded.updated_at, "
        "removed_at=NULL",
        (int(user_id), uname, int(added_by_admin_id), normalized_grade, 1, ts, ts),
    )
    conn.commit()


def deactivate(conn: sqlite3.Connection, tz: str, user_id: int) -> bool:
    ts = iso(now(tz))
    cur = conn.execute(
        "UPDATE bot_admins SET is_active=0, updated_at=?, removed_at=? WHERE user_id=? AND is_active=1",
        (ts, ts, int(user_id)),
    )
    conn.commit()
    return int(cur.rowcount or 0) > 0


def set_grade(conn: sqlite3.Connection, tz: str, user_id: int, grade: str) -> bool:
    ts = iso(now(tz))
    normalized_grade = normalize_grade(grade)
    cur = conn.execute(
        "UPDATE bot_admins SET grade=?, updated_at=? WHERE user_id=?",
        (normalized_grade, ts, int(user_id)),
    )
    conn.commit()
    return int(cur.rowcount or 0) > 0
