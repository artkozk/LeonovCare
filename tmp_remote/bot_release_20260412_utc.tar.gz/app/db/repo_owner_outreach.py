from __future__ import annotations

import json
import sqlite3
from typing import Any

from app.services.timeutils import iso, now


LEAD_SENT = "sent"
LEAD_SEND_FAILED = "send_failed"
LEAD_BLOCKED = "blocked"
LEAD_NO_REPLY = "no_reply"
LEAD_REPLIED = "replied"
LEAD_NOT_INTERESTED = "not_interested"
LEAD_INTERESTED = "interested"
LEAD_CALL_BOOKED = "call_booked"
LEAD_CALL_DONE = "call_done"
LEAD_NEEDS_REVIEW = "needs_review"
POOL_READY = "ready"
POOL_CONTACTED = "contacted"
POOL_INVALID = "invalid"


def _norm_telegram(raw: str | None) -> tuple[str, str]:
    text = str(raw or "").strip()
    if not text:
        return "", ""
    if text.startswith("https://t.me/") or text.startswith("http://t.me/"):
        text = text.rsplit("/", 1)[-1]
    text = text.split("?", 1)[0].split("#", 1)[0].strip()
    if not text:
        return "", ""
    if not text.startswith("@"):
        text = "@" + text
    norm = text.lower()
    return text, norm


def _norm_status(raw: str | None) -> str:
    s = str(raw or "").strip().lower()
    allowed = {
        LEAD_SENT,
        LEAD_SEND_FAILED,
        LEAD_BLOCKED,
        LEAD_NO_REPLY,
        LEAD_REPLIED,
        LEAD_NOT_INTERESTED,
        LEAD_INTERESTED,
        LEAD_CALL_BOOKED,
        LEAD_CALL_DONE,
        LEAD_NEEDS_REVIEW,
    }
    return s if s in allowed else LEAD_SENT


def add_or_update_lead(
    conn: sqlite3.Connection,
    tz: str,
    job_id: int,
    telegram: str,
    direction: str,
    status: str,
    send_error: str | None = None,
    ai_step: int = 0,
) -> int:
    ts = iso(now(tz))
    tg = str(telegram or "").strip()
    cur = conn.execute(
        "INSERT INTO owner_outreach_leads("
        "job_id, telegram, direction, status, send_error, ai_step, created_at, updated_at"
        ") VALUES(?,?,?,?,?,?,?,?) "
        "ON CONFLICT(job_id, telegram) DO UPDATE SET "
        "direction=excluded.direction, "
        "status=excluded.status, "
        "send_error=excluded.send_error, "
        "ai_step=excluded.ai_step, "
        "updated_at=excluded.updated_at",
        (
            int(job_id),
            tg,
            str(direction or "").strip().lower() or "python",
            _norm_status(status),
            (send_error or "").strip() or None,
            max(int(ai_step or 0), 0),
            ts,
            ts,
        ),
    )
    conn.commit()
    if cur.lastrowid:
        return int(cur.lastrowid)
    row = conn.execute(
        "SELECT id FROM owner_outreach_leads WHERE job_id=? AND telegram=? LIMIT 1",
        (int(job_id), tg),
    ).fetchone()
    return int(row["id"]) if row else 0


def set_lead_status(
    conn: sqlite3.Connection,
    tz: str,
    lead_id: int,
    status: str,
    inbound_text: str | None = None,
    outbound_text: str | None = None,
    ai_step: int | None = None,
    send_error: str | None = None,
) -> bool:
    ts = iso(now(tz))
    row = conn.execute("SELECT * FROM owner_outreach_leads WHERE id=? LIMIT 1", (int(lead_id),)).fetchone()
    if not row:
        return False
    next_ai_step = int(row["ai_step"] or 0) if ai_step is None else max(int(ai_step), 0)
    conn.execute(
        "UPDATE owner_outreach_leads SET "
        "status=?, inbound_text=COALESCE(?, inbound_text), outbound_text=COALESCE(?, outbound_text), "
        "ai_step=?, send_error=COALESCE(?, send_error), updated_at=? "
        "WHERE id=?",
        (
            _norm_status(status),
            (inbound_text or "").strip() or None,
            (outbound_text or "").strip() or None,
            next_ai_step,
            (send_error or "").strip() or None,
            ts,
            int(lead_id),
        ),
    )
    conn.commit()
    return True


def list_by_job(conn: sqlite3.Connection, job_id: int) -> list[sqlite3.Row]:
    return conn.execute(
        "SELECT * FROM owner_outreach_leads WHERE job_id=? ORDER BY id ASC",
        (int(job_id),),
    ).fetchall()


def list_recent(conn: sqlite3.Connection, owner_tg_id: int, limit: int = 500) -> list[sqlite3.Row]:
    cap = max(1, min(int(limit or 0), 5000))
    return conn.execute(
        "SELECT l.* FROM owner_outreach_leads l "
        "JOIN owner_hh_jobs j ON j.id=l.job_id "
        "WHERE j.owner_tg_id=? "
        "ORDER BY l.updated_at DESC, l.id DESC LIMIT ?",
        (int(owner_tg_id), cap),
    ).fetchall()


def summary(conn: sqlite3.Connection, owner_tg_id: int) -> dict[str, int]:
    rows = conn.execute(
        "SELECT l.status AS status, COUNT(1) AS c "
        "FROM owner_outreach_leads l "
        "JOIN owner_hh_jobs j ON j.id=l.job_id "
        "WHERE j.owner_tg_id=? "
        "GROUP BY l.status",
        (int(owner_tg_id),),
    ).fetchall()
    out = {
        LEAD_SENT: 0,
        LEAD_SEND_FAILED: 0,
        LEAD_BLOCKED: 0,
        LEAD_NO_REPLY: 0,
        LEAD_REPLIED: 0,
        LEAD_NOT_INTERESTED: 0,
        LEAD_INTERESTED: 0,
        LEAD_CALL_BOOKED: 0,
        LEAD_CALL_DONE: 0,
        LEAD_NEEDS_REVIEW: 0,
    }
    for r in rows:
        key = _norm_status(r["status"])
        out[key] = int(r["c"] or 0)
    return out


def direction_stats(conn: sqlite3.Connection, owner_tg_id: int) -> list[dict[str, Any]]:
    rows = conn.execute(
        "SELECT l.direction AS direction, l.status AS status, COUNT(1) AS c "
        "FROM owner_outreach_leads l "
        "JOIN owner_hh_jobs j ON j.id=l.job_id "
        "WHERE j.owner_tg_id=? "
        "GROUP BY l.direction, l.status",
        (int(owner_tg_id),),
    ).fetchall()
    by_direction: dict[str, dict[str, int]] = {}
    for r in rows:
        d = str(r["direction"] or "").strip().lower() or "unknown"
        if d not in by_direction:
            by_direction[d] = {"total": 0}
        st = _norm_status(r["status"])
        c = int(r["c"] or 0)
        by_direction[d][st] = by_direction[d].get(st, 0) + c
        by_direction[d]["total"] += c
    out: list[dict[str, Any]] = []
    for d, payload in by_direction.items():
        out.append({"direction": d, **payload})
    out.sort(key=lambda x: str(x.get("direction") or ""))
    return out


def script_stats(conn: sqlite3.Connection, owner_tg_id: int) -> list[dict[str, Any]]:
    rows = conn.execute(
        "SELECT COALESCE(NULLIF(trim(script_version), ''), 'script4') AS script_version, "
        "COUNT(1) AS campaigns, COALESCE(SUM(send_success),0) AS sent_ok, COALESCE(SUM(send_failed),0) AS sent_fail "
        "FROM owner_hh_jobs WHERE owner_tg_id=? GROUP BY COALESCE(NULLIF(trim(script_version), ''), 'script4')",
        (int(owner_tg_id),),
    ).fetchall()
    out: list[dict[str, Any]] = []
    for r in rows:
        script_version = str(r["script_version"] or "script4")
        sent_ok = int(r["sent_ok"] or 0)
        sent_fail = int(r["sent_fail"] or 0)
        total = max(sent_ok + sent_fail, 1)
        conversion = round((sent_ok / total) * 100.0, 2)
        out.append(
            {
                "script_version": script_version,
                "campaigns": int(r["campaigns"] or 0),
                "sent_ok": sent_ok,
                "sent_fail": sent_fail,
                "delivery_rate_pct": conversion,
            }
        )
    return out


def add_event(
    conn: sqlite3.Connection,
    tz: str,
    job_id: int | None,
    lead_id: int | None,
    event_type: str,
    payload: dict[str, Any] | None = None,
) -> int:
    ts = iso(now(tz))
    cur = conn.execute(
        "INSERT INTO owner_outreach_events(job_id, lead_id, event_type, payload_json, created_at) VALUES(?,?,?,?,?)",
        (
            int(job_id) if job_id is not None else None,
            int(lead_id) if lead_id is not None else None,
            str(event_type or "").strip() or "event",
            json.dumps(payload or {}, ensure_ascii=False),
            ts,
        ),
    )
    conn.commit()
    return int(cur.lastrowid)


def was_contacted(conn: sqlite3.Connection, owner_tg_id: int, telegram: str) -> bool:
    _tg, tg_norm = _norm_telegram(telegram)
    if not tg_norm:
        return False
    row = conn.execute(
        "SELECT 1 FROM owner_outreach_contacted WHERE owner_tg_id=? AND telegram_norm=? LIMIT 1",
        (int(owner_tg_id), tg_norm),
    ).fetchone()
    return row is not None


def mark_contacted(
    conn: sqlite3.Connection,
    tz: str,
    owner_tg_id: int,
    telegram: str,
    job_id: int | None = None,
    account_id: int | None = None,
) -> bool:
    tg, tg_norm = _norm_telegram(telegram)
    if not tg_norm:
        return False
    ts = iso(now(tz))
    conn.execute(
        "INSERT INTO owner_outreach_contacted("
        "owner_tg_id, telegram, telegram_norm, first_job_id, first_account_id, first_sent_at, "
        "last_job_id, last_account_id, last_sent_at, created_at, updated_at"
        ") VALUES(?,?,?,?,?,?,?,?,?,?,?) "
        "ON CONFLICT(owner_tg_id, telegram_norm) DO UPDATE SET "
        "telegram=excluded.telegram, "
        "last_job_id=excluded.last_job_id, "
        "last_account_id=excluded.last_account_id, "
        "last_sent_at=excluded.last_sent_at, "
        "updated_at=excluded.updated_at",
        (
            int(owner_tg_id),
            tg,
            tg_norm,
            int(job_id) if job_id is not None else None,
            int(account_id) if account_id is not None else None,
            ts,
            int(job_id) if job_id is not None else None,
            int(account_id) if account_id is not None else None,
            ts,
            ts,
            ts,
        ),
    )
    conn.execute(
        "UPDATE owner_outreach_parsed_pool SET "
        "status=?, last_contacted_at=?, updated_at=? "
        "WHERE owner_tg_id=? AND telegram_norm=?",
        (
            POOL_CONTACTED,
            ts,
            ts,
            int(owner_tg_id),
            tg_norm,
        ),
    )
    conn.commit()
    return True


def mark_pool_status(
    conn: sqlite3.Connection,
    tz: str,
    owner_tg_id: int,
    telegram: str,
    status: str,
) -> bool:
    tg, tg_norm = _norm_telegram(telegram)
    if not tg_norm:
        return False
    st = str(status or "").strip().lower()
    if st not in {POOL_READY, POOL_CONTACTED, POOL_INVALID}:
        st = POOL_INVALID
    ts = iso(now(tz))
    cur = conn.execute(
        "UPDATE owner_outreach_parsed_pool SET "
        "telegram=?, status=?, updated_at=? "
        "WHERE owner_tg_id=? AND telegram_norm=?",
        (
            tg,
            st,
            ts,
            int(owner_tg_id),
            tg_norm,
        ),
    )
    conn.commit()
    return int(cur.rowcount or 0) > 0


def upsert_parsed_contacts(
    conn: sqlite3.Connection,
    tz: str,
    owner_tg_id: int,
    direction: str,
    contacts: list[dict[str, Any]],
    job_id: int | None = None,
) -> dict[str, int]:
    ts = iso(now(tz))
    d = str(direction or "").strip().lower() or "python"
    inserted = 0
    updated = 0
    for row in contacts:
        if not isinstance(row, dict):
            continue
        tg, tg_norm = _norm_telegram(row.get("telegram"))
        if not tg_norm:
            continue
        before = conn.execute(
            "SELECT id FROM owner_outreach_parsed_pool WHERE owner_tg_id=? AND telegram_norm=? LIMIT 1",
            (int(owner_tg_id), tg_norm),
        ).fetchone()
        conn.execute(
            "INSERT INTO owner_outreach_parsed_pool("
            "owner_tg_id, telegram, telegram_norm, direction, name, resume_id, resume_link, status, "
            "first_seen_job_id, last_seen_job_id, first_seen_at, last_seen_at, created_at, updated_at"
            ") VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?) "
            "ON CONFLICT(owner_tg_id, telegram_norm) DO UPDATE SET "
            "telegram=excluded.telegram, "
            "direction=excluded.direction, "
            "name=COALESCE(NULLIF(excluded.name,''), owner_outreach_parsed_pool.name), "
            "resume_id=COALESCE(NULLIF(excluded.resume_id,''), owner_outreach_parsed_pool.resume_id), "
            "resume_link=COALESCE(NULLIF(excluded.resume_link,''), owner_outreach_parsed_pool.resume_link), "
            "status=CASE "
            "  WHEN owner_outreach_parsed_pool.status=? THEN ? "
            "  ELSE owner_outreach_parsed_pool.status "
            "END, "
            "last_seen_job_id=excluded.last_seen_job_id, "
            "last_seen_at=excluded.last_seen_at, "
            "updated_at=excluded.updated_at",
            (
                int(owner_tg_id),
                tg,
                tg_norm,
                d,
                str(row.get("name") or "").strip(),
                str(row.get("resume_id") or "").strip(),
                str(row.get("resume_link") or "").strip(),
                POOL_READY,
                int(job_id) if job_id is not None else None,
                int(job_id) if job_id is not None else None,
                ts,
                ts,
                ts,
                ts,
                POOL_CONTACTED,
                POOL_CONTACTED,
            ),
        )
        if before is None:
            inserted += 1
        else:
            updated += 1
    conn.commit()
    return {"inserted": inserted, "updated": updated}


def pool_ready_count(conn: sqlite3.Connection, owner_tg_id: int, direction: str | None = None) -> int:
    d = str(direction or "").strip().lower()
    if d:
        row = conn.execute(
            "SELECT COUNT(1) AS c "
            "FROM owner_outreach_parsed_pool p "
            "LEFT JOIN owner_outreach_contacted c "
            "  ON c.owner_tg_id=p.owner_tg_id AND c.telegram_norm=p.telegram_norm "
            "WHERE p.owner_tg_id=? AND p.direction=? AND p.status=? AND c.id IS NULL",
            (int(owner_tg_id), d, POOL_READY),
        ).fetchone()
    else:
        row = conn.execute(
            "SELECT COUNT(1) AS c "
            "FROM owner_outreach_parsed_pool p "
            "LEFT JOIN owner_outreach_contacted c "
            "  ON c.owner_tg_id=p.owner_tg_id AND c.telegram_norm=p.telegram_norm "
            "WHERE p.owner_tg_id=? AND p.status=? AND c.id IS NULL",
            (int(owner_tg_id), POOL_READY),
        ).fetchone()
    return int(row["c"] or 0) if row else 0


def pool_contacts_for_send(
    conn: sqlite3.Connection,
    owner_tg_id: int,
    direction: str,
    limit: int,
) -> list[dict[str, Any]]:
    cap = max(0, min(int(limit or 0), 5000))
    if cap <= 0:
        return []
    rows = conn.execute(
        "SELECT p.telegram, p.name, p.resume_id, p.resume_link "
        "FROM owner_outreach_parsed_pool p "
        "LEFT JOIN owner_outreach_contacted c "
        "  ON c.owner_tg_id=p.owner_tg_id AND c.telegram_norm=p.telegram_norm "
        "WHERE p.owner_tg_id=? AND p.direction=? AND p.status=? AND c.id IS NULL "
        "ORDER BY p.last_seen_at DESC, p.id DESC "
        "LIMIT ?",
        (int(owner_tg_id), str(direction or "").strip().lower() or "python", POOL_READY, cap),
    ).fetchall()
    out: list[dict[str, Any]] = []
    for i, row in enumerate(rows, start=1):
        out.append(
            {
                "index": i,
                "telegram": str(row["telegram"] or "").strip(),
                "name": str(row["name"] or "").strip(),
                "resume_id": str(row["resume_id"] or "").strip(),
                "resume_link": str(row["resume_link"] or "").strip(),
            }
        )
    return out


def pool_summary(conn: sqlite3.Connection, owner_tg_id: int) -> dict[str, int]:
    row_total = conn.execute(
        "SELECT COUNT(1) AS c FROM owner_outreach_parsed_pool WHERE owner_tg_id=?",
        (int(owner_tg_id),),
    ).fetchone()
    row_contacted = conn.execute(
        "SELECT COUNT(1) AS c "
        "FROM owner_outreach_parsed_pool p "
        "JOIN owner_outreach_contacted c "
        "  ON c.owner_tg_id=p.owner_tg_id AND c.telegram_norm=p.telegram_norm "
        "WHERE p.owner_tg_id=?",
        (int(owner_tg_id),),
    ).fetchone()
    row_ready = conn.execute(
        "SELECT COUNT(1) AS c "
        "FROM owner_outreach_parsed_pool p "
        "LEFT JOIN owner_outreach_contacted c "
        "  ON c.owner_tg_id=p.owner_tg_id AND c.telegram_norm=p.telegram_norm "
        "WHERE p.owner_tg_id=? AND p.status=? AND c.id IS NULL",
        (int(owner_tg_id), POOL_READY),
    ).fetchone()
    total = int(row_total["c"] or 0) if row_total else 0
    contacted = int(row_contacted["c"] or 0) if row_contacted else 0
    ready = int(row_ready["c"] or 0) if row_ready else 0
    return {"total": total, "ready": max(ready, 0), "contacted": contacted}
