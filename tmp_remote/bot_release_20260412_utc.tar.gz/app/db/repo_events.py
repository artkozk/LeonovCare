from __future__ import annotations
import sqlite3
import datetime as dt
from typing import Optional
from app.services.timeutils import now, iso

def create(conn: sqlite3.Connection, tz: str, student_id: int | None, event_type: str,
           company: str | None, role: str | None, direction: str | None,
           link: str | None, start_at_iso: str, duration_min: int,
           remind_before_min: int, next_alert_at_iso: str,
           owner_tg_id: int | None = None, call_kind: str | None = None) -> int:
    ts = iso(now(tz))
    cur = conn.execute(
        "INSERT INTO events(student_id, owner_tg_id, call_kind, event_type, company, role, direction, link, start_at, duration_min, remind_before_min, next_alert_at, alerted, active, created_at, updated_at) "
        "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (
            student_id,
            int(owner_tg_id) if owner_tg_id is not None else None,
            (call_kind or "").strip() or None,
            event_type,
            company,
            role,
            direction,
            link,
            start_at_iso,
            int(duration_min),
            int(remind_before_min),
            next_alert_at_iso,
            0,
            1,
            ts,
            ts,
        )
    )
    conn.commit()
    return int(cur.lastrowid)

def update(conn: sqlite3.Connection, event_id: int, tz: str, **fields) -> None:
    if not fields:
        return
    fields["updated_at"]=iso(now(tz))
    parts=[]
    vals=[]
    for k,v in fields.items():
        parts.append(f"{k}=?")
        vals.append(v)
    vals.append(event_id)
    conn.execute(f"UPDATE events SET {', '.join(parts)} WHERE id=?", vals)
    conn.commit()

def get(conn: sqlite3.Connection, event_id: int) -> Optional[sqlite3.Row]:
    q = '''
    SELECT e.*, s.fio, s.username, COALESCE(up.username, '') AS owner_username
    FROM events e
    LEFT JOIN students s ON s.id=e.student_id
    LEFT JOIN user_profiles up ON up.user_id=e.owner_tg_id
    WHERE e.id=?
    '''
    return conn.execute(q, (event_id,)).fetchone()

def list_upcoming(conn: sqlite3.Connection, from_iso: str, to_iso: str) -> list[sqlite3.Row]:
    q = '''
    SELECT e.*, s.fio, s.username, COALESCE(up.username, '') AS owner_username
    FROM events e
    LEFT JOIN students s ON s.id=e.student_id
    LEFT JOIN user_profiles up ON up.user_id=e.owner_tg_id
    WHERE e.active=1 AND e.start_at >= ? AND e.start_at <= ?
    ORDER BY e.start_at
    '''
    return conn.execute(q, (from_iso, to_iso)).fetchall()

def list_all_upcoming(conn: sqlite3.Connection, limit: int=50) -> list[sqlite3.Row]:
    q = '''
    SELECT e.*, s.fio, s.username, COALESCE(up.username, '') AS owner_username
    FROM events e
    LEFT JOIN students s ON s.id=e.student_id
    LEFT JOIN user_profiles up ON up.user_id=e.owner_tg_id
    WHERE e.active=1
    ORDER BY e.start_at
    LIMIT ?
    '''
    return conn.execute(q, (limit,)).fetchall()


def list_candidates_for_range(conn: sqlite3.Connection, from_iso: str, to_iso: str) -> list[sqlite3.Row]:
    """Events that may intersect with the range; exact intersection is checked in python."""
    q = '''
    SELECT e.*, s.fio, s.username, COALESCE(up.username, '') AS owner_username
    FROM events e
    LEFT JOIN students s ON s.id=e.student_id
    LEFT JOIN user_profiles up ON up.user_id=e.owner_tg_id
    WHERE e.active=1 AND e.start_at >= ? AND e.start_at <= ?
    ORDER BY e.start_at
    '''
    return conn.execute(q, (from_iso, to_iso)).fetchall()


def find_overlaps(
    conn: sqlite3.Connection,
    start_at: dt.datetime,
    end_at: dt.datetime,
    tz: str,
    exclude_event_id: int | None = None,
) -> list[sqlite3.Row]:
    """Find active events that overlap with [start_at, end_at)."""
    candidates = list_candidates_for_range(
        conn,
        iso(start_at - dt.timedelta(days=1)),
        iso(end_at + dt.timedelta(days=1)),
    )

    overlaps: list[sqlite3.Row] = []
    for r in candidates:
        try:
            if exclude_event_id is not None and int(r["id"]) == int(exclude_event_id):
                continue
            s = dt.datetime.fromisoformat(r["start_at"])  # preserves tzinfo
            e = s + dt.timedelta(minutes=int(r["duration_min"] or 0))
            if s < end_at and e > start_at:
                overlaps.append(r)
        except Exception:
            continue
    return overlaps


def find_overlaps_exact(
    conn: sqlite3.Connection,
    start_at_iso: str,
    end_at_iso: str,
    exclude_event_id: int | None = None,
) -> list[sqlite3.Row]:
    """Find active events that overlap with [start_at_iso, end_at_iso) in SQL."""
    params: list[object] = [str(end_at_iso), str(start_at_iso)]
    q = (
        "SELECT e.*, s.fio, s.username, COALESCE(up.username, '') AS owner_username "
        "FROM events e "
        "LEFT JOIN students s ON s.id=e.student_id "
        "LEFT JOIN user_profiles up ON up.user_id=e.owner_tg_id "
        "WHERE e.active=1 "
        "AND datetime(e.start_at) < datetime(?) "
        "AND datetime(e.start_at, '+' || CAST(COALESCE(e.duration_min,0) AS TEXT) || ' minutes') > datetime(?) "
    )
    if exclude_event_id is not None:
        q += "AND e.id<>? "
        params.append(int(exclude_event_id))
    q += "ORDER BY e.start_at, e.id"
    return conn.execute(q, tuple(params)).fetchall()


def create_if_free(
    conn: sqlite3.Connection,
    tz: str,
    student_id: int | None,
    event_type: str,
    company: str | None,
    role: str | None,
    direction: str | None,
    link: str | None,
    start_at_iso: str,
    duration_min: int,
    remind_before_min: int,
    next_alert_at_iso: str,
    owner_tg_id: int | None = None,
    call_kind: str | None = None,
) -> tuple[int | None, list[sqlite3.Row]]:
    """Atomically create event only when slot is free."""
    start_dt = dt.datetime.fromisoformat(str(start_at_iso))
    end_dt = start_dt + dt.timedelta(minutes=max(1, int(duration_min or 0)))
    overlaps = find_overlaps_exact(conn, iso(start_dt), iso(end_dt))
    if overlaps:
        return None, overlaps
    event_id = create(
        conn,
        tz,
        student_id=student_id,
        event_type=event_type,
        company=company,
        role=role,
        direction=direction,
        link=link,
        start_at_iso=iso(start_dt),
        duration_min=int(duration_min),
        remind_before_min=int(remind_before_min),
        next_alert_at_iso=str(next_alert_at_iso),
        owner_tg_id=owner_tg_id,
        call_kind=call_kind,
    )
    return event_id, []


def move_if_free(
    conn: sqlite3.Connection,
    event_id: int,
    tz: str,
    start_at_iso: str,
    duration_min: int,
    next_alert_at_iso: str,
) -> tuple[bool, list[sqlite3.Row]]:
    """Atomically move existing event only when target slot is free."""
    start_dt = dt.datetime.fromisoformat(str(start_at_iso))
    end_dt = start_dt + dt.timedelta(minutes=max(1, int(duration_min or 0)))
    overlaps = find_overlaps_exact(conn, iso(start_dt), iso(end_dt), exclude_event_id=int(event_id))
    if overlaps:
        return False, overlaps
    update(
        conn,
        int(event_id),
        tz,
        start_at=iso(start_dt),
        duration_min=int(duration_min),
        next_alert_at=next_alert_at_iso,
        alerted=0,
        active=1,
    )
    return True, []


def list_for_day(conn: sqlite3.Connection, day: dt.date, tz: str) -> list[sqlite3.Row]:
    """List active events that intersect the given day (00:00..24:00 in tz)."""
    tzinfo = now(tz).tzinfo
    day_start = dt.datetime.combine(day, dt.time.min).replace(tzinfo=tzinfo)
    day_end = day_start + dt.timedelta(days=1)
    candidates = list_candidates_for_range(conn, iso(day_start - dt.timedelta(days=1)), iso(day_end))
    res: list[sqlite3.Row] = []
    for r in candidates:
        try:
            s = dt.datetime.fromisoformat(r["start_at"])  # preserves tzinfo
            e = s + dt.timedelta(minutes=int(r["duration_min"] or 0))
            if s < day_end and e > day_start:
                res.append(r)
        except Exception:
            continue
    return res


def list_student_calls(
    conn: sqlite3.Connection,
    student_id: int,
    from_iso: str | None = None,
    limit: int = 30,
) -> list[sqlite3.Row]:
    if from_iso:
        return conn.execute(
            "SELECT e.*, s.fio, s.username, COALESCE(up.username, '') AS owner_username "
            "FROM events e "
            "LEFT JOIN students s ON s.id=e.student_id "
            "LEFT JOIN user_profiles up ON up.user_id=e.owner_tg_id "
            "WHERE e.active=1 AND e.student_id=? AND e.event_type='CALL' AND e.start_at>=? "
            "ORDER BY e.start_at ASC LIMIT ?",
            (int(student_id), from_iso, int(max(1, limit))),
        ).fetchall()
    return conn.execute(
        "SELECT e.*, s.fio, s.username, COALESCE(up.username, '') AS owner_username "
        "FROM events e "
        "LEFT JOIN students s ON s.id=e.student_id "
        "LEFT JOIN user_profiles up ON up.user_id=e.owner_tg_id "
        "WHERE e.active=1 AND e.student_id=? AND e.event_type='CALL' "
        "ORDER BY e.start_at ASC LIMIT ?",
        (int(student_id), int(max(1, limit))),
    ).fetchall()


def get_student_call(conn: sqlite3.Connection, event_id: int, student_id: int) -> Optional[sqlite3.Row]:
    return conn.execute(
        "SELECT e.*, s.fio, s.username, COALESCE(up.username, '') AS owner_username "
        "FROM events e "
        "LEFT JOIN students s ON s.id=e.student_id "
        "LEFT JOIN user_profiles up ON up.user_id=e.owner_tg_id "
        "WHERE e.id=? AND e.student_id=? AND e.event_type='CALL' AND e.active=1",
        (int(event_id), int(student_id)),
    ).fetchone()


def list_owner_calls(
    conn: sqlite3.Connection,
    owner_tg_id: int,
    from_iso: str | None = None,
    limit: int = 30,
    call_kind: str | None = None,
) -> list[sqlite3.Row]:
    where = [
        "e.active=1",
        "e.owner_tg_id=?",
        "e.event_type='CALL'",
    ]
    params: list[object] = [int(owner_tg_id)]
    if call_kind:
        where.append("COALESCE(e.call_kind,'')=?")
        params.append((call_kind or "").strip())
    if from_iso:
        where.append("e.start_at>=?")
        params.append(from_iso)
    params.append(int(max(1, limit)))
    q = (
        "SELECT e.*, s.fio, s.username, COALESCE(up.username, '') AS owner_username "
        "FROM events e "
        "LEFT JOIN students s ON s.id=e.student_id "
        "LEFT JOIN user_profiles up ON up.user_id=e.owner_tg_id "
        f"WHERE {' AND '.join(where)} "
        "ORDER BY e.start_at ASC LIMIT ?"
    )
    return conn.execute(q, tuple(params)).fetchall()


def get_owner_call(
    conn: sqlite3.Connection,
    event_id: int,
    owner_tg_id: int,
    call_kind: str | None = None,
) -> Optional[sqlite3.Row]:
    where = [
        "e.id=?",
        "e.owner_tg_id=?",
        "e.event_type='CALL'",
        "e.active=1",
    ]
    params: list[object] = [int(event_id), int(owner_tg_id)]
    if call_kind:
        where.append("COALESCE(e.call_kind,'')=?")
        params.append((call_kind or "").strip())
    q = (
        "SELECT e.*, s.fio, s.username, COALESCE(up.username, '') AS owner_username "
        "FROM events e "
        "LEFT JOIN students s ON s.id=e.student_id "
        "LEFT JOIN user_profiles up ON up.user_id=e.owner_tg_id "
        f"WHERE {' AND '.join(where)}"
    )
    return conn.execute(q, tuple(params)).fetchone()


def owner_call_count(
    conn: sqlite3.Connection,
    owner_tg_id: int,
    call_kind: str | None = None,
    include_inactive: bool = True,
) -> int:
    where = [
        "owner_tg_id=?",
        "event_type='CALL'",
    ]
    params: list[object] = [int(owner_tg_id)]
    if call_kind:
        where.append("COALESCE(call_kind,'')=?")
        params.append((call_kind or "").strip())
    if not include_inactive:
        where.append("active=1")
    row = conn.execute(
        f"SELECT COUNT(1) AS c FROM events WHERE {' AND '.join(where)}",
        tuple(params),
    ).fetchone()
    return int((row["c"] if row else 0) or 0)


def owner_calls_summary(conn: sqlite3.Connection, owner_tg_id: int, from_iso: str | None = None) -> dict[str, int]:
    where = [
        "owner_tg_id=?",
        "event_type='CALL'",
    ]
    params: list[object] = [int(owner_tg_id)]
    if from_iso:
        where.append("start_at>=?")
        params.append(from_iso)
    row = conn.execute(
        "SELECT "
        "COUNT(1) AS total, "
        "SUM(CASE WHEN active=1 THEN 1 ELSE 0 END) AS active, "
        "SUM(CASE WHEN COALESCE(call_kind,'')='student' THEN 1 ELSE 0 END) AS student_calls, "
        "SUM(CASE WHEN COALESCE(call_kind,'')='diagnostic' THEN 1 ELSE 0 END) AS diagnostic_calls "
        f"FROM events WHERE {' AND '.join(where)}",
        tuple(params),
    ).fetchone()
    return {
        "total": int((row["total"] if row else 0) or 0),
        "active": int((row["active"] if row else 0) or 0),
        "student_calls": int((row["student_calls"] if row else 0) or 0),
        "diagnostic_calls": int((row["diagnostic_calls"] if row else 0) or 0),
    }


def calls_summary(conn: sqlite3.Connection, from_iso: str | None = None) -> dict[str, int]:
    pivot = from_iso or ""
    row = conn.execute(
        "SELECT "
        "SUM(CASE WHEN event_type='CALL' THEN 1 ELSE 0 END) AS calls_total, "
        "SUM(CASE WHEN event_type='CALL' AND active=1 THEN 1 ELSE 0 END) AS calls_active, "
        "SUM(CASE WHEN event_type='CALL' AND active=1 AND start_at>=? THEN 1 ELSE 0 END) AS calls_upcoming, "
        "SUM(CASE WHEN event_type='CALL' AND COALESCE(call_kind,'')='student' THEN 1 ELSE 0 END) AS student_calls_total, "
        "SUM(CASE WHEN event_type='CALL' AND COALESCE(call_kind,'')='diagnostic' THEN 1 ELSE 0 END) AS diagnostic_calls_total, "
        "SUM(CASE WHEN event_type='CALL' AND COALESCE(call_kind,'')='diagnostic' AND active=1 AND start_at>=? THEN 1 ELSE 0 END) AS diagnostic_calls_upcoming "
        "FROM events",
        (pivot, pivot),
    ).fetchone()
    users = conn.execute(
        "SELECT COUNT(DISTINCT owner_tg_id) AS c "
        "FROM events WHERE event_type='CALL' AND COALESCE(call_kind,'')='diagnostic' AND owner_tg_id IS NOT NULL"
    ).fetchone()
    return {
        "calls_total": int((row["calls_total"] if row else 0) or 0),
        "calls_active": int((row["calls_active"] if row else 0) or 0),
        "calls_upcoming": int((row["calls_upcoming"] if row else 0) or 0),
        "student_calls_total": int((row["student_calls_total"] if row else 0) or 0),
        "diagnostic_calls_total": int((row["diagnostic_calls_total"] if row else 0) or 0),
        "diagnostic_calls_upcoming": int((row["diagnostic_calls_upcoming"] if row else 0) or 0),
        "diagnostic_unique_users": int((users["c"] if users else 0) or 0),
    }

def mark_alerted(conn: sqlite3.Connection, event_id: int, tz: str) -> None:
    update(conn, event_id, tz, alerted=1)


def delete(conn: sqlite3.Connection, event_id: int) -> None:
    conn.execute("DELETE FROM events WHERE id=?", (event_id,))
    conn.commit()
