from __future__ import annotations

import json
import sqlite3
from typing import Any

from app.services.timeutils import iso, now


STATUS_CREATED = "created"
STATUS_RUNNING = "running"
STATUS_DONE = "done"
STATUS_FAILED = "failed"


def create(
    conn: sqlite3.Connection,
    tz: str,
    owner_tg_id: int,
    owner_chat_id: int,
    direction: str,
    script_version: str,
    ai_enabled: bool,
    search_text: str | None,
    search_link: str | None,
    parse_limit: int,
    send_limit: int,
    message_text: str | None,
) -> int:
    ts = iso(now(tz))
    cur = conn.execute(
        "INSERT INTO owner_hh_jobs("
        "owner_tg_id, owner_chat_id, direction, script_version, ai_enabled, "
        "search_text, search_link, parse_limit, send_limit, message_text, "
        "status, stage, created_at, updated_at"
        ") VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (
            int(owner_tg_id),
            int(owner_chat_id),
            str(direction or "").strip().lower() or "python",
            str(script_version or "").strip() or "script4",
            1 if bool(ai_enabled) else 0,
            (search_text or "").strip() or None,
            (search_link or "").strip() or None,
            max(int(parse_limit or 0), 1),
            max(int(send_limit or 0), 0),
            (message_text or "").strip() or None,
            STATUS_CREATED,
            "queued",
            ts,
            ts,
        ),
    )
    conn.commit()
    return int(cur.lastrowid)


def set_running(conn: sqlite3.Connection, tz: str, job_id: int, stage: str) -> None:
    ts = iso(now(tz))
    conn.execute(
        "UPDATE owner_hh_jobs SET status=?, stage=?, started_at=COALESCE(started_at, ?), updated_at=? WHERE id=?",
        (STATUS_RUNNING, (stage or "").strip() or "running", ts, ts, int(job_id)),
    )
    conn.commit()


def update_parse_result(
    conn: sqlite3.Connection,
    tz: str,
    job_id: int,
    parsed_total: int,
    tg_found_total: int,
    output_file: str,
    contacts_file: str,
    parser_payload: dict[str, Any] | None = None,
) -> None:
    ts = iso(now(tz))
    conn.execute(
        "UPDATE owner_hh_jobs SET "
        "stage='parsed', "
        "parsed_total=?, tg_found_total=?, output_file=?, contacts_file=?, parser_payload_json=?, updated_at=? "
        "WHERE id=?",
        (
            max(int(parsed_total or 0), 0),
            max(int(tg_found_total or 0), 0),
            (output_file or "").strip() or None,
            (contacts_file or "").strip() or None,
            json.dumps(parser_payload or {}, ensure_ascii=False),
            ts,
            int(job_id),
        ),
    )
    conn.commit()


def update_send_result(
    conn: sqlite3.Connection,
    tz: str,
    job_id: int,
    send_success: int,
    send_failed: int,
    report_file: str,
    sender_payload: dict[str, Any] | None = None,
) -> None:
    ts = iso(now(tz))
    conn.execute(
        "UPDATE owner_hh_jobs SET "
        "stage='sent', "
        "send_success=?, send_failed=?, report_file=?, sender_payload_json=?, updated_at=? "
        "WHERE id=?",
        (
            max(int(send_success or 0), 0),
            max(int(send_failed or 0), 0),
            (report_file or "").strip() or None,
            json.dumps(sender_payload or {}, ensure_ascii=False),
            ts,
            int(job_id),
        ),
    )
    conn.commit()


def mark_done(conn: sqlite3.Connection, tz: str, job_id: int) -> None:
    ts = iso(now(tz))
    conn.execute(
        "UPDATE owner_hh_jobs SET status=?, stage='done', finished_at=?, updated_at=? WHERE id=?",
        (STATUS_DONE, ts, ts, int(job_id)),
    )
    conn.commit()


def mark_failed(conn: sqlite3.Connection, tz: str, job_id: int, error_text: str) -> None:
    ts = iso(now(tz))
    conn.execute(
        "UPDATE owner_hh_jobs SET status=?, stage='failed', error_text=?, finished_at=?, updated_at=? WHERE id=?",
        (
            STATUS_FAILED,
            (error_text or "").strip()[:2000] or "unknown error",
            ts,
            ts,
            int(job_id),
        ),
    )
    conn.commit()


def get(conn: sqlite3.Connection, job_id: int) -> sqlite3.Row | None:
    return conn.execute("SELECT * FROM owner_hh_jobs WHERE id=? LIMIT 1", (int(job_id),)).fetchone()


def last_by_owner(conn: sqlite3.Connection, owner_tg_id: int) -> sqlite3.Row | None:
    return conn.execute(
        "SELECT * FROM owner_hh_jobs WHERE owner_tg_id=? ORDER BY id DESC LIMIT 1",
        (int(owner_tg_id),),
    ).fetchone()


def active_by_owner(conn: sqlite3.Connection, owner_tg_id: int) -> sqlite3.Row | None:
    return conn.execute(
        "SELECT * FROM owner_hh_jobs "
        "WHERE owner_tg_id=? AND status IN (?, ?) "
        "ORDER BY id DESC LIMIT 1",
        (int(owner_tg_id), STATUS_CREATED, STATUS_RUNNING),
    ).fetchone()
