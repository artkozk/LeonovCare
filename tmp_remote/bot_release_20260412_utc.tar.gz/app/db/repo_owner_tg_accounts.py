from __future__ import annotations

import sqlite3

from app.services.timeutils import iso, now

ACCOUNT_STANDARD = "standard"
ACCOUNT_POLYGON = "polygon"


def _norm_account_type(raw: str | None) -> str:
    t = str(raw or "").strip().lower()
    return t if t in {ACCOUNT_STANDARD, ACCOUNT_POLYGON} else ACCOUNT_STANDARD


def list_all(conn: sqlite3.Connection, owner_tg_id: int) -> list[sqlite3.Row]:
    return conn.execute(
        "SELECT * FROM owner_tg_accounts WHERE owner_tg_id=? ORDER BY is_active DESC, id ASC",
        (int(owner_tg_id),),
    ).fetchall()


def get(conn: sqlite3.Connection, account_id: int) -> sqlite3.Row | None:
    return conn.execute("SELECT * FROM owner_tg_accounts WHERE id=? LIMIT 1", (int(account_id),)).fetchone()


def active(conn: sqlite3.Connection, owner_tg_id: int) -> sqlite3.Row | None:
    return conn.execute(
        "SELECT * FROM owner_tg_accounts WHERE owner_tg_id=? AND is_active=1 ORDER BY id DESC LIMIT 1",
        (int(owner_tg_id),),
    ).fetchone()


def create(
    conn: sqlite3.Connection,
    tz: str,
    owner_tg_id: int,
    title: str,
    account_type: str,
    api_id: int,
    api_hash: str,
    session_file: str,
    is_active: bool = False,
) -> int:
    ts = iso(now(tz))
    if is_active:
        conn.execute(
            "UPDATE owner_tg_accounts SET is_active=0, updated_at=? WHERE owner_tg_id=?",
            (ts, int(owner_tg_id)),
        )
    cur = conn.execute(
        "INSERT INTO owner_tg_accounts("
        "owner_tg_id, title, account_type, api_id, api_hash, session_file, is_active, created_at, updated_at"
        ") VALUES(?,?,?,?,?,?,?,?,?)",
        (
            int(owner_tg_id),
            str(title or "").strip() or f"account-{int(owner_tg_id)}",
            _norm_account_type(account_type),
            max(int(api_id or 0), 0),
            str(api_hash or "").strip(),
            str(session_file or "").strip(),
            1 if is_active else 0,
            ts,
            ts,
        ),
    )
    conn.commit()
    return int(cur.lastrowid)


def set_active(conn: sqlite3.Connection, tz: str, owner_tg_id: int, account_id: int) -> bool:
    row = get(conn, account_id)
    if not row or int(row["owner_tg_id"] or 0) != int(owner_tg_id):
        return False
    ts = iso(now(tz))
    conn.execute(
        "UPDATE owner_tg_accounts SET is_active=0, updated_at=? WHERE owner_tg_id=?",
        (ts, int(owner_tg_id)),
    )
    conn.execute(
        "UPDATE owner_tg_accounts SET is_active=1, updated_at=? WHERE id=?",
        (ts, int(account_id)),
    )
    conn.commit()
    return True


def update_title(conn: sqlite3.Connection, tz: str, account_id: int, title: str) -> bool:
    ts = iso(now(tz))
    cur = conn.execute(
        "UPDATE owner_tg_accounts SET title=?, updated_at=? WHERE id=?",
        (str(title or "").strip(), ts, int(account_id)),
    )
    conn.commit()
    return int(cur.rowcount or 0) > 0


def deactivate(conn: sqlite3.Connection, tz: str, account_id: int) -> bool:
    ts = iso(now(tz))
    cur = conn.execute(
        "UPDATE owner_tg_accounts SET is_active=0, updated_at=? WHERE id=?",
        (ts, int(account_id)),
    )
    conn.commit()
    return int(cur.rowcount or 0) > 0


def delete(conn: sqlite3.Connection, owner_tg_id: int, account_id: int) -> bool:
    cur = conn.execute(
        "DELETE FROM owner_tg_accounts WHERE id=? AND owner_tg_id=?",
        (int(account_id), int(owner_tg_id)),
    )
    conn.commit()
    return int(cur.rowcount or 0) > 0


def set_type(conn: sqlite3.Connection, tz: str, owner_tg_id: int, account_id: int, account_type: str) -> bool:
    row = get(conn, account_id)
    if not row or int(row["owner_tg_id"] or 0) != int(owner_tg_id):
        return False
    ts = iso(now(tz))
    cur = conn.execute(
        "UPDATE owner_tg_accounts SET account_type=?, updated_at=? WHERE id=?",
        (_norm_account_type(account_type), ts, int(account_id)),
    )
    conn.commit()
    return int(cur.rowcount or 0) > 0


def by_type(conn: sqlite3.Connection, owner_tg_id: int, account_type: str) -> list[sqlite3.Row]:
    t = _norm_account_type(account_type)
    return conn.execute(
        "SELECT * FROM owner_tg_accounts WHERE owner_tg_id=? AND lower(account_type)=? ORDER BY is_active DESC, id ASC",
        (int(owner_tg_id), t),
    ).fetchall()
