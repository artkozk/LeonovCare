from __future__ import annotations

import json
import sqlite3
from typing import Any

from app.services.timeutils import iso, now


def _ts(tz: str) -> str:
    return iso(now(tz))


def create(
    conn: sqlite3.Connection,
    tz: str,
    owner_tg_id: int,
    owner_chat_id: int | None,
    owner_username: str | None,
    checkout_payment_id: int | None,
    external_license_id: int | None,
    license_key: str,
    plan: str,
    enabled: bool = True,
    expires_at: str | None = None,
    note: str | None = None,
    payload: dict[str, Any] | None = None,
) -> int:
    ts = _ts(tz)
    cur = conn.execute(
        "INSERT INTO interview_helper_licenses("
        "owner_tg_id, owner_chat_id, owner_username, checkout_payment_id, external_license_id, "
        "license_key, plan, enabled, expires_at, note, payload_json, created_at, updated_at"
        ") VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (
            int(owner_tg_id),
            int(owner_chat_id) if owner_chat_id is not None else None,
            (owner_username or "").strip().lstrip("@") or None,
            int(checkout_payment_id) if checkout_payment_id is not None else None,
            int(external_license_id) if external_license_id is not None else None,
            (license_key or "").strip(),
            (plan or "").strip() or "PRO",
            1 if enabled else 0,
            (expires_at or "").strip() or None,
            (note or "").strip() or None,
            json.dumps(payload or {}, ensure_ascii=False),
            ts,
            ts,
        ),
    )
    conn.commit()
    return int(cur.lastrowid)


def get_by_payment(conn: sqlite3.Connection, checkout_payment_id: int) -> sqlite3.Row | None:
    return conn.execute(
        "SELECT * FROM interview_helper_licenses WHERE checkout_payment_id=? LIMIT 1",
        (int(checkout_payment_id),),
    ).fetchone()


def latest_for_user(conn: sqlite3.Connection, owner_tg_id: int) -> sqlite3.Row | None:
    return conn.execute(
        "SELECT * FROM interview_helper_licenses WHERE owner_tg_id=? ORDER BY id DESC LIMIT 1",
        (int(owner_tg_id),),
    ).fetchone()


def payload(row: sqlite3.Row | None) -> dict[str, Any]:
    if not row:
        return {}
    raw = row["payload_json"] if "payload_json" in row.keys() else None
    if not raw:
        return {}
    try:
        data = json.loads(raw)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def active_count(conn: sqlite3.Connection) -> int:
    row = conn.execute(
        "SELECT COUNT(1) AS c FROM interview_helper_licenses WHERE enabled=1"
    ).fetchone()
    return int(row["c"] or 0) if row else 0


def deactivate_all(conn: sqlite3.Connection, tz: str, reason: str | None = None) -> int:
    ts = _ts(tz)
    suffix = (reason or "").strip()
    if suffix:
        note_expr = "CASE WHEN coalesce(note,'')='' THEN ? ELSE note || '; ' || ? END"
        params: tuple[Any, ...] = (ts, suffix, suffix, ts)
    else:
        note_expr = "coalesce(note, '')"
        params = (ts, ts)
    sql = (
        "UPDATE interview_helper_licenses "
        "SET enabled=0, "
        "expires_at=CASE WHEN coalesce(expires_at,'')='' THEN ? ELSE expires_at END, "
        f"note={note_expr}, "
        "updated_at=? "
        "WHERE enabled=1"
    )
    cur = conn.execute(sql, params)
    conn.commit()
    return int(cur.rowcount or 0)
