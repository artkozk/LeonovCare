from __future__ import annotations

import json
import sqlite3
from typing import Any

from app.services.timeutils import iso, now


def add(
    conn: sqlite3.Connection,
    tz: str,
    owner_tg_id: int,
    account_id: int | None,
    channel: str,
    message_id: int,
    reaction: str,
    status: str,
    error_text: str | None = None,
    payload: dict[str, Any] | None = None,
) -> int:
    ts = iso(now(tz))
    cur = conn.execute(
        "INSERT INTO owner_channel_reactions("
        "owner_tg_id, account_id, channel, message_id, reaction, status, error_text, payload_json, created_at"
        ") VALUES(?,?,?,?,?,?,?,?,?)",
        (
            int(owner_tg_id),
            int(account_id) if account_id is not None else None,
            str(channel or "").strip(),
            int(message_id),
            str(reaction or "").strip(),
            str(status or "").strip() or "ok",
            (error_text or "").strip() or None,
            json.dumps(payload or {}, ensure_ascii=False),
            ts,
        ),
    )
    conn.commit()
    return int(cur.lastrowid)


def summary(conn: sqlite3.Connection, owner_tg_id: int) -> dict[str, int]:
    rows = conn.execute(
        "SELECT status, COUNT(1) AS c FROM owner_channel_reactions WHERE owner_tg_id=? GROUP BY status",
        (int(owner_tg_id),),
    ).fetchall()
    out: dict[str, int] = {"ok": 0, "failed": 0}
    for r in rows:
        st = str(r["status"] or "").strip().lower() or "ok"
        out[st] = int(r["c"] or 0)
    return out


def already_reacted_ok(
    conn: sqlite3.Connection,
    owner_tg_id: int,
    channel: str,
    message_id: int,
    account_id: int | None = None,
) -> bool:
    if account_id is None:
        row = conn.execute(
            "SELECT 1 AS x FROM owner_channel_reactions "
            "WHERE owner_tg_id=? AND channel=? AND message_id=? AND lower(status)='ok' LIMIT 1",
            (int(owner_tg_id), str(channel or "").strip(), int(message_id)),
        ).fetchone()
    else:
        row = conn.execute(
            "SELECT 1 AS x FROM owner_channel_reactions "
            "WHERE owner_tg_id=? AND account_id=? AND channel=? AND message_id=? AND lower(status)='ok' LIMIT 1",
            (int(owner_tg_id), int(account_id), str(channel or "").strip(), int(message_id)),
        ).fetchone()
    return row is not None


def list_recent(conn: sqlite3.Connection, owner_tg_id: int, limit: int = 300) -> list[sqlite3.Row]:
    cap = max(1, min(int(limit or 0), 5000))
    return conn.execute(
        "SELECT * FROM owner_channel_reactions WHERE owner_tg_id=? ORDER BY id DESC LIMIT ?",
        (int(owner_tg_id), cap),
    ).fetchall()
